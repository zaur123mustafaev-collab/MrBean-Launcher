package com.mrbean.visuals.core;

import java.util.HashMap;
import java.util.Map;

public final class Lang {
   public static boolean english = false;
   private static final Map<String, String[]> UI = new HashMap<>();

   private Lang() {
   }

   public static String t(String ru, String en) {
      return english && en != null ? en : ru;
   }

   private static void put(String key, String ru, String en) {
      UI.put(key, new String[]{ru, en});
   }

   public static String ui(String key) {
      String[] v = UI.get(key);
      if (v == null) {
         return key;
      } else {
         return english ? v[1] : v[0];
      }
   }

   static {
      put("cat.dashboard", "Главная", "Dashboard");
      put("cat.visuals", "Визуалы", "Visuals");
      put("cat.cosmetics", "Косметика", "Cosmetics");
      put("cat.hud", "HUD", "HUD");
      put("cat.world", "Мир", "World");
      put("cat.particles", "Частицы", "Particles");
      put("cat.animations", "Анимации", "Animations");
      put("cat.performance", "Оптимизация", "Performance");
      put("cat.themes", "Темы", "Themes");
      put("cat.utilities", "Утилиты", "Utilities");
      put("cat.crystal", "Crystal PvP", "Crystal PvP");
      put("cat.settings", "Настройки", "Settings");
      put("ui.search", "Поиск модулей...", "Search modules...");
      put("ui.hud_editor", "Редактор HUD", "HUD Editor");
      put("ui.enabled", "Включено", "Enabled");
      put("ui.disabled", "Выключено", "Disabled");
      put("ui.on", "вкл", "on");
      put("ui.off", "выкл", "off");
      put("ui.settings", "Настройки", "Settings");
      put("ui.reset", "Сбросить", "Reset");
      put("ui.back", "Назад", "Back");
      put("ui.save", "Сохранить", "Save");
      put("ui.close", "Закрыть", "Close");
      put("ui.nothing_found", "Ничего не найдено", "Nothing found");
      put("ui.modules_active", "активных модулей", "active modules");
      put("ui.preview", "Превью", "Preview");
      put("ui.account", "Аккаунт", "Account");
      put("ui.welcome", "Добро пожаловать в MrBean Visuals!", "Welcome to MrBean Visuals!");
      put("ui.next", "Далее", "Next");
      put("ui.skip", "Пропустить", "Skip");
      put("ui.finish", "Готово", "Finish");
      put("ui.install", "Установить", "Install");
      put("ui.restart_needed", "Перезапусти игру, чтобы моды заработали", "Restart the game to load the new mods");
   }
}
