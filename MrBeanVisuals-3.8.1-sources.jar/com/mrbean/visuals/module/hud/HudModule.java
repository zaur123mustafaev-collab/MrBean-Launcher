package com.mrbean.visuals.module.hud;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Mobile;
import net.minecraft.class_332;

public abstract class HudModule extends Module {
   public double fx;
   public double fy;
   private final double defFx;
   private final double defFy;
   protected int w = 40;
   protected int h = 10;
   public int sx;
   public int sy;
   public int sw;
   public int sh;
   public static boolean editing;
   private float appear;
   public final Setting.Num scale = this.add(new Setting.Num("hud_scale", "Размер", "Size", 1.0, 0.5, 2.5, 0.05).suffix("x"));
   public final Setting.Num opacity = this.add(new Setting.Num("hud_opacity", "Непрозрачность", "Opacity", 100.0, 10.0, 100.0, 1.0).suffix("%"));
   public final Setting.Bool background = this.add(new Setting.Bool("hud_bg", "Фон", "Background", true));
   public final Setting.Bool customBg = (Setting.Bool)this.add(new Setting.Bool("hud_custom_bg", "Свой цвет фона", "Custom background color", false))
      .showIf(() -> this.background.value);
   public final Setting.Color bgColor = (Setting.Color)this.add(new Setting.Color("hud_bg_color", "Цвет фона", "Background color", -1341124072).withAlpha())
      .showIf(() -> this.background.value && this.customBg.value);
   public final Setting.Num radius = (Setting.Num)this.add(new Setting.Num("hud_radius", "Скругление", "Corner radius", 4.0, 0.0, 10.0, 1.0))
      .showIf(() -> this.background.value);
   public final Setting.Bool border = this.add(new Setting.Bool("hud_border", "Рамка", "Border", false));
   public final Setting.Bool shadow = this.add(new Setting.Bool("hud_shadow", "Тень", "Shadow", true));
   public final Setting.Bool customAccent = this.add(new Setting.Bool("hud_custom_accent", "Свой цвет акцента", "Custom accent color", false));
   public final Setting.Color accentColor = (Setting.Color)this.add(new Setting.Color("hud_accent", "Цвет акцента", "Accent color", -13703779))
      .showIf(() -> this.customAccent.value);
   public final Setting.Mode font = this.add(
      new Setting.Mode("hud_font", "Шрифт", "Font", 0, "default", "Minecraft", "Minecraft", "uniform", "Юникод (тонкий)", "Unicode (thin)")
   );
   public final Setting.Bool textShadow = this.add(new Setting.Bool("hud_text_shadow", "Тень текста", "Text shadow", true));

   protected HudModule(String id, boolean defEnabled, double fx, double fy, String ru, String en, String dRu, String dEn) {
      super(id, Category.HUD, defEnabled, ru, en, dRu, dEn);
      this.fx = this.defFx = fx;
      this.fy = this.defFy = fy;
   }

   public void resetPosition() {
      this.fx = this.defFx;
      this.fy = this.defFy;
   }

   protected abstract void layout();

   protected abstract void draw(class_332 var1, float var2);

   protected boolean hasContent() {
      return true;
   }

   protected int pad() {
      return this.background.value ? 4 : 0;
   }

   public int accent(float off) {
      return this.customAccent.value ? this.accentColor.argb | 0xFF000000 : Modules.theme().accent(off);
   }

   protected boolean ts() {
      return this.textShadow.value;
   }

   public final void renderHud(class_332 ctx, float delta, int screenW, int screenH) {
      boolean show = editing || this.hasContent();
      this.appear = R2D.approach(this.appear, show ? 1.0F : 0.0F, 0.3F);
      if (this.appear < 0.02F) {
         this.sw = 0;
         this.sh = 0;
      } else {
         this.layout();
         int p = this.pad();
         float s = this.scale.f() * Mobile.hud();
         int fullW = this.w + p * 2;
         int fullH = this.h + p * 2;
         int pw = Math.round(fullW * s);
         int ph = Math.round(fullH * s);
         int x = (int)Math.round(this.fx * Math.max(0, screenW - pw));
         int y = (int)Math.round(this.fy * Math.max(0, screenH - ph));
         this.sx = x;
         this.sy = y;
         this.sw = pw;
         this.sh = ph;
         float oldAlpha = R2D.alpha;
         R2D.alpha = this.opacity.f() / 100.0F * this.appear;
         R2D.font = this.font.is("uniform") ? R2D.FONT_UNIFORM : null;
         ctx.method_51448().pushMatrix();
         ctx.method_51448().translate(x, y);
         ctx.method_51448().scale(s, s);

         try {
            int r = this.radius.i();
            if (this.background.value) {
               if (this.shadow.value && Modules.theme().shadows.value) {
                  R2D.shadow(ctx, 0, 1, fullW, fullH, 6, 1073741824);
               }

               R2D.round(ctx, 0, 0, fullW, fullH, r, this.customBg.value ? this.bgColor.argb : Modules.theme().background());
            }

            if (this.border.value) {
               R2D.outline(ctx, 0, 0, fullW, fullH, this.background.value ? r : 0, this.accent(0.0F));
            }

            ctx.method_51448().translate(p, p);
            this.draw(ctx, delta);
         } finally {
            ctx.method_51448().popMatrix();
            R2D.alpha = oldAlpha;
            R2D.font = null;
         }
      }
   }

   protected void text(class_332 ctx, String s, int x, int y, int color) {
      R2D.text(ctx, s, x, y, color, this.ts());
   }

   protected int tw(String s) {
      return R2D.width(s);
   }
}
