package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.EmoteWheelScreen;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.net.EmoteNetwork;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1102;
import net.minecraft.class_1113;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5819;

/**
 * Эмоции персонажа. Позы считаются процедурно по t (0..1), mixin добавляет их к ванильным углам модели.
 * Своя поза ставится сразу локально, а на сервер уходит EmoteProtocol.Play — сервер показывает её
 * остальным, если стоит MrBeanServerBridge или MrBeanBadgePlugin. Без моста эмоция видна только себе.
 * Зацикленная эмоция крутится бесконечно, пока её не выключат повторным кликом.
 */
public final class Emotes {
   private static final float R = (float)Math.PI / 180.0F;
   private static final Map<String, Def> DEFS = new LinkedHashMap<>();
   private static final Map<Integer, Run> RUNS = new ConcurrentHashMap<>();
   private static final Pose SHARED = new Pose();
   private static class_1113 loopSound;

   private Emotes() {
   }

   public static final class Pose {
      public float headPitch;
      public float headYaw;
      public float headRoll;
      public float bodyPitch;
      public float bodyYaw;
      public float rArmPitch;
      public float rArmYaw;
      public float rArmRoll;
      public float lArmPitch;
      public float lArmYaw;
      public float lArmRoll;
      public float rLegPitch;
      public float lLegPitch;
      public boolean legs;
      public float strength;

      public void clear() {
         this.headPitch = 0.0F;
         this.headYaw = 0.0F;
         this.headRoll = 0.0F;
         this.bodyPitch = 0.0F;
         this.bodyYaw = 0.0F;
         this.rArmPitch = 0.0F;
         this.rArmYaw = 0.0F;
         this.rArmRoll = 0.0F;
         this.lArmPitch = 0.0F;
         this.lArmYaw = 0.0F;
         this.lArmRoll = 0.0F;
         this.rLegPitch = 0.0F;
         this.lLegPitch = 0.0F;
         this.legs = false;
      }

      public void leg(float right, float left) {
         this.rLegPitch = right;
         this.lLegPitch = left;
         this.legs = true;
      }
   }

   public interface Clip {
      void apply(Pose var1, float var2);
   }

   /** sound — идентификатор SoundEvent или null; music — цикл крутится по длине трека. */
   public record Def(String id, String ru, String en, float seconds, Clip clip, String sound, boolean music) {
   }

   private static final class Run {
      final Def def;
      final long start;
      final float seconds;
      final boolean loop;
      long stopAt;

      Run(Def def, long start, float seconds, boolean loop) {
         this.def = def;
         this.start = start;
         this.seconds = seconds;
         this.loop = loop;
      }
   }

   private static void reg(String id, String ru, String en, float seconds, Clip clip) {
      reg(id, ru, en, seconds, clip, null, false);
   }

   private static void reg(String id, String ru, String en, float seconds, Clip clip, String sound) {
      reg(id, ru, en, seconds, clip, sound, false);
   }

   private static void reg(String id, String ru, String en, float seconds, Clip clip, String sound, boolean music) {
      DEFS.put(id, new Def(id, ru, en, seconds, clip, sound, music));
   }

   public static Def def(String id) {
      return id == null ? null : DEFS.get(id.toLowerCase());
   }

   public static List<Def> all() {
      return new ArrayList<>(DEFS.values());
   }

   public static String ids() {
      return String.join(", ", DEFS.keySet());
   }

   public static boolean play(int entityId, String id, float speed) {
      return play(entityId, id, speed, false);
   }

   public static boolean play(int entityId, String id, float speed, boolean loop) {
      return play(entityId, id, speed, loop, false);
   }

   /** force=true заменяет текущую эмоцию (нужно для предпросмотра в колесе). */
   public static boolean play(int entityId, String id, float speed, boolean loop, boolean force) {
      Def d = def(id);
      if (d == null) {
         return false;
      } else if (!force && busy(entityId)) {
         return false;
      } else {
         RUNS.put(entityId, new Run(d, System.currentTimeMillis(), Math.max(0.2F, d.seconds() / Math.max(0.2F, speed)), loop));
         if (isSelf(entityId)) {
            startSound(d);
         }

         return true;
      }
   }

   /** Мягкая остановка: позa гаснет за треть секунды, звук обрывается сразу. */
   public static void stop(int entityId) {
      Run r = RUNS.get(entityId);
      if (r != null) {
         if (r.loop && r.stopAt == 0L) {
            r.stopAt = System.currentTimeMillis() + 320L;
         } else {
            RUNS.remove(entityId);
         }

         if (isSelf(entityId)) {
            stopSound();
         }
      }
   }

   public static void stopNow(int entityId) {
      RUNS.remove(entityId);
      if (isSelf(entityId)) {
         stopSound();
      }
   }

   public static String current(int entityId) {
      Run r = RUNS.get(entityId);
      return r == null ? null : r.def.id();
   }

   public static boolean isLooping(int entityId) {
      Run r = RUNS.get(entityId);
      return r != null && r.loop && r.stopAt == 0L;
   }

   public static boolean busy(int entityId) {
      Run r = RUNS.get(entityId);
      if (r == null) {
         return false;
      } else if (r.loop) {
         return alive(r, System.currentTimeMillis());
      } else if (progress(r) >= 1.0F) {
         RUNS.remove(entityId);
         return false;
      } else {
         return true;
      }
   }

   private static float progress(Run r) {
      return (float)(System.currentTimeMillis() - r.start) / 1000.0F / r.seconds;
   }

   private static boolean alive(Run r, long now) {
      if (r.stopAt != 0L) {
         return now < r.stopAt;
      } else {
         return now - r.start < 600000L;
      }
   }

   /** Заполняет общую позу и возвращает силу подмешивания в Pose.strength; null, если эмоции нет. */
   public static Pose pose(int entityId) {
      Run r = RUNS.get(entityId);
      if (r == null) {
         return null;
      } else {
         long now = System.currentTimeMillis();
         float raw = progress(r);
         float b;
         float t;
         if (r.loop) {
            if (!alive(r, now)) {
               RUNS.remove(entityId);
               return null;
            }

            t = raw - (float)Math.floor(raw);
            b = Math.min(1.0F, (float)(now - r.start) / 350.0F);
            if (r.stopAt != 0L) {
               b = Math.min(b, Math.max(0.0F, (float)(r.stopAt - now) / 320.0F));
            }
         } else {
            if (raw >= 1.0F) {
               RUNS.remove(entityId);
               return null;
            }

            t = raw;
            b = t < 0.12F ? t / 0.12F : (t > 0.78F ? (1.0F - t) / 0.22F : 1.0F);
         }

         SHARED.clear();
         r.def.clip().apply(SHARED, Math.max(0.0F, t));
         SHARED.strength = Math.max(0.0F, Math.min(1.0F, b));
         return SHARED;
      }
   }

   /** Убирает эмоции игроков, которых уже нет в мире, и всё при выходе из мира. */
   public static void tickCleanup() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1687 == null || mc.field_1724 == null) {
         RUNS.clear();
         stopSound();
      } else {
         for (Integer id : RUNS.keySet()) {
            if (id != mc.field_1724.method_5628() && mc.field_1687.method_8469(id) == null) {
               RUNS.remove(id);
            }
         }

         if (loopSound != null && !RUNS.containsKey(mc.field_1724.method_5628())) {
            // поза доиграла или упёрлась в лимит — трек без неё не живёт
            stopSound();
         }
      }
   }

   private static boolean isSelf(int entityId) {
      class_310 mc = class_310.method_1551();
      return mc.field_1724 != null && mc.field_1724.method_5628() == entityId;
   }

   private static void startSound(Def d) {
      stopSound();
      if (d.sound() == null) {
         return;
      } else {
         EmoteModule em = module();
         if (em != null && !em.sounds.get()) {
            return;
         } else {
            class_2960 id = class_2960.method_12829(d.sound());
            if (id == null) {
               return;
            } else {
               float vol = em == null ? 0.8F : (float)(em.soundVolume.value / 100.0);
               if (vol <= 0.001F) {
                  return;
               } else {
                  loopSound = new EmoteSound(class_3414.method_47908(id), vol, d.music());

                  try {
                     class_310.method_1551().method_1483().method_4873(loopSound);
                  } catch (Exception var4) {
                     loopSound = null;
                  }
               }
            }
         }
      }
   }

   public static void stopSound() {
      if (loopSound != null) {
         class_1113 inst = loopSound;
         loopSound = null;

         try {
            class_310.method_1551().method_1483().method_4870(inst);
         } catch (Exception var2) {
         }
      }
   }

   private static final class EmoteSound extends class_1102 {
      EmoteSound(class_3414 e, float vol, boolean loop) {
         super(e, class_3419.field_15247, class_5819.method_43047());
         this.field_5442 = vol;
         this.field_5441 = 1.0F;
         this.field_5446 = loop;
         this.field_5440 = class_1114.field_5478;
      }

      public boolean method_26273() {
         return true;
      }

      public boolean method_4785() {
         return true;
      }
   }

   private static float sin(float cycles, float t) {
      return (float)Math.sin(t * cycles * Math.PI * 2.0);
   }

   private static float hold(float t, float from, float to) {
      float in = Math.min(1.0F, t / from);
      float out2 = Math.min(1.0F, Math.max(0.0F, (1.0F - t) / to));
      return Math.min(in, out2);
   }

   static {
      reg(
         "wave", "Пока", "Wave", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.25F);
            p.rArmPitch = -150.0F * R * k;
            p.rArmRoll = -22.0F * R * k;
            p.rArmYaw = sin(6.0F, t) * 26.0F * R * k;
            p.headYaw = sin(6.0F, t) * 7.0F * R * k;
            p.bodyYaw = 6.0F * R * k;
         },
         "minecraft:entity.experience_orb.pickup"
      );
      reg(
         "clap", "Хлопки", "Clap", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.2F);
            float s = sin(7.0F, t);
            p.rArmPitch = (-75.0F + s * 8.0F) * R * k;
            p.lArmPitch = (-75.0F + s * 8.0F) * R * k;
            p.rArmYaw = (-42.0F - s * 22.0F) * R * k;
            p.lArmYaw = (42.0F + s * 22.0F) * R * k;
            p.headPitch = 12.0F * R * k;
         },
         "minecraft:block.note_block.hat"
      );
      reg(
         "cheer", "Ура", "Cheer", 3.0F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.22F);
            float s = sin(4.0F, t);
            p.rArmPitch = (-165.0F + s * 12.0F) * R * k;
            p.lArmPitch = (-165.0F - s * 12.0F) * R * k;
            p.rArmRoll = -28.0F * R * k;
            p.lArmRoll = 28.0F * R * k;
            p.bodyPitch = s * 5.0F * R * k;
            p.headPitch = (-10.0F + s * 6.0F) * R * k;
            p.leg(s * 12.0F * R * k, -s * 12.0F * R * k);
         },
         "minecraft:entity.firework_rocket.blast"
      );
      reg(
         "point", "Указать", "Point", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.12F, 0.25F);
            p.rArmPitch = (-96.0F + sin(2.0F, t) * 4.0F) * R * k;
            p.rArmYaw = -12.0F * R * k;
            p.bodyYaw = -18.0F * R * k;
            p.headYaw = -10.0F * R * k;
            p.lArmPitch = 8.0F * R * k;
         },
         "minecraft:entity.splash_potion.throw"
      );
      reg(
         "facepalm", "Рука к лицу", "Facepalm", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.3F);
            p.rArmPitch = -152.0F * R * k;
            p.rArmYaw = -28.0F * R * k;
            p.rArmRoll = 10.0F * R * k;
            p.headPitch = 26.0F * R * k;
            p.bodyPitch = 6.0F * R * k;
         },
         "minecraft:block.wool.place"
      );
      reg(
         "shrug", "Пожатье плечами", "Shrug", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.28F);
            float s = sin(2.0F, t);
            p.rArmPitch = (-38.0F + s * 4.0F) * R * k;
            p.lArmPitch = (-38.0F - s * 4.0F) * R * k;
            p.rArmRoll = -58.0F * R * k;
            p.lArmRoll = 58.0F * R * k;
            p.headRoll = (10.0F + s * 4.0F) * R * k;
            p.bodyPitch = -4.0F * R * k;
         },
         "minecraft:block.note_block.bass"
      );
      reg(
         "dance", "Танец", "Dance", 6.0F,
         (p, t) -> {
            float s = sin(4.0F, t);
            float c = sin(4.0F, t + 0.25F);
            p.bodyYaw = s * 24.0F * R;
            p.bodyPitch = c * 6.0F * R;
            p.rArmPitch = (-135.0F + s * 45.0F) * R;
            p.lArmPitch = (-135.0F - s * 45.0F) * R;
            p.rArmRoll = (-20.0F + c * 15.0F) * R;
            p.lArmRoll = (20.0F - c * 15.0F) * R;
            p.headYaw = c * 12.0F * R;
            p.leg((18.0F + c * 22.0F) * R, (18.0F - c * 22.0F) * R);
         },
         "minecraft:music_disc.cat",
         true
      );
      reg(
         "yes", "Кивать", "Yes", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            p.headPitch = sin(6.0F, t) * 22.0F * R * k;
            p.bodyPitch = sin(6.0F, t) * 4.0F * R * k;
         },
         "minecraft:entity.villager.yes"
      );
      reg(
         "no", "Мотать головой", "No", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            p.headYaw = sin(5.0F, t) * 34.0F * R * k;
            p.headRoll = sin(5.0F, t) * 6.0F * R * k;
            p.bodyYaw = sin(5.0F, t) * 8.0F * R * k;
         },
         "minecraft:entity.villager.no"
      );
      reg(
         "rock", "Рок", "Rock", 3.4F,
         (p, t) -> {
            float s = sin(6.0F, t);
            p.rArmPitch = (-158.0F + s * 14.0F) * R;
            p.rArmRoll = -18.0F * R;
            p.lArmPitch = (-30.0F + s * 10.0F) * R;
            p.headPitch = (-24.0F + s * 6.0F) * R;
            p.bodyPitch = s * 9.0F * R;
         },
         "minecraft:music_disc.pigstep",
         true
      );
      reg(
         "mognu", "Я тебя могу", "Ya Tebya Mognu", 2.2F,
         (p, t) -> {
            float s = sin(2.0F, t);
            float c = sin(2.0F, t + 0.25F);
            p.bodyPitch = (-8.0F + s * 11.0F) * R;
            p.bodyYaw = c * 13.0F * R;
            p.rArmPitch = (-42.0F + s * 32.0F) * R;
            p.lArmPitch = (-42.0F - s * 32.0F) * R;
            p.rArmRoll = -34.0F * R;
            p.lArmRoll = 34.0F * R;
            p.headPitch = (-6.0F + s * 8.0F) * R;
            p.headYaw = c * 9.0F * R;
            p.leg(s * 15.0F * R, -s * 15.0F * R);
         },
         "mrbeanvisuals:emote.mognu",
         true
      );
      reg(
         "nowkie", "Новки", "Nowkie", 2.0F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.bodyPitch = (-10.0F + sin(4.0F, t) * 6.0F) * R;
            p.bodyYaw = s * 17.0F * R;
            p.rArmPitch = (-62.0F + s * 40.0F) * R;
            p.lArmPitch = (-62.0F - s * 40.0F) * R;
            p.rArmYaw = -26.0F * R;
            p.lArmYaw = 26.0F * R;
            p.headYaw = sin(2.0F, t + 0.25F) * 15.0F * R;
            p.leg(28.0F * R * Math.max(0.0F, s), 28.0F * R * Math.max(0.0F, -s));
         },
         "mrbeanvisuals:emote.nowkie",
         true
      );
      reg(
         "newdance", "Новый танец", "New Dance", 2.4F,
         (p, t) -> {
            float s = sin(2.0F, t);
            float c = sin(2.0F, t + 0.25F);
            p.bodyYaw = s * 21.0F * R;
            p.bodyPitch = c * 7.0F * R;
            p.rArmPitch = (-152.0F + c * 22.0F) * R;
            p.lArmPitch = (-152.0F - c * 22.0F) * R;
            p.rArmRoll = (-16.0F + s * 14.0F) * R;
            p.lArmRoll = (16.0F - s * 14.0F) * R;
            p.headRoll = s * 11.0F * R;
            p.leg((16.0F + c * 20.0F) * R, (16.0F - c * 20.0F) * R);
         },
         "mrbeanvisuals:emote.newdance",
         true
      );
      reg(
         "floss", "Флосс", "Floss", 1.6F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.bodyYaw = s * 30.0F * R;
            p.rArmPitch = (-22.0F - s * 42.0F) * R;
            p.lArmPitch = (-22.0F + s * 42.0F) * R;
            p.rArmRoll = -8.0F * R;
            p.lArmRoll = 8.0F * R;
            p.headYaw = -s * 14.0F * R;
            p.leg(s * 24.0F * R, -s * 24.0F * R);
         },
         "minecraft:music_disc.stal",
         true
      );
      reg(
         "shuffle", "Шффл", "Shuffle", 2.2F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.bodyYaw = s * 11.0F * R;
            p.bodyPitch = sin(4.0F, t) * 5.0F * R;
            p.rArmPitch = -168.0F * R;
            p.rArmRoll = -22.0F * R;
            p.lArmPitch = (-32.0F + s * 22.0F) * R;
            p.lArmRoll = 26.0F * R;
            p.headYaw = -s * 10.0F * R;
            p.leg((20.0F + s * 30.0F) * R, (20.0F - s * 30.0F) * R);
         },
         "minecraft:music_disc.mall",
         true
      );
      reg(
         "robot", "Робот", "Robot", 2.0F,
         (p, t) -> {
            float q = (float)Math.floor((double)(t * 4.0F % 4.0F)) / 3.0F * 2.0F - 1.0F;
            p.headYaw = q * 30.0F * R;
            p.headPitch = -6.0F * R;
            p.bodyYaw = q * 8.0F * R;
            p.rArmPitch = (-62.0F + q * 42.0F) * R;
            p.lArmPitch = (-62.0F - q * 42.0F) * R;
            p.rArmYaw = -22.0F * R;
            p.lArmYaw = 22.0F * R;
            p.rArmRoll = -14.0F * R;
            p.lArmRoll = 14.0F * R;
            p.leg(q * 8.0F * R, -q * 8.0F * R);
         },
         "minecraft:music_disc.wait",
         true
      );
      reg(
         "thumbs", "Палец вверх", "Thumbs Up", 1.8F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.22F);
            float s = sin(2.0F, t);
            p.rArmPitch = (-92.0F + s * 5.0F) * R * k;
            p.rArmRoll = 14.0F * R * k;
            p.rArmYaw = -18.0F * R * k;
            p.lArmPitch = 6.0F * R * k;
            p.headPitch = (-8.0F + s * 4.0F) * R * k;
            p.bodyPitch = s * 3.0F * R * k;
         },
         "minecraft:entity.player.levelup"
      );
      reg(
         "salute", "Салют", "Salute", 2.0F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.25F);
            p.rArmPitch = -150.0F * R * k;
            p.rArmYaw = -32.0F * R * k;
            p.rArmRoll = 26.0F * R * k;
            p.lArmPitch = 4.0F * R * k;
            p.headPitch = -10.0F * R * k;
            p.bodyPitch = 2.0F * R * k;
         },
         "minecraft:entity.firework_rocket.shoot"
      );
      reg(
         "laugh", "Смех", "Laugh", 1.6F,
         (p, t) -> {
            float s = sin(4.0F, t);
            p.headPitch = (-22.0F + s * 9.0F) * R;
            p.bodyPitch = (6.0F + s * 7.0F) * R;
            p.rArmPitch = (10.0F + s * 9.0F) * R;
            p.lArmPitch = (10.0F - s * 9.0F) * R;
            p.rArmRoll = -10.0F * R;
            p.lArmRoll = 10.0F * R;
            p.leg(s * 8.0F * R, -s * 8.0F * R);
         },
         "minecraft:block.brewing_stand.bubble"
      );
   }

   public static class EmoteModule extends Module {
      public final Setting.Mode pick = this.add(new Setting.Mode("emote", "Эмоция", "Emote", 0, modeArgs()));
      public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость", "Speed", 1.0, 0.5, 2.0, 0.05).suffix("x"));
      public final Setting.Bool calmLegs = this.add(new Setting.Bool("calm_legs", "Не махать ногами", "Calm legs", true));
      public final Setting.Bool firstPerson = this.add(new Setting.Bool("first_person", "Видеть от первого лица", "First person", false));
      public final Setting.Bool watchOthers = this.add(
         new Setting.Bool("watch_others", "Видеть эмоции других", "See others' emotes", true)
      );
      public final Setting.Bool wheel = this.add(new Setting.Bool("wheel", "Колесо эмоций по B", "Emote wheel on B", true));
      public final Setting.Bool loopSel = this.add(
         new Setting.Bool("loop", "Повторять выбранную", "Loop selected", true)
      );
      public final Setting.Bool sounds = this.add(new Setting.Bool("emote_sounds", "Звук эмоций", "Emote sounds", true));
      public final Setting.Num soundVolume = (Setting.Num)this.add(
         new Setting.Num("emote_volume", "Громкость звука", "Sound volume", 80.0, 0.0, 100.0, 5.0)
      ).suffix("%").showIf(() -> this.sounds.value);
      public final Setting.Action playBtn = this.add(new Setting.Action("play", "Сыграть", "Play", this::trigger));
      public final Setting.Action stopBtn = this.add(new Setting.Action("stop", "Стоп", "Stop", this::stopSelf));
      public final Setting.Action wheelBtn = this.add(new Setting.Action("open_wheel", "Открыть колесо", "Open wheel", this::openWheel));
      public final Map<String, Setting.Key> binds = new LinkedHashMap<>();
      public class_304 key;
      public long wheelClosedAt;
      private String activeId;
      private String previewId;

      public EmoteModule() {
         super(
            "emotes",
            Category.ANIMATIONS,
            false,
            "Эмоции",
            "Emotes",
            "Анимации персонажа: пока, хлопки, танец, указательный жест",
            "Character animations: wave, clap, dance, pointing"
         );

         for (Def d : DEFS.values()) {
            this.binds.put(
               d.id(),
               this.add(new Setting.Key("key_" + d.id(), "Бинд: " + d.ru(), "Bind: " + d.en(), -1))
            );
         }
      }

      private static String[] modeArgs() {
         List<String> l = new ArrayList<>();

         for (Map.Entry<String, Def> e : DEFS.entrySet()) {
            Def d = e.getValue();
            l.add(d.id());
            l.add(d.ru());
            l.add(d.en());
         }

         return l.toArray(new String[0]);
      }

      @Override
      public void onTick() {
         Emotes.tickCleanup();
         EmoteNetwork.applyInbound();
         if (this.key != null) {
            while (this.key.method_1436()) {
               if (this.wheel.get()) {
                  if (this.mc.field_1755 == null && System.currentTimeMillis() - this.wheelClosedAt > 400L) {
                     this.openWheel();
                  }
               } else {
                  this.trigger();
               }
            }
         }

         for (Map.Entry<String, Setting.Key> e : this.binds.entrySet()) {
            if (e.getValue().pressed()) {
               this.start(e.getKey());
            }
         }

         if (this.mc.field_1724 == null && (this.activeId != null || this.previewId != null)) {
            this.activeId = null;
            this.previewId = null;
         }
      }

      /** Открывает колесо выбора. Никак, если уже открыт другой экран. */
      public void openWheel() {
         if (this.mc.field_1755 == null) {
            this.mc.method_1507(new EmoteWheelScreen(null));
         }
      }

      /** Колесо закрылось: край клавиши B в этот момент игнорируем, иначе оно открылось бы снова. */
      public void wheelClosed() {
         this.wheelClosedAt = System.currentTimeMillis();
      }

      public String selected() {
         return this.pick.ids[this.pick.index];
      }

      public void trigger() {
         this.start(this.selected());
      }

      /** Идёт ли сейчас зацикленная эмоция. */
      public String active() {
         return this.mc.field_1724 != null && isLooping(this.mc.field_1724.method_5628()) ? this.activeId : null;
      }

      /**
       * Ставит эмоцию себе и просит сервер показать её другим.
       * Повторный клик по той же зацикленной эмоции — выключает её, как в Fortnite.
       */
      public void start(String id) {
         if (this.mc.field_1724 == null) {
            return;
         }

         int self = this.mc.field_1724.method_5628();
         if (id != null && id.equals(this.activeId) && isLooping(self)) {
            this.stopSelf();
         } else {
            boolean loop = this.loopSel.get();
            this.previewId = null;
            if (play(self, id, this.speed.f(), loop, true)) {
               EmoteNetwork.send(id, this.speed.f(), loop);
               this.activeId = loop ? id : null;
            }
         }
      }

      /** Предпросмотр при наведении в колесе: локально, без отправки на сервер. */
      public void preview(String id) {
         if (this.mc.field_1724 == null) {
            return;
         }

         int self = this.mc.field_1724.method_5628();
         if (id.equals(this.previewId)) {
            return;
         }

         this.previewId = id;
         if (!id.equals(this.activeId) || !isLooping(self)) {
            play(self, id, this.speed.f(), true, true);
         }
      }

      /** Возврат к закреплённой эмоции после закрытия колеса. true — предпросмотр что-то показывал. */
      public boolean restoreAfterPreview() {
         if (this.mc.field_1724 == null) {
            return false;
         } else {
            boolean was = this.previewId != null;
            this.previewId = null;
            if (was) {
               int self = this.mc.field_1724.method_5628();
               if (this.activeId != null) {
                  play(self, this.activeId, this.speed.f(), true, true);
               } else {
                  stopNow(self);
               }
            }

            return was;
         }
      }

      public void stopSelf() {
         if (this.mc.field_1724 != null) {
            String id = this.activeId != null ? this.activeId : current(this.mc.field_1724.method_5628());
            this.activeId = null;
            this.previewId = null;
            stop(this.mc.field_1724.method_5628());
            if (id != null) {
               EmoteNetwork.sendStop(id);
            }
         }
      }

      @Override
      public void onDisable() {
         this.activeId = null;
         this.previewId = null;
         if (this.mc.field_1724 != null) {
            stopNow(this.mc.field_1724.method_5628());
         }
      }
   }

   public static EmoteModule module() {
      return Modules.get("emotes") instanceof EmoteModule em ? em : null;
   }

   /** Поза для модели игрока: null, если эмоции нет или модуль выключен. */
   public static Pose activePose(int entityId, EmoteModule em) {
      if (em == null || !em.isEnabled()) {
         return null;
      } else if (!em.firstPerson.get() && isFirstPersonSelf(entityId)) {
         return null;
      } else {
         return pose(entityId);
      }
   }

   private static boolean isFirstPersonSelf(int entityId) {
      class_310 mc = class_310.method_1551();
      return mc.field_1724 != null && mc.field_1724.method_5628() == entityId && mc.field_1690.method_31044().method_31034();
   }

   /** Запускает эмоцию у своего игрока. null — получилось. */
   public static String playSelf(String id, float speed) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1724 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || !em.isEnabled()) {
         return Lang.t("Включи модуль «Эмоции» в меню", "Enable the Emotes module first");
      } else if (def(id) == null) {
         return Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + ids();
      } else {
         em.start(id);
         return null;
      }
   }

   /** Выключает свою эмоцию. null — получилось. */
   public static String stopSelf() {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1724 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (current(mc.field_1724.method_5628()) == null) {
         return Lang.t("Эмоция не идёт", "No emote is playing");
      } else {
         em.stopSelf();
         return null;
      }
   }

   /** Клавиша одной эмоции — для .emotebind. null, если модуля или такой эмоции нет. */
   public static Setting.Key bindOf(String id) {
      EmoteModule em = module();
      Def d = def(id);
      if (em == null || d == null) {
         return null;
      } else {
         return em.binds.get(d.id());
      }
   }

   /** Список «эмоция — клавиша» для чата. */
   public static String bindList() {
      EmoteModule em = module();
      if (em == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();

         for (Map.Entry<String, Setting.Key> e : em.binds.entrySet()) {
            if (e.getValue().value >= 0) {
               if (sb.length() > 0) {
                  sb.append(", ");
               }

               sb.append(e.getKey()).append("=").append(e.getValue().display());
            }
         }

         return sb.toString();
      }
   }

   /** Ищет игрока по нику рядом и запускает у него эмоцию. */
   public static String playOn(String nick, String id, float speed) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1687 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || !em.isEnabled()) {
         return Lang.t("Включи модуль «Эмоции» в меню", "Enable the Emotes module first");
      } else if (def(id) == null) {
         return Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + ids();
      } else {
         for (class_1657 p : mc.field_1687.method_18456()) {
            if (p.method_7334().name().equalsIgnoreCase(nick)) {
               return play(p.method_5628(), id, speed)
                  ? null
                  : Lang.t("У этого игрока уже идёт эмоция", "That player is already emoting");
            }
         }

         return Lang.t("Игрок не найден рядом: ", "Player not found nearby: ") + nick;
      }
   }
}
