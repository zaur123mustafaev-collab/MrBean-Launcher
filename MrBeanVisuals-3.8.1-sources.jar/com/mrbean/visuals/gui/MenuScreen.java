package com.mrbean.visuals.gui;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.CfgManager;
import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.preview.CosmeticPreview;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.cosmetic.PlayerCosmetic;
import com.mrbean.visuals.module.impl.PerformanceModule;
import com.mrbean.visuals.module.impl.ThemeModule;
import com.mrbean.visuals.optimize.OptimizationScreen;
import com.mrbean.visuals.render.CosmeticRenderer;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.PostFx;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import com.mrbean.visuals.util.Mobile;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_7532;
import net.minecraft.class_8030;
import org.joml.Matrix3x2fStack;

public class MenuScreen extends class_437 {
   private final Ui ui = new Ui();
   private static Category category = Category.DASHBOARD;
   private static int winW = -1;
   private static int winH = -1;
   private static int winX = -1;
   private static int winY = -1;
   private Module openModule;
   private float openAnim;
   private float pageAnim = 1.0F;
   private float settingsAnim;
   private boolean closing;
   private double scroll;
   private double scrollTarget;
   private int contentHeight;
   private String search = "";
   private boolean draggingWin;
   private boolean resizing;
   private double dragDX;
   private double dragDY;
   private String newProfileName = "";
   private int resetConfirm;
   private String cfgName = "";
   private String cfgConfirmDel;
   private float gs = 1.0F;
   private static boolean soundOpen = true;
   private static final int SIDE = 104;
   private static final int HEAD = 30;
   private static final String[] HELPERS = new String[]{
      "totem_counter",
      "durability_warning",
      "combat_timer",
      "hit_particles",
      "target_hud",
      "armor",
      "potions",
      "inventory_hud",
      "item_counter",
      "keystrokes",
      "cps",
      "fps",
      "ping",
      "coords",
      "crosshair",
      "fullbright",
      "crystal_counter",
      "crystal_overlay",
      "crystal_preview"
   };

   public static void testCategory(String key) {
      for (Category c : Category.values()) {
         if (c.key.equals(key)) {
            category = c;
         }
      }
   }

   private int vw() {
      return (int)(this.field_22789 / this.gs);
   }

   private int vh() {
      return (int)(this.field_22790 / this.gs);
   }

   private void updateScale() {
      float want = (float)(Modules.theme().guiScale.value / 100.0);
      float max = Math.min(this.field_22789 / 300.0F, this.field_22790 / 200.0F);
      this.gs = Math.max(0.5F, Math.min(want * Mobile.menu(), max));
   }

   public MenuScreen() {
      super(class_2561.method_43470("MrBean Visuals"));
   }

   public boolean method_25421() {
      return false;
   }

   protected void method_25426() {
      this.updateScale();
      int W = this.vw();
      int H = this.vh();
      if (winW < 0 || winW > W - 8 || winH > H - 8) {
         winW = Math.min(640, W - 16);
         winH = Math.min(390, H - 16);
         winX = (W - winW) / 2;
         winY = (H - winH) / 2;
      }

      this.clampWin();
      if (soundOpen) {
         Sounds.play(Sounds.OPEN);
         soundOpen = false;
      }
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      if (Modules.theme().blur.value && this.field_22787 != null && this.field_22787.field_1687 != null) {
         context.method_71278();
      }

      context.method_25296(0, 0, this.field_22789, this.field_22790, R2D.argb((int)(90.0F * this.openAnim), 5, 6, 10), R2D.argb((int)(150.0F * this.openAnim), 5, 6, 10));
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.openAnim = R2D.approach(this.openAnim, this.closing ? 0.0F : 1.0F, 0.25F);
      if (this.closing && this.openAnim < 0.03F) {
         soundOpen = true;
         super.method_25419();
      } else {
         float oldGs = this.gs;
         this.updateScale();
         if (oldGs != this.gs) {
            this.clampWin();
         }

         float s = 0.94F + 0.06F * this.openAnim;
         float cx = winX + winW / 2.0F;
         float cy = winY + winH / 2.0F;
         double vmx = mouseX / this.gs;
         double vmy = mouseY / this.gs;
         double mx = (vmx - cx) / s + cx;
         double my = (vmy - cy) / s + cy;
         context.method_51448().pushMatrix();
         context.method_51448().scale(this.gs, this.gs);
         context.method_51448().translate(cx, cy);
         context.method_51448().scale(s, s);
         context.method_51448().translate(-cx, -cy);
         float oldA = R2D.alpha;
         R2D.alpha = Math.min(1.0F, this.openAnim * 1.2F);
         this.ui.begin(context, mx, my);
         R2D.panel(
            context,
            winX,
            winY,
            winW,
            winH,
            10,
            R2D.withAlpha(Modules.theme().background(), Math.max(200, Modules.theme().background() >>> 24)),
            true,
            587202559
         );
         this.drawSidebar(context);
         this.drawHeader(context);
         this.drawContent(context);
         int rx = winX + winW - 10;
         int ry = winY + winH - 10;

         for (int i = 0; i < 3; i++) {
            R2D.rect(context, rx + 6 - i * 3, ry + 6, 2, 2, 1090519039);
         }

         R2D.rect(context, rx + 6, ry + 3, 2, 2, 1090519039);
         R2D.rect(context, rx + 6, ry, 2, 2, 1090519039);
         R2D.rect(context, rx + 3, ry + 3, 2, 2, 1090519039);
         if (this.ui.pressedIn(rx - 2, ry - 2, 14, 14)) {
            this.resizing = true;
         }

         this.ui.end();
         R2D.alpha = oldA;
         context.method_51448().popMatrix();
         Notifications.render(context);
         if (this.draggingWin) {
            if (!this.ui.mouseDown) {
               this.draggingWin = false;
            } else {
               winX = (int)(mouseX / this.gs - this.dragDX);
               winY = (int)(mouseY / this.gs - this.dragDY);
               this.clampWin();
            }
         }

         if (this.resizing) {
            if (!this.ui.mouseDown) {
               this.resizing = false;
            } else {
               winW = (int)(mouseX / this.gs - winX);
               winH = (int)(mouseY / this.gs - winY);
               this.clampWin();
            }
         }
      }
   }

   private void clampWin() {
      int W = this.vw();
      int H = this.vh();
      winW = Math.max(Math.min(400, W - 8), Math.min(winW, W - 8));
      winH = Math.max(Math.min(240, H - 8), Math.min(winH, H - 8));
      winX = Math.max(0, Math.min(winX, W - winW));
      winY = Math.max(0, Math.min(winY, H - winH));
   }

   private void drawSidebar(class_332 ctx) {
      int x = winX;
      int y = winY;
      R2D.round(ctx, x, y, 104, winH, 10, R2D.withAlpha(-16777216, 70));
      R2D.rect(ctx, x + 104 - 1, y + 8, 1, winH - 16, 352321535);
      R2D.bean(ctx, x + 10, y + 9, 14);
      R2D.gradientText(ctx, "MrBean", x + 28, y + 9, 0.06F, false);
      R2D.text(ctx, "Visuals", x + 28, y + 18, -4670004, false);
      if (this.ui.pressedIn(x, y, 104, 30)) {
         this.draggingWin = true;
         this.dragDX = this.ui.mx - winX;
         this.dragDY = this.ui.my - winY;
      }

      int iy = y + 38;
      int itemH = Math.max(14, Math.min(19, (winH - 38 - 46) / Category.values().length));
      float sel = this.ui.anim("side_sel", category.ordinal(), 0.3F);
      R2D.round(ctx, x + 6, (int)(iy + sel * itemH), 92, itemH - 2, 5, R2D.withAlpha(R2D.accent(0.0F), 40));
      R2D.rect(ctx, x + 6, (int)(iy + sel * itemH) + 3, 2, itemH - 8, R2D.accent(0.0F));

      for (Category c : Category.values()) {
         int cy = iy + c.ordinal() * itemH;
         boolean hov = this.ui.hover(x + 6, cy, 92, itemH - 2);
         float t = this.ui.anim("side:" + c.key, hov ? 1.0F : 0.0F, 0.3F);
         if (t > 0.01F) {
            R2D.round(ctx, x + 6, cy, 92, itemH - 2, 5, R2D.withAlpha(-1, (int)(12.0F * t)));
         }

         boolean act = c == category;
         R2D.text(ctx, c.icon, x + 13, cy + (itemH - 2) / 2 - 4, act ? R2D.accent(0.0F) : -6643532, false);
         R2D.text(ctx, c.title(), x + 26 + (int)(2.0F * t), cy + (itemH - 2) / 2 - 4, act ? -1 : R2D.lerp(-6643532, -1183755, t), false);
         if (this.ui.clicked(x + 6, cy, 92, itemH - 2)) {
            this.switchCategory(c);
         }
      }

      int ay = y + winH - 36;
      R2D.round(ctx, x + 6, ay, 92, 30, 6, 587202559);
      if (this.field_22787 != null && this.field_22787.field_1724 != null) {
         class_7532.method_52722(ctx, this.field_22787.field_1724.method_52814(), x + 11, ay + 6, 18);
      } else {
         R2D.circle(ctx, x + 20, ay + 15, 9, R2D.accent(0.0F));
      }

      String name = this.field_22787 == null ? "?" : this.field_22787.method_1548().method_1676();
      if (R2D.width(name) > 58) {
         name = name.substring(0, Math.min(name.length(), 9)) + "…";
      }

      R2D.text(ctx, name, x + 34, ay + 6, -1183755, false);
      boolean ms = Info.microsoftAccount();
      R2D.textScaled(ctx, ms ? "● Microsoft" : "● " + Lang.t("Офлайн", "Offline"), x + 34, ay + 18, 0.75F, ms ? -11870592 : -20448, false);
   }

   private void switchCategory(Category c) {
      if (c != category || this.openModule != null) {
         category = c;
         this.openModule = null;
         this.pageAnim = 0.0F;
         this.scroll = this.scrollTarget = 0.0;
         this.ui.closeOverlay();
      }
   }

   private void drawHeader(class_332 ctx) {
      int x = winX + 104;
      int y = winY;
      int w = winW - 104;
      if (this.ui.pressedIn(x, y, w - 210, 30)) {
         this.draggingWin = true;
         this.dragDX = this.ui.mx - winX;
         this.dragDY = this.ui.my - winY;
      }

      String title = this.openModule != null ? this.openModule.name() : category.title();
      R2D.textScaled(ctx, title, x + 12, y + 10, 1.25F, -1, false);
      int sw = Math.min(150, w - 230);
      if (sw > 60) {
         int sx = x + w - sw - 74;
         this.search = this.ui.textField("search", sx, y + 8, sw, this.search, "⌕ " + Lang.ui("ui.search"), 32);
         if (!this.search.isEmpty() && this.openModule != null) {
            this.openModule = null;
         }
      }

      if (this.ui.button("hud_editor", x + w - 68, y + 8, 60, 14, "✥ HUD", 2)) {
         this.field_22787.method_1507(Screens.hudEditor(this));
      }

      R2D.rect(ctx, x + 8, y + 30 - 1, w - 16, 1, 352321535);
   }

   private void drawContent(class_332 ctx) {
      int x = winX + 104 + 10;
      int y = winY + 30 + 6;
      int w = winW - 104 - 20;
      int h = winH - 30 - 12;
      this.pageAnim = R2D.approach(this.pageAnim, 1.0F, 0.2F);
      this.settingsAnim = R2D.approach(this.settingsAnim, this.openModule != null ? 1.0F : 0.0F, 0.25F);
      if (this.ui.scroll != 0.0 && this.ui.hover(x, y, w, h) && !this.ui.overlayOpen()) {
         this.scrollTarget = this.scrollTarget - this.ui.scroll * 24.0;
         this.ui.scroll = 0.0;
      }

      this.scrollTarget = Math.max(0.0, Math.min((double)Math.max(0, this.contentHeight - h + 8), this.scrollTarget));
      this.scroll = R2D.approach((float)this.scroll, (float)this.scrollTarget, 0.35F);
      ctx.method_44379(x - 4, y - 2, x + w + 4, y + h + 2);
      CosmeticPreview.clip = new class_8030(x - 4, y - 2, w + 8, h + 4);
      ctx.method_51448().pushMatrix();
      float slide = (1.0F - this.pageAnim) * 12.0F;
      ctx.method_51448().translate(0.0F, (float)(-this.scroll + slide));
      float a = R2D.alpha;
      R2D.alpha = R2D.alpha * this.pageAnim;
      double oy = this.ui.my;
      this.ui.my = this.ui.my + (this.scroll - slide);
      int used;
      if (!this.search.isEmpty()) {
         used = this.drawSearch(ctx, x, y, w);
      } else if (this.openModule != null) {
         used = this.drawModuleSettings(ctx, x, y, w, h);
      } else {
         used = switch (category) {
            case DASHBOARD -> this.drawDashboard(ctx, x, y, w);
            case THEMES -> this.drawThemes(ctx, x, y, w);
            case PERFORMANCE -> this.drawPerformance(ctx, x, y, w);
            case SETTINGS -> this.drawSettings(ctx, x, y, w);
            case UTILITIES -> this.drawUtilities(ctx, x, y, w);
            default -> this.drawModuleGrid(ctx, x, y, w, Modules.of(category));
         };
      }

      this.contentHeight = used;
      this.ui.my = oy;
      R2D.alpha = a;
      ctx.method_51448().popMatrix();
      ctx.method_44380();
      CosmeticPreview.clip = null;
      if (this.contentHeight > h) {
         float frac = (float)h / this.contentHeight;
         int bh = Math.max(16, (int)(h * frac));
         int by = y + (int)((h - bh) * (this.scroll / Math.max(1, this.contentHeight - h + 8)));
         R2D.round(ctx, x + w + 3, by, 2, bh, 1, 1090519039);
      }
   }

   private int drawModuleGrid(class_332 ctx, int x, int y, int w, List<Module> mods) {
      int cols = w >= 520 ? 3 : (w >= 340 ? 2 : 1);
      int gap = 6;
      int cw = (w - gap * (cols - 1)) / cols;
      int ch = 48;
      int i = 0;

      for (Module m : mods) {
         int cx = x + i % cols * (cw + gap);
         int cy = y + i / cols * (ch + gap);
         float in = this.ui.anim("in:" + category.key + ":" + m.id, 1.0F, 0.12F + Math.min(0.1F, i * 0.004F));
         float oldA = R2D.alpha;
         R2D.alpha *= in;
         this.moduleCard(ctx, m, cx, cy + (int)((1.0F - in) * 6.0F), cw, ch);
         R2D.alpha = oldA;
         i++;
      }

      if (mods.isEmpty()) {
         R2D.text(ctx, Lang.ui("ui.nothing_found"), x, y + 4, -6643532, false);
      }

      return (mods.size() + cols - 1) / cols * (ch + gap);
   }

   private void moduleCard(class_332 ctx, Module m, int x, int y, int w, int h) {
      boolean hov = this.ui.hover(x, y, w, h);
      float t = this.ui.anim("card:" + m.id, hov ? 1.0F : 0.0F, 0.3F);
      float on = this.ui.anim("cardon:" + m.id, m.isEnabled() ? 1.0F : 0.0F, 0.25F);
      int acc = R2D.accent(0.0F);
      if (t > 0.02F && Modules.theme().shadows.value) {
         R2D.shadow(ctx, x, y, w, h, 6, R2D.withAlpha(-16777216, (int)(70.0F * t)));
      }

      R2D.round(ctx, x, y, w, h, 8, R2D.lerp(this.ui.panelColor(), this.ui.panelHover(), t));
      if (on > 0.01F) {
         R2D.round(ctx, x, y, w, h, 8, R2D.withAlpha(acc, (int)(20.0F * on)));
      }

      R2D.outline(ctx, x, y, w, h, 8, R2D.lerp(352321535, R2D.withAlpha(acc, 140), Math.max(t * 0.7F, on * 0.45F)));
      int is = 22;
      int ix = x + 8;
      int iy = y + (h - is) / 2;
      R2D.round(ctx, ix, iy, is, is, 6, R2D.lerp(419430399, R2D.withAlpha(acc, 70), on));
      String icon = m.category.icon;
      R2D.text(ctx, icon, ix + is / 2 - R2D.width(icon) / 2, iy + 7, on > 0.5F ? -1 : R2D.lerp(-6643532, acc, t), false);
      int tx0 = ix + is + 8;
      int maxW = w - (tx0 - x) - 36;
      String name = m.name();
      if (R2D.width(name) > maxW) {
         while (R2D.width(name + "…") > maxW && name.length() > 3) {
            name = name.substring(0, name.length() - 1);
         }

         name = name + "…";
      }

      R2D.text(ctx, name, tx0 + (int)(2.0F * t), y + 11, -1, false);
      String d = m.description();
      String dd = d;
      if (R2D.width(d) * 0.8F > maxW) {
         while (R2D.width(dd + "…") * 0.8F > maxW && dd.length() > 3) {
            dd = dd.substring(0, dd.length() - 1);
         }

         dd = dd + "…";
      }

      R2D.textScaled(ctx, dd, tx0, y + 25, 0.8F, -6643532, false);
      if (hov && !dd.equals(d)) {
         this.ui.tooltip(d);
      }

      boolean hasSettings = !m.settings.isEmpty();
      if (hasSettings) {
         R2D.textScaled(ctx, "⚙ " + m.settings.size(), tx0, y + 36, 0.7F, hov ? acc : -9735802, false);
      }

      int tgx = x + w - 30;
      if (m.toggleable()) {
         boolean nv = this.ui.toggle("card_tg:" + m.id, tgx, y + h / 2 - 6, m.isEnabled());
         if (nv != m.isEnabled()) {
            m.toggle();
            Config.markDirty();
         }
      }

      if (this.ui.rightClicked(x, y, w, h) && hasSettings) {
         this.openSettings(m);
      } else if (this.ui.clicked(x, y, w, h)) {
         if (hasSettings) {
            this.openSettings(m);
         } else if (m.toggleable()) {
            m.toggle();
            Config.markDirty();
         }
      }
   }

   private void preview(class_332 ctx, int x0, int y0, int x1, int y1, int size, float yaw, String id) {
      Matrix3x2fStack mt = ctx.method_51448();
      float sx = mt.m00();
      float sy = mt.m11();
      CosmeticPreview.draw(
         ctx, (int)(x0 * sx + mt.m20()), (int)(y0 * sy + mt.m21()), (int)(x1 * sx + mt.m20()), (int)(y1 * sy + mt.m21()), Math.round(size * sx), yaw, id
      );
   }

   private void openSettings(Module m) {
      this.openModule = m;
      this.pageAnim = 0.0F;
      this.scroll = this.scrollTarget = 0.0;
      this.ui.closeOverlay();
      this.search = "";
   }

   private int drawUtilities(class_332 ctx, int x, int y, int w) {
      int yy = y + this.drawModuleGrid(ctx, x, y, w, Modules.of(Category.UTILITIES));
      yy += 6;
      R2D.text(ctx, Lang.t("Помощники PvP / PvE", "PvP / PvE helpers"), x, yy, -1183755, false);
      R2D.textScaled(
         ctx,
         Lang.t("те же модули, что в HUD, Частицах и Crystal PvP", "same modules as in HUD, Particles and Crystal PvP"),
         x + R2D.width(Lang.t("Помощники PvP / PvE", "PvP / PvE helpers")) + 8,
         yy + 1,
         0.7F,
         -9735802,
         false
      );
      yy += 13;
      List<Module> helpers = new ArrayList<>();

      for (String id : HELPERS) {
         Module m = Modules.get(id);
         if (m != null) {
            helpers.add(m);
         }
      }

      yy += this.drawModuleGrid(ctx, x, yy, w, helpers);
      return yy - y;
   }

   private int drawSearch(class_332 ctx, int x, int y, int w) {
      String q = this.search.toLowerCase();
      List<Module> found = new ArrayList<>();

      for (Module m : Modules.all()) {
         if (m.searchText().contains(q)) {
            found.add(m);
         }
      }

      R2D.text(ctx, Lang.t("Найдено: ", "Found: ") + found.size(), x, y, -6643532, false);
      return 14 + this.drawModuleGrid(ctx, x, y + 14, w, found);
   }

   private int drawModuleSettings(class_332 ctx, int x, int y, int w, int h) {
      Module m = this.openModule;
      if (this.ui.button("back", x, y, 54, 14, "‹ " + Lang.ui("ui.back"), 2)) {
         this.openModule = null;
         this.pageAnim = 0.0F;
         return 0;
      } else {
         if (m.toggleable()) {
            R2D.text(ctx, m.isEnabled() ? Lang.ui("ui.enabled") : Lang.ui("ui.disabled"), x + w - 84, y + 3, m.isEnabled() ? R2D.accent(0.0F) : -6643532, false);
            boolean nv = this.ui.toggle("set_main:" + m.id, x + w - 22, y + 1, m.isEnabled());
            if (nv != m.isEnabled()) {
               m.toggle();
               Config.markDirty();
            }
         }

         int yy = y + 20;

         for (String line : Ui.wrap(m.description(), w)) {
            R2D.text(ctx, line, x, yy, -6643532, false);
            yy += 10;
         }

         yy += 6;
         boolean preview = m instanceof PlayerCosmetic && this.field_22787 != null && this.field_22787.field_1724 != null;
         int pw = preview && w >= 330 ? 120 : 0;
         int sx = x;
         int swd = w - (pw > 0 ? pw + 12 : 0);
         if (preview && pw > 0) {
            R2D.round(ctx, x + w - pw, yy, pw, 150, 8, 1073741824);
            R2D.outline(ctx, x + w - pw, yy, pw, 150, 8, 352321535);
            float yaw = (float)(System.currentTimeMillis() % 12000L) / 12000.0F * 360.0F;
            this.preview(ctx, x + w - pw, yy + 4, x + w, yy + 146, 38, yaw, m.id);
            R2D.textScaled(ctx, Lang.ui("ui.preview"), x + w - pw + 6, yy + 140, 0.7F, -9735802, false);
         } else if (preview) {
            float yaw = (float)(System.currentTimeMillis() % 12000L) / 12000.0F * 360.0F;
            R2D.round(ctx, x, yy, w, 120, 8, 1073741824);
            this.preview(ctx, x, yy, x + w, yy + 120, 30, yaw, m.id);
            yy += 128;
         }

         int startY = yy;
         R2D.round(ctx, x, yy, swd, 1, 0, 0);

         for (Setting s : m.settings) {
            if (s.visible.getAsBoolean()) {
               int rh = this.ui.settingRow("set:" + m.id + ":", s, sx + 6, yy + 4, swd - 12);
               yy += rh + 4;
            }
         }

         if (this.ui.button("reset:" + m.id, sx + 6, yy + 6, 90, 14, "⟲ " + Lang.ui("ui.reset"), 3)) {
            m.resetSettings();
            Config.markDirty();
         }

         yy += 26;
         return Math.max(yy - y, preview && pw > 0 ? startY - y + 156 : 0);
      }
   }

   private int drawDashboard(class_332 ctx, int x, int y, int w) {
      R2D.round(ctx, x, y, w, 52, 8, this.ui.panelColor());
      R2D.accentBar(ctx, x + 8, y, w - 16, 1);
      if (this.field_22787.field_1724 != null) {
         class_7532.method_52722(ctx, this.field_22787.field_1724.method_52814(), x + 10, y + 10, 32);
      }

      String name = this.field_22787.method_1548().method_1676();
      R2D.textScaled(ctx, Lang.t("Привет, ", "Hi, ") + name + "!", x + 50, y + 11, 1.25F, -1, false);
      boolean ms = Info.microsoftAccount();
      R2D.text(
         ctx,
         (ms ? "§a✔ " + Lang.t("Аккаунт Microsoft", "Microsoft account") : "§6● " + Lang.t("Офлайн-аккаунт", "Offline account")) + " §7· MrBean Visuals " + com.mrbean.visuals.MrBeanClient.VERSION,
         x + 50,
         y + 29,
         -6643532,
         false
      );
      if (w > 340 && this.ui.button("wizard", x + w - 92, y + 8, 84, 14, Lang.t("✦ Мастер", "✦ Setup"), 0)) {
         this.field_22787.method_1507(Screens.wizard(this));
      }

      if (w > 340 && this.ui.button("hud2", x + w - 92, y + 28, 84, 14, "✥ " + Lang.ui("ui.hud_editor"), 0)) {
         this.field_22787.method_1507(Screens.hudEditor(this));
      }

      int yy = y + 60;
      String[][] stats = new String[][]{
         {"FPS", String.valueOf(this.field_22787.method_47599()), Lang.t("сред. ", "avg ") + Math.round(Info.avgFps())},
         {Lang.t("Кадр", "Frame"), String.format("%.1f ms", Info.frameTimeMs()), Lang.t("макс ", "max ") + String.format("%.0f", Info.worstFrameMs())},
         {Lang.t("Память", "Memory"), Info.usedMemMb() + " MB", "/ " + Info.maxMemMb() + " MB"},
         {Lang.t("Эффекты", "Effects"), String.valueOf(PerformanceModule.activeEffects()), Lang.t("активно", "active")}
      };
      int cols = w >= 360 ? 4 : 2;
      int gap = 6;
      int tw = (w - gap * (cols - 1)) / cols;

      for (int i = 0; i < stats.length; i++) {
         int tx = x + i % cols * (tw + gap);
         int ty = yy + i / cols * 40;
         R2D.round(ctx, tx, ty, tw, 34, 7, this.ui.panelColor());
         R2D.text(ctx, stats[i][0], tx + 7, ty + 5, -6643532, false);
         R2D.textScaled(ctx, stats[i][1], tx + 7, ty + 16, 1.15F, R2D.accent(i * 0.15F), false);
         R2D.textScaled(ctx, stats[i][2], tx + tw - 6 - R2D.width(stats[i][2]) * 0.75F, ty + 6, 0.75F, -9735802, false);
         if (i == 0) {
            this.sparkline(ctx, tx + tw / 2, ty + 18, tw / 2 - 8, 12);
         }
      }

      yy += stats.length / cols * 40 + 4;
      R2D.text(ctx, Lang.t("Быстрые переключатели", "Quick toggles"), x, yy, -1183755, false);
      yy += 12;
      String[] quick = new String[]{
         "china_hat", "fullbright", "zoom", "keystrokes", "auto_sprint", "halo", "color_grade", "custom_hotbar", "angel_wings", "time_changer"
      };
      int qc = w >= 360 ? 2 : 1;
      int qw = (w - gap * (qc - 1)) / qc;
      int n = 0;

      for (String id : quick) {
         Module m = Modules.get(id);
         if (m != null) {
            int qx = x + n % qc * (qw + gap);
            int qy = yy + n / qc * 22;
            boolean hov = this.ui.hover(qx, qy, qw, 18);
            R2D.round(ctx, qx, qy, qw, 18, 6, hov ? this.ui.panelHover() : this.ui.panelColor());
            R2D.text(ctx, m.name(), qx + 8, qy + 5, m.isEnabled() ? -1 : -6643532, false);
            boolean nv = this.ui.toggle("q:" + id, qx + qw - 28, qy + 3, m.isEnabled());
            if (nv != m.isEnabled()) {
               m.toggle();
               Config.markDirty();
            }

            if (!m.settings.isEmpty() && this.ui.rightClicked(qx, qy, qw, 18)) {
               this.openSettings(m);
            }

            n++;
         }
      }

      yy += (n + qc - 1) / qc * 22 + 6;
      if (this.field_22787.field_1724 != null) {
         int ph = 140;
         R2D.round(ctx, x, yy, w, ph, 8, this.ui.panelColor());
         R2D.text(ctx, Lang.t("Твоя косметика", "Your cosmetics"), x + 8, yy + 7, -1183755, false);
         int on = 0;

         for (Module m : Modules.all()) {
            if (m instanceof PlayerCosmetic && m.isEnabled()) {
               on++;
            }
         }

         R2D.text(
            ctx,
            on == 0 ? Lang.t("Ничего не включено — загляни в «Косметику»", "Nothing enabled — see Cosmetics") : Lang.t("Включено: ", "Enabled: ") + on,
            x + 8,
            yy + 19,
            -6643532,
            false
         );
         if (this.ui.button("go_cos", x + 8, yy + ph - 22, 90, 14, Lang.t("Косметика →", "Cosmetics →"), 0)) {
            this.switchCategory(Category.COSMETICS);
         }

         float yaw = (float)(System.currentTimeMillis() % 12000L) / 12000.0F * 360.0F;
         int ox = (int)ctx.method_51448().m20();
         int oy = (int)ctx.method_51448().m21();
         CosmeticPreview.draw(ctx, x + w - 150 + ox, yy + oy, x + w + ox, yy + ph + oy, 36.0F, yaw, null);
         yy += ph + 6;
      }

      return yy - y;
   }

   private void sparkline(class_332 ctx, int x, int y, int w, int h) {
      float[] hist = Info.fpsHistory;
      int n = hist.length;
      int start = Info.fpsHistoryIndex();
      float max = 1.0F;

      for (float v : hist) {
         max = Math.max(max, v);
      }

      int pts = Math.min(n, w);

      for (int i = 0; i < pts; i++) {
         float v = hist[(start + n - pts + i) % n];
         int bh = (int)(v / max * h);
         R2D.rect(ctx, x + i, y + h - bh, 1, bh, R2D.withAlpha(R2D.accent((float)i / pts * 0.4F), 160));
      }
   }

   private int drawThemes(class_332 ctx, int x, int y, int w) {
      ThemeModule t = Modules.theme();
      R2D.text(ctx, Lang.t("Пресеты", "Presets"), x, y, -1183755, false);
      int yy = y + 12;
      int cols = w >= 380 ? 4 : 2;
      int gap = 6;
      int cw = (w - gap * (cols - 1)) / cols;
      int ch = 36;
      int saved = t.preset.index;

      for (int i = 0; i < t.preset.ids.length; i++) {
         int cx = x + i % cols * (cw + gap);
         int cy = yy + i / cols * (ch + gap);
         t.preset.index = i;
         int c1 = t.accent(0.0F);
         int c2 = t.accent(0.5F);
         t.preset.index = saved;
         boolean sel = i == saved;
         boolean hov = this.ui.hover(cx, cy, cw, ch);
         R2D.round(ctx, cx, cy, cw, ch, 7, hov ? this.ui.panelHover() : this.ui.panelColor());
         R2D.hGradient(ctx, cx + 6, cy + 6, cw - 12, 10, c1, c2);
         R2D.text(ctx, t.preset.label(i), cx + 6, cy + 21, sel ? -1 : -6643532, false);
         if (sel) {
            R2D.outline(ctx, cx, cy, cw, ch, 7, R2D.accent(0.0F));
         }

         if (this.ui.clicked(cx, cy, cw, ch)) {
            t.preset.index = i;
            saved = i;
            Config.markDirty();
         }
      }

      yy += (t.preset.ids.length + cols - 1) / cols * (ch + gap) + 6;
      R2D.round(ctx, x, yy, w, 1, 0, 352321535);
      yy += 6;

      for (Setting s : t.settings) {
         if (s != t.preset && s.visible.getAsBoolean()) {
            yy += this.ui.settingRow("theme:", s, x + 4, yy, w - 8) + 4;
         }
      }

      return yy - y + 6;
   }

   private int drawPerformance(class_332 ctx, int x, int y, int w) {
      PerformanceModule p = (PerformanceModule)Modules.get("performance");
      int yy = y;
      R2D.round(ctx, x, y, w, 92, 8, this.ui.panelColor());
      R2D.text(ctx, Lang.t("Панель производительности", "Performance dashboard"), x + 8, y + 6, -1183755, false);
      String[][] m = new String[][]{
         {"FPS", this.field_22787.method_47599() + "", Lang.t("Средний FPS", "Average FPS"), String.format("%.0f", Info.avgFps())},
         {
               Lang.t("Время кадра", "Frame time"),
               String.format("%.2f ms", Info.frameTimeMs()),
               Lang.t("Худший кадр", "Worst frame"),
               String.format("%.1f ms", Info.worstFrameMs())
         },
         {Lang.t("Память", "Memory"), Info.usedMemMb() + " / " + Info.maxMemMb() + " MB", "CPU", Info.cpu() < 0.0 ? "—" : Math.round(Info.cpu() * 100.0) + "%"},
         {
               Lang.t("Косметика", "Cosmetics"),
               String.format("%.2f ms", CosmeticRenderer.lastNanos / 1000000.0),
               Lang.t("Пост-эффекты", "Post FX"),
               String.format("%.2f ms", PostFx.lastNanos / 1000000.0)
         },
         {
               Lang.t("Частицы", "Particles"),
               ParticleEngine.count() + " / " + ParticleEngine.limit,
               Lang.t("Эффектов", "Effects"),
               String.valueOf(PerformanceModule.activeEffects())
         }
      };
      int colW = (w - 16) / 2;

      for (int i = 0; i < m.length; i++) {
         int ry = yy + 20 + i * 13;
         R2D.text(ctx, m[i][0], x + 8, ry, -6643532, false);
         R2D.text(ctx, m[i][1], x + 8 + colW - 10 - R2D.width(m[i][1]), ry, -1, false);
         R2D.text(ctx, m[i][2], x + 8 + colW + 6, ry, -6643532, false);
         R2D.text(ctx, m[i][3], x + w - 8 - R2D.width(m[i][3]), ry, -1, false);
      }

      yy += 98;
      R2D.round(ctx, x, yy, w, 44, 8, this.ui.panelColor());
      R2D.text(ctx, Lang.t("FPS за 30 секунд", "FPS, last 30 s"), x + 8, yy + 5, -6643532, false);
      this.sparkline(ctx, x + 8, yy + 16, w - 16, 22);
      yy += 50;
      R2D.textScaled(ctx, "GPU: " + Info.gpu(), x + 2, yy, 0.75F, -9735802, false);
      yy += 10;
      String[] names = new String[p.preset.ids.length];

      for (int i = 0; i < names.length; i++) {
         names[i] = p.preset.label(i);
      }

      int sel = this.ui.segmented("perf_preset", x, yy, w, names, p.preset.index);
      if (sel != p.preset.index) {
         p.preset.index = sel;
         p.applyPreset(true);
      }

      yy += 22;

      for (Setting s : p.settings) {
         if (s != p.preset) {
            yy += this.ui.settingRow("perf:", s, x + 4, yy, w - 8) + 4;
         }
      }

      if (p.benchmarking()) {
         R2D.text(ctx, Lang.t("Идёт замер FPS…", "Benchmark running…"), x + 4, yy, R2D.accent(0.0F), false);
      }

      yy += 4;
      if (!p.results.isEmpty()) {
         R2D.text(ctx, Lang.t("Результаты замеров", "Benchmark results"), x, yy, -1183755, false);
         yy += 12;

         for (PerformanceModule.Result r : p.results) {
            R2D.text(
               ctx,
               String.format("%s — %.0f FPS (%s %.0f) · %s %d", r.preset, r.avg, Lang.t("низ.", "low"), r.low, Lang.t("эффектов", "effects"), r.effects),
               x + 4,
               yy,
               -6643532,
               false
            );
            yy += 11;
         }

         yy += 4;
      }

      R2D.round(ctx, x, yy, w, 46, 8, this.ui.panelColor());
      R2D.text(ctx, Lang.t("Оптимизационные моды", "Optimization mods"), x + 8, yy + 6, -1183755, false);
      R2D.text(
         ctx,
         Lang.t(
            "Sodium, Lithium, FerriteCore и др. — с Modrinth, с твоего разрешения", "Sodium, Lithium, FerriteCore & more — from Modrinth, with your permission"
         ),
         x + 8,
         yy + 18,
         -6643532,
         false
      );
      if (this.ui.button("optmods", x + 8, yy + 28, 140, 13, Lang.t("Проверить и установить…", "Check & install…"), 1)) {
         this.field_22787.method_1507(new OptimizationScreen(this));
      }

      yy += 52;
      List<Module> rest = new ArrayList<>(Modules.of(Category.PERFORMANCE));
      rest.remove(p);
      if (!rest.isEmpty()) {
         yy += this.drawModuleGrid(ctx, x, yy, w, rest);
      }

      return yy - y;
   }

   private int drawSettings(class_332 ctx, int x, int y, int w) {
      R2D.text(ctx, Lang.t("Язык интерфейса", "Interface language"), x, y + 4, -1183755, false);
      int li = this.ui.segmented("lang", x + w - 140, y, 140, new String[]{"Русский", "English"}, Lang.english ? 1 : 0);
      if (li == 1 != Lang.english) {
         Lang.english = li == 1;
         Config.save();
      }

      int yy = y + 22;
      R2D.text(ctx, Lang.t("Уведомления о вкл/выкл", "Toggle notifications"), x, yy + 2, -1183755, false);
      boolean nb = this.ui.toggle("notif", x + w - 22, yy, Notifications.enabled);
      if (nb != Notifications.enabled) {
         Notifications.enabled = nb;
      }

      yy += 20;
      R2D.round(ctx, x, yy, w, 44, 8, this.ui.panelColor());
      if (this.field_22787.field_1724 != null) {
         class_7532.method_52722(ctx, this.field_22787.field_1724.method_52814(), x + 8, yy + 8, 28);
      }

      boolean ms = Info.microsoftAccount();
      R2D.text(ctx, Lang.ui("ui.account") + ": " + this.field_22787.method_1548().method_1676(), x + 44, yy + 9, -1, false);
      R2D.text(
         ctx,
         ms
            ? Lang.t("§aВход через Microsoft — лицензия подтверждена", "§aSigned in with Microsoft — license verified")
            : Lang.t("§6Офлайн. Войти через Microsoft можно в MrBean Launcher", "§6Offline. Sign in with Microsoft in MrBean Launcher"),
         x + 44,
         yy + 22,
         -6643532,
         false
      );
      yy += 50;
      yy = this.configBlock(ctx, x, yy, w);
      yy = this.profileBlock(ctx, x, yy, w, Lang.t("Профили настроек", "Config profiles"), Config.profilesDir(), Config.profile, true);
      yy = this.profileBlock(ctx, x, yy, w, Lang.t("HUD-пресеты", "HUD presets"), Config.hudDir(), Config.hudPreset, false);
      R2D.text(ctx, Lang.t("Импорт и экспорт", "Import & export"), x, yy, -1183755, false);
      yy += 12;
      int bw = (w - 18) / 4;
      if (this.ui.button("exp_file", x, yy, bw, 14, Lang.t("Экспорт в файл", "Export file"), 0)) {
         Path p = Config.export();
         Notifications.push(Lang.t("Сохранено: ", "Saved: ") + p.getFileName(), true);
      }

      if (this.ui.button("exp_clip", x + bw + 6, yy, bw, 14, Lang.t("Копировать", "Copy"), 0)) {
         this.field_22787.field_1774.method_1455(Config.exportString());
         Notifications.push(Lang.t("Настройки скопированы", "Settings copied"), true);
      }

      if (this.ui.button("imp_clip", x + (bw + 6) * 2, yy, bw, 14, Lang.t("Вставить", "Paste"), 0)) {
         boolean ok = Config.importString(this.field_22787.field_1774.method_1460());
         Notifications.push(ok ? Lang.t("Настройки импортированы", "Settings imported") : Lang.t("В буфере нет настроек", "No settings in clipboard"), ok);
      }

      if (this.ui.button("imp_file", x + (bw + 6) * 3, yy, bw, 14, Lang.t("Из файла", "From file"), 0)) {
         Path p = Config.latestExport();
         boolean ok = p != null && Config.importFile(p);
         Notifications.push(ok ? Lang.t("Импорт: ", "Imported: ") + p.getFileName() : Lang.t("Нет файлов в exports", "No files in exports"), ok);
      }

      yy += 20;
      if (this.ui.button("open_dir", x, yy, bw * 2 + 6, 14, Lang.t("Открыть папку конфигов", "Open config folder"), 2)) {
         class_156.method_668().method_672(Config.dir().toFile());
      }

      String rl = this.resetConfirm == 0 ? Lang.t("Сбросить всё", "Reset everything") : Lang.t("Точно? Нажми ещё раз", "Sure? Click again");
      if (this.ui.button("reset_all", x + (bw + 6) * 2, yy, bw * 2 + 6, 14, rl, 3)) {
         if (this.resetConfirm == 0) {
            this.resetConfirm = 1;
         } else {
            Config.resetAll();
            this.resetConfirm = 0;
            Notifications.push(Lang.t("Настройки сброшены", "Settings reset"), true);
         }
      }

      yy += 24;
      yy += this.drawModuleGrid(ctx, x, yy, w, Modules.of(Category.SETTINGS));
      return yy - y + 4;
   }

   private int configBlock(class_332 ctx, int x, int yy, int w) {
      R2D.text(ctx, Lang.t("Конфиги", "Configs"), x, yy, -1183755, false);
      R2D.textScaled(
         ctx,
         Lang.t("в чате: .cfg save/load/list/delete/rename — на сервер не уходит", "in chat: .cfg save/load/list/delete/rename — never sent to the server"),
         x + 52,
         yy + 1,
         0.7F,
         -9735802,
         false
      );
      yy += 13;
      List<String> list = CfgManager.list();
      if (list.isEmpty()) {
         R2D.text(ctx, Lang.t("Пока нет — введите имя и нажмите «Сохранить»", "None yet — type a name and press Save"), x, yy + 2, -6643532, false);
         yy += 14;
      }

      for (String n : list) {
         boolean act = n.equals(CfgManager.active);
         R2D.round(ctx, x, yy, w, 18, 5, act ? R2D.withAlpha(R2D.accent(0.0F), 40) : this.ui.panelColor());
         R2D.circle(ctx, x + 8, yy + 9, 3, act ? R2D.accent(0.0F) : 1090519039);
         R2D.text(ctx, n, x + 16, yy + 5, -1183755, false);
         if (act) {
            R2D.textScaled(ctx, Lang.t("активный", "active"), x + 20 + R2D.width(n), yy + 6, 0.7F, R2D.accent(0.0F), false);
         }

         int bx = x + w - 4;
         String dl = n.equals(this.cfgConfirmDel) ? Lang.t("Точно?", "Sure?") : Lang.t("Удалить", "Delete");
         int dw = R2D.width(dl) + 10;
         bx -= dw;
         if (this.ui.button("cfgdel:" + n, bx, yy + 2, dw, 14, dl, 3)) {
            if (n.equals(this.cfgConfirmDel)) {
               CfgManager.Result r = CfgManager.delete(n);
               Notifications.push(r.message(), r.ok());
               this.cfgConfirmDel = null;
            } else {
               this.cfgConfirmDel = n;
            }
         }

         String sl = Lang.t("Перезаписать", "Overwrite");
         int sw = R2D.width(sl) + 10;
         bx -= sw + 4;
         if (this.ui.button("cfgsave:" + n, bx, yy + 2, sw, 14, sl, 0)) {
            CfgManager.Result r = CfgManager.save(n);
            Notifications.push(r.message(), r.ok());
         }

         String ll = Lang.t("Загрузить", "Load");
         int lw = R2D.width(ll) + 10;
         bx -= lw + 4;
         if (this.ui.button("cfgload:" + n, bx, yy + 2, lw, 14, ll, act ? 0 : 1)) {
            CfgManager.Result r = CfgManager.load(n);
            Notifications.push(r.message(), r.ok());
         }

         yy += 21;
      }

      this.cfgName = this.ui
         .textField("cfgname", x, yy + 2, w - 96, this.cfgName, Lang.t("Имя нового конфига, напр. donut", "New config name, e.g. donut"), 32);
      if (this.ui.button("cfgnew", x + w - 90, yy + 2, 90, 14, Lang.t("Сохранить", "Save"), 1) && !this.cfgName.isBlank()) {
         CfgManager.Result r = CfgManager.save(this.cfgName);
         Notifications.push(r.message(), r.ok());
         if (r.ok()) {
            this.cfgName = "";
         }
      }

      return yy + 26;
   }

   private int profileBlock(class_332 ctx, int x, int yy, int w, String title, Path dir, String current, boolean profiles) {
      R2D.text(ctx, title, x, yy, -1183755, false);
      yy += 12;
      List<String> list = Config.list(dir);
      int px = x;

      for (String name : list) {
         int bw = R2D.width(name) + 14;
         if (px + bw > x + w) {
            px = x;
            yy += 18;
         }

         boolean act = name.equals(current);
         if (this.ui.button((profiles ? "prof:" : "hudp:") + name, px, yy, bw, 14, name, act ? 1 : 0) && !act) {
            if (profiles) {
               Config.switchProfile(name);
            } else {
               Config.switchHudPreset(name);
            }

            Notifications.push(title + ": " + name, true);
         }

         if (!act && !name.equals("default") && this.ui.rightClicked(px, yy, bw, 14)) {
            Config.deleteProfile(dir, name);
         }

         px += bw + 4;
      }

      yy += 18;
      String key = profiles ? "newprof" : "newhud";
      this.newProfileName = this.ui.textField(key, x, yy, w - 96, this.newProfileName, Lang.t("Название нового…", "New name…"), 24);
      if (this.ui.button(key + "_btn", x + w - 90, yy, 90, 14, Lang.t("Создать", "Create"), 0) && !this.newProfileName.isBlank()) {
         if (profiles) {
            Config.switchProfile(this.newProfileName);
         } else {
            Config.switchHudPreset(this.newProfileName);
         }

         this.newProfileName = "";
      }

      R2D.textScaled(ctx, Lang.t("ПКМ по названию — удалить", "Right-click a name to delete"), x, yy + 17, 0.7F, -9735802, false);
      return yy + 28;
   }

   private double[] toWin(double mx, double my) {
      mx /= this.gs;
      my /= this.gs;
      float s = 0.94F + 0.06F * this.openAnim;
      float cx = winX + winW / 2.0F;
      float cy = winY + winH / 2.0F;
      return new double[]{(mx - cx) / s + cx, (my - cy) / s + cy};
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      double[] p = this.toWin(click.comp_4798(), click.comp_4799());
      this.ui.onClick(p[0], p[1], click.method_74245());
      if (!R2D.inside(click.comp_4798(), click.comp_4799(), winX, winY, winW, winH) && !this.ui.overlayOpen() && click.method_74245() == 0) {
      }

      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      int k = input.comp_4795();
      if (this.ui.focus != null) {
         if (k == 256) {
            this.ui.focus = null;
            return true;
         } else {
            this.ui.onKey(k);
            return true;
         }
      } else if (k == 256) {
         if (this.ui.overlayOpen()) {
            this.ui.closeOverlay();
            return true;
         } else if (!this.search.isEmpty()) {
            this.search = "";
            return true;
         } else if (this.openModule != null) {
            this.openModule = null;
            this.pageAnim = 0.0F;
            return true;
         } else {
            this.method_25419();
            return true;
         }
      } else if (MrBeanClient.menuKey.method_1417(input)) {
         this.method_25419();
         return true;
      } else {
         return super.method_25404(input);
      }
   }

   public boolean method_25400(class_11905 input) {
      String s = input.method_74226();
      if (this.ui.focus == null && s != null && !s.isBlank() && this.openModule == null) {
         this.ui.focus = "search";
      }

      if (s != null) {
         for (char ch : s.toCharArray()) {
            this.ui.onChar(ch);
         }
      }

      return true;
   }

   public void method_25419() {
      if (!this.closing) {
         this.closing = true;
         Sounds.play(Sounds.CLOSE);
         Config.save();
      }
   }

   public void method_25432() {
      Config.save();
   }
}
