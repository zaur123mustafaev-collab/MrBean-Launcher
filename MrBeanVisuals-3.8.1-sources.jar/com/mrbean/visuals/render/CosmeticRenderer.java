package com.mrbean.visuals.render;

import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.cosmetic.PlayerCosmetic;
import com.mrbean.visuals.module.impl.CrystalModules;
import com.mrbean.visuals.module.impl.RvModules;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;

public final class CosmeticRenderer {
   private static final class_310 mc = class_310.method_1551();
   private static final PlayerCosmetic.Ctx ctx = new PlayerCosmetic.Ctx();
   private static final List<PlayerCosmetic> active = new ArrayList<>();
   public static long lastNanos;

   private CosmeticRenderer() {
   }

   public static void render(WorldRenderContext wrc) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         long t0 = System.nanoTime();
         active.clear();

         for (Module m : Modules.all()) {
            if (m instanceof PlayerCosmetic pc && pc.isEnabled()) {
               active.add(pc);
            }
         }

         class_243 cam = mc.field_1773.method_19418().method_71156();
         float td = mc.method_61966().method_60637(true);
         class_4587 ms = wrc.matrices();
         class_4598 buf = mc.method_22940().method_23000();
         boolean firstPerson = mc.field_1690.method_31044().method_31034();
         if (!active.isEmpty()) {
            for (class_1657 p : mc.field_1687.method_18456()) {
               boolean self = p == mc.field_1724;
               if ((self || !p.method_5756(mc.field_1724)) && !p.method_7325()) {
                  class_243 pos = p.method_30950(td);
                  if (self || !(pos.method_1025(cam) > 4096.0)) {
                     PlayerCosmetic.fill(ctx, p, td);
                     ctx.self = self;
                     ctx.preview = false;
                     ctx.firstPerson = self && firstPerson;
                     ctx.buffers = buf;
                     ctx.matrices = ms;

                     for (PlayerCosmetic pc : active) {
                        if (pc.shouldRender(ctx)) {
                           ms.method_22903();
                           ms.method_22904(pos.field_1352 - cam.field_1352, pos.field_1351 - cam.field_1351, pos.field_1350 - cam.field_1350);

                           try {
                              pc.draw(ctx);
                           } catch (Exception var17) {
                           }

                           ms.method_22909();
                        }
                     }
                  }
               }
            }
         }

         try {
            CrystalModules.renderWorld(ms, buf, cam, td);
         } catch (Exception var16) {
         }

         try {
            RvModules.renderWorld(ms, buf, cam, td);
         } catch (Exception var15) {
         }

         ParticleEngine.render(ms, buf, cam, td);
         if (Modules.get("player_badge") instanceof com.mrbean.visuals.module.impl.PlayerBadge badge) {
            try {
               badge.renderWorld(ms, buf, mc.field_1773.method_19418(), cam, td);
            } catch (Exception var14) {
            }
         }

         buf.method_22994(World3D.normalLayer());
         buf.method_22994(World3D.glowLayer());
         lastNanos = System.nanoTime() - t0;
      }
   }
}
