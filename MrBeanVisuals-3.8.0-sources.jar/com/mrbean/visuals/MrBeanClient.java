package com.mrbean.visuals;

import com.mrbean.visuals.core.ChatCommands;
import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Friends;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.menu.AccountScreen;
import com.mrbean.visuals.gui.menu.MenuBackground;
import com.mrbean.visuals.gui.preview.CosmeticPreview;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.module.impl.AutoDuel;
import com.mrbean.visuals.module.impl.Emotes;
import com.mrbean.visuals.module.impl.HelperModules;
import com.mrbean.visuals.module.impl.MacroModule;
import com.mrbean.visuals.module.impl.RvModules;
import com.mrbean.visuals.module.impl.VisualModules;
import com.mrbean.visuals.render.CosmeticRenderer;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.test.AutoTest;
import com.mrbean.visuals.util.Info;
import com.mrbean.visuals.util.LastServer;
import com.mrbean.visuals.util.Mobile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.Chat;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.Game;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents.AllowChat;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents.ModifyChat;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_304.class_11900;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_307;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_500;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MrBeanClient implements ClientModInitializer {
   public static final String MOD_ID = "mrbeanvisuals";
   public static final String VERSION = "3.8.0";
   public static final Logger LOG = LoggerFactory.getLogger("MrBean Visuals");
   public static final class_11900 CATEGORY = class_11900.method_74698(class_2960.method_60655("mrbeanvisuals", "main"));
   public static class_304 menuKey;
   public static class_304 zoomKey;
   public static class_304 hudEditorKey;
   private static final List<class_304> MOD_KEYS = new ArrayList<>();
   private static final Set<Module> heldBinds = new HashSet<>();
   private static boolean midHeld;

   public static List<class_304> modKeys() {
      return MOD_KEYS;
   }

   private static class_304 key(class_304 kb) {
      class_304 r = KeyBindingHelper.registerKeyBinding(kb);
      MOD_KEYS.add(r);
      return r;
   }

   public void onInitializeClient() {
      Modules.init();
      menuKey = key(new class_304("key.mrbeanvisuals.menu", class_307.field_1668, 344, CATEGORY));
      zoomKey = key(new class_304("key.mrbeanvisuals.zoom", class_307.field_1668, 67, CATEGORY));
      hudEditorKey = key(new class_304("key.mrbeanvisuals.hud_editor", class_307.field_1668, -1, CATEGORY));
      if (Modules.get("macros") instanceof MacroModule mm) {
         for (int i = 0; i < 6; i++) {
            mm.keys[i] = key(new class_304("key.mrbeanvisuals.macro" + (i + 1), class_307.field_1668, -1, CATEGORY));
         }
      }

      if (Modules.get("auto_duel") instanceof AutoDuel ad) {
         ad.key = key(new class_304("key.mrbeanvisuals.duel", class_307.field_1668, 71, CATEGORY));
         ClientReceiveMessageEvents.GAME.register((Game)(message, overlay) -> {
            if (!overlay) {
               ad.onMessage(message);
            }
         });
      }

      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> client.execute(() -> LastServer.remember(client)));
      if (Modules.get("emotes") instanceof Emotes.EmoteModule em) {
         em.key = key(new class_304("key.mrbeanvisuals.emote", class_307.field_1668, 66, CATEGORY));
      }

      com.mrbean.visuals.net.BadgeNetwork.init();
      com.mrbean.visuals.net.EmoteNetwork.init();
      ScreenEvents.AFTER_INIT
         .register(
            (AfterInit)(client, screen, w, h) -> {
               if (screen instanceof class_433 gm && gm.method_53558() && Modules.theme().menuButton.value) {
                  Screens.getButtons(screen)
                     .add(
                        class_4185.method_46430(class_2561.method_43470("✦ MrBean Visuals"), b -> client.method_1507(com.mrbean.visuals.gui.Screens.menu()))
                           .method_46434(6, 6, 120, 20)
                           .method_46431()
                     );
               }

               if (screen instanceof class_500 && MenuBackground.enabled()) {
                  String nick = client.method_1548().method_1676();
                  Screens.getButtons(screen)
                     .add(
                        class_4185.method_46430(class_2561.method_43470(Lang.t("Аккаунт: ", "Account: ") + nick), b -> client.method_1507(new AccountScreen(screen)))
                           .method_46434(6, 6, Math.min(170, 70 + client.field_1772.method_1727(nick)), 20)
                           .method_46431()
                     );
               }
            }
         );
      ClientSendMessageEvents.ALLOW_CHAT.register(ChatCommands::allow);
      ClientSendMessageEvents.ALLOW_CHAT.register((AllowChat)msg -> {
         if (!(Modules.get("chat_filter") instanceof RvModules.ChatFilter f)) {
            return true;
         } else {
            String r = f.check(msg);
            return r == null || !r.isEmpty();
         }
      });
      ClientSendMessageEvents.MODIFY_CHAT.register((ModifyChat)msg -> {
         if (Modules.get("chat_filter") instanceof RvModules.ChatFilter f && f.isEnabled()) {
            String low = msg.toLowerCase();
            boolean any = false;

            for (String w : f.words.value.split(",")) {
               if (!w.isBlank() && low.contains(w.trim().toLowerCase())) {
                  any = true;
               }
            }

            if (any) {
               String out = msg;

               for (String wx : f.words.value.split(",")) {
                  String t = wx.trim();
                  if (!t.isEmpty()) {
                     out = out.replaceAll("(?iu)" + Pattern.quote(t), "*".repeat(t.length()));
                  }
               }

               return out;
            }
         }

         return msg;
      });
      ClientReceiveMessageEvents.CHAT.register((Chat)(message, signed, sender, params, ts) -> {
         if (Modules.get("name_ping") instanceof RvModules.NamePing np) {
            np.onMessage(message);
         }
      });
      ClientReceiveMessageEvents.GAME.register((Game)(message, overlay) -> {
         if (!overlay && Modules.get("name_ping") instanceof RvModules.NamePing np) {
            np.onMessage(message);
         }
      });
      Config.load();
      AutoTest.init();
      CosmeticPreview.register();
      AutoTest.guiFactory = com.mrbean.visuals.gui.Screens::menu;
      AutoTest.hudEditorFactory = () -> com.mrbean.visuals.gui.Screens.hudEditor(null);
      AutoTest.wizardFactory = () -> com.mrbean.visuals.gui.Screens.wizard(null);
      ClientTickEvents.END_CLIENT_TICK.register(this::tick);
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)c -> Config.save());
      WorldRenderEvents.AFTER_ENTITIES.register(CosmeticRenderer::render);
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hit) -> {
         if (world.method_8608() && entity instanceof class_1309 le) {
            Info.onAttack(le);
            if (Modules.get("hit_particles") instanceof HelperModules.HitParticles hp) {
               hp.onHit(le);
            }

            if (Modules.get("hitmarker") instanceof VisualModules.HitMarker hm && hm.isEnabled()) {
               hm.onHit();
            }
         }

         return class_1269.field_5811;
      });
      HudElementRegistry.addLast(class_2960.method_60655("mrbeanvisuals", "hud"), (ctx, tick) -> renderHud(ctx, tick.method_60637(false)));
      LOG.info("MrBean Visuals {} загружен. Меню — правый Shift{}.", VERSION, Mobile.is() ? " / кнопка в паузе / .menu (телефон)" : "");
      if (Mobile.is()) {
         ParticleEngine.limit = Math.min(ParticleEngine.limit, 600);
      }
   }

   private void tick(class_310 mc) {
      Hooks.onTick(mc);
      if (mc.field_1755 == null && mc.method_22683() != null) {
         for (Module m : Modules.all()) {
            if (m.bind >= 0 && m.toggleable()) {
               boolean down = class_3675.method_15987(mc.method_22683(), m.bind);
               if (down && heldBinds.add(m)) {
                  m.onBindPress();
                  Config.markDirty();
               } else if (!down) {
                  heldBinds.remove(m);
               }
            }
         }

         boolean mid = GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 2) == 1;
         if (mid && !midHeld && mc.field_1692 instanceof class_1657 p) {
            String n = p.method_7334().name();
            boolean added = Friends.toggle(n);
            Notifications.push((added ? Lang.t("Друг добавлен: ", "Friend added: ") : Lang.t("Друг удалён: ", "Friend removed: ")) + n, added);
            Config.save();
         }

         midHeld = mid;
      }

      Info.tick();

      for (Module mx : Modules.all()) {
         if (mx.isEnabled()) {
            try {
               mx.onTick();
            } catch (Exception var6) {
               LOG.error("Ошибка в модуле {}", mx.id, var6);
            }
         }
      }

      ParticleEngine.tick();
      Config.tick();
      AutoTest.tick();
   }

   public static void renderHud(class_332 ctx, float delta) {
      class_310 mc = class_310.method_1551();
      if (!mc.field_1690.field_1842) {
         Hooks.beforeHud(ctx, delta);
         Info.frame();
         if (!HudModule.editing) {
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();

            for (Module m : Modules.all()) {
               if (m.isEnabled()) {
                  try {
                     if (m instanceof HudModule h) {
                        h.renderHud(ctx, delta, sw, sh);
                     } else {
                        m.renderOverlay(ctx, delta);
                     }
                  } catch (Exception var8) {
                     LOG.error("Ошибка отрисовки {}", m.id, var8);
                     R2D.alpha = 1.0F;
                     R2D.font = null;
                  }
               }
            }
         }

         if (!Hooks.menuOpen()) {
            Notifications.render(ctx);
         }
      }
   }
}
