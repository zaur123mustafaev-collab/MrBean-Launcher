package com.mrbean.visuals.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Опрос Chromium-браузера через DevTools Protocol: что сейчас играет во вкладках, название трека
 * из Media Session и кадр страницы для мини-экранчика. Работает только если браузер запущен с
 * --remote-debugging-port. Опрашивается исключительно localhost; при недоступности браузера модуль
 * молча показывает своё состояние и не шумит в логах.
 */
public final class ChromeMedia {
   public record Media(String title, String artist, String url, String docTitle, boolean playing, float pos, float dur, boolean live) {
      public String text() {
         if (!this.playing) {
            return "";
         } else {
            String t = this.title.isEmpty() ? this.docTitle : this.title;
            return this.artist.isEmpty() ? t : t + " — " + this.artist;
         }
      }
   }

   private static final String EXPRESSION = "(function(){try{var m=(navigator.mediaSession&&navigator.mediaSession.metadata)||null;"
      + "var v=document.querySelectorAll('video');var b=null;"
      + "for(var i=0;i<v.length;i++){var e=v[i];if(!e.paused&&!e.ended&&e.readyState>1){b=e;break;}}"
      + "if(!b){var a=document.querySelectorAll('audio');for(var j=0;j<a.length;j++){if(!a[j].paused&&!a[j].ended){b=a[j];break;}}}"
      + "var x=0,y=0,w=0,h=0;if(b){var r=b.getBoundingClientRect();x=Math.round(r.x);y=Math.round(r.y);w=Math.round(r.width);h=Math.round(r.height);}"
      + "var d=b?(b.duration||0):0;if(!isFinite(d)||d<=0){d=0;}"
      + "var pw=Math.round(innerWidth||0),phh=Math.round(innerHeight||0);"
      + "return JSON.stringify({t:m&&m.title?m.title:'',ar:m&&m.artist?m.artist:'',dt:document.title||'',u:location.href||'',"
      + "p:!!b,d:d,c:b?(b.currentTime||0):0,x:x,y:y,w:w,h:h,pw:pw,ph:phh});"
      + "}catch(e){return JSON.stringify({t:'',ar:'',dt:'',u:'',p:false,d:0,c:0,x:0,y:0,w:0,h:0,pw:0,ph:0});}})()";
   private static final HttpClient HTTP = HttpClient.newBuilder()
      .version(HttpClient.Version.HTTP_1_1)
      .connectTimeout(java.time.Duration.ofMillis(800))
      .build();
   private static volatile Media media = new Media("", "", "", "", false, 0.0F, 0.0F, false);
   private static volatile byte[] frame;
   private static volatile String state = "—";
   private static volatile String shotNote = "кадр ждём";
   private static volatile boolean wantFrame;
   private static volatile boolean on;
   private static int refs;
   private static int shotTick;
   private static int port = 9222;
   private static Thread worker;

   private ChromeMedia() {
   }

   public static Media media() {
      return media;
   }

   public static String state() {
      return state;
   }

   /** Последний кадр играющего видео, null — нового нет. */
   public static byte[] takeFrame() {
      byte[] f = frame;
      frame = null;
      return f;
   }

   public static void setDebugPort(int p) {
      if (p != port) {
         port = p;
         state = "—";
      }
   }

   public static void wantFrame(boolean b) {
      wantFrame = b;
      if (!b) {
         frame = null;
      } else {
         shotNote = "кадр ждём";
      }
   }

   public static synchronized void acquire() {
      refs++;
      if (on) {
         return;
      }

      on = true;
      worker = new Thread(ChromeMedia::loop, "mrbean-chrome-media");
      worker.setDaemon(true);
      worker.start();
   }

   public static synchronized void release() {
      refs = Math.max(0, refs - 1);

      if (refs == 0) {
         on = false;
         media = new Media("", "", "", "", false, 0.0F, 0.0F, false);
         state = "—";
         frame = null;
      }
   }

   public static boolean running() {
      return on;
   }

   private static void loop() {
      while (on) {
         try {
            poll();
            Thread.sleep(1100L);
         } catch (InterruptedException var2) {
            return;
         } catch (Exception var3) {
            state = "нет связи с браузером";
            try {
               Thread.sleep(4000L);
            } catch (InterruptedException var1) {
               return;
            }
         }
      }
   }

   private static void poll() throws Exception {
      shotTick++;
      String body = get("/json/list");
      JsonArrayHolder tabs = JsonArrayHolder.parse(body);

      if (tabs == null) {
         state = "порт " + port + " не отвечает";
         media = new Media("", "", "", "", false, 0.0F, 0.0F, false);
         return;
      }

      Media found = null;
      int checked = 0;
      boolean wantShot = wantFrame && shotTick % 3 == 0;

      for (JsonObject t : tabs.items) {
         if (checked >= 6) {
            break;
         }

         String ws = str(t, "webSocketDebuggerUrl");
         if (ws.isEmpty() || !"page".equals(str(t, "type"))) {
            continue;
         }

         checked++;
         // Одна вкладка — один сокет: снимок идёт в том же соединении, что и опрос, иначе
         // второе подключение к занятой цели обрывается и кадр никогда не приходит.
         Session s = null;

         try {
            s = new Session(ws);
         } catch (Exception var15) {
            shotNote = "соединение не открыть";
         }

         if (s == null) {
            continue;
         }

         try {
            M m = s.evaluate();

            if (m == null) {
               continue;
            }

            if (m.playing && found == null) {
               found = m.toMedia();

               if (wantShot) {
                  byte[] img = s.shot(m);

                  if (img != null) {
                     frame = img;
                     shotNote = "кадр " + m.vw + "x" + m.vh;
                  }
               }
            } else if (found == null && !m.title.isEmpty()) {
               found = m.toMedia();
            }
         } catch (Exception var16) {
            shotNote = "нет кадра";
         } finally {
            s.close();
         }
      }

      media = found == null ? new Media("", "", "", "", false, 0.0F, 0.0F, false) : found;
      String base = "вкладок: " + checked + (media.playing() ? " · играет" : " · тишина");
      state = wantFrame ? base + " · " + shotNote : base;
   }

   /** Одно соединение с вкладкой: опрос и снимок живут в нём же. */
   private static final class Session {
      private final WebSocket socket;
      private final Collector c = new Collector();
      private int nextId;

      Session(String ws) throws Exception {
         this.socket = HTTP.newWebSocketBuilder()
            .connectTimeout(java.time.Duration.ofMillis(1200L))
            .buildAsync(URI.create(ws), this.c)
            .get(1200L, TimeUnit.MILLISECONDS);
      }

      M evaluate() throws Exception {
         String res = this.call(
               "Runtime.evaluate", "{\"expression\":" + quote(EXPRESSION) + ",\"returnByValue\":true}", 1100L
            );
         JsonObject o = JsonParser.parseString(res).getAsJsonObject();
         JsonObject r = o.has("result") ? o.getAsJsonObject("result") : o;
         if (!r.has("result")) {
            return null;
         } else {
            JsonObject inner = r.getAsJsonObject("result");
            if (!inner.has("value")) {
               return null;
            } else {
               JsonObject v = JsonParser.parseString(inner.get("value").getAsString()).getAsJsonObject();
               M m = new M();
               m.title = str(v, "t");
               m.artist = str(v, "ar");
               m.docTitle = str(v, "dt");
               m.url = str(v, "u");
               m.playing = v.has("p") && v.get("p").getAsBoolean();
               m.dur = v.has("d") ? v.get("d").getAsFloat() : 0.0F;
               m.pos = v.has("c") ? v.get("c").getAsFloat() : 0.0F;
               m.vx = v.has("x") ? v.get("x").getAsInt() : 0;
               m.vy = v.has("y") ? v.get("y").getAsInt() : 0;
               m.vw = v.has("w") ? v.get("w").getAsInt() : 0;
               m.vh = v.has("h") ? v.get("h").getAsInt() : 0;
               m.pageW = v.has("pw") ? v.get("pw").getAsInt() : 0;
               m.pageH = v.has("ph") ? v.get("ph").getAsInt() : 0;
               return m;
            }
         }
      }

      byte[] shot(M m) {
         try {
            this.call("Page.enable", null, 1100L);
         } catch (Exception var8) {
         }

         byte[] img = null;

         if (m.vw > 40 && m.vh > 30) {
            int w = m.pageW > 0 ? Math.min(m.vw, m.pageW) : m.vw;
            int h = m.pageH > 0 ? Math.min(m.vh, m.pageH) : m.vh;
            int x = Math.max(0, Math.min(m.vx, Math.max(0, m.pageW - w)));
            int y = Math.max(0, Math.min(m.vy, Math.max(0, m.pageH - h)));
            float scale = Math.min(1.0F, 340.0F / (float)w);
            String clip = "{\"x\":" + x + ",\"y\":" + y + ",\"width\":" + w + ",\"height\":" + h + ",\"scale\":" + scale + "}";

            try {
               img = this.image("{\"format\":\"png\",\"clip\":" + clip + "}");
            } catch (Exception var17) {
               img = null;
            }
         }

         if (img == null) {
            try {
               img = this.image("{\"format\":\"png\",\"scale\":0.35}");
            } catch (Exception var16) {
               shotNote = "кадр не отдаёт браузер";
            }
         }

         return img;
      }

      private byte[] image(String params) throws Exception {
         String res = this.call("Page.captureScreenshot", params, 2600L);
         JsonObject o = JsonParser.parseString(res).getAsJsonObject();
         if (!o.has("result")) {
            return null;
         } else {
            JsonObject r = o.getAsJsonObject("result");
            if (!r.has("data")) {
               return null;
            } else {
               byte[] img = Base64.getDecoder().decode(r.get("data").getAsString());
               return img.length > 8 && img.length < 4000000 ? img : null;
            }
         }
      }

      private String call(String method, String params, long timeoutMs) throws Exception {
         int id = ++this.nextId;
         CompletableFuture<String> waiting = this.c.expect(id);
         String req = params == null
               ? "{\"id\":" + id + ",\"method\":\"" + method + "\"}"
               : "{\"id\":" + id + ",\"method\":\"" + method + "\",\"params\":" + params + "}";
         this.socket.sendText(req, true).get(timeoutMs, TimeUnit.MILLISECONDS);
         String res = waiting.get(timeoutMs, TimeUnit.MILLISECONDS);

         if (res == null) {
            throw new IllegalStateException("браузер молчит");
         } else {
            JsonObject o = JsonParser.parseString(res).getAsJsonObject();
            if (o.has("error")) {
               throw new IllegalStateException("браузер отказал");
            } else {
               return res;
            }
         }
      }

      void close() {
         try {
            this.socket.sendClose(1000, "done").get(300L, TimeUnit.MILLISECONDS);
         } catch (Exception var2) {
         }
      }
   }

   private static String get(String path) throws Exception {
      HttpRequest req = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path)).timeout(java.time.Duration.ofMillis(900)).GET().build();
      HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
      return r.statusCode() == 200 ? r.body() : null;
   }

   private static String quote(String s) {
      StringBuilder sb = new StringBuilder("\"");

      for (int i = 0; i < s.length(); i++) {
         char c = s.charAt(i);
         if (c == '"' || c == '\\') {
            sb.append('\\').append(c);
         } else if (c == '\n') {
            sb.append("\\n");
         } else if (c < ' ') {
            sb.append(String.format("\\u%04x", (int)c));
         } else {
            sb.append(c);
         }
      }

      return sb.append('"').toString();
   }

   private static String str(JsonObject o, String k) {
      return o != null && o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : "";
   }

   private static final class M {
      String title = "";
      String artist = "";
      String docTitle = "";
      String url = "";
      boolean playing;
      float dur;
      float pos;
      int vx;
      int vy;
      int vw;
      int vh;
      int pageW;
      int pageH;

      Media toMedia() {
         boolean live = this.playing && this.dur <= 0.0F;
         return new Media(this.title, this.artist, this.url, this.docTitle, this.playing, this.pos, this.dur, live);
      }
   }

   /** Обёртка над массивом вкладок, чтобы не тянуть gson ТипToken ради одного списка. */
   private static final class JsonArrayHolder {
      final List<JsonObject> items = new ArrayList<>();

      static JsonArrayHolder parse(String body) {
         if (body == null) {
            return null;
         } else {
            JsonArrayHolder h = new JsonArrayHolder();

            try {
               com.google.gson.JsonElement e = JsonParser.parseString(body);
               if (e.isJsonArray()) {
                  for (com.google.gson.JsonElement x : e.getAsJsonArray()) {
                     if (x.isJsonObject()) {
                        h.items.add(x.getAsJsonObject());
                     }
                  }

                  return h;
               }
            } catch (Exception var3) {
            }

            return null;
         }
      }
   }

   private static final class Collector implements WebSocket.Listener {
      private final StringBuilder buf = new StringBuilder();
      private final Map<Integer, CompletableFuture<String>> waiting = new ConcurrentHashMap<>();

      CompletableFuture<String> expect(int id) {
         CompletableFuture<String> f = new CompletableFuture<>();
         this.waiting.put(id, f);
         return f;
      }

      public void onOpen(WebSocket s) {
         s.request(1);
      }

      public CompletionStage<?> onText(WebSocket s, CharSequence data, boolean last) {
         this.buf.append(data);

         if (last) {
            String txt = this.buf.toString();
            this.buf.setLength(0);

            try {
               JsonObject o = JsonParser.parseString(txt).getAsJsonObject();
               if (o.has("id") && (o.has("result") || o.has("error"))) {
                  CompletableFuture<String> f = this.waiting.remove(Integer.valueOf(o.get("id").getAsInt()));
                  if (f != null) {
                     f.complete(txt);
                  }
               }
            } catch (Exception var5) {
            }
         }

         s.request(1);
         return null;
      }

      public void onError(WebSocket s, Throwable error) {
         this.failAll(error);
      }

      public CompletionStage<?> onClose(WebSocket s, int statusCode, String reason) {
         this.failAll(new IllegalStateException("соединение закрыто"));
         return null;
      }

      private void failAll(Throwable cause) {
         for (CompletableFuture<String> f : this.waiting.values()) {
            f.completeExceptionally(cause);
         }

         this.waiting.clear();
      }
   }
}
