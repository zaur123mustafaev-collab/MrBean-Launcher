package com.mrbean.visuals.module.cosmetic;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

public class Nameplate extends Module {
   public final Setting.Mode style = this.add(
      new Setting.Mode(
         "style",
         "Цвет ника",
         "Name color",
         0,
         "gradient",
         "Градиент темы",
         "Theme gradient",
         "rainbow",
         "Радуга",
         "Rainbow",
         "custom",
         "Свой цвет",
         "Custom color",
         "keep",
         "Как на сервере",
         "Server default"
      )
   );
   public final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("color", "Свой цвет", "Custom color", -11174))
      .showIf(() -> this.style.is("custom"));
   public final Setting.Mode icon = this.add(
      new Setting.Mode(
         "icon", "Значок", "Icon", 1, "none", "Нет", "None", "star", "★", "★", "crown", "♛", "♛", "leaf", "☘", "☘", "bolt", "⚡", "⚡", "heart", "❤", "❤"
      )
   );
   public final Setting.Bool bold = this.add(new Setting.Bool("bold", "Жирный", "Bold", false));
   public final Setting.Bool health = this.add(new Setting.Bool("health", "Показывать здоровье", "Show health", true));
   public final Setting.Bool others = this.add(new Setting.Bool("others", "Применять к другим игрокам", "Apply to other players", true));
   public final Setting.Bool showOwn = this.add(new Setting.Bool("show_own", "Свой ник от 3-го лица", "Own name in third person", true));

   public Nameplate() {
      super(
         "nameplate",
         Category.COSMETICS,
         false,
         "Стиль ника",
         "Custom Nameplate",
         "Градиентные ники, значок и здоровье над головой",
         "Gradient nametags with icon and health"
      );
   }

   @Override
   public boolean showInArray() {
      return true;
   }

   public class_2561 style(class_1657 p, class_2561 original) {
      boolean self = p == mc.field_1724;
      if (!self && !this.others.value) {
         return original;
      } else {
         class_5250 out = class_2561.method_43473();
         String name = this.icon.get();

         String ic = switch (name) {
            case "star" -> "★ ";
            case "crown" -> "♛ ";
            case "leaf" -> "☘ ";
            case "bolt" -> "⚡ ";
            case "heart" -> "❤ ";
            default -> "";
         };
         if (!ic.isEmpty()) {
            out.method_10852(class_2561.method_43470(ic).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(Modules.theme().accent(0.0F) & 16777215))));
         }

         if (this.style.is("keep")) {
            out.method_10852(original);
         } else {
            name = p.method_5477().getString();
            double t = System.currentTimeMillis() % 100000L / 1000.0;

            for (int i = 0; i < name.length(); i++) {
               String var11 = this.style.get();

               int c = switch (var11) {
                  case "rainbow" -> R2D.hsv((float)((i * 0.06 + t * 0.3) % 1.0), 0.7F, 1.0F);
                  case "custom" -> this.custom.argb;
                  default -> Modules.theme().accent(i * 0.05F);
               };
               out.method_10852(
                  class_2561.method_43470(String.valueOf(name.charAt(i))).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(c & 16777215)).method_10982(this.bold.value))
               );
            }
         }

         if (this.health.value) {
            float hp = p.method_6032() + p.method_6067();
            int c = R2D.healthColor(p.method_6032() / Math.max(1.0F, p.method_6063()));
            out.method_10852(class_2561.method_43470(String.format(" %.0f❤", hp)).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(c & 16777215))));
         }

         return out;
      }
   }
}
