package com.mrbean.visuals.module.cosmetic;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;

public abstract class PlayerCosmetic extends Module {
   public final Setting.Bool others = this.add(new Setting.Bool("others", "Показывать на других игроках", "Show on other players", false));
   public final Setting.Bool firstPerson = this.add(new Setting.Bool("first_person", "Видно от первого лица", "Visible in first person", false));

   protected PlayerCosmetic(String id, String ru, String en, String dRu, String dEn) {
      super(id, Category.COSMETICS, false, ru, en, dRu, dEn);
   }

   public static void fill(PlayerCosmetic.Ctx c, class_1657 p, float td) {
      c.player = p;
      c.delta = td;
      c.sneaking = p.method_18276();
      class_4050 pose = p.method_18376();
      c.headTop = p.method_17682();
      if (pose == class_4050.field_18076) {
         c.headTop = 1.8F;
      }

      if (c.sneaking) {
         c.headTop = 1.5F;
      }

      c.neck = c.headTop - 0.27F * (c.headTop / 1.8F);
      c.bodyYaw = class_3532.method_17821(td, p.field_6220, p.field_6283);
      c.headYaw = class_3532.method_17821(td, p.field_6259, p.field_6241);
      c.pitch = p.method_61414(td);
      c.time = System.currentTimeMillis() % 3600000L / 1000.0;
      double dx = p.method_23317() - p.field_6014;
      double dz = p.method_23321() - p.field_5969;
      c.speed = (float)Math.sqrt(dx * dx + dz * dz);
   }

   public boolean shouldRender(PlayerCosmetic.Ctx c) {
      return !c.self ? this.others.value : !c.firstPerson || this.firstPerson.value;
   }

   public abstract void draw(PlayerCosmetic.Ctx var1);

   public <T extends Setting> T add2(T s) {
      return this.add(s);
   }

   protected static int col(int argb, float alphaMul) {
      return R2D.mulAlpha(argb, alphaMul);
   }

   protected static int theme(float off) {
      return Modules.theme().accent(off);
   }

   public static final class Ctx {
      public class_1657 player;
      public class_4587 matrices;
      public class_4598 buffers;
      public float delta;
      public float headTop;
      public float neck;
      public float bodyYaw;
      public float headYaw;
      public float pitch;
      public boolean sneaking;
      public boolean self;
      public boolean firstPerson;
      public double time;
      public float speed;
      public boolean preview;
   }
}
