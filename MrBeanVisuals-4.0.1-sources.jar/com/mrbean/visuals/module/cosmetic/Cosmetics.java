package com.mrbean.visuals.module.cosmetic;

import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.render.World3D;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public final class Cosmetics {
   private Cosmetics() {
   }

   static Setting.Mode colorMode(PlayerCosmetic m, int def) {
      return m.add2(
         new Setting.Mode(
            "color_mode", "Цвет", "Color", def, "theme", "Цвет темы", "Theme color", "rainbow", "Радуга", "Rainbow", "custom", "Свой цвет", "Custom color"
         )
      );
   }

   static int pick(Setting.Mode mode, Setting.Color custom, float off, double time) {
      String var5 = mode.get();

      return switch (var5) {
         case "rainbow" -> R2D.hsv((float)((time * 0.2 + off) % 1.0 + 1.0) % 1.0F, 0.75F, 1.0F);
         case "custom" -> custom.argb | 0xFF000000;
         default -> PlayerCosmetic.theme(off);
      };
   }

   static void bodySpace(PlayerCosmetic.Ctx c) {
      c.matrices.method_22907(class_7833.field_40716.rotationDegrees(-c.bodyYaw));
   }

   static void headSpace(PlayerCosmetic.Ctx c, boolean tilt) {
      c.matrices.method_46416(0.0F, c.neck, 0.0F);
      c.matrices.method_22907(class_7833.field_40716.rotationDegrees(-c.headYaw));
      if (tilt) {
         c.matrices.method_22907(class_7833.field_40714.rotationDegrees(c.pitch));
      }

      c.matrices.method_46416(0.0F, c.headTop - c.neck, 0.0F);
   }

   public static class Aura extends PlayerCosmetic {
      final Setting.Mode color = Cosmetics.colorMode(this, 0);
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("color", "Свой цвет", "Custom color", -8635667))
         .showIf(() -> this.color.is("custom"));
      final Setting.Num radius = this.add(new Setting.Num("radius", "Радиус", "Radius", 0.55, 0.3, 1.5, 0.05));
      final Setting.Num height = this.add(new Setting.Num("height", "Высота", "Height", 1.6, 0.3, 2.5, 0.05));
      final Setting.Num intensity = this.add(new Setting.Num("intensity", "Яркость", "Intensity", 60.0, 5.0, 100.0, 1.0).suffix("%"));
      final Setting.Bool sparkles = this.add(new Setting.Bool("sparkles", "Искры", "Sparkles", true));
      final Setting.Bool rings = this.add(new Setting.Bool("rings", "Кольца", "Rings", true));

      public Aura() {
         super("aura", "Аура", "Player Aura", "Светящийся столб и искры вокруг игрока", "Glowing aura and sparkles around you");
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         class_4587 ms = c.matrices;
         ms.method_22903();
         Matrix4f m = ms.method_23760().method_23761();
         double t = c.time;
         float k = this.intensity.f() / 100.0F;
         class_4588 g = c.buffers.method_73477(World3D.glowLayer());
         float r = this.radius.f() + (float)Math.sin(t * 2.0) * 0.03F;
         World3D.cylinder(
            g,
            m,
            r,
            0.02F,
            this.height.f(),
            36,
            (a, s) -> R2D.withAlpha(Cosmetics.pick(this.color, this.custom, a + (float)t * 0.1F, t), (int)(150.0F * k * (1.0F - s)))
         );
         if (this.rings.value) {
            for (int i = 0; i < 2; i++) {
               float y = (float)((t * 0.6 + i * 0.5) % 1.0) * this.height.f();
               float fade = 1.0F - y / this.height.f();
               World3D.ring(g, m, y, r - 0.04F, r + 0.02F, 36, (a, s) -> R2D.withAlpha(Cosmetics.pick(this.color, this.custom, a, t), (int)(200.0F * k * fade)));
            }
         }

         ms.method_22909();
         if (this.sparkles.value && !c.preview && c.player != null && !class_310.method_1551().method_1493() && Math.random() < 0.25 * k) {
            class_1657 p = c.player;
            double ang = Math.random() * Math.PI * 2.0;
            ParticleEngine.spawn(
               p.method_23317() + Math.cos(ang) * this.radius.value,
               p.method_23318() + Math.random() * this.height.value,
               p.method_23321() + Math.sin(ang) * this.radius.value,
               0.0F,
               0.02F,
               0.0F,
               30,
               0.08F,
               Cosmetics.pick(this.color, this.custom, (float)Math.random(), t),
               0.0F,
               0.96F,
               true,
               1
            );
         }
      }
   }

   public static class Cape extends PlayerCosmetic {
      final Setting.Mode pattern = this.add(
         new Setting.Mode(
            "pattern",
            "Узор",
            "Pattern",
            0,
            "gradient",
            "Градиент",
            "Gradient",
            "stripes",
            "Полосы",
            "Stripes",
            "rainbow",
            "Радуга",
            "Rainbow",
            "solid",
            "Однотонный",
            "Solid"
         )
      );
      final Setting.Bool themeColors = this.add(new Setting.Bool("theme_colors", "Цвета темы", "Theme colors", true));
      final Setting.Color color1 = (Setting.Color)this.add(new Setting.Color("color1", "Цвет 1", "Color 1", -14735049)).showIf(() -> !this.themeColors.value);
      final Setting.Color color2 = (Setting.Color)this.add(new Setting.Color("color2", "Цвет 2", "Color 2", -13703779)).showIf(() -> !this.themeColors.value);
      final Setting.Num length = this.add(new Setting.Num("length", "Длина", "Length", 1.0, 0.6, 1.4, 0.05));
      final Setting.Num sway = this.add(new Setting.Num("sway", "Развевание", "Flutter", 1.0, 0.0, 2.0, 0.1));
      private final Map<UUID, Float> angle = new HashMap<>();
      private static final UUID PREVIEW = new UUID(0L, 0L);

      public Cape() {
         super("cape", "Плащ", "Cosmetic Cape", "Развевающийся плащ (виден только тебе)", "Fluttering cosmetic cape (client-side)");
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         class_4587 ms = c.matrices;
         ms.method_22903();
         Cosmetics.bodySpace(c);
         float top = c.sneaking ? 1.2F : 1.45F;
         ms.method_46416(0.0F, top, c.sneaking ? -0.28F : -0.15F);
         float target = Math.min(70.0F, 8.0F + c.speed * 220.0F * this.sway.f()) + (float)Math.sin(c.time * 3.0) * 3.0F * this.sway.f();
         if (c.sneaking) {
            target += 25.0F;
         }

         UUID key = !c.preview && c.player != null ? c.player.method_5667() : PREVIEW;
         float cur = this.angle.getOrDefault(key, target);
         cur += (target - cur) * 0.08F;
         this.angle.put(key, cur);
         ms.method_22907(class_7833.field_40714.rotationDegrees(cur));
         Matrix4f m = ms.method_23760().method_23761();
         class_4588 vc = c.buffers.method_73477(World3D.normalLayer());
         float w = 0.3F;
         float len = this.length.f();
         int rows = 10;
         double t = c.time;
         int c1 = this.themeColors.value ? R2D.brighten(theme(0.0F), 0.35F) : this.color1.argb | 0xFF000000;
         int c2 = this.themeColors.value ? theme(0.3F) : this.color2.argb | 0xFF000000;

         for (int i = 0; i < rows; i++) {
            float y0 = -len * i / rows;
            float y1 = -len * (i + 1) / rows;
            float wave0 = (float)Math.sin(c.time * 4.0 - i * 0.6) * 0.02F * this.sway.f() * i / rows;
            float wave1 = (float)Math.sin(c.time * 4.0 - (i + 1) * 0.6) * 0.02F * this.sway.f() * (i + 1) / rows;
            int ca = this.colorRow((float)i / rows, c1, c2, t);
            int cb = this.colorRow((float)(i + 1) / rows, c1, c2, t);
            World3D.quad(
               vc, m, new float[]{-w, y0, -wave0}, new float[]{w, y0, -wave0}, new float[]{w, y1, -wave1}, new float[]{-w, y1, -wave1}, ca, ca, cb, cb
            );
         }

         ms.method_22909();
      }

      private int colorRow(float k, int c1, int c2, double t) {
         String var6 = this.pattern.get();

         return switch (var6) {
            case "stripes" -> ((int)(k * 6.0F) & 1) == 0 ? c1 : c2;
            case "rainbow" -> R2D.hsv((float)((k + t * 0.15) % 1.0), 0.7F, 0.95F);
            case "solid" -> c2;
            default -> R2D.lerp(c2, c1, k);
         };
      }
   }

   public static class Companion extends PlayerCosmetic {
      final Setting.Mode kind = this.add(
         new Setting.Mode("kind", "Спутник", "Companion", 0, "bean", "Бобик", "Bean", "slime", "Слайм", "Slime", "spark", "Искорка", "Spark")
      );
      final Setting.Mode side = this.add(new Setting.Mode("side", "Плечо", "Shoulder", 0, "right", "Правое", "Right", "left", "Левое", "Left"));
      final Setting.Num size = this.add(new Setting.Num("size", "Размер", "Size", 1.0, 0.5, 2.0, 0.05));
      private final Map<UUID, class_243> smooth = new HashMap<>();

      public Companion() {
         super("companion", "Спутник на плече", "Shoulder Companion", "Маленький питомец парит у плеча", "A tiny pet floats by your shoulder");
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         class_4587 ms = c.matrices;
         ms.method_22903();
         Cosmetics.bodySpace(c);
         float sx = this.side.is("right") ? -0.55F : 0.55F;
         float bob = (float)Math.sin(c.time * 2.6) * 0.06F;
         ms.method_46416(sx, (c.sneaking ? 1.3F : 1.6F) + bob, -0.05F);
         ms.method_22907(class_7833.field_40716.rotationDegrees((float)Math.sin(c.time * 1.3) * 20.0F));
         float s = this.size.f();
         ms.method_22905(s, s, s);
         Matrix4f m = ms.method_23760().method_23761();
         class_4588 vc = c.buffers.method_73477(World3D.normalLayer());
         String kind = this.kind.get();
         switch (kind) {
            case "slime":
               World3D.cube(vc, m, 0.22F, -1334323094, -1336098992, -1337947592);
               World3D.cube(vc, m, 0.12F, -11624892, -11624892, -12944845);
               break;
            case "spark":
               class_4588 g = c.buffers.method_73477(World3D.glowLayer());
               int col = theme((float)c.time * 0.2F);
               World3D.cube(g, m, 0.12F, col, col, col);
               ms.method_22903();
               ms.method_22907(class_7833.field_40716.rotationDegrees(45.0F));
               ms.method_22907(class_7833.field_40714.rotationDegrees(45.0F));
               World3D.cube(g, ms.method_23760().method_23761(), 0.1F, -1862270977, -1862270977, -1862270977);
               ms.method_22909();
               vc = null;
               break;
            default:
               int body = theme(0.0F);
               World3D.cube(vc, m, 0.2F, R2D.brighten(body, 1.05F), body, R2D.brighten(body, 0.6F));
               ms.method_22903();
               ms.method_46416(0.05F, 0.08F, 0.04F);
               World3D.cube(vc, ms.method_23760().method_23761(), 0.08F, R2D.lerp(body, -1, 0.3F), R2D.lerp(body, -1, 0.3F), body);
               ms.method_22909();
         }

         if (vc != null) {
            int eye = -15658735;

            for (int e = -1; e <= 1; e += 2) {
               ms.method_22903();
               ms.method_46416(e * 0.045F, 0.02F, 0.105F);
               World3D.cube(c.buffers.method_73477(World3D.normalLayer()), ms.method_23760().method_23761(), 0.035F, eye, eye, eye);
               ms.method_22909();
            }
         }

         ms.method_22909();
      }
   }

   public static class Crown extends PlayerCosmetic {
      final Setting.Mode style = this.add(
         new Setting.Mode("style", "Вид", "Style", 0, "gold", "Золотая", "Golden", "diamond", "Бриллиантовая", "Diamond", "theme", "Цвет темы", "Theme")
      );
      final Setting.Num size = this.add(new Setting.Num("size", "Размер", "Size", 1.0, 0.5, 2.0, 0.05));
      final Setting.Num height = this.add(new Setting.Num("height", "Высота", "Height", 0.12, 0.0, 0.8, 0.01));
      final Setting.Bool floatAnim = this.add(new Setting.Bool("float", "Парящая (вращается)", "Floating (spins)", true));
      final Setting.Bool gems = this.add(new Setting.Bool("gems", "Камни", "Gems", true));

      public Crown() {
         super("crown", "Корона", "Floating Crown", "Парящая корона над головой", "Floating crown above your head");
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         class_4587 ms = c.matrices;
         ms.method_22903();
         Cosmetics.headSpace(c, false);
         float s = this.size.f();
         float y = this.height.f() + (this.floatAnim.value ? (float)Math.sin(c.time * 2.0) * 0.03F : 0.0F);
         ms.method_46416(0.0F, y, 0.0F);
         if (this.floatAnim.value) {
            ms.method_22907(class_7833.field_40716.rotationDegrees((float)(c.time * 40.0 % 360.0)));
         }

         ms.method_22905(s, s, s);
         Matrix4f m = ms.method_23760().method_23761();
         String styleKey = this.style.get();
         int base;
         int light;
         int gem;
         switch (styleKey) {
            case "diamond":
               base = -8395022;
               light = -2491393;
               gem = -12877066;
               break;
            case "theme":
               base = theme(0.0F);
               light = R2D.lerp(theme(0.3F), -1, 0.4F);
               gem = theme(0.5F);
               break;
            default:
               base = -1525968;
               light = -7558;
               gem = -2024120;
         }

         class_4588 vc = c.buffers.method_73477(World3D.normalLayer());
         float r = 0.24F;
         float band = 0.07F;
         int seg = 32;
         World3D.cylinder(vc, m, r, 0.0F, band, seg, (a, t) -> R2D.brighten(t > 0.5F ? light : base, 0.8F + 0.2F * (float)Math.cos(a * Math.PI * 2.0)));
         World3D.cylinder(vc, m, r * 0.97F, 0.0F, band, seg, (a, t) -> R2D.brighten(base, 0.6F));
         int spikes = 8;

         for (int i = 0; i < spikes; i++) {
            double a0 = (double)i / spikes * Math.PI * 2.0;
            double a1 = (double)(i + 1) / spikes * Math.PI * 2.0;
            double am = (a0 + a1) / 2.0;
            float[] p0 = new float[]{(float)Math.cos(a0) * r, band, (float)Math.sin(a0) * r};
            float[] p1 = new float[]{(float)Math.cos(a1) * r, band, (float)Math.sin(a1) * r};
            float[] tip = new float[]{(float)Math.cos(am) * r, band + 0.13F, (float)Math.sin(am) * r};
            int sh = R2D.brighten(light, 0.85F + 0.15F * (float)Math.cos(am));
            World3D.quad(vc, m, p0, p1, tip, tip, base, base, sh, sh);
         }

         if (this.gems.value) {
            for (int i = 0; i < spikes; i++) {
               double am = (i + 0.5) / spikes * Math.PI * 2.0;
               ms.method_22903();
               ms.method_46416((float)Math.cos(am) * r * 1.02F, band * 0.5F, (float)Math.sin(am) * r * 1.02F);
               ms.method_22907(class_7833.field_40716.rotation((float)(-am)));
               World3D.cube(c.buffers.method_73477(World3D.normalLayer()), ms.method_23760().method_23761(), 0.035F, gem, gem, gem);
               ms.method_22909();
            }
         }

         ms.method_22909();
      }
   }

   public static class Halo extends PlayerCosmetic {
      final Setting.Mode color = Cosmetics.colorMode(this, 2);
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("color", "Свой цвет", "Custom color", -11174))
         .showIf(() -> this.color.is("custom"));
      final Setting.Num radius = this.add(new Setting.Num("radius", "Радиус", "Radius", 0.28, 0.15, 0.6, 0.01));
      final Setting.Num thick = this.add(new Setting.Num("thickness", "Толщина", "Thickness", 0.035, 0.01, 0.1, 0.005));
      final Setting.Num height = this.add(new Setting.Num("height", "Высота над головой", "Height above head", 0.22, 0.05, 0.8, 0.01));
      final Setting.Bool bob = this.add(new Setting.Bool("bob", "Парение", "Floating", true));
      final Setting.Bool glow = this.add(new Setting.Bool("glow", "Свечение", "Glow", true));
      final Setting.Bool tilt = this.add(new Setting.Bool("tilt", "Наклон с головой", "Tilt with head", true));

      public Halo() {
         super("halo", "Нимб", "Halo", "Светящийся нимб над головой", "Glowing halo above your head");
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         class_4587 ms = c.matrices;
         ms.method_22903();
         Cosmetics.headSpace(c, this.tilt.value);
         float y = this.height.f() + (this.bob.value ? (float)Math.sin(c.time * 2.2) * 0.03F : 0.0F);
         ms.method_46416(0.0F, y, 0.0F);
         ms.method_22907(class_7833.field_40714.rotationDegrees(-8.0F));
         Matrix4f m = ms.method_23760().method_23761();
         double t = c.time;
         class_4588 vc = c.buffers.method_73477(World3D.normalLayer());
         World3D.torus(vc, m, this.radius.f(), this.thick.f(), 40, 8, (a, s) -> R2D.withAlpha(Cosmetics.pick(this.color, this.custom, a, t), 235));
         if (this.glow.value) {
            class_4588 g = c.buffers.method_73477(World3D.glowLayer());
            World3D.ring(
               g,
               m,
               0.0F,
               this.radius.f() - this.thick.f() * 2.5F,
               this.radius.f(),
               40,
               (a, s) -> R2D.withAlpha(Cosmetics.pick(this.color, this.custom, a, t), s > 0.5F ? 110 : 0)
            );
            World3D.ring(
               g,
               m,
               0.0F,
               this.radius.f(),
               this.radius.f() + this.thick.f() * 2.5F,
               40,
               (a, s) -> R2D.withAlpha(Cosmetics.pick(this.color, this.custom, a, t), s < 0.5F ? 110 : 0)
            );
         }

         ms.method_22909();
      }
   }

   public static class MoveParticles extends PlayerCosmetic {
      final Setting.Bool steps = this.add(new Setting.Bool("steps", "Следы шагов", "Footsteps", true));
      final Setting.Bool jump = this.add(new Setting.Bool("jump", "Прыжок", "Jump burst", true));
      final Setting.Bool land = this.add(new Setting.Bool("land", "Приземление", "Landing burst", true));
      final Setting.Mode color = Cosmetics.colorMode(this, 0);
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("color", "Свой цвет", "Custom color", -1)).showIf(() -> this.color.is("custom"));
      final Setting.Num amount = this.add(new Setting.Num("amount", "Количество", "Amount", 1.0, 0.2, 3.0, 0.1).suffix("x"));
      private final Map<UUID, double[]> state = new HashMap<>();

      public MoveParticles() {
         super("move_particles", "Частицы движения", "Movement Particles", "Частицы при шагах, прыжках и приземлении", "Particles on steps, jumps and landings");
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
      }

      @Override
      public void onTick() {
         if (mc.field_1687 != null && !mc.method_1493()) {
            double t = System.currentTimeMillis() % 3600000L / 1000.0;

            for (class_1657 p : mc.field_1687.method_18456()) {
               if ((p == mc.field_1724 || this.others.value) && !p.method_7325() && !p.method_5756(mc.field_1724)) {
                  double[] s = this.state.computeIfAbsent(p.method_5667(), u -> new double[]{0.0, 1.0, p.method_23318()});
                  boolean ground = p.method_24828();
                  double dx = p.method_23317() - p.field_6014;
                  double dz = p.method_23321() - p.field_5969;
                  if (ground && this.steps.value) {
                     s[0] += Math.sqrt(dx * dx + dz * dz);
                     if (s[0] > 0.9) {
                        s[0] = 0.0;

                        for (int i = 0; i < (int)Math.ceil(3.0 * this.amount.value); i++) {
                           ParticleEngine.spawn(
                              p.method_23317() + (Math.random() - 0.5) * 0.3,
                              p.method_23318() + 0.05,
                              p.method_23321() + (Math.random() - 0.5) * 0.3,
                              (float)(Math.random() - 0.5) * 0.03F,
                              0.02F,
                              (float)(Math.random() - 0.5) * 0.03F,
                              18,
                              0.07F,
                              Cosmetics.pick(this.color, this.custom, (float)Math.random(), t),
                              0.002F,
                              0.92F,
                              true,
                              1
                           );
                        }
                     }
                  }

                  if (s[1] > 0.0 && !ground && p.method_18798().field_1351 > 0.2 && this.jump.value) {
                     this.burst(p, 10, 0.08F, t);
                  }

                  if (!ground && s[1] > 0.0) {
                     s[2] = p.method_23318();
                  }

                  if (!ground) {
                     s[2] = Math.max(s[2], p.method_23318());
                  }

                  if (ground && s[1] == 0.0 && s[2] - p.method_23318() > 1.2 && this.land.value) {
                     this.burst(p, 22, 0.14F, t);
                  }

                  s[1] = ground ? 1.0 : 0.0;
               }
            }

            this.state.keySet().removeIf(u -> mc.field_1687.method_18470(u) == null);
         }
      }

      private void burst(class_1657 p, int n, float spd, double t) {
         int count = (int)Math.ceil(n * this.amount.value);

         for (int i = 0; i < count; i++) {
            double a = (double)i / count * Math.PI * 2.0;
            ParticleEngine.spawn(
               p.method_23317(),
               p.method_23318() + 0.1,
               p.method_23321(),
               (float)Math.cos(a) * spd,
               0.03F,
               (float)Math.sin(a) * spd,
               20,
               0.09F,
               Cosmetics.pick(this.color, this.custom, (float)i / count, t),
               0.003F,
               0.9F,
               true,
               0
            );
         }
      }
   }

   public static class Trail extends PlayerCosmetic {
      final Setting.Mode color = Cosmetics.colorMode(this, 1);
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("color", "Свой цвет", "Custom color", -14494738))
         .showIf(() -> this.color.is("custom"));
      final Setting.Num length = this.add(new Setting.Num("length", "Длина", "Length", 20.0, 5.0, 60.0, 1.0));
      final Setting.Num width = this.add(new Setting.Num("width", "Высота ленты", "Ribbon height", 0.35, 0.05, 1.5, 0.05));
      final Setting.Bool glow = this.add(new Setting.Bool("glow", "Свечение", "Glow", true));
      private final Map<UUID, ArrayDeque<class_243>> history = new HashMap<>();

      public Trail() {
         super("trail", "Шлейф", "Cosmetic Trail", "Светящаяся лента за игроком", "Glowing ribbon trail behind you");
      }

      @Override
      public void onTick() {
         if (mc.field_1687 == null) {
            this.history.clear();
         } else {
            for (class_1657 p : mc.field_1687.method_18456()) {
               if (p == mc.field_1724 || this.others.value) {
                  ArrayDeque<class_243> h = this.history.computeIfAbsent(p.method_5667(), u -> new ArrayDeque<>());
                  class_243 pos = p.method_73189();
                  if (h.isEmpty() || h.peekLast().method_1025(pos) > 4.0E-4) {
                     h.addLast(pos);
                  } else if (h.size() > 1) {
                     h.pollFirst();
                  }

                  while (h.size() > this.length.i()) {
                     h.pollFirst();
                  }
               }
            }

            this.history.keySet().removeIf(u -> mc.field_1687.method_18470(u) == null);
         }
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         if (!c.preview && c.player != null) {
            ArrayDeque<class_243> h = this.history.get(c.player.method_5667());
            if (h != null && h.size() >= 2) {
               class_243 base = c.player.method_30950(c.delta);
               Matrix4f m = c.matrices.method_23760().method_23761();
               class_4588 vc = c.buffers.method_73477(this.glow.value ? World3D.glowLayer() : World3D.normalLayer());
               class_243 prev = null;
               int i = 0;
               int n = h.size();
               double t = c.time;
               float hh = this.width.f();

               for (class_243 p : h) {
                  if (prev != null) {
                     float k0 = (float)(i - 1) / n;
                     float k1 = (float)i / n;
                     int c0 = R2D.withAlpha(Cosmetics.pick(this.color, this.custom, k0, t), (int)(200.0F * k0));
                     int c1 = R2D.withAlpha(Cosmetics.pick(this.color, this.custom, k1, t), (int)(200.0F * k1));
                     float ax = (float)(prev.field_1352 - base.field_1352);
                     float az = (float)(prev.field_1350 - base.field_1350);
                     float ay = (float)(prev.field_1351 - base.field_1351) + 0.1F;
                     float bx = (float)(p.field_1352 - base.field_1352);
                     float bz = (float)(p.field_1350 - base.field_1350);
                     float by = (float)(p.field_1351 - base.field_1351) + 0.1F;
                     World3D.quad(
                        vc,
                        m,
                        new float[]{ax, ay, az},
                        new float[]{bx, by, bz},
                        new float[]{bx, by + hh * k1, bz},
                        new float[]{ax, ay + hh * k0, az},
                        c0,
                        c1,
                        R2D.withAlpha(c1, 0),
                        R2D.withAlpha(c0, 0)
                     );
                  }

                  prev = p;
                  i++;
               }
            }
         }
      }
   }

   public static class Wings extends PlayerCosmetic {
      final boolean devil;
      final Setting.Mode color = Cosmetics.colorMode(this, 2);
      final Setting.Color custom;
      final Setting.Num size = this.add(new Setting.Num("size", "Размер", "Size", 1.0, 0.5, 2.0, 0.05));
      final Setting.Num flap = this.add(new Setting.Num("flap", "Скорость взмахов", "Flap speed", 1.0, 0.0, 4.0, 0.1));
      final Setting.Num opacity = this.add(new Setting.Num("opacity", "Непрозрачность", "Opacity", 95.0, 10.0, 100.0, 1.0).suffix("%"));
      final Setting.Bool glow = this.add(new Setting.Bool("glow", "Свечение кончиков", "Glowing tips", true));

      public Wings(boolean devil) {
         super(
            devil ? "devil_wings" : "angel_wings",
            devil ? "Крылья демона" : "Крылья ангела",
            devil ? "Devil Wings" : "Angel Wings",
            devil ? "Перепончатые крылья с анимацией взмахов" : "Пушистые крылья с анимацией взмахов",
            devil ? "Bat-like wings with flapping animation" : "Feathered wings with flapping animation"
         );
         this.devil = devil;
         this.custom = (Setting.Color)this.add(new Setting.Color("color", "Свой цвет", "Custom color", devil ? -7659987 : -658454))
            .showIf(() -> this.color.is("custom"));
      }

      private int base(float off, double t) {
         if (this.color.is("custom")) {
            return this.custom.argb | 0xFF000000;
         } else {
            return this.color.is("theme") ? theme(off) : R2D.hsv((float)((t * 0.2 + off) % 1.0 + 1.0) % 1.0F, 0.6F, 1.0F);
         }
      }

      @Override
      public void draw(PlayerCosmetic.Ctx c) {
         class_4587 ms = c.matrices;
         ms.method_22903();
         Cosmetics.bodySpace(c);
         float shoulder = c.sneaking ? 1.12F : 1.38F;
         ms.method_46416(0.0F, shoulder, c.sneaking ? -0.32F : -0.16F);
         if (c.sneaking) {
            ms.method_22907(class_7833.field_40714.rotationDegrees(28.0F));
         }

         float s = this.size.f();
         ms.method_22905(s, s, s);
         boolean air = !c.preview && c.player != null && !c.player.method_24828();
         double speed = this.flap.value * (air ? 2.2 : 1.0) + c.speed * 4.0F;
         float open = (float)(Math.sin(c.time * 3.2 * speed) * 0.5 + 0.5);
         float angle = 18.0F + 32.0F * open;
         float op = this.opacity.f() / 100.0F;
         double t = c.time;

         for (int side = -1; side <= 1; side += 2) {
            ms.method_22903();
            ms.method_46416(side * 0.1F, 0.0F, 0.0F);
            ms.method_22907(class_7833.field_40716.rotationDegrees(side * angle));
            Matrix4f m = ms.method_23760().method_23761();
            if (this.devil) {
               this.drawDevil(c, m, side, op, t);
            } else {
               this.drawAngel(c, m, side, op, t);
            }

            ms.method_22909();
         }

         ms.method_22909();
      }

      private void drawAngel(PlayerCosmetic.Ctx c, Matrix4f m, int side, float op, double t) {
         class_4588 vc = c.buffers.method_73477(World3D.normalLayer());
         float tipX = 0.95F * side;
         float tipY = 0.42F;
         int feathers = 11;

         for (int layer = 0; layer < 3; layer++) {
            float lenMul = layer == 0 ? 1.0F : (layer == 1 ? 0.62F : 0.35F);
            float z = -0.02F - layer * 0.015F;

            for (int i = 0; i < feathers; i++) {
               float k = (i + 0.5F) / feathers;
               float ax = tipX * k;
               float ay = tipY * k * (1.15F - 0.15F * k);
               double ang = Math.toRadians(-95.0F + 55.0F * k);
               float len = (0.28F + 0.55F * k) * lenMul;
               float dx = (float)Math.cos(ang) * len * side;
               float dy = (float)Math.sin(ang) * len;
               float wdt = 0.055F + 0.02F * k;
               float nx = (float)(-Math.sin(ang)) * wdt * side;
               float ny = (float)Math.cos(ang) * wdt;
               float shade = layer == 0 ? 0.86F : (layer == 1 ? 0.95F : 1.02F);
               int root = R2D.withAlpha(R2D.brighten(this.base(k * 0.3F, t), shade), (int)(255.0F * op));
               int tip = R2D.withAlpha(R2D.lerp(R2D.brighten(this.base(k * 0.3F + 0.15F, t), shade), -1, 0.2F), (int)(255.0F * op));
               World3D.quad(
                  vc,
                  m,
                  new float[]{ax - nx * 0.6F, ay - ny * 0.6F, z},
                  new float[]{ax + nx * 0.6F, ay + ny * 0.6F, z},
                  new float[]{ax + dx * 0.85F + nx, ay + dy * 0.85F + ny, z - 0.01F},
                  new float[]{ax + dx * 0.85F - nx, ay + dy * 0.85F - ny, z - 0.01F},
                  root,
                  root,
                  tip,
                  tip
               );
               World3D.quad(
                  vc,
                  m,
                  new float[]{ax + dx * 0.85F - nx, ay + dy * 0.85F - ny, z - 0.01F},
                  new float[]{ax + dx * 0.85F + nx, ay + dy * 0.85F + ny, z - 0.01F},
                  new float[]{ax + dx, ay + dy, z - 0.012F},
                  new float[]{ax + dx, ay + dy, z - 0.012F},
                  tip,
                  tip,
                  tip,
                  tip
               );
            }
         }

         int arm = R2D.withAlpha(R2D.lerp(this.base(0.0F, t), -1, 0.35F), (int)(255.0F * op));
         World3D.quad(
            vc,
            m,
            new float[]{0.0F, -0.04F, -0.07F},
            new float[]{0.0F, 0.04F, -0.07F},
            new float[]{tipX, tipY + 0.025F, -0.07F},
            new float[]{tipX, tipY - 0.025F, -0.07F},
            arm,
            arm,
            arm,
            arm
         );
         if (this.glow.value) {
            class_4588 g = c.buffers.method_73477(World3D.glowLayer());
            int gc = R2D.withAlpha(this.base(0.5F, t), (int)(70.0F * op));
            World3D.quad(
               g,
               m,
               new float[]{0.0F, -0.07F, -0.08F},
               new float[]{0.0F, 0.07F, -0.08F},
               new float[]{tipX, tipY + 0.06F, -0.08F},
               new float[]{tipX, tipY - 0.06F, -0.08F},
               gc,
               gc,
               R2D.withAlpha(gc, 0),
               R2D.withAlpha(gc, 0)
            );
         }
      }

      private void drawDevil(PlayerCosmetic.Ctx c, Matrix4f m, int side, float op, double t) {
         class_4588 vc = c.buffers.method_73477(World3D.normalLayer());
         int bones = 5;
         float[][] tips = new float[bones][];

         for (int i = 0; i < bones; i++) {
            float k = (float)i / (bones - 1);
            double ang = Math.toRadians(60.0F - k * 100.0F);
            float len = 0.95F - 0.35F * k;
            tips[i] = new float[]{(float)Math.cos(ang) * len * side, (float)Math.sin(ang) * len, -0.04F};
         }

         int membrane = R2D.withAlpha(R2D.brighten(this.base(0.0F, t), 0.75F), (int)(225.0F * op));
         int membraneEdge = R2D.withAlpha(R2D.brighten(this.base(0.2F, t), 0.5F), (int)(235.0F * op));
         float[] root = new float[]{0.0F, 0.0F, 0.0F};

         for (int i = 0; i < bones - 1; i++) {
            float[] a = tips[i];
            float[] b = tips[i + 1];
            float[] mid = new float[]{(a[0] + b[0]) * 0.38F, (a[1] + b[1]) * 0.38F, -0.03F};
            World3D.quad(vc, m, root, a, mid, b, membrane, membraneEdge, membrane, membraneEdge);
         }

         int bone = R2D.withAlpha(R2D.brighten(this.base(0.1F, t), 0.35F), (int)(255.0F * op));

         for (float[] tp : tips) {
            World3D.quad(
               vc,
               m,
               new float[]{0.0F, 0.025F, -0.05F},
               new float[]{0.0F, -0.025F, -0.05F},
               new float[]{tp[0], tp[1] - 0.012F, -0.05F},
               new float[]{tp[0], tp[1] + 0.012F, -0.05F},
               bone,
               bone,
               bone,
               bone
            );
         }

         if (this.glow.value) {
            class_4588 g = c.buffers.method_73477(World3D.glowLayer());
            int gc = R2D.withAlpha(-53200, (int)(140.0F * op));
            float[] tp = tips[0];
            World3D.quad(
               g,
               m,
               new float[]{tp[0] - 0.04F, tp[1] - 0.04F, -0.06F},
               new float[]{tp[0] + 0.04F, tp[1] - 0.04F, -0.06F},
               new float[]{tp[0] + 0.04F, tp[1] + 0.04F, -0.06F},
               new float[]{tp[0] - 0.04F, tp[1] + 0.04F, -0.06F},
               gc,
               gc,
               gc,
               gc
            );
         }
      }
   }
}
