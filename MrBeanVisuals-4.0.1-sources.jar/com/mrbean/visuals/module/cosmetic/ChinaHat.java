package com.mrbean.visuals.module.cosmetic;

import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.render.World3D;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public class ChinaHat extends PlayerCosmetic {
   public final Setting.Mode mode = this.add(
      new Setting.Mode(
         "mode",
         "Режим",
         "Mode",
         2,
         "static",
         "Статичный",
         "Static",
         "rainbow",
         "Радуга",
         "Rainbow",
         "gradient",
         "Градиент",
         "Gradient",
         "spinning",
         "Вращение",
         "Spinning",
         "glowing",
         "Свечение",
         "Glowing",
         "transparent",
         "Прозрачный",
         "Transparent",
         "neon",
         "Неон",
         "Neon"
      )
   );
   public final Setting.Num radius = this.add(new Setting.Num("radius", "Радиус", "Radius", 0.65, 0.3, 1.5, 0.05));
   public final Setting.Num height = this.add(new Setting.Num("height", "Высота", "Height", 0.3, 0.1, 1.0, 0.05));
   public final Setting.Num opacity = this.add(new Setting.Num("opacity", "Непрозрачность", "Opacity", 75.0, 0.0, 100.0, 1.0).suffix("%"));
   public final Setting.Num offset = this.add(new Setting.Num("offset", "Смещение по высоте", "Vertical offset", 0.05, -0.3, 0.8, 0.01));
   public final Setting.Num rotSpeed = this.add(new Setting.Num("rot_speed", "Скорость вращения", "Rotation speed", 2.0, 0.0, 10.0, 0.5));
   public final Setting.Num rotation = this.add(new Setting.Num("rotation", "Поворот", "Rotation", 0.0, 0.0, 360.0, 5.0).suffix("°"));
   public final Setting.Bool themeColors = this.add(new Setting.Bool("theme_colors", "Цвета темы", "Use theme colors", true));
   public final Setting.Color color1 = (Setting.Color)this.add(new Setting.Color("color1", "Цвет 1", "Color 1", -13703779))
      .showIf(() -> !this.themeColors.value);
   public final Setting.Color color2 = (Setting.Color)this.add(new Setting.Color("color2", "Цвет 2", "Color 2", -6557078))
      .showIf(() -> !this.themeColors.value);
   public final Setting.Bool followHead = this.add(new Setting.Bool("follow_head", "Наклон вместе с головой", "Tilt with head", true));
   public final Setting.Bool outline = this.add(new Setting.Bool("outline", "Светящийся край", "Glowing rim", true));
   public final Setting.Num quality = this.add(new Setting.Num("quality", "Качество (сегменты)", "Quality (segments)", 48.0, 12.0, 128.0, 4.0));

   public ChinaHat() {
      super(
         "china_hat",
         "Китайская шляпа",
         "China Hat",
         "Конусная шляпа над головой: радуга, градиент, неон и другие режимы",
         "Conical hat above your head with rainbow, gradient, neon modes"
      );
   }

   private int c1(float off) {
      return this.themeColors.value ? theme(off) : this.color1.argb | 0xFF000000;
   }

   private int c2(float off) {
      return this.themeColors.value ? theme(off + 0.5F) : this.color2.argb | 0xFF000000;
   }

   public int colorAt(float a, float t, double time) {
      float op = this.opacity.f() / 100.0F;
      float spin = (float)(time * this.rotSpeed.value * 0.15);
      String var7 = this.mode.get();

      return switch (var7) {
         case "static" -> shade(this.c1(0.0F), a, t, op);
         case "rainbow" -> shade(R2D.hsv(((a + spin) % 1.0F + 1.0F) % 1.0F, 0.75F, 1.0F), a, t, op);
         case "gradient" -> {
            float k = (float)((Math.sin((a + spin) * Math.PI * 2.0) + 1.0) / 2.0);
            int base = R2D.lerp(this.c1(0.0F), this.c2(0.0F), k);
            int tip = R2D.lerp(base, -1, 0.25F);
            yield shade(R2D.lerp(tip, base, t), a, t, op);
         }
         case "spinning" -> {
            int stripes = 8;
            boolean even = ((int)Math.floor((a + spin) * stripes) & 1) == 0;
            yield shade(even ? R2D.lerp(this.c1(0.0F), -1, 0.15F) : R2D.brighten(this.c2(0.0F), 0.45F), a, t, op);
         }
         case "glowing" -> {
            float pulse = (float)(0.65 + 0.35 * Math.sin(time * 3.0));
            yield R2D.withAlpha(this.c1(a * 0.5F), (int)(255.0F * op * pulse * (0.35F + 0.65F * t)));
         }
         case "transparent" -> R2D.withAlpha(R2D.lerp(this.c1(0.0F), -1, 0.3F), (int)(255.0F * op * 0.3F));
         case "neon" -> R2D.withAlpha(R2D.brighten(R2D.hsv(((a + spin) % 1.0F + 1.0F) % 1.0F, 0.9F, 1.0F), 0.35F), (int)(255.0F * op * (0.55F + 0.3F * t)));
         default -> this.c1(0.0F);
      };
   }

   private static int shade(int c, float a, float t, float op) {
      float light = 0.78F + 0.22F * (float)Math.cos((a - 0.15) * Math.PI * 2.0);
      float edge = 1.0F - 0.12F * t;
      return R2D.withAlpha(R2D.brighten(c, light * edge), (int)(255.0F * op));
   }

   private boolean glowMode() {
      return this.mode.is("glowing");
   }

   @Override
   public void draw(PlayerCosmetic.Ctx c) {
      class_4587 ms = c.matrices;
      ms.method_22903();
      ms.method_46416(0.0F, c.neck, 0.0F);
      ms.method_22907(class_7833.field_40716.rotationDegrees(-c.headYaw));
      if (this.followHead.value) {
         ms.method_22907(class_7833.field_40714.rotationDegrees(c.pitch));
      }

      float top = c.headTop - c.neck;
      ms.method_46416(0.0F, top + this.offset.f(), 0.0F);
      float spinDeg = (float)(c.time * this.rotSpeed.value * 36.0 % 360.0);
      ms.method_22907(class_7833.field_40716.rotationDegrees(this.rotation.f() + (!this.mode.is("spinning") && !this.mode.is("rainbow") ? spinDeg : 0.0F)));
      Matrix4f m = ms.method_23760().method_23761();
      int seg = this.quality.i();
      float r = this.radius.f();
      float h = this.height.f();
      double time = c.time;
      class_4588 vc = c.buffers.method_73477(this.glowMode() ? World3D.glowLayer() : World3D.normalLayer());
      World3D.cone(vc, m, r, h, seg, (a, t) -> this.colorAt(a, t, time));
      if (this.mode.is("neon")) {
         class_4588 g = c.buffers.method_73477(World3D.glowLayer());
         int ribs = 12;
         float spin = (float)(time * this.rotSpeed.value * 0.15);
         float op = this.opacity.f() / 100.0F;

         for (int i = 0; i < ribs; i++) {
            double ang = (double)i / ribs * Math.PI * 2.0;
            float cx = (float)Math.cos(ang);
            float cz = (float)Math.sin(ang);
            float px = -cz * 0.02F;
            float pz = cx * 0.02F;
            int col = R2D.withAlpha(R2D.hsv((((float)i / ribs + spin) % 1.0F + 1.0F) % 1.0F, 0.85F, 1.0F), (int)(230.0F * op));
            World3D.vtx(g, m, px * 0.3F, h + 0.002F, pz * 0.3F, col);
            World3D.vtx(g, m, -px * 0.3F, h + 0.002F, -pz * 0.3F, col);
            World3D.vtx(g, m, cx * r - px, 0.002F, cz * r - pz, col);
            World3D.vtx(g, m, cx * r + px, 0.002F, cz * r + pz, col);
         }
      }

      if (this.outline.value || this.mode.is("neon")) {
         class_4588 g = c.buffers.method_73477(World3D.glowLayer());
         float w = this.mode.is("neon") ? 0.05F : 0.025F;
         float op = this.opacity.f() / 100.0F;
         float spin = (float)(time * this.rotSpeed.value * 0.15);
         World3D.ring(g, m, 0.002F, r - w, r + w * 0.4F, seg, (a, t) -> {
            int base = !this.mode.is("rainbow") && !this.mode.is("neon") ? this.c1(a) : R2D.hsv(((a + spin) % 1.0F + 1.0F) % 1.0F, 0.8F, 1.0F);
            return R2D.withAlpha(base, (int)(255.0F * Math.min(1.0F, op + 0.2F) * (t > 0.5F ? 0.9F : 0.35F)));
         });
      }

      ms.method_22909();
   }
}
