package com.mrbean.visuals.module;

import com.mrbean.visuals.core.Lang;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_307;
import org.lwjgl.glfw.GLFW;

public abstract class Setting {
   public final String id;
   private final String ru;
   private final String en;
   public BooleanSupplier visible = () -> true;

   protected Setting(String id, String ru, String en) {
      this.id = id;
      this.ru = ru;
      this.en = en;
   }

   public String name() {
      return Lang.t(this.ru, this.en);
   }

   public abstract String save();

   public abstract void load(String var1);

   public abstract void reset();

   public Setting showIf(BooleanSupplier b) {
      this.visible = b;
      return this;
   }

   public static class Action extends Setting {
      public final Runnable run;

      public Action(String id, String ru, String en, Runnable run) {
         super(id, ru, en);
         this.run = run;
      }

      @Override
      public String save() {
         return null;
      }

      @Override
      public void load(String s) {
      }

      @Override
      public void reset() {
      }
   }

   public static class Bool extends Setting {
      public boolean value;
      private final boolean def;

      public Bool(String id, String ru, String en, boolean def) {
         super(id, ru, en);
         this.def = def;
         this.value = def;
      }

      @Override
      public String save() {
         return String.valueOf(this.value);
      }

      @Override
      public void load(String s) {
         this.value = Boolean.parseBoolean(s);
      }

      @Override
      public void reset() {
         this.value = this.def;
      }

      public boolean get() {
         return this.value;
      }
   }

   public static class Color extends Setting {
      public int argb;
      private final int def;
      public boolean alpha;

      public Color(String id, String ru, String en, int def) {
         super(id, ru, en);
         this.def = def;
         this.argb = def;
      }

      public Setting.Color withAlpha() {
         this.alpha = true;
         return this;
      }

      public int get() {
         return this.argb;
      }

      @Override
      public String save() {
         return String.format("#%08X", this.argb);
      }

      @Override
      public void load(String s) {
         try {
            this.argb = (int)Long.parseLong(s.replace("#", ""), 16);
         } catch (Exception var3) {
         }
      }

      @Override
      public void reset() {
         this.argb = this.def;
      }
   }

   public static class Key extends Setting {
      public static final int MOUSE = 1000;
      public int value;
      private final int def;
      private boolean was;

      public Key(String id, String ru, String en, int def) {
         super(id, ru, en);
         this.def = def;
         this.value = def;
      }

      @Override
      public String save() {
         return String.valueOf(this.value);
      }

      @Override
      public void load(String s) {
         try {
            this.value = Integer.parseInt(s.trim());
         } catch (Exception var3) {
            this.value = this.def;
         }
      }

      @Override
      public void reset() {
         this.value = this.def;
      }

      public boolean isDown() {
         class_310 mc = class_310.method_1551();
         if (this.value >= 0 && mc.method_22683() != null) {
            long h = mc.method_22683().method_4490();
            return this.value >= 1000 ? GLFW.glfwGetMouseButton(h, this.value - 1000) == 1 : class_3675.method_15987(mc.method_22683(), this.value);
         } else {
            return false;
         }
      }

      public boolean pressed() {
         class_310 mc = class_310.method_1551();
         boolean d = mc.field_1755 == null && this.isDown();
         boolean r = d && !this.was;
         this.was = d;
         return r;
      }

      public String display() {
         if (this.value < 0) {
            return "None";
         } else if (this.value >= 1000) {
            return Lang.t("Мышь ", "Mouse ") + (this.value - 1000 + 1);
         } else {
            try {
               String s = class_307.field_1668.method_1447(this.value).method_27445().getString();
               return s.length() > 10 ? s.substring(0, 10) : s;
            } catch (Exception var2) {
               return "#" + this.value;
            }
         }
      }
   }

   public static class Mode extends Setting {
      public final String[] ids;
      private final String[] ru;
      private final String[] en;
      public int index;
      private final int def;

      public Mode(String id, String ruName, String enName, int def, String... triples) {
         super(id, ruName, enName);
         int n = triples.length / 3;
         this.ids = new String[n];
         this.ru = new String[n];
         this.en = new String[n];

         for (int i = 0; i < n; i++) {
            this.ids[i] = triples[i * 3];
            this.ru[i] = triples[i * 3 + 1];
            this.en[i] = triples[i * 3 + 2];
         }

         this.def = def;
         this.index = def;
      }

      public String get() {
         return this.ids[this.index];
      }

      public boolean is(String id) {
         return this.ids[this.index].equals(id);
      }

      public String label(int i) {
         return Lang.t(this.ru[i], this.en[i]);
      }

      public String label() {
         return this.label(this.index);
      }

      public void cycle(int d) {
         this.index = Math.floorMod(this.index + d, this.ids.length);
      }

      @Override
      public String save() {
         return this.ids[this.index];
      }

      @Override
      public void load(String s) {
         for (int i = 0; i < this.ids.length; i++) {
            if (this.ids[i].equals(s)) {
               this.index = i;
            }
         }
      }

      @Override
      public void reset() {
         this.index = this.def;
      }
   }

   public static class Num extends Setting {
      public double value;
      public final double min;
      public final double max;
      public final double step;
      private final double def;
      public String suffix = "";

      public Num(String id, String ru, String en, double def, double min, double max, double step) {
         super(id, ru, en);
         this.def = def;
         this.min = min;
         this.max = max;
         this.step = step;
         this.value = def;
      }

      public Setting.Num suffix(String s) {
         this.suffix = s;
         return this;
      }

      public void set(double v) {
         v = Math.max(this.min, Math.min(this.max, v));
         v = Math.round(v / this.step) * this.step;
         this.value = Math.max(this.min, Math.min(this.max, v));
      }

      public float f() {
         return (float)this.value;
      }

      public int i() {
         return (int)Math.round(this.value);
      }

      public double frac() {
         return (this.value - this.min) / (this.max - this.min);
      }

      public String display() {
         if (this.step >= 1.0) {
            return (int)Math.round(this.value) + this.suffix;
         } else {
            return this.step >= 0.1
               ? String.format(Locale.ROOT, "%.1f", this.value) + this.suffix
               : String.format(Locale.ROOT, "%.2f", this.value) + this.suffix;
         }
      }

      @Override
      public String save() {
         return String.valueOf(this.value);
      }

      @Override
      public void load(String s) {
         try {
            this.set(Double.parseDouble(s));
         } catch (Exception var3) {
         }
      }

      @Override
      public void reset() {
         this.value = this.def;
      }
   }

   public static class Text extends Setting {
      public String value;
      private final String def;
      public int maxLen = 256;

      public Text(String id, String ru, String en, String def) {
         super(id, ru, en);
         this.def = def;
         this.value = def;
      }

      @Override
      public String save() {
         return this.value;
      }

      @Override
      public void load(String s) {
         this.value = s == null ? "" : s;
      }

      @Override
      public void reset() {
         this.value = this.def;
      }
   }
}
