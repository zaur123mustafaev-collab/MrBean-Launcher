package com.mrbean.visuals.module;

import com.mrbean.visuals.core.Lang;

public enum Category {
   DASHBOARD("dashboard", "⌂"),
   VISUALS("visuals", "☀"),
   COSMETICS("cosmetics", "♛"),
   HUD("hud", "▣"),
   WORLD("world", "☁"),
   PARTICLES("particles", "✦"),
   ANIMATIONS("animations", "↻"),
   PERFORMANCE("performance", "⚡"),
   THEMES("themes", "✎"),
   CRYSTAL("crystal", "◆"),
   UTILITIES("utilities", "⚔"),
   PVE("pve", "⛏"),
   MARKERS("markers", "◎"),
   SETTINGS("settings", "⚙");

   public final String key;
   public final String icon;

   private Category(String key, String icon) {
      this.key = key;
      this.icon = icon;
   }

   public String title() {
      return Lang.ui("cat." + this.key);
   }
}
