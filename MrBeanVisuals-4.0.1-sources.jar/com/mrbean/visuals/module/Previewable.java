package com.mrbean.visuals.module;

import net.minecraft.class_332;

public interface Previewable {
   int previewHeight();

   void drawPreview(class_332 var1, int var2, int var3, int var4, int var5);
}
