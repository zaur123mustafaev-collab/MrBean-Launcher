package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_2338;
import net.minecraft.class_5819;
import net.minecraft.class_6908;

public final class ParticleModules {
   static final class_5819 rnd = class_5819.method_43047();

   private ParticleModules() {
   }

   static ParticleModules.Engine engine() {
      return (ParticleModules.Engine)Modules.get("particle_engine");
   }

   public static void registerAll() {
      Modules.reg(new ParticleModules.Engine());
      Modules.reg(new ParticleModules.Fireflies());
      Modules.reg(new ParticleModules.FallingLeaves());
      Modules.reg(new ParticleModules.Snow());
      Modules.reg(new ParticleModules.Sparkles());
      Modules.reg(new ParticleModules.NeonRain());
   }

   abstract static class Ambient extends Module {
      final Setting.Num amount = this.add(new Setting.Num("amount", "Количество", "Amount", 100.0, 10.0, 300.0, 10.0).suffix("%"));
      final Setting.Num radius = this.add(new Setting.Num("radius", "Радиус", "Radius", 12.0, 4.0, 32.0, 1.0).suffix(" m"));

      Ambient(String id, String ru, String en, String dRu, String dEn) {
         super(id, Category.PARTICLES, false, ru, en, dRu, dEn);
      }

      abstract boolean allowed();

      abstract void spawnOne(double var1, double var3, double var5);

      abstract float rate();

      @Override
      public void onTick() {
         if (mc.field_1724 != null && mc.field_1687 != null && !mc.method_1493() && this.allowed()) {
            float n = this.rate() * this.amount.f() / 100.0F * ParticleModules.engine().dens();
            int count = (int)n + (ParticleModules.rnd.method_43057() < n - (int)n ? 1 : 0);
            double r = this.radius.value;

            for (int i = 0; i < count; i++) {
               double x = mc.field_1724.method_23317() + (ParticleModules.rnd.method_43058() * 2.0 - 1.0) * r;
               double z = mc.field_1724.method_23321() + (ParticleModules.rnd.method_43058() * 2.0 - 1.0) * r;
               double y = mc.field_1724.method_23318() + ParticleModules.rnd.method_43058() * 6.0 - 1.0;
               this.spawnOne(x, y, z);
            }
         }
      }
   }

   public static class Engine extends Module {
      public final Setting.Num limit = this.add(new Setting.Num("limit", "Лимит частиц", "Particle limit", 1500.0, 100.0, 4000.0, 100.0));
      public final Setting.Num size = this.add(new Setting.Num("size", "Размер", "Size", 100.0, 30.0, 300.0, 10.0).suffix("%"));
      public final Setting.Num density = this.add(new Setting.Num("density", "Плотность", "Density", 100.0, 10.0, 300.0, 10.0).suffix("%"));
      public final Setting.Mode color = this.add(
         new Setting.Mode(
            "color",
            "Цвет атмосферных частиц",
            "Ambient particle color",
            0,
            "natural",
            "Естественный",
            "Natural",
            "theme",
            "Цвет темы",
            "Theme",
            "rgb",
            "RGB",
            "RGB",
            "custom",
            "Свой",
            "Custom"
         )
      );
      public final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -7558))
         .showIf(() -> this.color.is("custom"));

      public Engine() {
         super(
            "particle_engine",
            Category.PARTICLES,
            true,
            "Движок частиц",
            "Particle Engine",
            "Лимит, размер и цвет всех частиц мода",
            "Limit, size and color for all mod particles"
         );
      }

      @Override
      public boolean toggleable() {
         return false;
      }

      @Override
      public void setEnabled(boolean e) {
         super.setEnabled(true);
      }

      @Override
      public boolean showInArray() {
         return false;
      }

      @Override
      public void onTick() {
         ParticleEngine.limit = this.limit.i();
         ParticleEngine.sizeMul = this.size.f() / 100.0F;
      }

      public int pick(int natural) {
         String var2 = this.color.get();

         return switch (var2) {
            case "theme" -> Modules.theme().accent((float)Math.random());
            case "rgb" -> R2D.hsv((float)Math.random(), 0.8F, 1.0F);
            case "custom" -> this.custom.argb;
            default -> natural;
         };
      }

      public float dens() {
         return this.density.f() / 100.0F;
      }
   }

   public static class FallingLeaves extends ParticleModules.Ambient {
      final Setting.Bool forestsOnly = this.add(new Setting.Bool("forests_only", "Только в лесах", "Forests only", true));

      public FallingLeaves() {
         super("falling_leaves", "Падающие листья", "Falling Leaves", "Листья медленно падают в лесах", "Leaves drift down in forests");
      }

      @Override
      boolean allowed() {
         return !this.forestsOnly.value || mc.field_1687.method_23753(mc.field_1724.method_24515()).method_40220(class_6908.field_36517);
      }

      @Override
      float rate() {
         return 0.5F;
      }

      @Override
      void spawnOne(double x, double y, double z) {
         int[] cols = new int[]{-9459654, -4864966, -2519506, -7618742};
         ParticleEngine.spawn(
            x,
            y + 4.0,
            z,
            0.0F,
            -0.02F,
            0.0F,
            160,
            0.09F,
            ParticleModules.engine().pick(cols[ParticleModules.rnd.method_43048(cols.length)]),
            8.0E-4F,
            0.98F,
            false,
            3
         );
      }
   }

   public static class Fireflies extends ParticleModules.Ambient {
      final Setting.Bool nightOnly = this.add(new Setting.Bool("night_only", "Только ночью", "Night only", true));

      public Fireflies() {
         super("fireflies", "Светлячки", "Fireflies", "Мерцающие светлячки вокруг", "Glowing fireflies around you");
      }

      @Override
      boolean allowed() {
         long t = mc.field_1687.method_8532() % 24000L;
         return !this.nightOnly.value || t > 12500L && t < 23500L;
      }

      @Override
      float rate() {
         return 0.4F;
      }

      @Override
      void spawnOne(double x, double y, double z) {
         if (mc.field_1687.method_8320(class_2338.method_49637(x, y, z)).method_26215()) {
            ParticleEngine.spawn(
               x, y, z, 0.0F, 0.0F, 0.0F, 120 + ParticleModules.rnd.method_43048(80), 0.07F, ParticleModules.engine().pick(-1507478), 0.0F, 0.92F, true, 2
            );
         }
      }
   }

   public static class NeonRain extends ParticleModules.Ambient {
      public NeonRain() {
         super("custom_rain", "Свой дождь", "Custom Rain", "Цветные капли во время дождя", "Colored droplets while it rains");
      }

      @Override
      boolean allowed() {
         return mc.field_1687.method_8419();
      }

      @Override
      float rate() {
         return 3.0F;
      }

      @Override
      void spawnOne(double x, double y, double z) {
         ParticleEngine.spawn(x, y + 6.0, z, 0.0F, -0.45F, 0.0F, 22, 0.05F, ParticleModules.engine().pick(-1065364225), 0.0F, 1.0F, true, 0);
      }
   }

   public static class Snow extends ParticleModules.Ambient {
      public Snow() {
         super("snow_particles", "Снегопад", "Snow Particles", "Мягкий снег вокруг игрока", "Soft snowfall around you");
      }

      @Override
      boolean allowed() {
         return true;
      }

      @Override
      float rate() {
         return 2.5F;
      }

      @Override
      void spawnOne(double x, double y, double z) {
         ParticleEngine.spawn(x, y + 6.0, z, 0.0F, -0.05F, 0.0F, 140, 0.06F, ParticleModules.engine().pick(-251658241), 5.0E-4F, 0.99F, false, 4);
      }
   }

   public static class Sparkles extends ParticleModules.Ambient {
      public Sparkles() {
         super("sparkles", "Искорки", "Sparkles", "Парящие сверкающие искры", "Floating twinkling sparkles");
      }

      @Override
      boolean allowed() {
         return true;
      }

      @Override
      float rate() {
         return 0.7F;
      }

      @Override
      void spawnOne(double x, double y, double z) {
         ParticleEngine.spawn(
            x, y, z, 0.0F, 0.004F, 0.0F, 70, 0.08F, ParticleModules.engine().pick(Modules.theme().accent((float)Math.random())), 0.0F, 0.97F, true, 1
         );
      }
   }
}
