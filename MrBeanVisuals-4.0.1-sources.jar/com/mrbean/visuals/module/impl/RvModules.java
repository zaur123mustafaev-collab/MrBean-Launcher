package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Friends;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.render.World3D;
import com.mrbean.visuals.util.LastServer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_7923;
import org.joml.Matrix4f;

public final class RvModules {
   private RvModules() {
   }

   public static void registerAll() {
      Modules.reg(new RvModules.AutoAccept());
      Modules.reg(new RvModules.Cooldowns());
      Modules.reg(new RvModules.Scanner());
      Modules.reg(new RvModules.ChatFilter());
      Modules.reg(new RvModules.NamePing());
      Modules.reg(new RvModules.AutoCommand());
      Modules.reg(new RvModules.RadiusPreview());
      Modules.reg(new RvModules.Pinger());
      Modules.reg(new RvModules.PlayerOutline());
      Modules.reg(new RvModules.BlockOverlay());
   }

   public static void renderWorld(class_4587 ms, class_4598 buf, class_243 cam, float td) {
      if (Modules.get("radius_preview") instanceof RvModules.RadiusPreview r && r.isEnabled()) {
         r.renderWorld(ms, buf, cam, td);
      }

      if (Modules.get("player_outline") instanceof RvModules.PlayerOutline o && o.isEnabled()) {
         o.renderWorld(ms, buf, cam, td);
      }

      if (Modules.get("block_overlay") instanceof RvModules.BlockOverlay b && b.isEnabled()) {
         b.renderWorld(ms, buf, cam);
      }
   }

   /**
    * Авто-принятие запросов в чате (телепорт, заявка в друзья, группа, обмен) — и только от тех,
    * кто есть в вашем списке друзей. Незнакомые отправители игнорируются: ник сначала ищется в
    * Friends, и если совпадения нет, команда не отправляется вовсе.
    */
   public static class AutoAccept extends Module {
      private static final Pattern NICK = Pattern.compile("[A-Za-z0-9_]{3,16}");
      final Setting.Text keywords = this.add(
         new Setting.Text(
            "keywords",
            "Слова запроса (через запятую)",
            "Request words (comma separated)",
            "accept,прими,принять,заявка,request,приглашение,invite,телепорт,tpa,группа,party,обмен,trade,друг,friend"
         )
      );
      final Setting.Text command = this.add(new Setting.Text("command", "Команда принятия (%n% — ник)", "Accept command (%n% = name)", "/accept %n%"));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление о принятии", "Notice on accept", true));
      final Setting.Bool ignored = this.add(new Setting.Bool("ignored", "Сообщать о проигнорированных", "Report ignored strangers", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук", "Sound", true));
      final Setting.Num pause = this.add(new Setting.Num("pause", "Пауза между принятиями", "Delay between accepts", 1.5, 0.5, 10.0, 0.5).suffix(" с"));
      private final Map<String, Long> sent = new LinkedHashMap<>();
      private long last;

      public AutoAccept() {
         super(
            "auto_accept",
            Category.UTILITIES,
            false,
            "Авто-принятие (друзья)",
            "Auto Accept (friends)",
            "Принимает запросы в чате только от игроков из вашего списка друзей; незнакомые игнорируются",
            "Accepts chat requests only from players on your friend list; strangers are ignored"
         );
      }

      @Override
      public void onEnable() {
         this.sent.clear();
         this.last = 0L;
      }

      @Override
      public void onTick() {
         if (mc.field_1724 == null) {
            this.sent.clear();
         }
      }

      public void onMessage(class_2561 message) {
         if (this.isEnabled() && mc.field_1724 != null && mc.method_1562() != null) {
            String raw = message.getString().replaceAll("§.", "");
            String low = raw.toLowerCase(Locale.ROOT);
            if (this.wanted(low)) {
               String me = mc.field_1724.method_7334().name();
               List<String> names = candidates(raw, me);
               String friend = null;

               for (String n : names) {
                  if (Friends.is(n)) {
                     friend = n;
                     break;
                  }
               }

               if (friend != null) {
                  this.accept(friend);
               } else if (this.ignored.value && !names.isEmpty()) {
                  Notifications.push(Lang.t("Запрос от незнакомца проигнорирован: ", "Ignored a stranger's request: ") + names.get(0), false);
               }
            }
         }
      }

      private boolean wanted(String low) {
         if (this.keywords.value == null) {
            return false;
         } else {
            for (String w : this.keywords.value.split(",")) {
               String t = w.trim().toLowerCase(Locale.ROOT);
               if (!t.isEmpty() && low.contains(t)) {
                  return true;
               }
            }

            return false;
         }
      }

      /** Ники из сообщения: сначала тот, что стоит прямо в команде сервера, затем по порядку. */
      private static List<String> candidates(String raw, String me) {
         List<String> out = new ArrayList<>();
         Matcher m = Pattern.compile("(?i)(?:accept|deny|прими|принять)\\s+([A-Za-z0-9_]{3,16})").matcher(raw);

         while (m.find()) {
            add(out, m.group(1), me);
         }

         Matcher t = NICK.matcher(raw);

         while (t.find()) {
            add(out, t.group(), me);
         }

         return out;
      }

      private static void add(List<String> out, String n, String me) {
         if (!n.equalsIgnoreCase(me) && !out.contains(n) && Friends.valid(n)) {
            out.add(n);
         }
      }

      private void accept(String name) {
         long now = System.currentTimeMillis();
         Long prev = this.sent.get(name);
         if (prev == null || now - prev > 8000L) {
            this.sent.put(name, now);
            this.sent.values().removeIf(t -> now - t > 60000L);
            if (now - this.last >= (long)(this.pause.value * 1000.0)) {
               this.last = now;
               String c = this.command.value == null ? "" : this.command.value.trim();
               if (!c.isEmpty()) {
                  c = c.contains("%n%") ? c.replace("%n%", name) : c;
                  if (c.startsWith("/")) {
                     mc.method_1562().method_45730(c.substring(1));
                  } else {
                     mc.method_1562().method_45729(c);
                  }

                  if (this.sound.value) {
                     Sounds.play(Sounds.ON);
                  }

                  if (this.notify.value) {
                     Notifications.push(Lang.t("Принят запрос от друга: ", "Accepted a friend's request: ") + name, true);
                  }
               }
            }
         }
      }
   }

   public static class AutoCommand extends Module {
      final Setting.Text command = this.add(new Setting.Text("command", "Команда", "Command", "/fix all"));
      final Setting.Num minutes = this.add(new Setting.Num("minutes", "Каждые", "Every", 5.0, 1.0, 60.0, 1.0).suffix(" мин"));
      final Setting.Bool onlyRw = this.add(new Setting.Bool("only_rw", "Только на ReallyWorld", "Only on ReallyWorld", false));
      private long next;

      public AutoCommand() {
         super(
            "auto_command",
            Category.UTILITIES,
            false,
            "Авто-команда",
            "Auto Command",
            "Сама отправляет команду по таймеру (например /fix all или /heal). Не чаще раза в минуту",
            "Sends a command on a timer (e.g. /fix all or /heal). At most once a minute"
         );
      }

      @Override
      public void onEnable() {
         this.next = System.currentTimeMillis() + 3000L;
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null && mc.method_1562() != null) {
            if (!this.onlyRw.value || LastServer.currentAddress(mc).contains("reallyworld")) {
               long now = System.currentTimeMillis();
               if (now >= this.next) {
                  this.next = now + (long)(Math.max(1.0, this.minutes.value) * 60000.0);
                  String c = this.command.value == null ? "" : this.command.value.trim();
                  if (!c.isEmpty()) {
                     if (c.startsWith("/")) {
                        mc.method_1562().method_45730(c.substring(1));
                     } else {
                        mc.method_1562().method_45729(c);
                     }

                     Notifications.push(Lang.t("Авто-команда: ", "Auto command: ") + c, true);
                  }
               }
            }
         }
      }
   }

   public static class BlockOverlay extends Module {
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -11873281))
         .showIf(() -> this.color.is("custom"));
      final Setting.Num fillA = this.add(new Setting.Num("fill", "Заливка", "Fill", 25.0, 0.0, 80.0, 1.0).suffix("%"));
      final Setting.Num width = this.add(new Setting.Num("width", "Толщина рамки", "Outline width", 2.0, 1.0, 5.0, 1.0));
      final Setting.Bool pulse = this.add(new Setting.Bool("pulse", "Пульсация", "Pulse", true));

      public BlockOverlay() {
         super(
            "block_overlay",
            Category.VISUALS,
            false,
            "Block Overlay",
            "Block Overlay",
            "Своя подсветка блока под прицелом: цвет, заливка, толщина",
            "Custom highlight for the aimed block: color, fill, outline width"
         );
      }

      public void renderWorld(class_4587 ms, class_4598 buf, class_243 cam) {
         if (mc.field_1687 != null && mc.field_1765 instanceof class_3965 bhr && bhr.method_17783() == class_240.field_1332) {
            class_2338 pos = bhr.method_17777();
            class_265 shape = mc.field_1687.method_8320(pos).method_26218(mc.field_1687, pos);
            if (!shape.method_1110()) {
               class_238 bb = shape.method_1107();
               float k = this.pulse.value ? 0.75F + 0.25F * (float)Math.sin(System.currentTimeMillis() / 220.0) : 1.0F;
               int col = CrystalModules.colorOf(this.color, this.custom, 0.0F);
               class_4588 vc = buf.method_73477(World3D.normalLayer());
               ms.method_22903();
               ms.method_22904(pos.method_10263() - cam.field_1352, pos.method_10264() - cam.field_1351, pos.method_10260() - cam.field_1350);
               Matrix4f m = ms.method_23760().method_23761();
               double g = 0.004;
               if (this.fillA.value > 0.0) {
                  CrystalModules.bar(
                     vc,
                     m,
                     (float)(bb.field_1323 - g),
                     (float)(bb.field_1322 - g),
                     (float)(bb.field_1321 - g),
                     (float)(bb.field_1320 + g),
                     (float)(bb.field_1325 + g),
                     (float)(bb.field_1324 + g),
                     R2D.withAlpha(col, (int)(255.0 * this.fillA.value / 100.0 * k))
                  );
               }

               CrystalModules.boxEdges(
                  vc,
                  m,
                  bb.field_1323 - g,
                  bb.field_1322 - g,
                  bb.field_1321 - g,
                  bb.field_1320 + g,
                  bb.field_1325 + g,
                  bb.field_1324 + g,
                  0.008F * this.width.i(),
                  R2D.withAlpha(col, (int)(240.0F * k))
               );
               ms.method_22909();
            }
         }
      }
   }

   public static class ChatFilter extends Module {
      public final Setting.Text words = this.add(new Setting.Text("words", "Запрещённые слова (через запятую)", "Banned words (comma separated)", "дурак, лох"));
      final Setting.Mode action = this.add(
         new Setting.Mode("action", "Что делать", "Action", 0, "block", "Не отправлять", "Don't send", "mask", "Заменить на ***", "Replace with ***")
      );

      public ChatFilter() {
         super(
            "chat_filter",
            Category.UTILITIES,
            false,
            "Фильтр чата",
            "Chat Filter",
            "Не даёт случайно отправить сообщение с запрещёнными словами (чтобы не получить мут)",
            "Stops you from accidentally sending banned words (avoid mutes)"
         );
      }

      private List<String> list() {
         List<String> l = new ArrayList<>();

         for (String w : this.words.value.split(",")) {
            String t = w.trim().toLowerCase(Locale.ROOT);
            if (!t.isEmpty()) {
               l.add(t);
            }
         }

         return l;
      }

      public String check(String msg) {
         if (this.isEnabled() && msg != null && !msg.startsWith("/") && !msg.startsWith(".")) {
            String low = msg.toLowerCase(Locale.ROOT);
            boolean hit = false;
            String out = msg;

            for (String w : this.list()) {
               if (low.contains(w)) {
                  hit = true;
                  if (this.action.is("mask")) {
                     out = out.replaceAll("(?iu)" + Pattern.quote(w), "*".repeat(w.length()));
                  }
               }
            }

            if (!hit) {
               return null;
            } else {
               Notifications.push(
                  this.action.is("block")
                     ? Lang.t("Сообщение не отправлено: запрещённое слово", "Message blocked: banned word")
                     : Lang.t("Запрещённые слова скрыты", "Banned words masked"),
                  false
               );
               return this.action.is("block") ? "" : out;
            }
         } else {
            return null;
         }
      }
   }

   public static class Cooldowns extends HudModule {
      final Setting.Bool bar = this.add(new Setting.Bool("bar", "Полоска", "Bar", true));
      private final List<class_1799> items = new ArrayList<>();
      private final List<Float> prog = new ArrayList<>();

      public Cooldowns() {
         super(
            "cooldowns",
            false,
            0.72,
            0.86,
            "Кулдауны",
            "Cooldowns",
            "Одна панель с перезарядкой предметов: перлы, хорусы, щит, ветряные заряды и др.",
            "One panel with item cooldowns: pearls, chorus, shield, wind charges and more"
         );
      }

      @Override
      protected void layout() {
         this.items.clear();
         this.prog.clear();
         if (mc.field_1724 != null) {
            class_1796 cd = mc.field_1724.method_7357();
            Set<String> seen = new HashSet<>();
            class_1661 inv = mc.field_1724.method_31548();

            for (int i = 0; i < inv.method_5439(); i++) {
               class_1799 s = inv.method_5438(i);
               if (!s.method_7960() && cd.method_7904(s)) {
                  String g = String.valueOf(cd.method_62836(s));
                  if (seen.add(g)) {
                     this.items.add(s);
                     this.prog.add(cd.method_7905(s, 0.0F));
                  }
               }
            }
         }

         if (editing && this.items.isEmpty()) {
            this.items.add(new class_1799(class_1802.field_8634));
            this.prog.add(0.6F);
            this.items.add(new class_1799(class_1802.field_8233));
            this.prog.add(0.3F);
         }

         this.w = Math.max(40, this.items.size() * 22);
         this.h = 22;
      }

      @Override
      protected boolean hasContent() {
         if (mc.field_1724 == null) {
            return false;
         } else {
            class_1796 cd = mc.field_1724.method_7357();
            class_1661 inv = mc.field_1724.method_31548();

            for (int i = 0; i < inv.method_5439(); i++) {
               class_1799 s = inv.method_5438(i);
               if (!s.method_7960() && cd.method_7904(s)) {
                  return true;
               }
            }

            return false;
         }
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         for (int i = 0; i < this.items.size(); i++) {
            int x = i * 22;
            float p = this.prog.get(i);
            ctx.method_51427(this.items.get(i), x + 2, 1);
            R2D.rect(ctx, x + 2, 1, 16, Math.round(16.0F * p), Integer.MIN_VALUE);
            if (this.bar.value) {
               R2D.rect(ctx, x + 2, 19, 16, 2, 1610612736);
               R2D.rect(ctx, x + 2, 19, Math.max(1, Math.round(16.0F * (1.0F - p))), 2, this.accent(i * 0.1F));
            }
         }
      }
   }

   public static class NamePing extends Module {
      final Setting.Text extra = this.add(new Setting.Text("extra", "Ещё слова (через запятую)", "Extra words (comma separated)", ""));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук", "Sound", true));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление", "Notification", true));
      private long last;

      public NamePing() {
         super(
            "name_ping",
            Category.UTILITIES,
            false,
            "Пинг по нику",
            "Name Ping",
            "Звук и уведомление, когда в чате пишут ваш ник",
            "Sound and notice when someone mentions your name in chat"
         );
      }

      public void onMessage(class_2561 message) {
         if (this.isEnabled() && mc.field_1724 != null) {
            String s = message.getString().toLowerCase(Locale.ROOT);
            String me = mc.field_1724.method_7334().name().toLowerCase(Locale.ROOT);
            if (!s.startsWith("<" + me + ">") && (!s.contains(me + ":") || s.indexOf(me) >= 25 || s.indexOf(me + ":") != s.indexOf(me))) {
               boolean hit = s.contains(me);
               if (!hit) {
                  for (String w : this.extra.value.split(",")) {
                     String t = w.trim().toLowerCase(Locale.ROOT);
                     if (!t.isEmpty() && s.contains(t)) {
                        hit = true;
                        break;
                     }
                  }
               }

               if (hit && System.currentTimeMillis() - this.last >= 1500L) {
                  this.last = System.currentTimeMillis();
                  if (this.sound.value) {
                     Sounds.play(Sounds.ON);
                  }

                  if (this.notify.value) {
                     Notifications.push(Lang.t("Вас упомянули в чате", "You were mentioned in chat"), true);
                  }
               }
            }
         }
      }
   }

   public static class Pinger extends Module {
      final Setting.Num threshold = this.add(
         new Setting.Num("threshold", "Порог прочности брони", "Armor durability threshold", 15.0, 5.0, 50.0, 5.0).suffix("%")
      );
      final Setting.Bool flash = this.add(new Setting.Bool("flash", "Вспышка экрана", "Screen flash", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук", "Sound", true));
      private final Set<String> warned = new HashSet<>();
      private long flashAt;

      public Pinger() {
         super(
            "pinger",
            Category.UTILITIES,
            false,
            "Pinger",
            "Pinger",
            "Звук и вспышка, когда броня почти сломалась",
            "Sound and flash when armor is about to break"
         );
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null && !mc.field_1724.method_68878()) {
            Set<String> now = new HashSet<>();

            for (class_1304 s : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
               class_1799 st = mc.field_1724.method_6118(s);
               if (!st.method_7960() && st.method_7963()) {
                  float f = 1.0F - (float)st.method_7919() / st.method_7936();
                  if (!(f * 100.0F > this.threshold.value)) {
                     String key = s.name() + st.method_7909();
                     now.add(key);
                     if (this.warned.add(key)) {
                        if (this.sound.value) {
                           Sounds.play(Sounds.OFF);
                        }

                        this.flashAt = System.currentTimeMillis();
                        Notifications.push(Lang.t("Броня ломается: ", "Armor breaking: ") + st.method_7964().getString(), false);
                     }
                  }
               }
            }

            this.warned.retainAll(now);
         } else {
            this.warned.clear();
         }
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.flash.value) {
            long dt = System.currentTimeMillis() - this.flashAt;
            if (dt <= 900L) {
               float a = (float)Math.sin(dt / 900.0 * Math.PI * 3.0) * (1.0F - (float)dt / 900.0F);
               if (!(a <= 0.0F)) {
                  ctx.method_25294(0, 0, ctx.method_51421(), ctx.method_51443(), R2D.argb((int)(70.0F * a), 255, 60, 40));
               }
            }
         }
      }
   }

   public static class PlayerOutline extends Module {
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -45715))
         .showIf(() -> this.color.is("custom"));
      final Setting.Num range = this.add(new Setting.Num("range", "Дальность", "Range", 48.0, 8.0, 128.0, 4.0).suffix(" бл"));
      final Setting.Bool fill = this.add(new Setting.Bool("fill", "Заливка", "Fill", false));

      public PlayerOutline() {
         super(
            "player_outline",
            Category.VISUALS,
            false,
            "Обводка игроков",
            "Player Outline",
            "Рамка вокруг игроков, которых вы и так видите (не сквозь стены)",
            "Box around players you can already see (not through walls)"
         );
      }

      public void renderWorld(class_4587 ms, class_4598 buf, class_243 cam, float td) {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            class_4588 vc = buf.method_73477(World3D.normalLayer());
            double r2 = this.range.value * this.range.value;
            int i = 0;

            for (class_1657 p : mc.field_1687.method_18456()) {
               if (p != mc.field_1724 && !p.method_7325() && !p.method_5767() && !(p.method_5858(mc.field_1724) > r2) && mc.field_1724.method_6057(p)) {
                  class_243 pos = p.method_30950(td);
                  class_238 bb = p.method_5829().method_989(-p.method_23317(), -p.method_23318(), -p.method_23321());
                  int col = Friends.is(p.method_7334().name()) ? -11870592 : CrystalModules.colorOf(this.color, this.custom, i++ * 0.12F);
                  ms.method_22903();
                  ms.method_22904(pos.field_1352 - cam.field_1352, pos.field_1351 - cam.field_1351, pos.field_1350 - cam.field_1350);
                  Matrix4f m = ms.method_23760().method_23761();
                  if (this.fill.value) {
                     CrystalModules.bar(
                        vc, m, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324, R2D.withAlpha(col, 40)
                     );
                  }

                  CrystalModules.boxEdges(vc, m, bb.field_1323, bb.field_1322, bb.field_1321, bb.field_1320, bb.field_1325, bb.field_1324, 0.025F, R2D.withAlpha(col, 230));
                  ms.method_22909();
               }
            }
         }
      }
   }

   public static class RadiusPreview extends Module {
      final Setting.Num radius = this.add(new Setting.Num("radius", "Радиус", "Radius", 5.0, 1.0, 30.0, 0.5).suffix(" бл"));
      final Setting.Text items = this.add(
         new Setting.Text("items", "Предметы (id или часть названия, через запятую)", "Items (id or part of name, comma separated)", "fire_charge, totem")
      );
      final Setting.Bool always = this.add(new Setting.Bool("always", "Показывать всегда", "Always show", false));
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -11873281))
         .showIf(() -> this.color.is("custom"));

      public RadiusPreview() {
         super(
            "radius_preview",
            Category.UTILITIES,
            false,
            "Radius Preview",
            "Radius Preview",
            "Круг нужного радиуса вокруг вас, когда в руке выбранный предмет (донат-предметы, сферы)",
            "A ring of chosen radius around you while holding a chosen item (donor items, orbs)"
         );
      }

      private boolean matches(class_1799 s) {
         if (s.method_7960()) {
            return false;
         } else {
            String id = class_7923.field_41178.method_10221(s.method_7909()).toString().toLowerCase(Locale.ROOT);
            String name = s.method_7964().getString().toLowerCase(Locale.ROOT);

            for (String w : this.items.value.split(",")) {
               String t = w.trim().toLowerCase(Locale.ROOT);
               if (!t.isEmpty() && (id.contains(t) || name.contains(t))) {
                  return true;
               }
            }

            return false;
         }
      }

      public void renderWorld(class_4587 ms, class_4598 buf, class_243 cam, float td) {
         if (mc.field_1724 != null) {
            if (this.always.value || this.matches(mc.field_1724.method_6047()) || this.matches(mc.field_1724.method_6079())) {
               class_243 p = mc.field_1724.method_30950(td);
               class_4588 vc = buf.method_73477(World3D.normalLayer());
               ms.method_22903();
               ms.method_22904(p.field_1352 - cam.field_1352, p.field_1351 - cam.field_1351 + 0.05, p.field_1350 - cam.field_1350);
               Matrix4f m = ms.method_23760().method_23761();
               float r = (float)this.radius.value;
               float spin = (float)(System.currentTimeMillis() % 4000L) / 4000.0F;
               World3D.ring(vc, m, 0.0F, r - 0.08F, r, 96, (a, t) -> R2D.withAlpha(CrystalModules.colorOf(this.color, this.custom, a + spin), 220));
               World3D.ring(vc, m, 0.0F, 0.0F, r - 0.08F, 96, (a, t) -> R2D.withAlpha(CrystalModules.colorOf(this.color, this.custom, a + spin), 28));
               ms.method_22909();
            }
         }
      }
   }

   public static class Scanner extends HudModule {
      final Setting.Num radius = this.add(new Setting.Num("radius", "Радиус", "Radius", 48.0, 8.0, 128.0, 4.0).suffix(" бл"));
      final Setting.Num every = this.add(new Setting.Num("every", "Проверять каждые", "Check every", 1.0, 0.5, 5.0, 0.5).suffix(" с"));
      final Setting.Bool alert = this.add(new Setting.Bool("alert", "Звук и сообщение о новом игроке", "Sound & message on new player", true));
      final Setting.Bool direction = this.add(new Setting.Bool("direction", "Стрелка направления", "Direction arrow", true));
      final Setting.Num max = this.add(new Setting.Num("max", "Сколько показывать", "Max shown", 6.0, 1.0, 15.0, 1.0));
      private final Map<String, double[]> near = new LinkedHashMap<>();
      private final Set<String> known = new HashSet<>();
      private long next;

      public Scanner() {
         super(
            "scanner",
            false,
            0.005,
            0.5,
            "Сканер / ниар",
            "Scanner / near",
            "Видимые игроки рядом: ник, расстояние и направление; звук, когда кто-то появляется в поле зрения. Сквозь стены не показывает",
            "Visible nearby players: name, distance and direction; alert when someone comes into view. Never through walls"
         );
      }

      @Override
      public void onTick() {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            long now = System.currentTimeMillis();
            if (now >= this.next) {
               this.next = now + (long)(this.every.value * 1000.0);
               this.near.clear();
               Set<String> current = new HashSet<>();
               List<class_1657> list = new ArrayList<>(mc.field_1687.method_18456());
               list.sort((a, b) -> Double.compare(a.method_5858(mc.field_1724), b.method_5858(mc.field_1724)));

               for (class_1657 p : list) {
                  // только тех, кого и так видно: без canSee это был радар игроков сквозь стены
                  if (p != mc.field_1724 && !p.method_7325() && !p.method_5767() && !Friends.is(p.method_7334().name()) && mc.field_1724.method_6057(p)) {
                     double dist = Math.sqrt(p.method_5858(mc.field_1724));
                     if (!(dist > this.radius.value)) {
                        String n = p.method_7334().name();
                        current.add(n);
                        double ang = Math.toDegrees(Math.atan2(p.method_23321() - mc.field_1724.method_23321(), p.method_23317() - mc.field_1724.method_23317())) - 90.0 - mc.field_1724.method_36454();
                        this.near.put(n, new double[]{dist, class_3532.method_15338(ang)});
                        if (this.alert.value && !this.known.contains(n)) {
                           Sounds.play(Sounds.OPEN);
                           if (mc.field_1705 != null) {
                              mc.field_1705
                                 .method_1743()
                                 .method_1812(
                                    class_2561.method_43470(
                                       "§a[MrBean] §f" + Lang.t("Рядом игрок: ", "Player nearby: ") + n + " §7(" + Math.round(dist) + Lang.t(" бл)", " m)")
                                    )
                                 );
                           }
                        }
                     }
                  }
               }

               this.known.clear();
               this.known.addAll(current);
            }
         } else {
            this.near.clear();
            this.known.clear();
         }
      }

      @Override
      protected void layout() {
         int n = Math.min(this.max.i(), this.near.size());
         int wmax = this.tw(Lang.t("Рядом: ", "Nearby: ") + this.near.size());
         int i = 0;

         for (Entry<String, double[]> e : this.near.entrySet()) {
            if (i++ >= n) {
               break;
            }

            wmax = Math.max(wmax, this.tw(e.getKey() + "  " + Math.round(e.getValue()[0]) + "м") + (this.direction.value ? 12 : 0));
         }

         if (editing && this.near.isEmpty()) {
            wmax = 90;
            n = 2;
         }

         this.w = wmax;
         this.h = 10 + n * 10;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         this.text(ctx, Lang.t("Рядом: ", "Nearby: ") + this.near.size(), 0, 0, this.accent(0.0F));
         int y = 10;
         int i = 0;
         if (editing && this.near.isEmpty()) {
            this.text(ctx, "Steve  12м", 12, y, -1);
            this.text(ctx, "Alex  30м", 12, y + 10, -1);
         } else {
            for (Entry<String, double[]> e : this.near.entrySet()) {
               if (i++ >= this.max.i()) {
                  break;
               }

               double dist = e.getValue()[0];
               int col = dist < 10.0 ? -42396 : (dist < 25.0 ? -16051 : -1);
               int x = 0;
               if (this.direction.value) {
                  this.arrow(ctx, 4, y + 4, (float)e.getValue()[1], col);
                  x = 12;
               }

               this.text(ctx, e.getKey() + "  " + Math.round(dist) + Lang.t("м", "m"), x, y, col);
               y += 10;
            }
         }
      }

      private void arrow(class_332 ctx, int cx, int cy, float deg, int col) {
         ctx.method_51448().pushMatrix();
         ctx.method_51448().translate(cx, cy);
         ctx.method_51448().rotate((float)Math.toRadians(deg));
         R2D.rect(ctx, -1, -3, 2, 6, col);
         R2D.rect(ctx, -2, -3, 4, 2, col);
         ctx.method_51448().popMatrix();
      }
   }
}
