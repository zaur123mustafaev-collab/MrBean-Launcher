package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.render.World3D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import org.joml.Matrix4f;

/**
 * Метки ReallyWorld: аирдропы, талисманы, события и важные объекты.
 * Координаты берутся только из того, что клиент и так видит — объявления сервера в чате
 * (сервер сам печатает числа) и имена загруженных сущностей и предметов. Ничего не угадывается:
 * если в объявлении координат нет, метка показывается без расстояния и без стрелки.
 */
public final class MarkersModules {
   private MarkersModules() {
   }

   public static void registerAll() {
      Modules.reg(new MarkersModules.Markers());
   }

   public static void renderWorld(class_4587 ms, class_4598 buf, class_243 cam, float td) {
      if (Modules.get("markers") instanceof MarkersModules.Markers m && m.isEnabled()) {
         m.renderWorld(ms, buf, cam);
      }
   }

   public static final class Markers extends HudModule {
      public static final String AIRDROP = "airdrop";
      public static final String TALISMAN = "talisman";
      public static final String EVENT = "event";
      public static final String OBJECT = "object";
      private static final Pattern NUM = Pattern.compile("(?<![\\w])-?\\d{1,7}(?![\\w])");

      final Setting.Bool airdrop = this.add(new Setting.Bool("airdrop", "Аирдропы", "Airdrops", true));
      final Setting.Color airdropColor = (Setting.Color)this.add(new Setting.Color("airdrop_color", "Цвет аирдропа", "Airdrop color", 0xFF9A2E))
         .showIf(() -> this.airdrop.value);
      final Setting.Text airdropWords = (Setting.Text)this.add(
            new Setting.Text("airdrop_words", "Слова аирдропа", "Airdrop words", "аирдроп,airdrop,air drop,supply drop,поставка")
         )
         .showIf(() -> this.airdrop.value);
      final Setting.Bool talisman = this.add(new Setting.Bool("talisman", "Талисманы", "Talismans", true));
      final Setting.Color talismanColor = (Setting.Color)this.add(new Setting.Color("talisman_color", "Цвет талисмана", "Talisman color", 0xB44CFF))
         .showIf(() -> this.talisman.value);
      final Setting.Text talismanWords = (Setting.Text)this.add(
            new Setting.Text("talisman_words", "Слова талисмана", "Talisman words", "талисман,talisman,амулет,amulet")
         )
         .showIf(() -> this.talisman.value);
      final Setting.Bool event = this.add(new Setting.Bool("event", "События и боссы", "Events and bosses", true));
      final Setting.Color eventColor = (Setting.Color)this.add(new Setting.Color("event_color", "Цвет события", "Event color", 0xFF4C6A))
         .showIf(() -> this.event.value);
      final Setting.Text eventWords = (Setting.Text)this.add(
            new Setting.Text("event_words", "Слова события", "Event words", "событие,event,босс,boss,рейд,raid,началось,started")
         )
         .showIf(() -> this.event.value);
      final Setting.Bool object = this.add(new Setting.Bool("object", "Важные объекты", "Important objects", true));
      final Setting.Color objectColor = (Setting.Color)this.add(new Setting.Color("object_color", "Цвет объекта", "Object color", 0x3CD0FF))
         .showIf(() -> this.object.value);
      final Setting.Text objectWords = (Setting.Text)this.add(
            new Setting.Text("object_words", "Слова объекта", "Object words", "алтарь,altar,портал,portal,сундук,chest,храм,temple,ключ,key")
         )
         .showIf(() -> this.object.value);
      final Setting.Bool chat = this.add(new Setting.Bool("chat", "Искать объявления в чате", "Watch chat announcements", true));
      final Setting.Bool entities = this.add(
         new Setting.Bool("entities", "Искать по именам сущностей и предметов", "Match entity and item names", true)
      );
      final Setting.Num range = this.add(
         new Setting.Num("range", "Показывать не дальше", "Show up to", 1500.0, 16.0, 20000.0, 16.0).suffix(" бл")
      );
      final Setting.Num ttl = this.add(
         new Setting.Num("ttl", "Держать метку из чата", "Keep a chat marker for", 120.0, 15.0, 600.0, 15.0).suffix(" с")
      );
      final Setting.Num every = this.add(
         new Setting.Num("every", "Обновлять позиции каждые", "Refresh positions every", 0.5, 0.2, 3.0, 0.1).suffix(" с")
      );
      final Setting.Bool arrow = this.add(new Setting.Bool("arrow", "Стрелка направления", "Direction arrow", true));
      final Setting.Bool coords = this.add(new Setting.Bool("coords", "Показывать координаты", "Show coordinates", true));
      final Setting.Bool world = this.add(new Setting.Bool("world", "Кольцо и луч в мире", "Ring and beam in the world", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук о новой метке", "Sound on a new marker", true));
      final Setting.Num max = this.add(new Setting.Num("max", "Сколько показывать", "Max shown", 8.0, 1.0, 20.0, 1.0));
      private final Map<String, Mark> marks = new LinkedHashMap<>();
      private final List<Mark> rows = new ArrayList<>();
      private final List<Mark> shown = new ArrayList<>();
      private long nextScan;

      public Markers() {
         super(
            "markers",
            Category.MARKERS,
            false,
            0.02,
            0.15,
            "Метки",
            "Markers",
            "Аирдропы, талисманы, события и важные объекты: название, направление, расстояние и цвет по типу. Метка сама пропадает, когда событие закончилось",
            "Airdrops, talismans, events and important objects: name, direction, distance and a colour per type. A marker disappears on its own when the event is over"
         );
         this.background.value = false;
      }

      @Override
      public void onEnable() {
         this.marks.clear();
         this.rows.clear();
         this.nextScan = 0L;
      }

      @Override
      public void onDisable() {
         this.marks.clear();
         this.rows.clear();
      }

      @Override
      public void onTick() {
         long now = System.currentTimeMillis();
         if (mc.field_1687 == null || mc.field_1724 == null) {
            this.marks.clear();
            this.rows.clear();
         } else {
            if (this.entities.value && now >= this.nextScan) {
               this.nextScan = now + (long)(this.every.value * 1000.0);
               this.scan(now);
            }

            this.marks.values().removeIf(m -> m.expires > 0L && now > m.expires || m.fromWorld && now - m.seen > 3000L);
            this.buildRows();
         }
      }

      /** Метки из чата: сервер сам напечатал объявление, мы только разбираем его числа. */
      public void onMessage(class_2561 message) {
         if (this.chat.value && this.isEnabled() && message != null && mc.field_1724 != null) {
            String raw = message.getString();
            if (!raw.isEmpty()) {
               String type = this.typeOf(raw.toLowerCase(Locale.ROOT));
               if (type != null) {
                  List<String> nums = numbers(raw);
                  String name = clean(raw);
                  long now = System.currentTimeMillis();
                  Mark m = null;
                  double[] pos = this.position(nums);
                  if (pos == null) {
                     m = this.upsert("c:" + type + ":" + name, type, now);
                     m.hasPos = false;
                  } else {
                     m = this.upsert("c:" + type + ":" + Math.round(pos[0]) + "," + Math.round(pos[2]), type, now);
                     m.x = pos[0];
                     m.y = pos[1];
                     m.z = pos[2];
                     m.flat = pos[3] > 0.0;
                     m.hasPos = true;
                  }

                  m.name = name;
                  m.expires = now + (long)(this.ttl.value * 1000.0);
               }
            }
         }
      }

      private Mark upsert(String key, String type, long now) {
         Mark m = this.marks.get(key);
         if (m == null || !m.type.equals(type)) {
            m = new Mark(type, false);
            this.marks.put(key, m);
            if (this.sound.value) {
               Sounds.play(Sounds.OPEN);
            }
         }

         m.seen = now;
         return m;
      }

      /** [x, y, z, flat] или null, если в объявлении нет похожих на координаты чисел. */
      private double[] position(List<String> nums) {
         if (nums.size() >= 3) {
            double x = parse(nums.get(0));
            double y = parse(nums.get(1));
            double z = parse(nums.get(2));
            if (ok(x) && ok(z) && y >= -512.0 && y <= 4096.0) {
               return new double[]{x, y, z, 0.0};
            }
         }

         if (nums.size() >= 2) {
            double x = parse(nums.get(0));
            double z = parse(nums.get(1));
            if (ok(x) && ok(z)) {
               // высота в объявлении не названа — берём свою, чтобы не выдумывать число
               return new double[]{x, mc.field_1724.method_23318(), z, 1.0};
            }
         }

         return null;
      }

      private static boolean ok(double v) {
         return Math.abs(v) <= 3.0E7;
      }

      private static double parse(String s) {
         try {
            return Double.parseDouble(s);
         } catch (Exception var2) {
            return Double.NaN;
         }
      }

      private static List<String> numbers(String raw) {
         List<String> out = new ArrayList<>();
         Matcher mt = NUM.matcher(raw);

         while (mt.find() && out.size() < 4) {
            out.add(mt.group());
         }

         return out;
      }

      private static String clean(String raw) {
         String s = raw.replaceAll("§.", "").trim();
         if (s.length() > 42) {
            s = s.substring(0, 42) + "…";
         }

         return s;
      }

      /** Имена видимых сущностей и лежащих предметов (canSee) — то, что игрок и так видит глазами. */
      private void scan(long now) {
         for (class_1297 e : mc.field_1687.method_18112()) {
            // только видимые: метки на предметы и сущности сквозь стены были бы ESP
            if (!(e instanceof class_1657) && mc.field_1724.method_6057(e)) {
               String nm = nameOf(e);
               if (nm != null) {
                  String type = this.typeOf(nm.toLowerCase(Locale.ROOT));
                  if (type != null) {
                     class_243 p = new class_243(e.method_23317(), e.method_23318(), e.method_23321());
                     Mark m = this.marks.get("e:" + e.method_5628());
                     if (m == null || !m.type.equals(type)) {
                        m = new Mark(type, true);
                        this.marks.put("e:" + e.method_5628(), m);
                        if (this.sound.value) {
                           Sounds.play(Sounds.OPEN);
                        }
                     }

                     m.name = nm;
                     m.x = p.field_1352;
                     m.y = p.field_1351;
                     m.z = p.field_1350;
                     m.hasPos = true;
                     m.seen = now;
                  }
               }
            }
         }
      }

      private static String nameOf(class_1297 e) {
         String s = null;
         if (e instanceof class_1542 ie) {
            s = ie.method_6983().method_7964().getString();
         } else if (e.method_16914() && e.method_5797() != null) {
            s = e.method_5797().getString();
         }

         return s == null || s.trim().isEmpty() ? null : s.trim();
      }

      private String typeOf(String low) {
         if (this.airdrop.value && this.any(low, this.airdropWords.value)) {
            return AIRDROP;
         } else if (this.talisman.value && this.any(low, this.talismanWords.value)) {
            return TALISMAN;
         } else if (this.event.value && this.any(low, this.eventWords.value)) {
            return EVENT;
         } else {
            return this.object.value && this.any(low, this.objectWords.value) ? OBJECT : null;
         }
      }

      private boolean any(String low, String words) {
         for (String w : words.split(",")) {
            String t = w.trim().toLowerCase(Locale.ROOT);
            if (!t.isEmpty() && low.contains(t)) {
               return true;
            }
         }

         return false;
      }

      int color(String type) {
         Setting.Color c = switch (type) {
            case "airdrop" -> this.airdropColor;
            case "talisman" -> this.talismanColor;
            case "event" -> this.eventColor;
            default -> this.objectColor;
         };
         return c.argb | 0xFF000000;
      }

      private boolean on(String type) {
         return switch (type) {
            case "airdrop" -> this.airdrop.value;
            case "talisman" -> this.talisman.value;
            case "event" -> this.event.value;
            default -> this.object.value;
         };
      }

      private void buildRows() {
         this.rows.clear();
         List<Mark> all = new ArrayList<>();

         for (Mark m : this.marks.values()) {
            if (this.on(m.type) && (!m.hasPos || this.dist(m) <= this.range.value)) {
               all.add(m);
            }
         }

         all.sort((a, b) -> Double.compare(a.hasPos ? this.dist(a) : Double.MAX_VALUE, b.hasPos ? this.dist(b) : Double.MAX_VALUE));

         for (int i = 0; i < all.size() && i < this.max.i(); i++) {
            this.rows.add(all.get(i));
         }
      }

      private double dist(Mark m) {
         if (mc.field_1724 == null || !m.hasPos) {
            return Double.MAX_VALUE;
         } else {
            double dx = m.x - mc.field_1724.method_23317();
            double dz = m.z - mc.field_1724.method_23321();
            return Math.sqrt(dx * dx + dz * dz);
         }
      }

      private float angle(Mark m) {
         double deg = Math.toDegrees(Math.atan2(m.z - mc.field_1724.method_23321(), m.x - mc.field_1724.method_23317())) - 90.0 - mc.field_1724.method_36454();
         return class_3532.method_15393((float)deg);
      }

      @Override
      protected boolean hasContent() {
         return !this.rows.isEmpty();
      }

      @Override
      protected void layout() {
         this.shown.clear();
         this.shown.addAll(this.rows);
         if (editing && this.shown.isEmpty()) {
            Mark a = new Mark(AIRDROP, false);
            a.name = Lang.t("Аирдроп", "Airdrop");
            a.x = 120.0;
            a.y = 70.0;
            a.z = -45.0;
            a.hasPos = true;
            Mark b = new Mark(TALISMAN, false);
            b.name = Lang.t("Талисман силы", "Talisman of Power");
            b.hasPos = false;
            this.shown.add(a);
            this.shown.add(b);
         }

         int wmax = this.tw(Lang.t("Метки: ", "Markers: ") + this.shown.size());

         for (Mark m : this.shown) {
            wmax = Math.max(wmax, this.tw(this.line(m)) + (this.arrow.value && m.hasPos ? 12 : 0));
         }

         this.w = Math.min(260, Math.max(60, wmax));
         this.h = 10 + this.shown.size() * 11;
      }

      private String line(Mark m) {
         if (!m.hasPos) {
            return m.name;
         } else {
            String s = m.name + "  " + Math.round(this.dist(m)) + Lang.t("м", "m");
            if (this.coords.value) {
               s = s + " [" + Math.round(m.x) + ", " + (m.flat ? "~" : Math.round(m.y)) + ", " + Math.round(m.z) + "]";
            }

            return s;
         }
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         this.text(ctx, Lang.t("Метки: ", "Markers: ") + this.shown.size(), 0, 0, this.accent(0.0F));
         int y = 10;

         for (Mark m : this.shown) {
            int col = this.color(m.type);
            int x = 0;
            if (this.arrow.value && m.hasPos) {
               this.arrow(ctx, 4, y + 4, this.angle(m), col);
               x = 12;
            }

            this.text(ctx, m.hasPos && !editing ? fit(this.line(m), 240) : this.line(m), x, y, col);
            y += 11;
         }
      }

      private void arrow(class_332 ctx, int cx, int cy, float deg, int col) {
         ctx.method_51448().pushMatrix();
         ctx.method_51448().translate(cx, cy);
         ctx.method_51448().rotate((float)Math.toRadians(deg));
         R2D.rect(ctx, -1, -3, 2, 6, col);
         R2D.rect(ctx, -2, -3, 4, 2, col);
         ctx.method_51448().popMatrix();
      }

      private static String fit(String s, int max) {
         if (R2D.width(s) <= max) {
            return s;
         } else {
            String out = s;

            while (out.length() > 1 && R2D.width(out + "…") > max) {
               out = out.substring(0, out.length() - 1);
            }

            return out + "…";
         }
      }

      /** Кольцо и луч на месте метки. Дальше 256 блоков их всё равно не видно, поэтому не рисуем. */
      void renderWorld(class_4587 ms, class_4598 buf, class_243 cam) {
         if (this.world.value && mc.field_1724 != null) {
            class_4588 vc = buf.method_73477(World3D.normalLayer());
            Set<String> done = new HashSet<>();

            for (Mark m : this.marks.values()) {
               if (m.hasPos && this.on(m.type) && this.dist(m) <= 256.0 && done.add(m.type + Math.round(m.x) + "," + Math.round(m.z))) {
                  int col = this.color(m.type);
                  float fade = (float)(Math.sin(System.currentTimeMillis() / 700.0) + 1.0) / 2.0F;
                  ms.method_22903();
                  ms.method_22904(m.x - cam.field_1352, m.y - cam.field_1351, m.z - cam.field_1350);
                  Matrix4f mt = ms.method_23760().method_23761();
                  World3D.ring(vc, mt, 0.05F, 1.05F, 1.35F, 48, (a, t) -> R2D.withAlpha(col, 200));
                  World3D.ring(vc, mt, 0.05F, 0.0F, 1.05F, 48, (a, t) -> R2D.withAlpha(col, 34));
                  World3D.cylinder(vc, mt, 0.22F, 0.0F, 7.0F, 20, (a, t) -> R2D.withAlpha(col, (int)(70.0F + 40.0F * fade * (1.0F - t))));
                  ms.method_22909();
               }
            }
         }
      }

      static final class Mark {
         final String type;
         final boolean fromWorld;
         String name = "";
         double x;
         double y;
         double z;
         boolean hasPos;
         boolean flat;
         long seen;
         long expires;

         Mark(String type, boolean fromWorld) {
            this.type = type;
            this.fromWorld = fromWorld;
         }
      }
   }
}
