package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.cosmetic.ChinaHat;
import com.mrbean.visuals.module.cosmetic.PlayerCosmetic;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.util.Info;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_315;
import net.minecraft.class_4063;
import net.minecraft.class_4066;

public class PerformanceModule extends Module {
   public final Setting.Mode preset = this.add(
      new Setting.Mode(
         "preset",
         "Пресет",
         "Preset",
         1,
         "max",
         "Максимум FPS",
         "Maximum FPS",
         "balanced",
         "Баланс",
         "Balanced",
         "beautiful",
         "Красиво",
         "Beautiful",
         "ultra",
         "Ультра-визуалы",
         "Ultra Visuals",
         "custom",
         "Свой",
         "Custom"
      )
   );
   public final Setting.Bool vanilla = this.add(new Setting.Bool("vanilla", "Менять и настройки игры", "Also change game settings", false));
   public final Setting.Bool lowEnd = this.add(new Setting.Bool("low_end", "Режим слабого ПК", "Low-performance mode", false));
   public final Setting.Bool auto = this.add(new Setting.Bool("auto", "Автоподбор пресета", "Automatic preset", false));
   public final Setting.Action apply = this.add(new Setting.Action("apply", "Применить пресет", "Apply preset", () -> this.applyPreset(true)));
   public final Setting.Action bench = this.add(new Setting.Action("benchmark", "Замерить FPS (10 сек)", "Benchmark FPS (10 s)", this::startBenchmark));
   public final List<PerformanceModule.Result> results = new ArrayList<>();
   private long benchUntil;
   private final List<Double> samples = new ArrayList<>();
   private int autoTicks = -1;
   private boolean lastLowEnd;

   public PerformanceModule() {
      super(
         "performance",
         Category.PERFORMANCE,
         true,
         "Пресеты производительности",
         "Performance Presets",
         "Быстро настроить баланс между FPS и красотой",
         "Quickly balance FPS against visuals"
      );
   }

   @Override
   public boolean toggleable() {
      return false;
   }

   @Override
   public void setEnabled(boolean e) {
      super.setEnabled(true);
   }

   @Override
   public boolean showInArray() {
      return false;
   }

   private static void on(String id, boolean v) {
      Module m = Modules.get(id);
      if (m != null) {
         m.setEnabled(v);
      }
   }

   public void applyPreset(boolean notify) {
      String p = this.preset.get();
      if (!p.equals("custom")) {
         ParticleModules.Engine eng = (ParticleModules.Engine)Modules.get("particle_engine");
         ChinaHat hat = Modules.chinaHat;
         switch (p) {
            case "max":
               eng.limit.set(300.0);
               hat.quality.set(16.0);

               for (String id : new String[]{
                  "bloom", "motion_blur", "dof", "color_grade", "vignette", "fireflies", "falling_leaves", "snow_particles", "sparkles", "custom_rain"
               }) {
                  on(id, false);
               }

               Modules.theme().shadows.value = false;
               Modules.theme().blur.value = false;
               break;
            case "balanced":
               eng.limit.set(1200.0);
               hat.quality.set(40.0);

               for (String id : new String[]{"bloom", "motion_blur", "dof"}) {
                  on(id, false);
               }

               Modules.theme().shadows.value = true;
               Modules.theme().blur.value = true;
               break;
            case "beautiful":
               eng.limit.set(2500.0);
               hat.quality.set(64.0);
               on("color_grade", true);
               on("vignette", true);
               Modules.theme().shadows.value = true;
               Modules.theme().blur.value = true;
               break;
            case "ultra":
               eng.limit.set(4000.0);
               hat.quality.set(96.0);
               on("color_grade", true);
               on("vignette", true);
               on("bloom", true);
               on("sparkles", true);
               Modules.theme().shadows.value = true;
               Modules.theme().blur.value = true;
         }

         if (this.vanilla.value) {
            class_315 o = mc.field_1690;
            switch (p) {
               case "max":
                  o.method_42475().method_41748(class_4066.field_18199);
                  o.method_42528().method_41748(class_4063.field_18162);
                  o.method_42435().method_41748(false);
                  break;
               case "balanced":
                  o.method_42475().method_41748(class_4066.field_18198);
                  o.method_42528().method_41748(class_4063.field_18163);
                  o.method_42435().method_41748(true);
                  break;
               default:
                  o.method_42475().method_41748(class_4066.field_18197);
                  o.method_42528().method_41748(class_4063.field_18164);
                  o.method_42435().method_41748(true);
            }

            o.method_1640();
         }

         Config.markDirty();
         if (notify) {
            Notifications.push(Lang.t("Пресет: ", "Preset: ") + this.preset.label(), true);
         }
      }
   }

   @Override
   public void onTick() {
      if (this.lowEnd.value != this.lastLowEnd) {
         this.lastLowEnd = this.lowEnd.value;
         Modules.theme().animations.value = !this.lowEnd.value;
         if (this.lowEnd.value) {
            ParticleEngine.clear();
            ((ParticleModules.Engine)Modules.get("particle_engine")).limit.set(200.0);

            for (Module m : Modules.all()) {
               if (m instanceof PlayerCosmetic pc) {
                  pc.others.value = false;
               }
            }
         }
      }

      if (this.auto.value && mc.field_1687 != null) {
         if (this.autoTicks < 0) {
            this.autoTicks = 300;
         } else if (this.autoTicks > 0 && --this.autoTicks == 0) {
            double fps = Info.avgFps();
            this.preset.load(fps < 45.0 ? "max" : (fps < 90.0 ? "balanced" : (fps < 160.0 ? "beautiful" : "ultra")));
            this.applyPreset(true);
         }
      }

      if (mc.field_1687 == null) {
         this.autoTicks = -1;
      }

      if (this.benchUntil > 0L) {
         this.samples.add((double)mc.method_47599());
         if (System.currentTimeMillis() > this.benchUntil) {
            this.benchUntil = 0L;
            PerformanceModule.Result r = new PerformanceModule.Result();
            r.preset = this.preset.label();
            r.avg = this.samples.stream().mapToDouble(d -> d).average().orElse(0.0);
            r.low = this.samples.stream().mapToDouble(d -> d).sorted().limit(Math.max(1, this.samples.size() / 10)).average().orElse(0.0);
            r.effects = activeEffects();
            this.results.add(0, r);
            if (this.results.size() > 6) {
               this.results.remove(this.results.size() - 1);
            }

            Notifications.push(String.format(Lang.t("Замер: %.0f FPS (низ. %.0f)", "Benchmark: %.0f FPS (low %.0f)"), r.avg, r.low), true);
         }
      }
   }

   public void startBenchmark() {
      if (mc.field_1687 == null) {
         Notifications.push(Lang.t("Зайди в мир для замера", "Join a world to benchmark"), false);
      } else {
         this.samples.clear();
         this.benchUntil = System.currentTimeMillis() + 10000L;
         Notifications.push(Lang.t("Замер FPS 10 секунд...", "Benchmarking FPS for 10 s..."), true);
      }
   }

   public boolean benchmarking() {
      return this.benchUntil > 0L;
   }

   public static int activeEffects() {
      int n = 0;

      for (Module m : Modules.all()) {
         if (m.isEnabled()
            && (m.category == Category.VISUALS || m.category == Category.COSMETICS || m.category == Category.WORLD || m.category == Category.PARTICLES)) {
            n++;
         }
      }

      return n;
   }

   public static final class Result {
      public String preset;
      public double avg;
      public double low;
      public int effects;
   }
}
