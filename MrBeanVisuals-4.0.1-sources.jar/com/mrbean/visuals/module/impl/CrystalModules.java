package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.render.World3D;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public final class CrystalModules {
   private static final class_310 mc = class_310.method_1551();

   private CrystalModules() {
   }

   public static void registerAll() {
      Modules.reg(new CrystalModules.Overlay());
      Modules.reg(new CrystalModules.Preview());
      Modules.reg(new CrystalModules.Render());
      Modules.reg(new CrystalModules.Explosions());
      Modules.reg(new CrystalModules.BreakParticles());
      Modules.reg(new CrystalModules.Counter());
   }

   static int colorOf(Setting.Mode mode, Setting.Color custom, float off) {
      if (mode.is("custom")) {
         return custom.argb | 0xFF000000;
      } else {
         return mode.is("rainbow") ? R2D.hsv(((float)(System.currentTimeMillis() % 4000L) / 4000.0F + off) % 1.0F, 0.7F, 1.0F) : R2D.accent(off);
      }
   }

   static Setting.Mode colorMode(String id) {
      return new Setting.Mode(id, "Цвет", "Color", 0, "theme", "Цвет темы", "Theme color", "rainbow", "Радуга", "Rainbow", "custom", "Свой", "Custom");
   }

   static void boxEdges(class_4588 vc, Matrix4f m, double x0, double y0, double z0, double x1, double y1, double z1, float t, int c) {
      float a = (float)x0;
      float b = (float)y0;
      float d = (float)z0;
      float e = (float)x1;
      float f = (float)y1;
      float g = (float)z1;
      bar(vc, m, a, b, d, e, b + t, d + t, c);
      bar(vc, m, a, b, g - t, e, b + t, g, c);
      bar(vc, m, a, f - t, d, e, f, d + t, c);
      bar(vc, m, a, f - t, g - t, e, f, g, c);
      bar(vc, m, a, b, d, a + t, b + t, g, c);
      bar(vc, m, e - t, b, d, e, b + t, g, c);
      bar(vc, m, a, f - t, d, a + t, f, g, c);
      bar(vc, m, e - t, f - t, d, e, f, g, c);
      bar(vc, m, a, b, d, a + t, f, d + t, c);
      bar(vc, m, e - t, b, d, e, f, d + t, c);
      bar(vc, m, a, b, g - t, a + t, f, g, c);
      bar(vc, m, e - t, b, g - t, e, f, g, c);
   }

   static void bar(class_4588 vc, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, int c) {
      float[] p0 = new float[]{x0, y0, z0};
      float[] p1 = new float[]{x1, y0, z0};
      float[] p2 = new float[]{x1, y1, z0};
      float[] p3 = new float[]{x0, y1, z0};
      float[] p4 = new float[]{x0, y0, z1};
      float[] p5 = new float[]{x1, y0, z1};
      float[] p6 = new float[]{x1, y1, z1};
      float[] p7 = new float[]{x0, y1, z1};
      World3D.quad(vc, m, p3, p2, p6, p7, c, c, c, c);
      World3D.quad(vc, m, p0, p1, p5, p4, c, c, c, c);
      World3D.quad(vc, m, p0, p1, p2, p3, c, c, c, c);
      World3D.quad(vc, m, p4, p5, p6, p7, c, c, c, c);
      World3D.quad(vc, m, p0, p4, p7, p3, c, c, c, c);
      World3D.quad(vc, m, p1, p5, p6, p2, c, c, c, c);
   }

   public static void renderWorld(class_4587 ms, class_4598 buf, class_243 cam, float td) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         if (Modules.get("crystal_overlay") instanceof CrystalModules.Overlay o && o.isEnabled()) {
            o.renderWorld(ms, buf, cam, td);
         }

         if (Modules.get("crystal_preview") instanceof CrystalModules.Preview p && p.isEnabled()) {
            p.renderWorld(ms, buf, cam);
         }
      }
   }

   public static class BreakParticles extends Module {
      final Setting.Num count = this.add(new Setting.Num("count", "Количество", "Count", 24.0, 4.0, 80.0, 2.0));
      final Setting.Num size = this.add(new Setting.Num("size", "Размер", "Size", 1.0, 0.4, 2.5, 0.1).suffix("x"));
      final Setting.Mode style = this.add(
         new Setting.Mode("style", "Вид", "Style", 0, "sparkle", "Искры", "Sparkles", "plain", "Точки", "Dots", "snow", "Хлопья", "Flakes")
      );
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -4956929))
         .showIf(() -> this.color.is("custom"));
      private final Map<Integer, class_243> last = new HashMap<>();
      private final Set<Integer> now = new HashSet<>();
      public static int breaks;

      public BreakParticles() {
         super(
            "crystal_particles",
            Category.CRYSTAL,
            false,
            "Частицы кристаллов",
            "Crystal Particles",
            "Свои настраиваемые частицы, когда рядом исчезает кристалл",
            "Custom particles when a nearby crystal disappears"
         );
      }

      @Override
      public void onTick() {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            this.now.clear();

            for (class_1297 e : mc.field_1687.method_18112()) {
               if (e instanceof class_1511 c && c.method_5858(mc.field_1724) < 2304.0) {
                  this.now.add(c.method_5628());
                  this.last.put(c.method_5628(), c.method_5829().method_1005());
               }
            }

            this.last.entrySet().removeIf(en -> {
               if (this.now.contains(en.getKey())) {
                  return false;
               } else {
                  class_243 p = en.getValue();
                  if (p.method_1025(mc.field_1724.method_73189()) < 1600.0) {
                     this.burst(p);
                  }

                  return true;
               }
            });
         } else {
            this.last.clear();
         }
      }

      private void burst(class_243 p) {
         breaks++;
         int n = this.count.i();
         int st = this.style.is("plain") ? 0 : (this.style.is("snow") ? 4 : 1);

         for (int i = 0; i < n; i++) {
            float vx = (float)(Math.random() - 0.5) * 0.35F;
            float vy = (float)Math.random() * 0.35F + 0.05F;
            float vz = (float)(Math.random() - 0.5) * 0.35F;
            ParticleEngine.spawn(
               p.field_1352,
               p.field_1351,
               p.field_1350,
               vx,
               vy,
               vz,
               22 + (int)(Math.random() * 14.0),
               (float)(0.16 * this.size.value),
               CrystalModules.colorOf(this.color, this.custom, (float)i / n),
               0.015F,
               0.92F,
               true,
               st
            );
         }
      }

      @Override
      public void onDisable() {
         this.last.clear();
      }
   }

   public static class Counter extends HudModule {
      final Setting.Bool obsidian = this.add(new Setting.Bool("obsidian", "Обсидиан", "Obsidian", true));
      final Setting.Bool nearby = this.add(new Setting.Bool("nearby", "Кристаллы рядом", "Crystals nearby", true));
      private int crystals;
      private int obs;
      private int near;

      public Counter() {
         super(
            "crystal_counter",
            false,
            0.5,
            0.74,
            "Crystal Counter",
            "Crystal Counter",
            "Кристаллы и обсидиан в инвентаре, кристаллы рядом",
            "Crystals and obsidian in inventory, crystals nearby"
         );
      }

      @Override
      protected void layout() {
         this.crystals = 0;
         this.obs = 0;
         this.near = 0;
         if (mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();

            for (int i = 0; i < inv.method_5439(); i++) {
               class_1799 s = inv.method_5438(i);
               if (s.method_31574(class_1802.field_8301)) {
                  this.crystals = this.crystals + s.method_7947();
               } else if (s.method_31574(class_1802.field_8281)) {
                  this.obs = this.obs + s.method_7947();
               }
            }

            if (this.nearby.value && mc.field_1687 != null) {
               for (class_1297 e : mc.field_1687.method_18112()) {
                  if (e instanceof class_1511 && e.method_5858(mc.field_1724) < 144.0) {
                     this.near++;
                  }
               }
            }
         }

         if (editing && this.crystals == 0) {
            this.crystals = 64;
            this.obs = 32;
            this.near = 2;
         }

         this.w = 18
            + this.tw(String.valueOf(this.crystals))
            + 6
            + (this.obsidian.value ? 18 + this.tw(String.valueOf(this.obs)) + 6 : 0)
            + (this.nearby.value ? this.tw("◆ " + this.near) + 2 : 0);
         this.h = 16;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         int x = 0;
         ctx.method_51427(new class_1799(class_1802.field_8301), x, 0);
         this.text(ctx, String.valueOf(this.crystals), x + 17, 5, this.crystals == 0 ? -42396 : -1);
         x += 18 + this.tw(String.valueOf(this.crystals)) + 6;
         if (this.obsidian.value) {
            ctx.method_51427(new class_1799(class_1802.field_8281), x, 0);
            this.text(ctx, String.valueOf(this.obs), x + 17, 5, -1);
            x += 18 + this.tw(String.valueOf(this.obs)) + 6;
         }

         if (this.nearby.value) {
            this.text(ctx, "◆ " + this.near, x, 5, this.accent(0.0F));
         }
      }
   }

   public static class Explosions extends Module {
      public final Setting.Mode vanilla = this.add(
         new Setting.Mode(
            "vanilla",
            "Обычные частицы взрыва",
            "Vanilla explosion particles",
            0,
            "normal",
            "Как в игре",
            "Normal",
            "reduced",
            "Меньше",
            "Reduced",
            "off",
            "Выключить",
            "Off"
         )
      );
      final Setting.Bool shockwave = this.add(new Setting.Bool("shockwave", "Ударная волна", "Shockwave", true));
      final Setting.Bool flash = this.add(new Setting.Bool("flash", "Вспышка", "Flash", true));
      final Setting.Num count = this.add(new Setting.Num("count", "Количество частиц", "Particle count", 40.0, 8.0, 120.0, 4.0));
      final Setting.Num size = this.add(new Setting.Num("size", "Размер частиц", "Particle size", 1.0, 0.4, 2.5, 0.1).suffix("x"));
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -30147))
         .showIf(() -> this.color.is("custom"));
      private long lastAt;
      private double lx;
      private double ly;
      private double lz;
      public static int bursts;
      public static int hidden;

      public Explosions() {
         super(
            "explosion_fx",
            Category.CRYSTAL,
            false,
            "Эффекты взрыва",
            "Explosion Effects",
            "Меньше «дыма» от взрывов и своя ударная волна нужного цвета",
            "Less explosion smoke and a custom-colored shockwave"
         );
      }

      public static CrystalModules.Explosions get() {
         return Modules.get("explosion_fx") instanceof CrystalModules.Explosions e && e.isEnabled() ? e : null;
      }

      public boolean onExplosionParticle(double x, double y, double z, boolean emitter) {
         long now = System.currentTimeMillis();
         boolean sameBlast = now - this.lastAt < 150L && (x - this.lx) * (x - this.lx) + (y - this.ly) * (y - this.ly) + (z - this.lz) * (z - this.lz) < 16.0;
         if (emitter && !sameBlast) {
            this.lastAt = now;
            this.lx = x;
            this.ly = y;
            this.lz = z;
            this.burst(x, y, z);
         }

         if (this.vanilla.is("off")) {
            hidden++;
            return true;
         } else {
            return this.vanilla.is("reduced") && Math.random() < 0.7;
         }
      }

      private void burst(double x, double y, double z) {
         bursts++;
         int n = this.count.i();
         float sz = (float)(0.22 * this.size.value);
         if (this.shockwave.value) {
            for (int i = 0; i < n; i++) {
               double a = (double)i / n * Math.PI * 2.0;
               float sp = 0.55F + (float)Math.random() * 0.1F;
               ParticleEngine.spawn(
                  x,
                  y + 0.2,
                  z,
                  (float)Math.cos(a) * sp,
                  0.02F,
                  (float)Math.sin(a) * sp,
                  14,
                  sz,
                  CrystalModules.colorOf(this.color, this.custom, (float)i / n),
                  0.0F,
                  0.86F,
                  true,
                  0
               );
            }
         }

         if (this.flash.value) {
            for (int i = 0; i < n / 2; i++) {
               float vx = (float)(Math.random() - 0.5) * 0.5F;
               float vy = (float)Math.random() * 0.45F;
               float vz = (float)(Math.random() - 0.5) * 0.5F;
               ParticleEngine.spawn(
                  x,
                  y + 0.5,
                  z,
                  vx,
                  vy,
                  vz,
                  18 + (int)(Math.random() * 10.0),
                  sz * 1.4F,
                  R2D.lerp(CrystalModules.colorOf(this.color, this.custom, 0.0F), -1, 0.5F),
                  0.01F,
                  0.9F,
                  true,
                  1
               );
            }
         }
      }
   }

   public static class Overlay extends Module {
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -4956929))
         .showIf(() -> this.color.is("custom"));
      final Setting.Bool box = this.add(new Setting.Bool("box", "Рамка", "Box", true));
      final Setting.Num fill = this.add(new Setting.Num("fill", "Заливка", "Fill", 18.0, 0.0, 80.0, 1.0).suffix("%"));
      final Setting.Bool ring = this.add(new Setting.Bool("ring", "Кольцо под кристаллом", "Ring under crystal", true));
      final Setting.Bool selected = this.add(new Setting.Bool("selected", "Выделять кристалл под прицелом", "Highlight aimed crystal", true));
      final Setting.Bool info = this.add(new Setting.Bool("info", "Подпись у прицела", "Label near crosshair", true));
      final Setting.Num range = this.add(new Setting.Num("range", "Дальность", "Range", 24.0, 4.0, 64.0, 1.0).suffix(" бл"));

      public Overlay() {
         super(
            "crystal_overlay",
            Category.CRYSTAL,
            false,
            "Crystal Overlay",
            "Crystal Overlay",
            "Рамка и кольцо вокруг видимых кристаллов, подсветка кристалла под прицелом",
            "Box and ring around visible crystals, highlight for the aimed crystal"
         );
      }

      void renderWorld(class_4587 ms, class_4598 buf, class_243 cam, float td) {
         double r2 = this.range.value * this.range.value;
         class_1297 aimed = mc.field_1692;
         class_4588 vc = buf.method_73477(World3D.normalLayer());
         int i = 0;

         for (class_1297 e : mc.field_1687.method_18112()) {
            if (e instanceof class_1511 c && !(c.method_5858(mc.field_1724) > r2) && mc.field_1724.method_6057(c)) {
               boolean sel = this.selected.value && c == aimed;
               int col = CrystalModules.colorOf(this.color, this.custom, i++ * 0.1F);
               if (sel) {
                  col = R2D.lerp(col, -1, 0.35F);
               }

               class_243 p = c.method_30950(td);
               class_238 bb = c.method_5829().method_989(-c.method_23317(), -c.method_23318(), -c.method_23321());
               ms.method_22903();
               ms.method_22904(p.field_1352 - cam.field_1352, p.field_1351 - cam.field_1351, p.field_1350 - cam.field_1350);
               Matrix4f m = ms.method_23760().method_23761();
               double grow = sel ? 0.06 : 0.02;
               if (this.fill.value > 0.0) {
                  CrystalModules.bar(
                     vc,
                     m,
                     (float)(bb.field_1323 - grow),
                     (float)(bb.field_1322 - grow),
                     (float)(bb.field_1321 - grow),
                     (float)(bb.field_1320 + grow),
                     (float)(bb.field_1325 + grow),
                     (float)(bb.field_1324 + grow),
                     R2D.withAlpha(col, (int)(255.0 * this.fill.value / 100.0 * (sel ? 1.6 : 1.0)))
                  );
               }

               if (this.box.value) {
                  CrystalModules.boxEdges(
                     vc,
                     m,
                     bb.field_1323 - grow,
                     bb.field_1322 - grow,
                     bb.field_1321 - grow,
                     bb.field_1320 + grow,
                     bb.field_1325 + grow,
                     bb.field_1324 + grow,
                     sel ? 0.05F : 0.03F,
                     R2D.withAlpha(col, 230)
                  );
               }

               if (this.ring.value) {
                  float spin = (float)(System.currentTimeMillis() % 3000L) / 3000.0F;
                  int fc = col;
                  World3D.ring(
                     vc, m, 0.02F, 0.75F, 0.95F, 32, (a, t) -> R2D.withAlpha(fc, (int)(200.0 * (0.4 + 0.6 * Math.abs(Math.sin((a + spin) * Math.PI * 2.0)))))
                  );
               }

               ms.method_22909();
            }
         }
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.info.value && mc.field_1692 instanceof class_1511 c && mc.field_1755 == null) {
            String s = "◆ "
               + Lang.t("Кристалл", "Crystal")
               + "  "
               + String.format("%.1f", Math.sqrt(c.method_5707(mc.field_1724.method_33571())))
               + Lang.t(" бл", " m");
            int w = R2D.width(s) + 10;
            int x = ctx.method_51421() / 2 + 10;
            int y = ctx.method_51443() / 2 + 8;
            R2D.round(ctx, x, y, w, 13, 6, -1879048192);
            R2D.text(ctx, s, x + 5, y + 3, CrystalModules.colorOf(this.color, this.custom, 0.0F), false);
         }
      }
   }

   public static class Preview extends Module {
      final Setting.Color ok = this.add(new Setting.Color("ok", "Цвет «можно»", "Valid color", -11870592));
      final Setting.Color bad = this.add(new Setting.Color("bad", "Цвет «нельзя»", "Invalid color", -42396));
      final Setting.Bool showBad = this.add(new Setting.Bool("show_bad", "Показывать «нельзя»", "Show invalid spots", true));
      final Setting.Num alpha = this.add(new Setting.Num("alpha", "Прозрачность", "Opacity", 35.0, 5.0, 90.0, 1.0).suffix("%"));

      public Preview() {
         super(
            "crystal_preview",
            Category.CRYSTAL,
            false,
            "Crystal Placement Preview",
            "Crystal Placement Preview",
            "С кристаллом в руке показывает, встанет ли он на блок под прицелом (обсидиан/бедрок)",
            "With a crystal in hand, shows whether it fits on the aimed block (obsidian/bedrock)"
         );
      }

      static boolean holding() {
         return mc.field_1724.method_5998(class_1268.field_5808).method_31574(class_1802.field_8301) || mc.field_1724.method_5998(class_1268.field_5810).method_31574(class_1802.field_8301);
      }

      static int check(class_2338 base) {
         class_2680 st = mc.field_1687.method_8320(base);
         if (!st.method_27852(class_2246.field_10540) && !st.method_27852(class_2246.field_9987)) {
            return -1;
         } else {
            class_2338 up = base.method_10084();
            if (!mc.field_1687.method_22347(up)) {
               return 0;
            } else {
               class_238 space = new class_238(up.method_10263(), up.method_10264(), up.method_10260(), up.method_10263() + 1, up.method_10264() + 2, up.method_10260() + 1);
               return mc.field_1687.method_8335(null, space).isEmpty() ? 1 : 0;
            }
         }
      }

      void renderWorld(class_4587 ms, class_4598 buf, class_243 cam) {
         if (holding()) {
            class_239 hr = mc.field_1765;
            if (hr instanceof class_3965 bhr && hr.method_17783() == class_240.field_1332) {
               class_2338 base = bhr.method_17777();
               int r = check(base);
               if (r >= 0 && (r != 0 || this.showBad.value)) {
                  int col = r == 1 ? this.ok.argb | 0xFF000000 : this.bad.argb | 0xFF000000;
                  float pulse = 0.75F + 0.25F * (float)Math.sin(System.currentTimeMillis() / 180.0);
                  class_4588 vc = buf.method_73477(World3D.normalLayer());
                  ms.method_22903();
                  ms.method_22904(base.method_10263() - cam.field_1352, base.method_10264() - cam.field_1351, base.method_10260() - cam.field_1350);
                  Matrix4f m = ms.method_23760().method_23761();
                  CrystalModules.bar(vc, m, 0.0F, 1.001F, 0.0F, 1.0F, 1.02F, 1.0F, R2D.withAlpha(col, (int)(255.0 * this.alpha.value / 100.0 * pulse)));
                  CrystalModules.boxEdges(vc, m, 0.02, 1.02, 0.02, 0.98, 1.98, 0.98, 0.025F, R2D.withAlpha(col, (int)(220.0F * pulse)));
                  if (r == 1) {
                     ms.method_22903();
                     ms.method_22904(0.5, 1.5, 0.5);
                     ms.method_22907(class_7833.field_40716.rotationDegrees((float)(System.currentTimeMillis() % 3600L) / 10.0F));
                     ms.method_22907(class_7833.field_40714.rotationDegrees(45.0F));
                     ms.method_22907(class_7833.field_40718.rotationDegrees(35.0F));
                     World3D.cube(vc, ms.method_23760().method_23761(), 0.42F, R2D.withAlpha(col, 140), R2D.withAlpha(col, 110), R2D.withAlpha(col, 90));
                     ms.method_22909();
                  }

                  ms.method_22909();
               }
            }
         }
      }
   }

   public static class Render extends Module {
      public final Setting.Num alpha = this.add(new Setting.Num("alpha", "Непрозрачность", "Opacity", 100.0, 10.0, 100.0, 1.0).suffix("%"));
      public final Setting.Num scale = this.add(new Setting.Num("scale", "Размер", "Size", 1.0, 0.3, 1.5, 0.05).suffix("x"));
      public final Setting.Num spin = this.add(new Setting.Num("spin", "Скорость вращения", "Spin speed", 1.0, 0.0, 3.0, 0.1).suffix("x"));
      public final Setting.Bool tint = this.add(new Setting.Bool("tint", "Окрашивать", "Tint", false));
      public final Setting.Mode color = (Setting.Mode)this.add(CrystalModules.colorMode("color")).showIf(() -> this.tint.value);
      public final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -4956929))
         .showIf(() -> this.tint.value && this.color.is("custom"));
      public final Setting.Num distance = this.add(new Setting.Num("distance", "Дальность отрисовки", "Render distance", 64.0, 4.0, 128.0, 2.0).suffix(" бл"));

      public Render() {
         super(
            "crystal_render",
            Category.CRYSTAL,
            false,
            "Crystal Render",
            "Crystal Render",
            "Прозрачность, размер, вращение, цвет и дальность отрисовки кристаллов",
            "Crystal opacity, size, spin, color and render distance"
         );
      }

      public static CrystalModules.Render get() {
         return Modules.get("crystal_render") instanceof CrystalModules.Render r && r.isEnabled() ? r : null;
      }

      public int tintColor() {
         int a = (int)(255.0 * this.alpha.value / 100.0);
         int rgb = this.tint.value ? CrystalModules.colorOf(this.color, this.custom, 0.0F) & 16777215 : 16777215;
         return a << 24 | rgb;
      }
   }
}
