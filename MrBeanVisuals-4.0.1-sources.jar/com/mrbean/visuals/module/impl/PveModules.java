package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.LastServer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4174;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

/**
 * PVE-набор: всё, что помогает жить на выживании и на ReallyWorld, а не в PvP.
 * Модули работают только через клиентские данные (инвентарь, прицел, прочность), ничего
 * не угадывают и не подменяют серверную логику.
 */
public final class PveModules {
   private PveModules() {
   }

   public static void registerAll() {
      // Auto Clicker и Fast Inventory Move удалены (нечестные), Auto Eat заменён на Eat Reminder.
      Modules.reg(new PveModules.AutoFixAll());
      Modules.reg(new PveModules.InventoryOrganizer());
      Modules.reg(new PveModules.EatReminder());
   }

   /** Порядок страницы PVE: свои модули плюс уже готовые предупреждения из других категорий. */
   public static List<Module> page() {
      String[] order = new String[]{"auto_fix_all", "durability_warning", "inv_organizer", "eat_reminder", "totem_alert"};
      List<Module> out = new ArrayList<>();

      for (String id : order) {
         Module m = Modules.get(id);
         if (m != null) {
            out.add(m);
         }
      }

      for (Module m : Modules.of(Category.PVE)) {
         if (!out.contains(m)) {
            out.add(m);
         }
      }

      return out;
   }

   /** Прочность (0..1) самой убитой вещи из брони и рук; 1, если ломаться нечему. */
   static float worstGear() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null || mc.field_1724.method_68878()) {
         return 1.0F;
      } else {
         float worst = 1.0F;

         for (class_1304 s : new class_1304[]{
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6173, class_1304.field_6171
         }) {
            class_1799 st = mc.field_1724.method_6118(s);
            if (!st.method_7960() && st.method_7963() && st.method_7936() > 0) {
               worst = Math.min(worst, 1.0F - (float)st.method_7919() / st.method_7936());
            }
         }

         return worst;
      }
   }

   public static class AutoFixAll extends Module {
      final Setting.Num threshold = this.add(
         new Setting.Num("threshold", "Чинить при прочности ниже", "Repair below", 25.0, 5.0, 80.0, 5.0).suffix("%")
      );
      final Setting.Text command = this.add(new Setting.Text("command", "Команда починки", "Repair command", "/fix all"));
      final Setting.Num cooldown = this.add(
         new Setting.Num("cooldown", "Не чаще, чем раз в", "At most once per", 60.0, 10.0, 600.0, 10.0).suffix(" с")
      );
      final Setting.Bool onlyRw = this.add(new Setting.Bool("only_rw", "Только на ReallyWorld", "Only on ReallyWorld", true));
      final Setting.Bool onJoin = this.add(new Setting.Bool("on_join", "Чинить сразу при входе", "Repair right after joining", true));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомления", "Notifications", true));
      private long next;
      private boolean inWorld;

      public AutoFixAll() {
         super(
            "auto_fix_all",
            Category.PVE,
            false,
            "Auto Fix All",
            "Auto Fix All",
            "Сам отправляет команду починки, когда броня или инструмент почти сломались. Команда сервера меняется в настройках",
            "Sends the repair command itself when armor or a tool is about to break. The server command is editable"
         );
      }

      @Override
      public void onEnable() {
         this.next = System.currentTimeMillis() + 4000L;
         this.inWorld = mc.field_1687 != null;
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null && mc.method_1562() != null) {
            boolean now = mc.field_1687 != null;
            if (now && !this.inWorld && this.onJoin.value) {
               this.next = System.currentTimeMillis() + 5000L;
            }

            this.inWorld = now;
            long t = System.currentTimeMillis();
            if (t >= this.next
               && (!this.onlyRw.value || LastServer.currentAddress(mc).contains("reallyworld"))
               && PveModules.worstGear() * 100.0F <= this.threshold.value) {
               String c = this.command.value == null ? "" : this.command.value.trim();
               if (!c.isEmpty()) {
                  if (c.startsWith("/")) {
                     mc.method_1562().method_45730(c.substring(1));
                  } else {
                     mc.method_1562().method_45729(c);
                  }

                  if (this.notify.value) {
                     Notifications.push(Lang.t("Починка: ", "Repair: ") + c, true);
                  }
               }

               this.next = t + (long)(Math.max(10.0, this.cooldown.value) * 1000.0);
            }
         } else {
            this.inWorld = false;
         }
      }
   }

   public static class InventoryOrganizer extends Module {
      final Setting.Key key = this.add(new Setting.Key("key", "Клавиша сортировки", "Sort key", 89));
      final Setting.Action sortBtn = this.add(new Setting.Action("sort", "Отсортировать сейчас", "Sort now", this::start));
      final Setting.Mode order = this.add(
         new Setting.Mode(
            "order",
            "Порядок",
            "Order",
            0,
            "type",
            "По типу и количеству",
            "By type and count",
            "name",
            "По названию",
            "By name",
            "size",
            "По количеству",
            "By count"
         )
      );
      final Setting.Bool keepHotbar = this.add(new Setting.Bool("keep_hotbar", "Не трогать хотбар", "Leave the hotbar alone", true));
      final Setting.Bool autoOpen = this.add(new Setting.Bool("auto_open", "Открывать инвентарь сам", "Open the inventory itself", true));
      final Setting.Num swaps = this.add(new Setting.Num("swaps", "Обменов за тик", "Swaps per tick", 2.0, 1.0, 6.0, 1.0));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление в конце", "Notify when done", true));
      private boolean running;
      private boolean opened;
      private boolean wasDown;
      private int closeIn;

      public InventoryOrganizer() {
         super(
            "inv_organizer",
            Category.PVE,
            false,
            "Inventory Organizer",
            "Inventory Organizer",
            "Раскладывает инвентарь по порядку: одинаковые предметы собираются рядом. Клавиша по умолчанию Y",
            "Sorts the inventory so identical items end up next to each other. Default key Y"
         );
      }

      @Override
      public void onDisable() {
         this.running = false;
         this.opened = false;
         this.wasDown = false;
         this.closeIn = 0;
      }

      void start() {
         if (mc.field_1724 != null) {
            if (mc.field_1755 == null) {
               if (!this.autoOpen.value) {
                  Notifications.push(Lang.t("Открой инвентарь и нажми ещё раз", "Open the inventory and press again"), false);
                  return;
               }

               this.opened = true;
               mc.method_1507(new class_490(mc.field_1724));
            } else if (!(mc.field_1755 instanceof class_465)) {
               return;
            }

            this.running = true;
            this.closeIn = 0;
         }
      }

      @Override
      public void onTick() {
         boolean down = this.key.isDown();
         if (down && !this.wasDown) {
            this.start();
         }

         this.wasDown = down;
         if (this.running) {
            if (mc.field_1724 == null || mc.field_1761 == null || !(mc.field_1755 instanceof class_465)) {
               this.running = false;
               this.opened = false;
            } else {
               int n = 0;

               for (int i = this.swaps.i(); i > 0 && this.step(); i--) {
                  n++;
               }

               if (n == 0) {
                  this.running = false;
                  if (this.notify.value) {
                     Notifications.push(Lang.t("Инвентарь отсортирован", "Inventory sorted"), true);
                  }

                  if (this.opened) {
                     this.closeIn = 6;
                  }
               }
            }
         }

         if (this.closeIn > 0 && --this.closeIn == 0) {
            this.opened = false;
            if (mc.field_1724 != null && mc.field_1755 instanceof class_465) {
               mc.field_1724.method_7346();
            }
         }
      }

      /** Один обмен местами. false — всё уже на своих местах. */
      private boolean step() {
         class_1703 h = mc.field_1724.field_7512;
         List<class_1735> slots = this.slots(h);
         if (slots.size() < 2) {
            return false;
         } else {
            List<class_1799> have = new ArrayList<>();

            for (class_1735 s : slots) {
               have.add(s.method_7677());
            }

            List<class_1799> want = new ArrayList<>(have);
            want.sort(this.comparator());

            for (int i = 0; i < have.size(); i++) {
               if (!class_1799.method_7973(have.get(i), want.get(i))) {
                  for (int j = i + 1; j < have.size(); j++) {
                     if (class_1799.method_7973(have.get(j), want.get(i))) {
                        this.swap(h, slots.get(i).field_7874, slots.get(j).field_7874);
                        return true;
                     }
                  }
               }
            }

            return false;
         }
      }

      /** Меняет два слота тремя кликами, курсор в конце пустой. */
      private void swap(class_1703 h, int a, int b) {
         mc.field_1761.method_2906(h.field_7763, a, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(h.field_7763, b, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(h.field_7763, a, 0, class_1713.field_7790, mc.field_1724);
      }

      private List<class_1735> slots(class_1703 h) {
         class_1661 inv = mc.field_1724.method_31548();
         List<class_1735> out = new ArrayList<>();

         for (class_1735 s : h.field_7761) {
            if (s.field_7871 == inv && s.method_7682() && (!this.keepHotbar.value || s.method_34266() >= 9)) {
               out.add(s);
            }
         }

         return out;
      }

      private Comparator<class_1799> comparator() {
         Comparator<class_1799> c = Comparator.comparing((class_1799 s) -> s.method_7960() ? 1 : 0);
         if (this.order.is("name")) {
            return c.thenComparing(InventoryOrganizer::label, String.CASE_INSENSITIVE_ORDER)
               .thenComparing((class_1799 s) -> -s.method_7947());
         } else if (this.order.is("size")) {
            return c.thenComparing((class_1799 s) -> -s.method_7947()).thenComparing(InventoryOrganizer::id);
         } else {
            return c.thenComparing(InventoryOrganizer::id).thenComparing((class_1799 s) -> -s.method_7947()).thenComparing(class_1799::method_7919);
         }
      }

      private static String id(class_1799 s) {
         return class_7923.field_41178.method_10221(s.method_7909()).toString();
      }

      private static String label(class_1799 s) {
         return s.method_7964().getString();
      }
   }

   /**
    * Честная замена бывшего Auto Eat: только подсказывает. Сам слот не переключает и есть не начинает —
    * игрок жмёт цифру слота и ПКМ как обычно.
    */
   public static class EatReminder extends Module {
      final Setting.Num hunger = this.add(
         new Setting.Num("hunger", "Напоминать при голоде ниже", "Remind below hunger", 14.0, 1.0, 20.0, 1.0).suffix(" 🍗")
      );
      final Setting.Bool highlight = this.add(new Setting.Bool("highlight", "Подсвечивать еду в хотбаре", "Highlight food in the hotbar", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук", "Sound", true));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление", "Notification", true));
      private boolean wasHungry;

      public EatReminder() {
         super(
            "eat_reminder",
            Category.PVE,
            false,
            "Eat Reminder",
            "Eat Reminder",
            "Напоминает поесть, когда голод ниже порога, и подсвечивает еду в хотбаре. Сам предметы не берёт и не ест",
            "Reminds you to eat when hunger drops below the threshold and highlights food in the hotbar. Never switches or eats by itself"
         );
      }

      @Override
      public void onDisable() {
         this.wasHungry = false;
      }

      private boolean hungry() {
         return mc.field_1724 != null
            && !mc.field_1724.method_68878()
            && !mc.field_1724.method_7325()
            && (double)mc.field_1724.method_7344().method_7586() < this.hunger.value;
      }

      /** Самая сытная еда в хотбаре или -1. */
      private int foodSlot() {
         class_1661 inv = mc.field_1724.method_31548();
         int best = -1;
         float bestScore = -1.0F;

         for (int i = 0; i < 9; i++) {
            class_4174 f = inv.method_5438(i).method_58694(class_9334.field_50075);
            if (f != null) {
               float sc = f.comp_2491() + f.comp_2492() * 2.0F;
               if (sc > bestScore) {
                  bestScore = sc;
                  best = i;
               }
            }
         }

         return best;
      }

      @Override
      public void onTick() {
         boolean h = this.hungry();
         if (h && !this.wasHungry) {
            if (this.sound.value) {
               Sounds.play(Sounds.OFF);
            }

            if (this.notify.value) {
               int s = this.foodSlot();
               Notifications.push(
                  s >= 0
                     ? Lang.t("Пора поесть — еда в слоте ", "Time to eat — food in slot ") + (s + 1)
                     : Lang.t("Пора поесть — в хотбаре нет еды", "Time to eat — no food in the hotbar"),
                  false
               );
            }
         }

         this.wasHungry = h;
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.highlight.value && this.wasHungry && mc.field_1724 != null && mc.field_1755 == null && !mc.field_1690.field_1842) {
            int s = this.foodSlot();
            if (s >= 0 && mc.field_1724.method_31548().method_67532() != s && !mc.field_1724.method_6079().method_57826(class_9334.field_50075)) {
               float beat = (float)(Math.sin(System.currentTimeMillis() / 160.0) + 1.0) / 2.0F;
               int x = ctx.method_51421() / 2 - 91 + s * 20;
               int y = ctx.method_51443() - 22;
               R2D.outline(ctx, x, y, 22, 22, 4, R2D.lerp(-16051, -1, beat));
            }
         }
      }
   }
}
