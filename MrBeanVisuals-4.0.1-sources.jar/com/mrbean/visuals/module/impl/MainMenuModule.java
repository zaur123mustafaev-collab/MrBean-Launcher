package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Setting;

public class MainMenuModule extends Module {
   public final Setting.Bool particles = this.add(new Setting.Bool("particles", "Частицы на фоне", "Background particles", true));
   public final Setting.Num count = (Setting.Num)this.add(new Setting.Num("count", "Количество частиц", "Particle count", 70.0, 10.0, 200.0, 5.0))
      .showIf(() -> this.particles.value);
   public final Setting.Bool glow = this.add(new Setting.Bool("glow", "Цветное свечение", "Color glow", true));
   public final Setting.Bool otherScreens = this.add(
      new Setting.Bool("other_screens", "Стиль для мультиплеера и других меню", "Style multiplayer & other menus", true)
   );
   public final Setting.Bool accountCard = this.add(new Setting.Bool("account_card", "Карточка аккаунта", "Account card", true));
   public final Setting.Bool tips = this.add(new Setting.Bool("tips", "Подсказки внизу", "Tips at the bottom", true));
   public final Setting.Bool intro = this.add(new Setting.Bool("intro", "Анимация появления", "Intro animation", true));

   public MainMenuModule() {
      super(
         "main_menu",
         Category.VISUALS,
         true,
         "Главное меню MrBean",
         "MrBean Main Menu",
         "Своё анимированное главное меню, смена аккаунта и красивый фон для мультиплеера",
         "Custom animated main menu, account switcher and styled multiplayer background"
      );
   }

   @Override
   public boolean showInArray() {
      return false;
   }
}
