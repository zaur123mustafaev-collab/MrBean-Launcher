package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.EmoteCatalogScreen;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.net.EmoteNetwork;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1102;
import net.minecraft.class_1113;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5498;
import net.minecraft.class_5819;

/**
 * Эмоции персонажа. Позы считаются процедурно по t (0..1), mixin добавляет их к ванильным углам модели.
 * Своя поза ставится сразу локально, а на сервер уходит EmoteProtocol.Play — сервер показывает её
 * остальным, если стоит MrBeanServerBridge или MrBeanBadgePlugin. Без моста эмоция видна только себе.
 * Зацикленная эмоция крутится бесконечно, пока её не выключат повторным кликом.
 */
public final class Emotes {
   private static final float R = (float)Math.PI / 180.0F;
   private static final Map<String, Def> DEFS = new LinkedHashMap<>();
   private static final Map<Integer, Run> RUNS = new ConcurrentHashMap<>();
   private static final Pose SHARED = new Pose();
   private static class_1113 loopSound;
   private static class_1113 listenSound;
   /** Разделы каталога: танцы, жесты, мемы. */
   public static final String G_DANCE = "dance";
   public static final String G_GESTURE = "gesture";
   public static final String G_MEME = "meme";
   private static final List<String> GROUPS = List.of(G_DANCE, G_GESTURE, G_MEME);

   private Emotes() {
   }

   public static final class Pose {
      public float headPitch;
      public float headYaw;
      public float headRoll;
      public float bodyPitch;
      public float bodyYaw;
      public float rArmPitch;
      public float rArmYaw;
      public float rArmRoll;
      public float lArmPitch;
      public float lArmYaw;
      public float lArmRoll;
      public float rLegPitch;
      public float lLegPitch;
      /** Отвод ноги в сторону; знак как у рук: правая наружу — минус, левая — плюс. */
      public float rLegRoll;
      public float lLegRoll;
      public boolean legs;
      public float strength;

      public void clear() {
         this.headPitch = 0.0F;
         this.headYaw = 0.0F;
         this.headRoll = 0.0F;
         this.bodyPitch = 0.0F;
         this.bodyYaw = 0.0F;
         this.rArmPitch = 0.0F;
         this.rArmYaw = 0.0F;
         this.rArmRoll = 0.0F;
         this.lArmPitch = 0.0F;
         this.lArmYaw = 0.0F;
         this.lArmRoll = 0.0F;
         this.rLegPitch = 0.0F;
         this.lLegPitch = 0.0F;
         this.rLegRoll = 0.0F;
         this.lLegRoll = 0.0F;
         this.legs = false;
      }

      public void leg(float right, float left) {
         this.rLegPitch = right;
         this.lLegPitch = left;
         this.legs = true;
      }

      public void legRoll(float right, float left) {
         this.rLegRoll = right;
         this.lLegRoll = left;
         this.legs = true;
      }

      /** Подмешивает позу фазы с весом w (фазы клипа суммируются, веса на стыках дают 1). */
      void add(Pose o, float w) {
         this.headPitch += o.headPitch * w;
         this.headYaw += o.headYaw * w;
         this.headRoll += o.headRoll * w;
         this.bodyPitch += o.bodyPitch * w;
         this.bodyYaw += o.bodyYaw * w;
         this.rArmPitch += o.rArmPitch * w;
         this.rArmYaw += o.rArmYaw * w;
         this.rArmRoll += o.rArmRoll * w;
         this.lArmPitch += o.lArmPitch * w;
         this.lArmYaw += o.lArmYaw * w;
         this.lArmRoll += o.lArmRoll * w;
         this.rLegPitch += o.rLegPitch * w;
         this.lLegPitch += o.lLegPitch * w;
         this.rLegRoll += o.rLegRoll * w;
         this.lLegRoll += o.lLegRoll * w;
         this.legs |= o.legs;
      }
   }

   public interface Clip {
      void apply(Pose var1, float var2);
   }

   /** sound — идентификатор SoundEvent или null; music — цикл крутится по длине трека; group — раздел каталога. */
   public record Def(String id, String ru, String en, String group, float seconds, Clip clip, String sound, boolean music) {
   }

   private static final class Run {
      final Def def;
      final long start;
      final float seconds;
      final boolean loop;
      long stopAt;

      Run(Def def, long start, float seconds, boolean loop) {
         this.def = def;
         this.start = start;
         this.seconds = seconds;
         this.loop = loop;
      }
   }

   private static void reg(String group, String id, String ru, String en, float seconds, Clip clip) {
      reg(group, id, ru, en, seconds, clip, null, false);
   }

   private static void reg(String group, String id, String ru, String en, float seconds, Clip clip, String sound) {
      reg(group, id, ru, en, seconds, clip, sound, false);
   }

   private static void reg(String group, String id, String ru, String en, float seconds, Clip clip, String sound, boolean music) {
      DEFS.put(id, new Def(id, ru, en, group, seconds, clip, sound, music));
   }

   /** Все эмоции одного раздела каталога (null — все подряд). */
   public static List<Def> of(String group) {
      List<Def> out = new ArrayList<>();

      for (Def d : DEFS.values()) {
         if (group == null || group.equals(d.group())) {
            out.add(d);
         }
      }

      return out;
   }

   public static List<String> groups() {
      return GROUPS;
   }

   public static String groupRu(String g) {
      return switch (g) {
         case G_DANCE -> "Танцы";
         case G_MEME -> "Мемы";
         default -> "Жесты";
      };
   }

   public static String groupEn(String g) {
      return switch (g) {
         case G_DANCE -> "Dance";
         case G_MEME -> "Meme";
         default -> "Gestures";
      };
   }

   public static String groupIcon(String g) {
      return switch (g) {
         case G_DANCE -> "♫";
         case G_MEME -> "☻";
         default -> "✋";
      };
   }

   public static Def def(String id) {
      return id == null ? null : DEFS.get(id.toLowerCase());
   }

   public static List<Def> all() {
      return new ArrayList<>(DEFS.values());
   }

   public static String ids() {
      return String.join(", ", DEFS.keySet());
   }

   public static boolean play(int entityId, String id, float speed) {
      return play(entityId, id, speed, false);
   }

   public static boolean play(int entityId, String id, float speed, boolean loop) {
      return play(entityId, id, speed, loop, false);
   }

   /** force=true заменяет текущую эмоцию (нужно для предпросмотра в колесе). */
   public static boolean play(int entityId, String id, float speed, boolean loop, boolean force) {
      Def d = def(id);
      if (d == null) {
         return false;
      } else if (!force && busy(entityId)) {
         return false;
      } else {
         RUNS.put(entityId, new Run(d, System.currentTimeMillis(), Math.max(0.2F, d.seconds() / Math.max(0.2F, speed)), loop));
         if (isSelf(entityId)) {
            startSound(d);
         }

         return true;
      }
   }

   /** Мягкая остановка: позa гаснет за треть секунды, звук обрывается сразу. */
   public static void stop(int entityId) {
      Run r = RUNS.get(entityId);
      if (r != null) {
         if (r.loop && r.stopAt == 0L) {
            r.stopAt = System.currentTimeMillis() + 320L;
         } else {
            RUNS.remove(entityId);
         }

         if (isSelf(entityId)) {
            stopSound();
         }
      }
   }

   public static void stopNow(int entityId) {
      RUNS.remove(entityId);
      if (isSelf(entityId)) {
         stopSound();
      }
   }

   public static String current(int entityId) {
      Run r = RUNS.get(entityId);
      return r == null ? null : r.def.id();
   }

   public static boolean isLooping(int entityId) {
      Run r = RUNS.get(entityId);
      return r != null && r.loop && r.stopAt == 0L;
   }

   public static boolean busy(int entityId) {
      Run r = RUNS.get(entityId);
      if (r == null) {
         return false;
      } else if (r.loop) {
         return alive(r, System.currentTimeMillis());
      } else if (progress(r) >= 1.0F) {
         RUNS.remove(entityId);
         return false;
      } else {
         return true;
      }
   }

   private static float progress(Run r) {
      return (float)(System.currentTimeMillis() - r.start) / 1000.0F / r.seconds;
   }

   private static boolean running(Run r, long now) {
      return r.loop ? alive(r, now) : progress(r) < 1.0F;
   }

   private static boolean alive(Run r, long now) {
      if (r.stopAt != 0L) {
         return now < r.stopAt;
      } else {
         return now - r.start < 600000L;
      }
   }

   /** Заполняет общую позу и возвращает силу подмешивания в Pose.strength; null, если эмоции нет. */
   public static Pose pose(int entityId) {
      Run r = RUNS.get(entityId);
      if (r == null) {
         return null;
      } else {
         long now = System.currentTimeMillis();
         float raw = progress(r);
         float b;
         float t;
         if (r.loop) {
            if (!alive(r, now)) {
               RUNS.remove(entityId);
               return null;
            }

            t = raw - (float)Math.floor(raw);
            b = Math.min(1.0F, (float)(now - r.start) / 350.0F);
            if (r.stopAt != 0L) {
               b = Math.min(b, Math.max(0.0F, (float)(r.stopAt - now) / 320.0F));
            }
         } else {
            if (raw >= 1.0F) {
               RUNS.remove(entityId);
               return null;
            }

            t = raw;
            b = t < 0.12F ? t / 0.12F : (t > 0.78F ? (1.0F - t) / 0.22F : 1.0F);
         }

         SHARED.clear();
         r.def.clip().apply(SHARED, Math.max(0.0F, t));
         SHARED.strength = Math.max(0.0F, Math.min(1.0F, b));
         return SHARED;
      }
   }

   /** Убирает эмоции игроков, которых уже нет в мире, и всё при выходе из мира. */
   public static void tickCleanup() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1687 == null || mc.field_1724 == null) {
         RUNS.clear();
         stopSound();
         stopListen();
         releaseFace();
      } else {
         long now = System.currentTimeMillis();

         for (Map.Entry<Integer, Run> e : RUNS.entrySet()) {
            int id = e.getKey();
            // кроме ушедших игроков убираем и отыгравшие позы: в первом лице pose() не зовётся, и они висели вечно,
            // из-за чего эмоция выглядела «играющей» и повторный клик не выключал, а перезапускал её
            if (id != mc.field_1724.method_5628() && mc.field_1687.method_8469(id) == null || !running(e.getValue(), now)) {
               RUNS.remove(id);
            }
         }

         if (loopSound != null && !RUNS.containsKey(mc.field_1724.method_5628())) {
            // поза доиграла или упёрлась в лимит — трек без неё не живёт
            stopSound();
         }

         faceView(RUNS.containsKey(mc.field_1724.method_5628()));
      }
   }

   private static class_5498 savedView;

   /**
    * Авто-F5 на лицо: в первом лице свою эмоцию не видно, поэтому на время эмоции или предпросмотра
    * ставим вид спереди, а когда поза доиграла — возвращаем прежнюю перспективу.
    */
   private static void faceView(boolean want) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      boolean on = want && em != null && em.autoFace.get();
      if (on && savedView == null) {
         savedView = mc.field_1690.method_31044();
         mc.field_1690.method_31043(class_5498.field_26666);
      } else if (!on && savedView != null) {
         mc.field_1690.method_31043(savedView);
         savedView = null;
      }
   }

   /** Возвращает перспективу, которую подменил авто-F5. */
   public static void releaseFace() {
      class_310 mc = class_310.method_1551();
      if (savedView != null) {
         mc.field_1690.method_31043(savedView);
         savedView = null;
      }
   }

   private static boolean isSelf(int entityId) {
      class_310 mc = class_310.method_1551();
      return mc.field_1724 != null && mc.field_1724.method_5628() == entityId;
   }

   private static void startSound(Def d) {
      stopSound();
      if (d.sound() == null) {
         return;
      } else {
         EmoteModule em = module();
         if (em != null && !em.sounds.get()) {
            return;
         } else {
            class_2960 id = class_2960.method_12829(d.sound());
            if (id == null) {
               return;
            } else {
               float vol = em == null ? 0.8F : (float)(em.soundVolume.value / 100.0);
               if (vol <= 0.001F) {
                  return;
               } else {
                  loopSound = new EmoteSound(class_3414.method_47908(id), vol, d.music());

                  try {
                     class_310.method_1551().method_1483().method_4873(loopSound);
                  } catch (Exception var4) {
                     loopSound = null;
                  }
               }
            }
         }
      }
   }

   public static void stopSound() {
      if (loopSound != null) {
         class_1113 inst = loopSound;
         loopSound = null;

         try {
            class_310.method_1551().method_1483().method_4870(inst);
         } catch (Exception var2) {
         }
      }
   }

   /** Прослушать звук эмоции, не запуская анимацию. Громкость — та же настройка, что и у эмоций. */
   public static boolean listen(Def d) {
      stopListen();
      if (d == null || d.sound() == null) {
         return false;
      } else {
         class_2960 id = class_2960.method_12829(d.sound());
         if (id == null) {
            return false;
         } else {
            EmoteModule em = module();
            float vol = em == null ? 0.8F : (float)(em.soundVolume.value / 100.0);
            if (vol <= 0.001F) {
               return false;
            } else {
               listenSound = new EmoteSound(class_3414.method_47908(id), vol, false);

               try {
                  class_310.method_1551().method_1483().method_4873(listenSound);
                  return true;
               } catch (Exception var4) {
                  listenSound = null;
                  return false;
               }
            }
         }
      }
   }

   public static void stopListen() {
      if (listenSound != null) {
         class_1113 inst = listenSound;
         listenSound = null;

         try {
            class_310.method_1551().method_1483().method_4870(inst);
         } catch (Exception var2) {
         }
      }
   }

   private static final class EmoteSound extends class_1102 {
      EmoteSound(class_3414 e, float vol, boolean loop) {
         super(e, class_3419.field_15247, class_5819.method_43047());
         this.field_5442 = vol;
         this.field_5441 = 1.0F;
         this.field_5446 = loop;
         this.field_5440 = class_1114.field_5478;
      }

      public boolean method_26273() {
         return true;
      }

      public boolean method_4785() {
         return true;
      }
   }

   private static float sin(float cycles, float t) {
      return (float)Math.sin(t * cycles * Math.PI * 2.0);
   }

   /** Вес фазы [a, b) клипа с плавным переходом ±f на границах; соседние фазы в сумме дают 1. */
   private static float win(float t, float a, float b, float f) {
      float in = Math.max(0.0F, Math.min(1.0F, (t - a) / f + 0.5F));
      float out = Math.max(0.0F, Math.min(1.0F, (b - t) / f + 0.5F));
      return in * out;
   }

   private static final Pose TMP = new Pose();

   /** Фаза клипа: заполняет TMP и подмешивает её в p с весом окна [a, b). */
   private static void phase(Pose p, float t, float a, float b, float f, Clip c) {
      float w = win(t, a, b, f);
      if (w > 0.0F) {
         TMP.clear();
         c.apply(TMP, t);
         p.add(TMP, w);
      }
   }

   private static float hold(float t, float from, float to) {
      float in = Math.min(1.0F, t / from);
      float out2 = Math.min(1.0F, Math.max(0.0F, (1.0F - t) / to));
      return Math.min(in, out2);
   }

   static {
      reg(
         G_GESTURE, "wave", "Пока", "Wave", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.25F);
            p.rArmPitch = -150.0F * R * k;
            p.rArmRoll = -22.0F * R * k;
            p.rArmYaw = sin(6.0F, t) * 26.0F * R * k;
            p.headYaw = sin(6.0F, t) * 7.0F * R * k;
            p.bodyYaw = 6.0F * R * k;
         },
         "minecraft:entity.experience_orb.pickup"
      );
      reg(
         G_GESTURE, "clap", "Хлопки", "Clap", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.2F);
            float s = sin(7.0F, t);
            p.rArmPitch = (-75.0F + s * 8.0F) * R * k;
            p.lArmPitch = (-75.0F + s * 8.0F) * R * k;
            p.rArmYaw = (-42.0F - s * 22.0F) * R * k;
            p.lArmYaw = (42.0F + s * 22.0F) * R * k;
            p.headPitch = 12.0F * R * k;
         },
         "minecraft:block.note_block.hat"
      );
      reg(
         G_GESTURE, "cheer", "Ура", "Cheer", 3.0F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.22F);
            float s = sin(4.0F, t);
            p.rArmPitch = (-165.0F + s * 12.0F) * R * k;
            p.lArmPitch = (-165.0F - s * 12.0F) * R * k;
            p.rArmRoll = -28.0F * R * k;
            p.lArmRoll = 28.0F * R * k;
            p.bodyPitch = s * 5.0F * R * k;
            p.headPitch = (-10.0F + s * 6.0F) * R * k;
            p.leg(s * 12.0F * R * k, -s * 12.0F * R * k);
         },
         "minecraft:entity.firework_rocket.blast"
      );
      reg(
         G_GESTURE, "point", "Указать", "Point", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.12F, 0.25F);
            p.rArmPitch = (-96.0F + sin(2.0F, t) * 4.0F) * R * k;
            p.rArmYaw = -12.0F * R * k;
            p.bodyYaw = -18.0F * R * k;
            p.headYaw = -10.0F * R * k;
            p.lArmPitch = 8.0F * R * k;
         },
         "minecraft:entity.splash_potion.throw"
      );
      reg(
         G_MEME, "facepalm", "Рука к лицу", "Facepalm", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.3F);
            p.rArmPitch = -152.0F * R * k;
            p.rArmYaw = -28.0F * R * k;
            p.rArmRoll = 10.0F * R * k;
            p.headPitch = 26.0F * R * k;
            p.bodyPitch = 6.0F * R * k;
         },
         "minecraft:block.wool.place"
      );
      reg(
         G_MEME, "shrug", "Пожатье плечами", "Shrug", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.28F);
            float s = sin(2.0F, t);
            p.rArmPitch = (-38.0F + s * 4.0F) * R * k;
            p.lArmPitch = (-38.0F - s * 4.0F) * R * k;
            p.rArmRoll = -58.0F * R * k;
            p.lArmRoll = 58.0F * R * k;
            p.headRoll = (10.0F + s * 4.0F) * R * k;
            p.bodyPitch = -4.0F * R * k;
         },
         "minecraft:block.note_block.bass"
      );
      reg(
         G_DANCE, "dance", "Танец", "Dance", 6.0F,
         (p, t) -> {
            float s = sin(4.0F, t);
            float c = sin(4.0F, t + 0.25F);
            p.bodyYaw = s * 24.0F * R;
            p.bodyPitch = c * 6.0F * R;
            p.rArmPitch = (-135.0F + s * 45.0F) * R;
            p.lArmPitch = (-135.0F - s * 45.0F) * R;
            p.rArmRoll = (-20.0F + c * 15.0F) * R;
            p.lArmRoll = (20.0F - c * 15.0F) * R;
            p.headYaw = c * 12.0F * R;
            p.leg((18.0F + c * 22.0F) * R, (18.0F - c * 22.0F) * R);
         },
         "minecraft:music_disc.cat",
         true
      );
      reg(
         G_GESTURE, "yes", "Кивать", "Yes", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            p.headPitch = sin(6.0F, t) * 22.0F * R * k;
            p.bodyPitch = sin(6.0F, t) * 4.0F * R * k;
         },
         "minecraft:entity.villager.yes"
      );
      reg(
         G_GESTURE, "no", "Мотать головой", "No", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            p.headYaw = sin(5.0F, t) * 34.0F * R * k;
            p.headRoll = sin(5.0F, t) * 6.0F * R * k;
            p.bodyYaw = sin(5.0F, t) * 8.0F * R * k;
         },
         "minecraft:entity.villager.no"
      );
      reg(
         G_DANCE, "rock", "Рок", "Rock", 3.4F,
         (p, t) -> {
            float s = sin(6.0F, t);
            p.rArmPitch = (-158.0F + s * 14.0F) * R;
            p.rArmRoll = -18.0F * R;
            p.lArmPitch = (-30.0F + s * 10.0F) * R;
            p.headPitch = (-24.0F + s * 6.0F) * R;
            p.bodyPitch = s * 9.0F * R;
         },
         "minecraft:music_disc.pigstep",
         true
      );
      // По вирусному видео «Я тебя могну»: 3 цикла на трек 6.76 с, в цикле 4 доли по ~0.56 с.
      reg(G_MEME, "mognu", "Я тебя могну", "Ya Tebya Mognu", 6.76F, Emotes::mognu, "mrbeanvisuals:emote.mognu", true);
      // По видео «Новки»: грув с коленями → «крылья» → колено + руки к груди → шаги → руки скрещены.
      reg(G_MEME, "nowkie", "Новки", "Nowkie", 12.0F, Emotes::nowkie, "mrbeanvisuals:emote.nowkie", true);
      reg(
         G_DANCE, "newdance", "Новый танец", "New Dance", 2.4F,
         (p, t) -> {
            float s = sin(2.0F, t);
            float c = sin(2.0F, t + 0.25F);
            p.bodyYaw = s * 21.0F * R;
            p.bodyPitch = c * 7.0F * R;
            p.rArmPitch = (-152.0F + c * 22.0F) * R;
            p.lArmPitch = (-152.0F - c * 22.0F) * R;
            p.rArmRoll = (-16.0F + s * 14.0F) * R;
            p.lArmRoll = (16.0F - s * 14.0F) * R;
            p.headRoll = s * 11.0F * R;
            p.leg((16.0F + c * 20.0F) * R, (16.0F - c * 20.0F) * R);
         },
         "mrbeanvisuals:emote.newdance",
         true
      );
      // Флосс по видео: прямые руки вместе машут в одну сторону (одна спереди, другая сзади),
      // бёдра — в обратную; полный мах туда-обратно ~0.5 с.
      reg(
         G_DANCE, "floss", "Флосс", "Floss", 1.0F,
         (p, t) -> {
            float s = sin(2.0F, t);
            float c = sin(2.0F, t + 0.25F);
            p.rArmRoll = (-12.0F + s * 38.0F) * R;
            p.lArmRoll = (12.0F + s * 38.0F) * R;
            p.rArmPitch = c * 32.0F * R;
            p.lArmPitch = -c * 32.0F * R;
            p.bodyYaw = -s * 10.0F * R;
            p.headYaw = -s * 6.0F * R;
            p.legRoll(-s * 10.0F * R, -s * 10.0F * R);
         },
         "minecraft:music_disc.stal",
         true
      );
      reg(
         G_DANCE, "shuffle", "Шффл", "Shuffle", 2.2F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.bodyYaw = s * 11.0F * R;
            p.bodyPitch = sin(4.0F, t) * 5.0F * R;
            p.rArmPitch = -168.0F * R;
            p.rArmRoll = -22.0F * R;
            p.lArmPitch = (-32.0F + s * 22.0F) * R;
            p.lArmRoll = 26.0F * R;
            p.headYaw = -s * 10.0F * R;
            p.leg((20.0F + s * 30.0F) * R, (20.0F - s * 30.0F) * R);
         },
         "minecraft:music_disc.mall",
         true
      );
      reg(
         G_DANCE, "robot", "Робот", "Robot", 2.0F,
         (p, t) -> {
            float q = (float)Math.floor((double)(t * 4.0F % 4.0F)) / 3.0F * 2.0F - 1.0F;
            p.headYaw = q * 30.0F * R;
            p.headPitch = -6.0F * R;
            p.bodyYaw = q * 8.0F * R;
            p.rArmPitch = (-62.0F + q * 42.0F) * R;
            p.lArmPitch = (-62.0F - q * 42.0F) * R;
            p.rArmYaw = -22.0F * R;
            p.lArmYaw = 22.0F * R;
            p.rArmRoll = -14.0F * R;
            p.lArmRoll = 14.0F * R;
            p.leg(q * 8.0F * R, -q * 8.0F * R);
         },
         "minecraft:music_disc.wait",
         true
      );
      reg(
         G_GESTURE, "thumbs", "Палец вверх", "Thumbs Up", 1.8F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.22F);
            float s = sin(2.0F, t);
            p.rArmPitch = (-92.0F + s * 5.0F) * R * k;
            p.rArmRoll = 14.0F * R * k;
            p.rArmYaw = -18.0F * R * k;
            p.lArmPitch = 6.0F * R * k;
            p.headPitch = (-8.0F + s * 4.0F) * R * k;
            p.bodyPitch = s * 3.0F * R * k;
         },
         "minecraft:entity.player.levelup"
      );
      reg(
         G_GESTURE, "salute", "Салют", "Salute", 2.0F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.25F);
            p.rArmPitch = -150.0F * R * k;
            p.rArmYaw = -32.0F * R * k;
            p.rArmRoll = 26.0F * R * k;
            p.lArmPitch = 4.0F * R * k;
            p.headPitch = -10.0F * R * k;
            p.bodyPitch = 2.0F * R * k;
         },
         "minecraft:entity.firework_rocket.shoot"
      );
      reg(
         G_MEME, "laugh", "Смех", "Laugh", 1.6F,
         (p, t) -> {
            float s = sin(4.0F, t);
            p.headPitch = (-22.0F + s * 9.0F) * R;
            p.bodyPitch = (6.0F + s * 7.0F) * R;
            p.rArmPitch = (10.0F + s * 9.0F) * R;
            p.lArmPitch = (10.0F - s * 9.0F) * R;
            p.rArmRoll = -10.0F * R;
            p.lArmRoll = 10.0F * R;
            p.leg(s * 8.0F * R, -s * 8.0F * R);
         },
         "minecraft:block.brewing_stand.bubble"
      );
      reg(
         G_GESTURE, "dab", "Даб", "Dab", 2.0F,
         (p, t) -> {
            float k = hold(t, 0.16F, 0.28F);
            float s = sin(2.0F, t);
            p.rArmPitch = -60.0F * R * k;
            p.rArmYaw = 40.0F * R * k;
            p.rArmRoll = -35.0F * R * k;
            p.lArmPitch = -140.0F * R * k;
            p.lArmYaw = -35.0F * R * k;
            p.lArmRoll = 20.0F * R * k;
            p.headPitch = 25.0F * R * k;
            p.headYaw = -30.0F * R * k;
            p.bodyYaw = (-20.0F + s * 4.0F) * R * k;
         },
         "minecraft:entity.firework_rocket.blast"
      );
      reg(
         G_GESTURE, "heart", "Сердце", "Heart", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            float s = sin(3.0F, t);
            p.rArmPitch = (-150.0F + s * 4.0F) * R * k;
            p.lArmPitch = (-150.0F - s * 4.0F) * R * k;
            p.rArmYaw = 22.0F * R * k;
            p.lArmYaw = -22.0F * R * k;
            p.rArmRoll = -18.0F * R * k;
            p.lArmRoll = 18.0F * R * k;
            p.headPitch = -6.0F * R * k;
            p.headRoll = (8.0F + s * 3.0F) * R * k;
         },
         "minecraft:block.amethyst_block.chime"
      );
      reg(
         G_GESTURE, "peace", "Мир", "Peace", 2.0F,
         (p, t) -> {
            float k = hold(t, 0.14F, 0.26F);
            float s = sin(3.0F, t);
            p.rArmPitch = (-160.0F + s * 8.0F) * R * k;
            p.rArmRoll = (-12.0F + s * 6.0F) * R * k;
            p.lArmPitch = 6.0F * R * k;
            p.headRoll = (-10.0F + s * 4.0F) * R * k;
            p.bodyYaw = 8.0F * R * k;
         },
         "minecraft:block.bell.use"
      );
      reg(
         G_GESTURE, "handsup", "Руки вверх", "Hands Up", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.14F, 0.24F);
            float s = sin(3.0F, t);
            p.rArmPitch = (-175.0F + s * 6.0F) * R * k;
            p.lArmPitch = (-175.0F - s * 6.0F) * R * k;
            p.rArmRoll = -8.0F * R * k;
            p.lArmRoll = 8.0F * R * k;
            p.headPitch = (-18.0F + s * 4.0F) * R * k;
            p.bodyPitch = -4.0F * R * k;
            p.leg(s * 6.0F * R * k, -s * 6.0F * R * k);
         },
         "minecraft:entity.wolf.howl"
      );
      reg(
         G_GESTURE, "bow", "Поклон", "Bow", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.2F, 0.3F);
            p.bodyPitch = 40.0F * R * k;
            p.headPitch = 25.0F * R * k;
            p.rArmPitch = 20.0F * R * k;
            p.lArmPitch = 20.0F * R * k;
            p.rArmRoll = -10.0F * R * k;
            p.lArmRoll = 10.0F * R * k;
            p.leg(-8.0F * R * k, -8.0F * R * k);
         },
         "minecraft:block.note_block.chime"
      );
      reg(
         G_DANCE, "griddy", "Гридди", "Griddy", 4.0F,
         (p, t) -> {
            float s = sin(6.0F, t);
            float c = sin(6.0F, t + 0.25F);
            p.bodyYaw = s * 14.0F * R;
            p.headPitch = (-8.0F + c * 6.0F) * R;
            p.rArmPitch = (-90.0F + c * 40.0F) * R;
            p.lArmPitch = (-90.0F - c * 40.0F) * R;
            p.rArmRoll = -30.0F * R;
            p.lArmRoll = 30.0F * R;
            p.rArmYaw = (20.0F + s * 15.0F) * R;
            p.lArmYaw = (-20.0F + s * 15.0F) * R;
            p.leg((-25.0F + s * 30.0F) * R, (-25.0F - s * 30.0F) * R);
         },
         "minecraft:music_disc.otherside",
         true
      );
      reg(
         G_DANCE, "breakdance", "Брейк", "Breakdance", 4.5F,
         (p, t) -> {
            float s = sin(3.0F, t);
            float c = sin(3.0F, t + 0.25F);
            p.bodyPitch = (30.0F + c * 25.0F) * R;
            p.bodyYaw = s * 45.0F * R;
            p.headPitch = -20.0F * R;
            p.rArmPitch = (-40.0F + s * 60.0F) * R;
            p.lArmPitch = (-40.0F - s * 60.0F) * R;
            p.rArmRoll = -45.0F * R;
            p.lArmRoll = 45.0F * R;
            p.leg((45.0F + c * 40.0F) * R, (-20.0F - c * 40.0F) * R);
         },
         "minecraft:music_disc.blocks",
         true
      );
      reg(
         G_DANCE, "moonwalk", "Лунная походка", "Moonwalk", 3.5F,
         (p, t) -> {
            float s = sin(4.0F, t);
            float c = sin(4.0F, t + 0.25F);
            p.bodyPitch = -8.0F * R;
            p.headPitch = 8.0F * R;
            p.rArmPitch = (15.0F + s * 45.0F) * R;
            p.lArmPitch = (15.0F - s * 45.0F) * R;
            p.rArmRoll = -6.0F * R;
            p.lArmRoll = 6.0F * R;
            p.leg((20.0F + c * 30.0F) * R, (20.0F - c * 30.0F) * R);
         },
         "minecraft:music_disc.chirp",
         true
      );
      reg(
         G_DANCE, "spin", "Вращение", "Spin", 2.4F,
         (p, t) -> {
            float e = Math.min(1.0F, t / 0.8F);
            e = e * e * (3.0F - 2.0F * e);
            p.bodyYaw = e * 360.0F * R;
            p.rArmPitch = -80.0F * R * e;
            p.lArmPitch = -80.0F * R * e;
            p.rArmRoll = -70.0F * R * e;
            p.lArmRoll = 70.0F * R * e;
            p.headYaw = -20.0F * R * e;
         },
         "minecraft:block.note_block.bit"
      );
      reg(
         G_DANCE, "headbang", "Хедбэнг", "Headbang", 3.0F,
         (p, t) -> {
            float s = sin(8.0F, t);
            p.headPitch = (25.0F + s * 30.0F) * R;
            p.bodyPitch = 18.0F * R;
            p.rArmPitch = (-20.0F + s * 25.0F) * R;
            p.lArmPitch = (-20.0F - s * 25.0F) * R;
            p.leg(s * 10.0F * R, -s * 10.0F * R);
         },
         "minecraft:music_disc.strad",
         true
      );
      reg(
         G_MEME, "flex", "Флекс", "Flex", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.16F, 0.26F);
            float s = sin(3.0F, t);
            p.rArmPitch = (-100.0F + s * 6.0F) * R * k;
            p.lArmPitch = (-100.0F - s * 6.0F) * R * k;
            p.rArmRoll = -85.0F * R * k;
            p.lArmRoll = 85.0F * R * k;
            p.headPitch = (-8.0F + s * 3.0F) * R * k;
            p.bodyPitch = -6.0F * R * k;
         },
         "minecraft:entity.player.levelup"
      );
      reg(
         G_MEME, "cry", "Плач", "Cry", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.28F);
            float s = sin(7.0F, t);
            p.rArmPitch = (-140.0F + s * 5.0F) * R * k;
            p.lArmPitch = (-140.0F - s * 5.0F) * R * k;
            p.rArmYaw = -25.0F * R * k;
            p.lArmYaw = 25.0F * R * k;
            p.headPitch = (18.0F + s * 4.0F) * R * k;
            p.bodyPitch = (10.0F + s * 3.0F) * R * k;
         },
         "minecraft:block.bubble_column.bubble_pop"
      );
      reg(
         G_MEME, "rage", "Ярость", "Rage", 2.0F,
         (p, t) -> {
            float k = hold(t, 0.1F, 0.25F);
            float s = sin(10.0F, t);
            float c = sin(10.0F, t + 0.25F);
            p.rArmPitch = (-120.0F + s * 50.0F) * R * k;
            p.lArmPitch = (-120.0F + c * 50.0F) * R * k;
            p.rArmRoll = (-30.0F + c * 20.0F) * R * k;
            p.lArmRoll = (30.0F - s * 20.0F) * R * k;
            p.headPitch = (10.0F + s * 10.0F) * R * k;
            p.bodyYaw = c * 12.0F * R * k;
            p.leg(s * 12.0F * R * k, -s * 12.0F * R * k);
         },
         "minecraft:entity.ender_dragon.growl"
      );
      reg(
         G_MEME, "sit", "Сесть", "Sit", 3.0F,
         (p, t) -> {
            float k = hold(t, 0.25F, 0.3F);
            float s = sin(1.0F, t);
            p.leg(-80.0F * R * k, -80.0F * R * k);
            p.bodyPitch = (-8.0F + s * 2.0F) * R * k;
            p.headPitch = (6.0F + s * 3.0F) * R * k;
            p.rArmPitch = (-25.0F + s * 4.0F) * R * k;
            p.lArmPitch = (-25.0F - s * 4.0F) * R * k;
         },
         "minecraft:entity.slime.squish"
      );
      reg(
         G_MEME, "tpose", "T-поза", "T-Pose", 2.0F,
         (p, t) -> {
            float k = hold(t, 0.2F, 0.25F);
            p.rArmRoll = -90.0F * R * k;
            p.lArmRoll = 90.0F * R * k;
            p.headPitch = -2.0F * R * k;
         }
      );
      // Танцы по видео OG-эмоций: темп и амплитуда сняты покадрово (шаг 0.125 с).
      // Апельсиновый свинг: полуприсед, руки вместе машут перед собой из стороны в сторону, на каждом
      // втором махе нога выбрасывается вбок; мах ~0.5 с.
      reg(
         G_DANCE, "orange", "Апельсиновый свинг", "Orange Swing", 2.0F,
         (p, t) -> {
            float s = sin(2.0F, t);
            float kick = Math.max(0.0F, sin(1.0F, t));
            p.bodyPitch = 12.0F * R;
            p.headPitch = -6.0F * R;
            p.rArmPitch = (-48.0F + Math.abs(s) * 10.0F) * R;
            p.lArmPitch = (-48.0F + Math.abs(s) * 10.0F) * R;
            p.rArmYaw = (-10.0F + s * 45.0F) * R;
            p.lArmYaw = (10.0F + s * 45.0F) * R;
            p.bodyYaw = s * 10.0F * R;
            p.leg(-14.0F * R, -14.0F * R);
            p.legRoll((-12.0F - kick * 38.0F) * R, (12.0F + Math.max(0.0F, -sin(1.0F, t)) * 38.0F) * R);
         },
         "minecraft:music_disc.far",
         true
      );
      // L на лбу: правая рука у лба, левая на поясе; ноги по очереди выбрасываются вперёд и вбок, ~0.25 с на удар.
      reg(
         G_DANCE, "lkick", "L на лбу", "L Kick", 1.0F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.rArmPitch = -150.0F * R;
            p.rArmYaw = -40.0F * R;
            p.rArmRoll = 12.0F * R;
            p.lArmPitch = -28.0F * R;
            p.lArmRoll = 22.0F * R;
            p.bodyYaw = 18.0F * R;
            p.headYaw = 14.0F * R;
            p.headPitch = (-4.0F + Math.abs(s) * 6.0F) * R;
            p.leg(-72.0F * Math.max(0.0F, s) * R, -58.0F * Math.max(0.0F, -s) * R);
            p.legRoll(-10.0F * Math.max(0.0F, s) * R, 30.0F * Math.max(0.0F, -s) * R);
         },
         "minecraft:music_disc.ward",
         true
      );
      // Фристайл: кулаки качают вверх по очереди, колени поднимаются в такт, ~0.6 с на сторону.
      reg(
         G_DANCE, "freestyle", "Фристайл", "Freestylin", 2.4F,
         (p, t) -> {
            float s = sin(2.0F, t);
            float b = sin(4.0F, t);
            p.rArmPitch = (-80.0F - Math.max(0.0F, s) * 60.0F) * R;
            p.lArmPitch = (-80.0F - Math.max(0.0F, -s) * 60.0F) * R;
            p.rArmRoll = -22.0F * R;
            p.lArmRoll = 22.0F * R;
            p.bodyPitch = (8.0F + Math.abs(b) * 6.0F) * R;
            p.bodyYaw = s * 14.0F * R;
            p.headPitch = b * 6.0F * R;
            p.leg(-55.0F * Math.max(0.0F, -s) * R, -55.0F * Math.max(0.0F, s) * R);
            p.legRoll(-8.0F * R, 8.0F * R);
         },
         "minecraft:music_disc.creator",
         true
      );
      // Голубь: руки разведены низко в стороны и мелко «хлопают», мелкие шаги на месте, голова клюёт.
      reg(
         G_DANCE, "pigeon", "Голубь", "Pigeon", 2.0F,
         (p, t) -> {
            float flap = sin(8.0F, t);
            float step = sin(4.0F, t);
            p.rArmPitch = -18.0F * R;
            p.lArmPitch = -18.0F * R;
            p.rArmRoll = (-55.0F - flap * 12.0F) * R;
            p.lArmRoll = (55.0F + flap * 12.0F) * R;
            p.headPitch = (Math.abs(step) * 14.0F - 4.0F) * R;
            p.bodyPitch = 5.0F * R;
            p.leg(step * 16.0F * R, -step * 16.0F * R);
         },
         "minecraft:music_disc.relic",
         true
      );
      // Буги: палец вверх-в-сторону, потом вниз через тело (диско), широкая стойка с подсечкой колена; ~1 с на мах.
      reg(
         G_DANCE, "boogie", "Буги", "Boogie", 2.0F,
         (p, t) -> {
            float s = sin(1.0F, t);
            float up = Math.max(0.0F, s);
            float down = Math.max(0.0F, -s);
            p.rArmPitch = (-40.0F - up * 130.0F + down * 10.0F) * R;
            p.rArmYaw = (down * -45.0F) * R;
            p.rArmRoll = (-20.0F - up * 15.0F) * R;
            p.lArmPitch = -25.0F * R;
            p.lArmRoll = 30.0F * R;
            p.bodyYaw = (up * -12.0F + down * 14.0F) * R;
            p.headPitch = (-up * 14.0F + down * 10.0F) * R;
            p.legRoll(-14.0F * R, 14.0F * R);
            p.leg(-down * 20.0F * R, 0.0F);
         },
         "minecraft:music_disc.mellohi",
         true
      );
      // Шаги: руки согнуты и чуть разведены, мелкие шаги на месте почти без движения корпуса (~0.6 с шаг).
      reg(
         G_DANCE, "jaywalk", "Шаги", "Jay Steps", 2.4F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.rArmPitch = -14.0F * R;
            p.lArmPitch = -14.0F * R;
            p.rArmRoll = -30.0F * R;
            p.lArmRoll = 30.0F * R;
            p.headPitch = Math.abs(s) * 4.0F * R;
            p.leg(-s * 12.0F * R, s * 12.0F * R);
         },
         "minecraft:music_disc.creator_music_box",
         true
      );
      // На-на: кулаки вверху, по очереди выстреливают в небо, широкая стойка, пружинка ~0.25 с.
      reg(
         G_DANCE, "nana", "На-на", "Na-Na", 2.0F,
         (p, t) -> {
            float s = sin(4.0F, t);
            float b = sin(8.0F, t);
            p.rArmPitch = (-140.0F - Math.max(0.0F, s) * 30.0F) * R;
            p.lArmPitch = (-140.0F - Math.max(0.0F, -s) * 30.0F) * R;
            p.rArmRoll = (-28.0F + Math.max(0.0F, s) * 14.0F) * R;
            p.lArmRoll = (28.0F - Math.max(0.0F, -s) * 14.0F) * R;
            p.headPitch = -8.0F * R;
            p.bodyYaw = s * 6.0F * R;
            p.legRoll(-14.0F * R, 14.0F * R);
            p.leg(Math.abs(b) * -8.0F * R, Math.abs(b) * -8.0F * R);
         },
         "minecraft:music_disc.precipice",
         true
      );
      // Грув: выпад в сторону с рукой к земле (первая половина), затем руки широко вверх «Y» (вторая).
      reg(
         G_DANCE, "groove", "Грув", "Groove", 4.0F,
         (p, t) -> {
            phase(p, t, -1.0F, 0.5F, 0.08F, (q, u) -> {
               float s = sin(2.0F, u);
               q.bodyPitch = 22.0F * R;
               q.bodyYaw = s * 18.0F * R;
               q.headPitch = 14.0F * R;
               q.rArmPitch = (-20.0F + s * 25.0F) * R;
               q.rArmYaw = -30.0F * R;
               q.lArmPitch = -10.0F * R;
               q.lArmRoll = 25.0F * R;
               q.legRoll((-25.0F + s * 10.0F) * R, (25.0F + s * 10.0F) * R);
            });
            phase(p, t, 0.5F, 2.0F, 0.08F, (q, u) -> {
               float s = sin(4.0F, u);
               q.rArmPitch = -170.0F * R;
               q.lArmPitch = -170.0F * R;
               q.rArmRoll = (-38.0F - s * 8.0F) * R;
               q.lArmRoll = (38.0F + s * 8.0F) * R;
               q.headPitch = -12.0F * R;
               q.legRoll(-16.0F * R, 16.0F * R);
            });
         },
         "minecraft:music_disc.otherside",
         true
      );
      // Чудик: ладони у лица, высокие колени по очереди ~0.75 с, голова мотается.
      reg(
         G_MEME, "zany", "Чудик", "Zany", 1.5F,
         (p, t) -> {
            float s = sin(2.0F, t);
            p.rArmPitch = -125.0F * R;
            p.lArmPitch = -125.0F * R;
            p.rArmYaw = (-18.0F + s * 6.0F) * R;
            p.lArmYaw = (18.0F + s * 6.0F) * R;
            p.rArmRoll = -20.0F * R;
            p.lArmRoll = 20.0F * R;
            p.headYaw = s * 16.0F * R;
            p.headRoll = s * 8.0F * R;
            p.leg(-70.0F * Math.max(0.0F, s) * R, -70.0F * Math.max(0.0F, -s) * R);
         },
         "minecraft:music_disc.13",
         true
      );
      // Звезда: рука на поясе, другая вскинута вверх-в-сторону, потом машет у лица; нога выставлена.
      reg(
         G_GESTURE, "starpower", "Звезда", "Star Pose", 2.0F,
         (p, t) -> {
            phase(p, t, -1.0F, 0.5F, 0.1F, (q, u) -> {
               q.rArmPitch = -165.0F * R;
               q.rArmRoll = -30.0F * R;
               q.lArmPitch = -15.0F * R;
               q.lArmRoll = 48.0F * R;
               q.lArmYaw = 20.0F * R;
               q.headRoll = 8.0F * R;
               q.bodyYaw = -10.0F * R;
               q.legRoll(-20.0F * R, 4.0F * R);
            });
            phase(p, t, 0.5F, 2.0F, 0.1F, (q, u) -> {
               float s = sin(6.0F, u);
               q.rArmPitch = -125.0F * R;
               q.rArmYaw = (-30.0F + s * 18.0F) * R;
               q.lArmPitch = -15.0F * R;
               q.lArmRoll = 48.0F * R;
               q.lArmYaw = 20.0F * R;
               q.headYaw = -10.0F * R;
               q.legRoll(-20.0F * R, 4.0F * R);
            });
         },
         "minecraft:music_disc.tears",
         true
      );
      // Хохот: сгибается пополам, руки на животе, плечи трясутся; потом выпрямляется и смеётся вверх.
      reg(
         G_MEME, "laughup", "Хохот", "Laugh Up", 2.4F,
         (p, t) -> {
            float shake = sin(12.0F, t);
            phase(p, t, -1.0F, 0.55F, 0.12F, (q, u) -> {
               q.bodyPitch = (30.0F + shake * 3.0F) * R;
               q.headPitch = 25.0F * R;
               q.rArmPitch = -45.0F * R;
               q.rArmYaw = -35.0F * R;
               q.lArmPitch = -20.0F * R;
               q.lArmRoll = 20.0F * R;
            });
            phase(p, t, 0.55F, 2.0F, 0.12F, (q, u) -> {
               q.bodyPitch = (-6.0F + shake * 2.0F) * R;
               q.headPitch = (-22.0F + shake * 4.0F) * R;
               q.rArmPitch = -50.0F * R;
               q.rArmYaw = -30.0F * R;
               q.lArmPitch = -50.0F * R;
               q.lArmYaw = 30.0F * R;
            });
         },
         "minecraft:entity.villager.celebrate"
      );
   }

   /** Могну: доли цикла — диагональ правой → скрёст внизу → диагональ левой → наклон с размахом. */
   private static void mognu(Pose p, float t) {
      float u = t * 3.0F % 1.0F;
      float f = 0.07F;
      phase(p, u, -0.25F, 0.0F, f, Emotes::mognuSweep);
      phase(p, u, 0.0F, 0.25F, f, Emotes::mognuRight);
      phase(p, u, 0.25F, 0.5F, f, Emotes::mognuCross);
      phase(p, u, 0.5F, 0.75F, f, Emotes::mognuLeft);
      phase(p, u, 0.75F, 1.0F, f, Emotes::mognuSweep);
      phase(p, u, 1.0F, 1.25F, f, Emotes::mognuRight);
      float b = Math.abs(sin(4.0F, u));
      p.rLegPitch += -b * 8.0F * R;
      p.lLegPitch += -b * 8.0F * R;
      p.legs = true;
   }

   private static void mognuRight(Pose q, float u) {
      q.rArmPitch = -145.0F * R;
      q.rArmYaw = -30.0F * R;
      q.rArmRoll = 14.0F * R;
      q.lArmPitch = 15.0F * R;
      q.lArmRoll = 35.0F * R;
      q.headYaw = -10.0F * R;
      q.headRoll = -6.0F * R;
      q.bodyYaw = -8.0F * R;
   }

   private static void mognuLeft(Pose q, float u) {
      q.lArmPitch = -145.0F * R;
      q.lArmYaw = 30.0F * R;
      q.lArmRoll = -14.0F * R;
      q.rArmPitch = 15.0F * R;
      q.rArmRoll = -35.0F * R;
      q.headYaw = 10.0F * R;
      q.headRoll = 6.0F * R;
      q.bodyYaw = 8.0F * R;
   }

   private static void mognuCross(Pose q, float u) {
      q.bodyPitch = 16.0F * R;
      q.headPitch = 22.0F * R;
      q.rArmPitch = -38.0F * R;
      q.rArmYaw = -45.0F * R;
      q.lArmPitch = -38.0F * R;
      q.lArmYaw = 45.0F * R;
   }

   private static void mognuSweep(Pose q, float u) {
      q.bodyPitch = 18.0F * R;
      q.headPitch = 25.0F * R;
      q.rArmPitch = -24.0F * R;
      q.rArmRoll = -22.0F * R;
      q.lArmPitch = -24.0F * R;
      q.lArmRoll = 22.0F * R;
   }

   /** Новки, 12 с: доли считаются в секундах трека, чтобы такт совпадал с музыкой. */
   private static void nowkie(Pose p, float t) {
      float sec = t * 12.0F;
      float f = 0.03F;
      // A 0–3.6 с: пружинистый грув — колени по очереди (~1 с), предплечья вперёд мелко дёргаются
      phase(p, t, -1.0F, 0.30F, f, (q, u) -> {
         float k = (float)Math.sin(sec * Math.PI * 2.0);
         float fl = (float)Math.sin(sec * Math.PI * 4.0);
         q.rArmPitch = (-35.0F + fl * 15.0F) * R;
         q.lArmPitch = (-35.0F - fl * 15.0F) * R;
         q.rArmYaw = -15.0F * R;
         q.lArmYaw = 15.0F * R;
         q.bodyPitch = (4.0F + Math.abs(fl) * 3.0F) * R;
         q.headPitch = fl * 5.0F * R;
         q.leg(-55.0F * Math.max(0.0F, k) * R, -55.0F * Math.max(0.0F, -k) * R);
      });
      // B 3.6–7.2 с: руки широко в стороны и машут как крылья (~0.6 с), корпус раскачивается, широкая стойка
      phase(p, t, 0.30F, 0.60F, f, (q, u) -> {
         float fl = (float)Math.sin(sec * Math.PI * 2.0 / 0.6);
         float sw = (float)Math.sin(sec * Math.PI * 2.0 / 1.2);
         q.rArmPitch = -10.0F * R;
         q.lArmPitch = -10.0F * R;
         q.rArmRoll = (-75.0F - fl * 20.0F) * R;
         q.lArmRoll = (75.0F + fl * 20.0F) * R;
         q.bodyYaw = sw * 12.0F * R;
         q.headYaw = sw * 8.0F * R;
         q.legRoll(-10.0F * R, 10.0F * R);
      });
      // C 7.2–8.5 с: высокое правое колено, руки сходятся у груди
      phase(p, t, 0.60F, 0.71F, f, (q, u) -> {
         float l = Math.max(0.0F, Math.min(1.0F, (t - 0.60F) / 0.11F));
         q.leg(-70.0F * (float)Math.sin(Math.PI * Math.min(1.0F, l * 1.6F)) * R, 0.0F);
         q.rArmPitch = -75.0F * R;
         q.rArmYaw = -35.0F * R;
         q.lArmPitch = -75.0F * R;
         q.lArmYaw = 35.0F * R;
      });
      // D 8.5–10.3 с: шаги в стороны, левое колено вверх, руки у живота
      phase(p, t, 0.71F, 0.86F, f, (q, u) -> {
         float l = Math.max(0.0F, Math.min(1.0F, (t - 0.71F) / 0.15F));
         q.leg(0.0F, -60.0F * (float)Math.sin(Math.PI * Math.max(0.0F, Math.min(1.0F, l * 1.6F - 0.2F))) * R);
         q.rArmPitch = -45.0F * R;
         q.rArmYaw = -25.0F * R;
         q.lArmPitch = -45.0F * R;
         q.lArmYaw = 25.0F * R;
         q.bodyYaw = (float)Math.sin(l * Math.PI * 2.0) * 10.0F * R;
      });
      // E 10.3–12 с: руки скрещены на груди, корпус чуть назад, подбородок вверх и кивок
      phase(p, t, 0.86F, 2.0F, f, (q, u) -> {
         q.rArmPitch = -85.0F * R;
         q.rArmYaw = -55.0F * R;
         q.rArmRoll = 10.0F * R;
         q.lArmPitch = -80.0F * R;
         q.lArmYaw = 55.0F * R;
         q.lArmRoll = -10.0F * R;
         q.bodyPitch = -5.0F * R;
         q.headPitch = (-10.0F + (float)Math.sin(sec * Math.PI * 2.0 / 0.8) * 4.0F) * R;
         q.legRoll(-6.0F * R, 6.0F * R);
      });
   }

   public static class EmoteModule extends Module {
      public final Setting.Mode pick = this.add(new Setting.Mode("emote", "Эмоция", "Emote", 0, modeArgs()));
      public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость", "Speed", 1.0, 0.5, 2.0, 0.05).suffix("x"));
      public final Setting.Bool calmLegs = this.add(new Setting.Bool("calm_legs", "Не махать ногами", "Calm legs", true));
      public final Setting.Bool firstPerson = this.add(new Setting.Bool("first_person", "Видеть от первого лица", "First person", false));
      public final Setting.Bool autoFace = this.add(
         new Setting.Bool("auto_face", "Авто-вид на лицо (F5)", "Auto face view (F5)", true)
      );
      public final Setting.Bool watchOthers = this.add(
         new Setting.Bool("watch_others", "Видеть эмоции других", "See others' emotes", true)
      );
      public final Setting.Bool loopSel = this.add(
         new Setting.Bool("loop", "Повторять выбранную", "Loop selected", true)
      );
      public final Setting.Bool stopOnMove = this.add(
         new Setting.Bool("stop_on_move", "Остановить при движении", "Stop when moving", true)
      );
      public final Setting.Bool sounds = this.add(new Setting.Bool("emote_sounds", "Звук эмоций", "Emote sounds", true));
      public final Setting.Num soundVolume = (Setting.Num)this.add(
         new Setting.Num("emote_volume", "Громкость звука", "Sound volume", 80.0, 0.0, 100.0, 5.0)
      ).suffix("%").showIf(() -> this.sounds.value);
      public final Setting.Text favs = this.add(
         new Setting.Text("favs", "Избранные эмоции (через запятую)", "Favourite emotes (comma separated)", "")
      );
      public final Setting.Action playBtn = this.add(new Setting.Action("play", "Сыграть", "Play", this::trigger));
      public final Setting.Action stopBtn = this.add(new Setting.Action("stop", "Стоп", "Stop", this::stopSelf));
      public final Setting.Action catalogBtn = this.add(
         new Setting.Action("open_catalog", "Каталог эмоций", "Emote catalog", this::openCatalog)
      );
      public final Map<String, Setting.Key> binds = new LinkedHashMap<>();
      public class_304 key;
      public long catalogClosedAt;
      private String activeId;
      private boolean activeLoop;
      private String previewId;

      public EmoteModule() {
         super(
            "emotes",
            Category.ANIMATIONS,
            false,
            "Эмоции",
            "Emotes",
            "Анимации персонажа: танцы (флосс, могну, новки, голубь, буги…), жесты и мемы. Движение останавливает эмоцию",
            "Character animations: dances, gestures and memes. Moving stops the emote"
         );

         for (Def d : DEFS.values()) {
            this.binds.put(
               d.id(),
               this.add(new Setting.Key("key_" + d.id(), "Бинд: " + d.ru(), "Bind: " + d.en(), -1))
            );
         }
      }

      private static String[] modeArgs() {
         List<String> l = new ArrayList<>();

         for (Map.Entry<String, Def> e : DEFS.entrySet()) {
            Def d = e.getValue();
            l.add(d.id());
            l.add(d.ru());
            l.add(d.en());
         }

         return l.toArray(new String[0]);
      }

      @Override
      public void onTick() {
         Emotes.tickCleanup();
         EmoteNetwork.applyInbound();
         if (this.key != null) {
            while (this.key.method_1436()) {
               if (this.mc.field_1755 == null && System.currentTimeMillis() - this.catalogClosedAt > 400L) {
                  this.openCatalog();
               }
            }
         }

         for (Map.Entry<String, Setting.Key> e : this.binds.entrySet()) {
            if (e.getValue().pressed()) {
               this.start(e.getKey());
            }
         }

         if (this.mc.field_1724 == null && (this.activeId != null || this.previewId != null)) {
            this.activeId = null;
            this.previewId = null;
         }

         if (this.mc.field_1724 != null && this.previewId == null && this.activeId != null && !busy(this.mc.field_1724.method_5628())) {
            // разовая эмоция доиграла сама — выбор снимается, следующий клик по ней запустит её снова
            this.activeId = null;
         }

         // как в Fortnite: пошёл или прыгнул — эмоция прекращается (каталог открыт — это предпросмотр, не трогаем)
         if (this.stopOnMove.get() && this.mc.field_1724 != null && this.mc.field_1755 == null
            && busy(this.mc.field_1724.method_5628()) && this.moving()) {
            this.stopSelf();
         }
      }

      private boolean moving() {
         return this.mc.field_1690.field_1894.method_1434()
            || this.mc.field_1690.field_1881.method_1434()
            || this.mc.field_1690.field_1913.method_1434()
            || this.mc.field_1690.field_1849.method_1434()
            || this.mc.field_1690.field_1903.method_1434();
      }

      /** Каталог: кубы эмоций, живой предпросмотр танца и настройки по сторонам. */
      public void openCatalog() {
         if (this.mc.field_1755 == null) {
            this.mc.method_1507(new EmoteCatalogScreen(null));
         }
      }

      public boolean isFav(String id) {
         if (id != null && this.favs.value != null) {
            for (String s : this.favs.value.split(",")) {
               if (s.trim().equalsIgnoreCase(id)) {
                  return true;
               }
            }
         }

         return false;
      }

      /** Кладёт эмоцию в избранное или убирает из него; список живёт в конфиге. */
      public boolean toggleFav(String id) {
         if (id == null) {
            return false;
         } else {
            List<String> l = new ArrayList<>();

            for (String s : (this.favs.value == null ? "" : this.favs.value).split(",")) {
               String t = s.trim();
               if (!t.isEmpty() && !t.equalsIgnoreCase(id)) {
                  l.add(t);
               }
            }

            boolean on = this.isFav(id);
            if (!on) {
               l.add(0, id);
            }

            this.favs.value = String.join(",", l);
            Config.markDirty();
            return !on;
         }
      }

      /** Избранные эмоции в порядке добавления. */
      public List<Def> favDefs() {
         List<Def> out = new ArrayList<>();

         for (String s : (this.favs.value == null ? "" : this.favs.value).split(",")) {
            Def d = def(s.trim());
            if (d != null && !out.contains(d)) {
               out.add(d);
            }
         }

         return out;
      }

      /** Каталог закрылся: край клавиши B в этот момент игнорируем, иначе он открылся бы снова. */
      public void catalogClosed() {
         this.catalogClosedAt = System.currentTimeMillis();
      }

      public String selected() {
         return this.pick.ids[this.pick.index];
      }

      public void trigger() {
         this.start(this.selected());
      }

      /** Эмоция, которую игрок выбрал сам (предпросмотр в каталоге не считается); null — ничего не выбрано. */
      public String active() {
         return this.activeId;
      }

      /**
       * Ставит эмоцию себе и просит сервер показать её другим.
       * Тот же id, что уже выбран, — выключает (как в Fortnite); другой id — старая останавливается, новая играет.
       * Решает только activeId: предпросмотр в каталоге подменяет играющую позу, но не выбор игрока.
       */
      public void start(String id) {
         if (this.mc.field_1724 == null || id == null) {
            return;
         }

         int self = this.mc.field_1724.method_5628();
         if (id.equals(this.activeId)) {
            this.stopSelf();
         } else {
            boolean loop = this.loopSel.get();
            this.previewId = null;
            // force=true заменяет текущую позу и обрывает её музыку; у других игроков её заменит пакет новой эмоции
            if (play(self, id, this.speed.f(), loop, true)) {
               EmoteNetwork.send(id, this.speed.f(), loop);
               this.activeId = id;
               this.activeLoop = loop;
            }
         }
      }

      /** Предпросмотр при наведении в каталоге: локально, без отправки на сервер. */
      public void preview(String id) {
         // Предпросмотр живёт только пока открыт каталог: раньше вызов из последнего кадра уже закрытого
         // каталога снова запускал эмоцию бесконечным циклом — и её было не остановить.
         if (this.mc.field_1724 == null || !(this.mc.field_1755 instanceof EmoteCatalogScreen)) {
            return;
         }

         if (id.equals(this.previewId)) {
            return;
         }

         this.previewId = id;
         play(this.mc.field_1724.method_5628(), id, this.speed.f(), true, true);
      }

      /**
       * Конец предпросмотра: возвращает то, что игрок выбрал сам. Зацикленная эмоция продолжается с начала,
       * разовая считается законченной. true — предпросмотр что-то показывал.
       */
      public boolean restoreAfterPreview() {
         if (this.mc.field_1724 == null) {
            return false;
         } else {
            boolean was = this.previewId != null;
            this.previewId = null;
            if (was) {
               int self = this.mc.field_1724.method_5628();
               if (this.activeId != null && this.activeLoop) {
                  play(self, this.activeId, this.speed.f(), true, true);
               } else {
                  this.activeId = null;
                  stopNow(self);
               }
            }

            return was;
         }
      }

      public void stopSelf() {
         if (this.mc.field_1724 != null) {
            String id = this.activeId != null ? this.activeId : current(this.mc.field_1724.method_5628());
            this.activeId = null;
            this.previewId = null;
            stop(this.mc.field_1724.method_5628());
            if (id != null) {
               EmoteNetwork.sendStop(id);
            }
         }
      }

      @Override
      public void onDisable() {
         this.activeId = null;
         this.previewId = null;
         stopListen();
         releaseFace();
         if (this.mc.field_1724 != null) {
            stopNow(this.mc.field_1724.method_5628());
         }
      }
   }

   public static EmoteModule module() {
      return Modules.get("emotes") instanceof EmoteModule em ? em : null;
   }

   /** Поза для модели игрока: null, если эмоции нет или модуль выключен. */
   public static Pose activePose(int entityId, EmoteModule em) {
      if (em == null || !em.isEnabled()) {
         return null;
      } else if (!em.firstPerson.get() && isFirstPersonSelf(entityId)) {
         return null;
      } else {
         return pose(entityId);
      }
   }

   private static boolean isFirstPersonSelf(int entityId) {
      class_310 mc = class_310.method_1551();
      return mc.field_1724 != null && mc.field_1724.method_5628() == entityId && mc.field_1690.method_31044().method_31034();
   }

   /** Запускает эмоцию у своего игрока. null — получилось. */
   public static String playSelf(String id, float speed) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1724 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || !em.isEnabled()) {
         return Lang.t("Включи модуль «Эмоции» в меню", "Enable the Emotes module first");
      } else if (def(id) == null) {
         return Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + ids();
      } else {
         em.start(id);
         return null;
      }
   }

   /** Выключает свою эмоцию. null — получилось. */
   public static String stopSelf() {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1724 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || current(mc.field_1724.method_5628()) == null) {
         return Lang.t("Эмоция не идёт", "No emote is playing");
      } else {
         em.stopSelf();
         return null;
      }
   }

   /** Клавиша одной эмоции — для .emotebind. null, если модуля или такой эмоции нет. */
   public static Setting.Key bindOf(String id) {
      EmoteModule em = module();
      Def d = def(id);
      if (em == null || d == null) {
         return null;
      } else {
         return em.binds.get(d.id());
      }
   }

   /** Список «эмоция — клавиша» для чата. */
   public static String bindList() {
      EmoteModule em = module();
      if (em == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();

         for (Map.Entry<String, Setting.Key> e : em.binds.entrySet()) {
            if (e.getValue().value >= 0) {
               if (sb.length() > 0) {
                  sb.append(", ");
               }

               sb.append(e.getKey()).append("=").append(e.getValue().display());
            }
         }

         return sb.toString();
      }
   }

   /** Ищет игрока по нику рядом и запускает у него эмоцию. */
   public static String playOn(String nick, String id, float speed) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1687 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || !em.isEnabled()) {
         return Lang.t("Включи модуль «Эмоции» в меню", "Enable the Emotes module first");
      } else if (def(id) == null) {
         return Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + ids();
      } else {
         for (class_1657 p : mc.field_1687.method_18456()) {
            if (p.method_7334().name().equalsIgnoreCase(nick)) {
               return play(p.method_5628(), id, speed)
                  ? null
                  : Lang.t("У этого игрока уже идёт эмоция", "That player is already emoting");
            }
         }

         return Lang.t("Игрок не найден рядом: ", "Player not found nearby: ") + nick;
      }
   }
}
