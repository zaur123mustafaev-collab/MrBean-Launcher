package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1661;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;

public final class UtilityModules {
   private UtilityModules() {
   }

   public static void registerAll() {
      Modules.reg(new UtilityModules.ClipPearl());
      Modules.reg(new UtilityModules.TotemAlert());
      Modules.reg(new UtilityModules.PvpHelper());
      Modules.reg(new UtilityModules.HpAlert());
      Modules.reg(new UtilityModules.TotemHelper());
   }

   public static class ClipPearl extends Module {
      public final Setting.Key key = this.add(new Setting.Key("key", "Клавиша броска", "Throw key", -1));
      final Setting.Bool restore = this.add(new Setting.Bool("restore", "Вернуть прежний слот", "Restore previous slot", true));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомления", "Notifications", true));
      final Setting.Bool indicator = this.add(new Setting.Bool("indicator", "Индикатор перезарядки", "Cooldown indicator", true));
      private int restoreSlot = -1;
      private int restoreIn;
      private int pearlSlot = -1;
      private long lastNoPearl;

      public ClipPearl() {
         super(
            "clip_pearl",
            Category.UTILITIES,
            false,
            "Clip Pearl",
            "Clip Pearl",
            "Бросает жемчуг из хотбара по своей клавише (настройка «Клавиша броска») и возвращает слот",
            "Throws an ender pearl from the hotbar on its own key (setting «Throw key») and restores the slot"
         );
      }

      public void throwPearl() {
         if (mc.field_1724 != null && mc.field_1761 != null && mc.field_1755 == null) {
            if (this.restoreIn <= 0) {
               class_1661 inv = mc.field_1724.method_31548();
               class_1268 hand = null;
               int slot = -1;
               if (mc.field_1724.method_6079().method_31574(class_1802.field_8634)) {
                  hand = class_1268.field_5810;
               } else if (inv.method_7391().method_31574(class_1802.field_8634)) {
                  hand = class_1268.field_5808;
               } else {
                  for (int i = 0; i < 9; i++) {
                     if (inv.method_5438(i).method_31574(class_1802.field_8634)) {
                        slot = i;
                        hand = class_1268.field_5808;
                        break;
                     }
                  }
               }

               if (hand != null) {
                  class_1799 pearl = new class_1799(class_1802.field_8634);
                  if (mc.field_1724.method_7357().method_7904(pearl)) {
                     this.say(Lang.t("Жемчуг на перезарядке", "Pearl is on cooldown"), false);
                  } else {
                     int prev = inv.method_67532();
                     if (slot >= 0) {
                        inv.method_61496(slot);
                     }

                     mc.field_1761.method_2919(mc.field_1724, hand);
                     mc.field_1724.method_6104(hand);
                     if (slot >= 0 && this.restore.value && prev != slot) {
                        this.restoreSlot = prev;
                        this.pearlSlot = slot;
                        this.restoreIn = 2;
                     }
                  }
               } else {
                  boolean inInv = false;

                  for (int ix = 9; ix < inv.method_5439(); ix++) {
                     if (inv.method_5438(ix).method_31574(class_1802.field_8634)) {
                        inInv = true;
                        break;
                     }
                  }

                  this.say(
                     inInv
                        ? Lang.t("Жемчуг есть только в инвентаре — положите его в хотбар", "Pearls are only in the inventory — put them in the hotbar")
                        : Lang.t("Нет жемчуга Края", "No ender pearls"),
                     false
                  );
               }
            }
         }
      }

      private void say(String s, boolean ok) {
         long now = System.currentTimeMillis();
         if (this.notify.value && now - this.lastNoPearl >= 1500L) {
            this.lastNoPearl = now;
            Notifications.push(s, ok);
         }
      }

      @Override
      public void onTick() {
         if (this.key.pressed()) {
            this.throwPearl();
         }

         if (this.restoreIn > 0 && --this.restoreIn == 0 && mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();
            if (inv.method_67532() == this.pearlSlot && class_1661.method_7380(this.restoreSlot)) {
               inv.method_61496(this.restoreSlot);
            }

            this.restoreSlot = -1;
            this.pearlSlot = -1;
         }
      }

      @Override
      public void onDisable() {
         this.restoreIn = 0;
         this.restoreSlot = -1;
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.indicator.value && mc.field_1724 != null && mc.field_1755 == null) {
            class_1799 pearl = new class_1799(class_1802.field_8634);
            class_1796 cd = mc.field_1724.method_7357();
            if (cd.method_7904(pearl)) {
               float p = cd.method_7905(pearl, delta);
               int cx = ctx.method_51421() / 2;
               int cy = ctx.method_51443() / 2 + 14;
               int w = 34;
               ctx.method_51427(pearl, cx - w / 2 - 18, cy - 4);
               R2D.round(ctx, cx - w / 2, cy + 2, w, 4, 2, Integer.MIN_VALUE);
               R2D.round(ctx, cx - w / 2, cy + 2, Math.max(2, (int)(w * (1.0F - p))), 4, 2, R2D.accent(0.0F));
            }
         }
      }
   }

   public static class HpAlert extends Module {
      final Setting.Num threshold = this.add(new Setting.Num("threshold", "Предупреждать при HP ниже", "Warn below HP", 8.0, 1.0, 19.0, 0.5).suffix(" ❤"));
      final Setting.Num critical = this.add(new Setting.Num("critical", "Критично ниже", "Critical below", 4.0, 0.5, 19.0, 0.5).suffix(" ❤"));
      final Setting.Bool absorption = this.add(new Setting.Bool("absorption", "Учитывать жёлтые сердца", "Count absorption", true));
      final Setting.Mode style = this.add(
         new Setting.Mode(
            "style",
            "Вид",
            "Style",
            0,
            "both",
            "Края экрана + надпись",
            "Edges + text",
            "edges",
            "Только красные края",
            "Edges only",
            "text",
            "Только надпись",
            "Text only"
         )
      );
      final Setting.Bool pulse = this.add(new Setting.Bool("pulse", "Пульсация", "Pulse", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук", "Sound", true));
      final Setting.Num repeat = (Setting.Num)this.add(new Setting.Num("repeat", "Повтор звука каждые", "Repeat sound every", 3.0, 0.0, 15.0, 1.0).suffix(" с"))
         .showIf(() -> this.sound.value);
      final Setting.Bool hearts = this.add(new Setting.Bool("hearts", "Показывать в сердечках (÷2)", "Show in hearts (÷2)", false));
      final Setting.Color color = this.add(new Setting.Color("color", "Цвет", "Color", -53184));
      private boolean low;
      private long lastSound;
      private float fade;

      public HpAlert() {
         super(
            "hp_alert",
            Category.UTILITIES,
            false,
            "HP Alert",
            "HP Alert",
            "Красные края экрана, надпись и звук, когда здоровья мало. Два порога: «мало» и «критично»",
            "Red screen edges, text and sound when health is low. Two levels: low and critical"
         );
      }

      float hp() {
         class_746 p = mc.field_1724;
         return p.method_6032() + (this.absorption.value ? p.method_6067() : 0.0F);
      }

      @Override
      public void onTick() {
         class_746 p = mc.field_1724;
         if (p != null && !p.method_68878() && !p.method_7325() && !p.method_29504()) {
            float hp = this.hp();
            boolean now = hp < this.threshold.value;
            boolean crit = hp < this.critical.value;
            long t = System.currentTimeMillis();
            if (this.sound.value && now) {
               long every = this.repeat.value <= 0.0 ? Long.MAX_VALUE : (long)(this.repeat.value * 1000.0 / (crit ? 2 : 1));
               if (!this.low || t - this.lastSound >= every) {
                  Sounds.play(Sounds.OFF);
                  this.lastSound = t;
               }
            }

            this.low = now;
         } else {
            this.low = false;
         }
      }

      @Override
      public void onDisable() {
         this.low = false;
         this.fade = 0.0F;
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         this.fade = R2D.approach(this.fade, this.low ? 1.0F : 0.0F, 0.15F);
         if (!(this.fade < 0.02F) && mc.field_1724 != null && !mc.field_1690.field_1842) {
            float hp = this.hp();
            boolean crit = hp < this.critical.value;
            float beat = this.pulse.value ? (float)(Math.sin(System.currentTimeMillis() / (crit ? 90.0 : 160.0)) + 1.0) / 2.0F : 1.0F;
            int sw = ctx.method_51421();
            int sh = ctx.method_51443();
            int col = this.color.argb | 0xFF000000;
            float strength = this.fade * (crit ? 1.0F : 0.6F) * (0.55F + 0.45F * beat);
            if (!this.style.is("text")) {
               int depth = Math.max(16, sh / 6);

               for (int i = 0; i < depth; i += 2) {
                  int a = (int)(150.0F * strength * (1.0F - (float)i / depth) * (1.0F - (float)i / depth));
                  if (a > 0) {
                     int c = R2D.withAlpha(col, a);
                     R2D.rect(ctx, 0, i, sw, 2, c);
                     R2D.rect(ctx, 0, sh - i - 2, sw, 2, c);
                     R2D.rect(ctx, i, 0, 2, sh, c);
                     R2D.rect(ctx, sw - i - 2, 0, 2, sh, c);
                  }
               }
            }

            if (!this.style.is("edges") && mc.field_1755 == null) {
               String v = this.hearts.value ? String.format("%.1f ❤", hp / 2.0F) : String.format("%.1f HP", hp);
               String s = (crit ? Lang.t("КРИТИЧНО: ", "CRITICAL: ") : Lang.t("МАЛО HP: ", "LOW HP: ")) + v;
               float sc = crit ? 1.6F : 1.3F;
               int w = (int)(R2D.width(s) * sc);
               int tc = R2D.withAlpha(R2D.lerp(col, -1, beat * 0.5F), (int)(255.0F * this.fade));
               R2D.textScaled(ctx, s, sw / 2.0F - w / 2.0F, sh / 2.0F - 46.0F, sc, tc, true);
            }
         }
      }
   }

   public static class PvpHelper extends Module {
      final Setting.Mode style = this.add(
         new Setting.Mode(
            "style",
            "Индикатор",
            "Indicator",
            0,
            "ring",
            "Кольцо у прицела",
            "Ring at crosshair",
            "text",
            "Надпись",
            "Text",
            "both",
            "Кольцо + надпись",
            "Ring + text"
         )
      );
      final Setting.Bool cooldown = this.add(new Setting.Bool("cooldown", "Показывать перезарядку удара", "Show attack cooldown", true));
      final Setting.Bool sprintWarn = this.add(new Setting.Bool("sprint_warn", "Предупреждать: бег отменяет крит", "Warn: sprinting cancels crit", true));
      final Setting.Bool counter = this.add(new Setting.Bool("counter", "Счётчик критов", "Crit counter", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук при крите", "Sound on crit", false));
      final Setting.Color critColor = this.add(new Setting.Color("crit_color", "Цвет «бей сейчас»", "«Hit now» color", -11870592));
      private int hits;
      private int crits;
      private long lastCrit;
      private float ready;
      private static UtilityModules.PvpHelper inst;

      public PvpHelper() {
         super(
            "pvp_helper",
            Category.UTILITIES,
            false,
            "PvP Helper",
            "PvP Helper",
            "Показывает, когда удар будет критом (падение после прыжка + перезарядка), и считает криты",
            "Shows when a hit will be a critical (falling after a jump + cooldown) and counts crits"
         );
         inst = this;
      }

      public static boolean critNow() {
         class_746 p = class_310.method_1551().field_1724;
         return p == null
            ? false
            : p.field_6017 > 0.0
               && !p.method_24828()
               && !p.method_6101()
               && !p.method_5799()
               && !p.method_5765()
               && !p.method_6059(class_1294.field_5919)
               && !p.method_5624()
               && p.method_7261(0.5F) > 0.9F;
      }

      public static void onAttack() {
         if (inst != null && inst.isEnabled()) {
            inst.hits++;
            if (critNow()) {
               inst.crits++;
               inst.lastCrit = System.currentTimeMillis();
               if (inst.sound.value) {
                  Sounds.play(Sounds.ON);
               }
            }
         }
      }

      @Override
      public void onEnable() {
         this.hits = 0;
         this.crits = 0;
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (mc.field_1724 != null && mc.field_1755 == null && !mc.field_1690.field_1842) {
            class_746 p = mc.field_1724;
            int cx = ctx.method_51421() / 2;
            int cy = ctx.method_51443() / 2;
            float cd = p.method_7261(delta);
            boolean airborne = !p.method_24828() && !p.method_6101() && !p.method_5799();
            boolean crit = critNow();
            this.ready = R2D.approach(this.ready, crit ? 1.0F : 0.0F, 0.35F);
            int good = this.critColor.argb | 0xFF000000;
            boolean ring = !this.style.is("text");
            boolean txt = !this.style.is("ring");
            if (ring) {
               int r = 9;
               if (this.cooldown.value && cd < 1.0F) {
                  int seg = 24;

                  for (int i = 0; i < seg * cd; i++) {
                     double a = (-Math.PI / 2) + i * 2 * Math.PI / seg;
                     R2D.rect(ctx, cx + (int)Math.round(Math.cos(a) * r), cy + (int)Math.round(Math.sin(a) * r), 1, 1, -1056964609);
                  }
               }

               if (airborne && cd > 0.9F) {
                  R2D.ringCircle(ctx, cx, cy, r, crit ? good : -15539);
               }

               if (this.ready > 0.05F) {
                  R2D.ringCircle(ctx, cx, cy, r + 2 + (int)(2.0F * (1.0F - this.ready)), R2D.withAlpha(good, (int)(200.0F * this.ready)));
               }
            }

            String msg = null;
            int mc0 = -1;
            if (crit) {
               msg = Lang.t("КРИТ — бей!", "CRIT — hit!");
               mc0 = good;
            } else if (this.sprintWarn.value && airborne && p.method_5624() && p.field_6017 > 0.0) {
               msg = Lang.t("Отпусти бег для крита", "Stop sprinting to crit");
               mc0 = -15539;
            } else if (airborne && p.method_18798().field_1351 > 0.0 && cd > 0.9F) {
               msg = Lang.t("жди падения…", "wait for the fall…");
               mc0 = -4670004;
            }

            if (txt && msg != null) {
               R2D.centered(ctx, msg, cx, cy + 16, mc0);
            }

            if (this.counter.value && this.hits > 0) {
               String c = Lang.t("Криты: ", "Crits: ") + this.crits + "/" + this.hits + " (" + Math.round(100.0F * this.crits / this.hits) + "%)";
               boolean flash = System.currentTimeMillis() - this.lastCrit < 400L;
               R2D.centered(ctx, c, cx, cy + (txt && msg != null ? 27 : 16), flash ? good : -4670004);
            }
         }
      }
   }

   public static class TotemAlert extends Module {
      final Setting.Bool onlyNeeded = this.add(
         new Setting.Bool("only_needed", "Только когда нужно (бой / мало HP)", "Only when needed (combat / low HP)", false)
      );
      final Setting.Num hp = (Setting.Num)this.add(new Setting.Num("hp", "«Мало HP» — ниже", "Low HP below", 12.0, 2.0, 20.0, 1.0))
         .showIf(() -> this.onlyNeeded.value);
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук", "Sound", true));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление после сломанного тотема", "Notify after a totem pop", true));
      final Setting.Bool counter = this.add(new Setting.Bool("counter", "Показывать сколько тотемов", "Show totem count", true));
      private boolean wasMissing;
      private int lastPops = -1;

      public TotemAlert() {
         super(
            "totem_alert",
            Category.UTILITIES,
            false,
            "Totem Alert",
            "Totem Alert",
            "Мигающее предупреждение и звук, когда во второй руке нет тотема (сам предметы не двигает)",
            "Blinking warning and sound when your offhand has no totem (does not move items itself)"
         );
      }

      int count() {
         int c = 0;
         class_1661 inv = mc.field_1724.method_31548();

         for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(class_1802.field_8288)) {
               c += s.method_7947();
            }
         }

         return c;
      }

      boolean missing() {
         if (mc.field_1724 != null && !mc.field_1724.method_68878() && !mc.field_1724.method_7325()) {
            if (mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
               return false;
            } else if (this.count() == 0) {
               return false;
            } else {
               if (this.onlyNeeded.value) {
                  boolean combat = System.currentTimeMillis() - Info.lastHurtAt < 10000L || System.currentTimeMillis() - Info.lastHitTime < 10000L;
                  if (!combat && mc.field_1724.method_6032() >= this.hp.value) {
                     return false;
                  }
               }

               return true;
            }
         } else {
            return false;
         }
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null) {
            boolean m = this.missing();
            if (m && !this.wasMissing && this.sound.value) {
               Sounds.play(Sounds.OFF);
            }

            int pops = Info.pops(mc.field_1724);
            if (this.lastPops >= 0 && pops > this.lastPops && this.notify.value) {
               Notifications.push(Lang.t("Тотем сломан! Осталось: ", "Totem popped! Left: ") + this.count(), false);
            }

            this.lastPops = pops;
            this.wasMissing = m;
         }
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.wasMissing && mc.field_1755 == null) {
            String s = "⚠ " + Lang.t("Нет тотема во второй руке", "No totem in offhand") + (this.counter.value ? "  (" + this.count() + ")" : "");
            float blink = (float)(Math.sin(System.currentTimeMillis() / 140.0) + 1.0) / 2.0F;
            int w = R2D.width(s) + 26;
            int x = ctx.method_51421() / 2 - w / 2;
            int y = ctx.method_51443() / 2 + 30;
            R2D.round(ctx, x, y, w, 16, 8, R2D.lerp(-1606418416, -1063251936, blink));
            ctx.method_51427(new class_1799(class_1802.field_8288), x + 2, y);
            R2D.text(ctx, s, x + 21, y + 4, -1, false);
         }
      }
   }

   public static class TotemHelper extends Module {
      public final Setting.Key key = this.add(new Setting.Key("key", "Клавиша «взять тотем»", "«Take totem» key", -1));
      final Setting.Num hp = this.add(new Setting.Num("hp", "Подсказывать при HP ниже", "Hint below HP", 8.0, 2.0, 19.0, 1.0).suffix(" HP"));
      final Setting.Bool highlight = this.add(new Setting.Bool("highlight", "Подсвечивать слот с тотемом", "Highlight the totem slot", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук при малом HP", "Sound at low HP", true));
      final Setting.Bool back = this.add(new Setting.Bool("back", "Клавиша ещё раз — вернуть прежний слот", "Press again — return to previous slot", true));
      private int prevSlot = -1;
      private boolean wasLow;

      public TotemHelper() {
         super(
            "totem_helper",
            Category.UTILITIES,
            false,
            "Totem Helper",
            "Totem Helper",
            "При малом HP подсвечивает тотем в хотбаре, а своя клавиша сразу берёт его в руку (сам слот не меняет)",
            "At low HP highlights the hotbar totem; your key instantly takes it in hand (never switches by itself)"
         );
      }

      int totemSlot() {
         class_1661 inv = mc.field_1724.method_31548();

         for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) {
               return i;
            }
         }

         return -1;
      }

      boolean low() {
         return mc.field_1724.method_6032() + mc.field_1724.method_6067() < this.hp.value && !mc.field_1724.method_68878() && !mc.field_1724.method_7325();
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();
            if (this.key.pressed()) {
               int s = this.totemSlot();
               if (this.back.value && this.prevSlot >= 0 && inv.method_7391().method_31574(class_1802.field_8288)) {
                  inv.method_61496(this.prevSlot);
                  this.prevSlot = -1;
               } else if (s >= 0) {
                  if (inv.method_67532() != s) {
                     this.prevSlot = inv.method_67532();
                  }

                  inv.method_61496(s);
               } else {
                  Notifications.push(Lang.t("В хотбаре нет тотема", "No totem in the hotbar"), false);
               }
            }

            boolean l = this.low()
               && this.totemSlot() >= 0
               && !inv.method_7391().method_31574(class_1802.field_8288)
               && !mc.field_1724.method_6079().method_31574(class_1802.field_8288);
            if (l && !this.wasLow && this.sound.value) {
               Sounds.play(Sounds.OFF);
            }

            this.wasLow = l;
         }
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.wasLow && mc.field_1724 != null && mc.field_1755 == null && !mc.field_1690.field_1842) {
            int s = this.totemSlot();
            if (s >= 0) {
               int sw = ctx.method_51421();
               int sh = ctx.method_51443();
               float beat = (float)(Math.sin(System.currentTimeMillis() / 110.0) + 1.0) / 2.0F;
               if (this.highlight.value) {
                  int x = sw / 2 - 91 + s * 20;
                  int y = sh - 22;
                  R2D.outline(ctx, x, y, 22, 22, 4, R2D.lerp(-15539, -1, beat));
                  R2D.round(ctx, x + 1, y + 1, 20, 20, 4, R2D.withAlpha(-15539, (int)(40.0F + 60.0F * beat)));
               }

               String k = this.key.value < 0 ? Lang.t("цифру ", "key ") + (s + 1) : this.key.display() + Lang.t(" или ", " or ") + (s + 1);
               String t = "\ud83d\udee1 " + Lang.t("Тотем! Нажми ", "Totem! Press ") + k;
               int w = R2D.width(t) + 12;
               int x = sw / 2 - w / 2;
               int y = sh - 58;
               R2D.round(ctx, x, y, w, 14, 7, R2D.lerp(-1069539328, -528461808, beat));
               R2D.text(ctx, t, x + 6, y + 3, -1, false);
            }
         }
      }
   }
}
