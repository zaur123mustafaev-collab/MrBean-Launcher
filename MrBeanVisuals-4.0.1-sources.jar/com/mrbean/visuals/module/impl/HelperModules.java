package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_332;

public final class HelperModules {
   private HelperModules() {
   }

   public static void registerAll() {
      Modules.reg(new HelperModules.TotemCounter());
      Modules.reg(new HelperModules.DurabilityWarning());
      Modules.reg(new HelperModules.CombatTimer());
      Modules.reg(new HelperModules.HitParticles());
   }

   public static class CombatTimer extends HudModule {
      final Setting.Num seconds = this.add(new Setting.Num("seconds", "Длительность боя", "Combat duration", 15.0, 5.0, 60.0, 1.0).suffix(" с"));
      final Setting.Bool onHurt = this.add(new Setting.Bool("on_hurt", "Учитывать урон по вам", "Count damage taken", true));
      final Setting.Bool bar = this.add(new Setting.Bool("bar", "Полоса", "Bar", true));

      public CombatTimer() {
         super(
            "combat_timer",
            false,
            0.5,
            0.2,
            "Combat Timer",
            "Combat Timer",
            "Сколько ещё вы «в бою» после последнего удара (как PvP-режим на серверах)",
            "How long you stay in combat after the last hit (like server PvP tags)"
         );
      }

      private long left() {
         long last = Info.lastHitTime;
         if (this.onHurt.value) {
            last = Math.max(last, Info.lastHurtAt);
         }

         long dur = (long)(this.seconds.value * 1000.0);
         return Math.max(0L, last + dur - System.currentTimeMillis());
      }

      @Override
      protected boolean hasContent() {
         return this.left() > 0L;
      }

      @Override
      protected void layout() {
         this.w = Math.max(this.tw(this.label(editing ? 9400L : this.left())), 70);
         this.h = this.bar.value ? 14 : 9;
      }

      private String label(long ms) {
         return "⚔ " + Lang.t("В бою: ", "In combat: ") + String.format("%.1f", ms / 1000.0) + Lang.t("с", "s");
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         long l = editing ? 9400L : this.left();
         float frac = (float)(l / (this.seconds.value * 1000.0));
         this.text(ctx, this.label(l), 0, 0, R2D.lerp(-1, -42396, frac));
         if (this.bar.value) {
            R2D.round(ctx, 0, 11, this.w, 3, 1, 1342177280);
            R2D.round(ctx, 0, 11, Math.max(2, (int)(this.w * frac)), 3, 1, R2D.lerp(this.accent(0.0F), -42396, frac));
         }
      }
   }

   public static class DurabilityWarning extends HudModule {
      final Setting.Num threshold = this.add(new Setting.Num("threshold", "Предупреждать ниже", "Warn below", 20.0, 5.0, 60.0, 5.0).suffix("%"));
      final Setting.Bool blink = this.add(new Setting.Bool("blink", "Мигание", "Blink", true));
      final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук при падении ниже порога", "Sound when crossing", true));
      final Setting.Bool hands = this.add(new Setting.Bool("hands", "Предметы в руках", "Held items", true));
      private final List<class_1799> low = new ArrayList<>();
      private final List<Float> fr = new ArrayList<>();
      private final Set<String> warned = new HashSet<>();

      public DurabilityWarning() {
         super(
            "durability_warning",
            true,
            0.5,
            0.62,
            "Durability Warning",
            "Durability Warning",
            "Броня и инструменты, которые скоро сломаются",
            "Armor and tools that are about to break"
         );
         this.background.value = false;
      }

      @Override
      protected void layout() {
         this.low.clear();
         this.fr.clear();
         if (mc.field_1724 != null && !mc.field_1724.method_68878()) {
            List<class_1304> slots = new ArrayList<>(List.of(class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166));
            if (this.hands.value) {
               slots.add(class_1304.field_6173);
               slots.add(class_1304.field_6171);
            }

            Set<String> nowLow = new HashSet<>();

            for (class_1304 s : slots) {
               class_1799 st = mc.field_1724.method_6118(s);
               if (!st.method_7960() && st.method_7963()) {
                  float f = 1.0F - (float)st.method_7919() / st.method_7936();
                  if (!(f * 100.0F > this.threshold.value)) {
                     this.low.add(st);
                     this.fr.add(f);
                     String key = s.name() + st.method_7909();
                     nowLow.add(key);
                     if (this.sound.value && this.warned.add(key)) {
                        Sounds.play(Sounds.OFF);
                     }
                  }
               }
            }

            this.warned.retainAll(nowLow);
         }

         if (editing && this.low.isEmpty()) {
            this.low.add(new class_1799(class_1802.field_8058));
            this.fr.add(0.12F);
         }

         this.w = Math.max(20, this.low.size() * 22);
         this.h = 22;
      }

      @Override
      protected boolean hasContent() {
         if (mc.field_1724 != null && !mc.field_1724.method_68878()) {
            for (class_1304 s : class_1304.values()) {
               if (this.hands.value || s != class_1304.field_6173 && s != class_1304.field_6171) {
                  class_1799 st = mc.field_1724.method_6118(s);
                  if (!st.method_7960() && st.method_7963() && (1.0F - (float)st.method_7919() / st.method_7936()) * 100.0F <= this.threshold.value) {
                     return true;
                  }
               }
            }

            return false;
         } else {
            return false;
         }
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         float pulse = this.blink.value ? (float)(Math.sin(System.currentTimeMillis() / 140.0) + 1.0) / 2.0F : 0.0F;

         for (int i = 0; i < this.low.size(); i++) {
            int x = i * 22;
            float f = this.fr.get(i);
            R2D.round(ctx, x, 0, 20, 22, 4, R2D.withAlpha(-53200, (int)(40.0F + 60.0F * pulse)));
            ctx.method_51427(this.low.get(i), x + 2, 1);
            R2D.rect(ctx, x + 2, 18, 16, 2, Integer.MIN_VALUE);
            R2D.rect(ctx, x + 2, 18, Math.max(1, (int)(16.0F * f)), 2, R2D.healthColor(f));
         }
      }
   }

   public static class HitParticles extends Module {
      final Setting.Num count = this.add(new Setting.Num("count", "Количество", "Count", 14.0, 2.0, 60.0, 1.0));
      final Setting.Num size = this.add(new Setting.Num("size", "Размер", "Size", 1.0, 0.4, 2.5, 0.1).suffix("x"));
      final Setting.Mode style = this.add(
         new Setting.Mode("style", "Вид", "Style", 0, "sparkle", "Искры", "Sparkles", "plain", "Точки", "Dots", "snow", "Хлопья", "Flakes")
      );
      final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -45715))
         .showIf(() -> this.color.is("custom"));
      final Setting.Bool critsMore = this.add(new Setting.Bool("crits_more", "Больше при крите (в падении)", "More on crits (falling)", true));

      public HitParticles() {
         super(
            "hit_particles",
            Category.PARTICLES,
            false,
            "Hit Particles",
            "Hit Particles",
            "Свои частицы на цели при ударе",
            "Custom particles on the target when you hit"
         );
      }

      public void onHit(class_1309 target) {
         if (this.isEnabled() && mc.field_1724 != null) {
            boolean crit = this.critsMore.value
               && mc.field_1724.field_6017 > 0.0
               && !mc.field_1724.method_24828()
               && !mc.field_1724.method_6101()
               && !mc.field_1724.method_5799();
            int n = this.count.i() * (crit ? 2 : 1);
            class_243 c = target.method_5829().method_1005();
            int st = this.style.is("plain") ? 0 : (this.style.is("snow") ? 4 : 1);

            for (int i = 0; i < n; i++) {
               float vx = (float)(Math.random() - 0.5) * 0.3F;
               float vy = (float)Math.random() * 0.25F + 0.05F;
               float vz = (float)(Math.random() - 0.5) * 0.3F;
               ParticleEngine.spawn(
                  c.field_1352,
                  c.field_1351 + (Math.random() - 0.5) * target.method_17682() * 0.6,
                  c.field_1350,
                  vx,
                  vy,
                  vz,
                  16 + (int)(Math.random() * 10.0),
                  (float)(0.14 * this.size.value),
                  CrystalModules.colorOf(this.color, this.custom, (float)i / n),
                  0.02F,
                  0.9F,
                  true,
                  st
               );
            }
         }
      }
   }

   public static class TotemCounter extends HudModule {
      final Setting.Bool pops = this.add(new Setting.Bool("pops", "Сколько тотемов сломано", "Totem pops", true));
      final Setting.Bool targetPops = this.add(new Setting.Bool("target_pops", "Сломанные у цели", "Target's pops", true));
      final Setting.Bool warnLow = this.add(new Setting.Bool("warn_low", "Красный, если тотемов мало", "Red when low", true));
      final Setting.Num low = (Setting.Num)this.add(new Setting.Num("low", "«Мало» — это меньше", "Low below", 2.0, 1.0, 10.0, 1.0))
         .showIf(() -> this.warnLow.value);
      private int count;
      private int myPops;
      private int tPops;
      private String tName;
      private static final int Ui_MUTED = -4670004;

      public TotemCounter() {
         super(
            "totem_counter",
            false,
            0.56,
            0.86,
            "Totem Counter",
            "Totem Counter",
            "Тотемы в инвентаре, сколько сломано у вас и у цели",
            "Totems in inventory, pops for you and your target"
         );
      }

      @Override
      protected void layout() {
         this.count = 0;
         this.tName = null;
         if (mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();

            for (int i = 0; i < inv.method_5439(); i++) {
               class_1799 s = inv.method_5438(i);
               if (s.method_31574(class_1802.field_8288)) {
                  this.count = this.count + s.method_7947();
               }
            }

            this.myPops = Info.pops(mc.field_1724);
            class_1309 t = Info.lastTarget;
            if (this.targetPops.value && t instanceof class_1657 && System.currentTimeMillis() - Info.lastTargetTime < 15000L) {
               this.tPops = Info.pops(t);
               this.tName = t.method_5477().getString();
            }
         }

         if (editing && this.count == 0) {
            this.count = 3;
            this.myPops = 1;
         }

         this.w = 18
            + this.tw("x" + this.count)
            + (this.pops.value ? 8 + this.tw(Lang.t("сломано ", "pops ") + this.myPops) : 0)
            + (this.tName != null && this.tPops > 0 ? 8 + this.tw(this.tName + ": " + this.tPops) : 0);
         this.h = 16;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         ctx.method_51427(new class_1799(class_1802.field_8288), 0, 0);
         boolean red = this.warnLow.value && this.count < this.low.value;
         this.text(ctx, "x" + this.count, 17, 5, red ? R2D.lerp(-42396, -1, (float)(Math.sin(System.currentTimeMillis() / 160.0) + 1.0) / 4.0F) : -1);
         int x = 18 + this.tw("x" + this.count);
         if (this.pops.value) {
            x += 8;
            String s = Lang.t("сломано ", "pops ") + this.myPops;
            this.text(ctx, s, x, 5, -4670004);
            x += this.tw(s);
         }

         if (this.tName != null && this.tPops > 0) {
            x += 8;
            this.text(ctx, this.tName + ": " + this.tPops, x, 5, this.accent(0.0F));
         }
      }
   }
}
