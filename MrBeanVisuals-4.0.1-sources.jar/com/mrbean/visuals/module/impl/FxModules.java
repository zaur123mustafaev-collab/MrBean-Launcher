package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Previewable;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.ParticleEngine;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import java.util.Random;
import net.minecraft.class_1299;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix3x2fStack;

public final class FxModules {
   private FxModules() {
   }

   public static void registerAll() {
      Modules.reg(new FxModules.SwordAnimation());
      Modules.reg(new FxModules.KillEffect());
   }

   private static void previewBox(class_332 ctx, int x, int y, int w, int h) {
      R2D.round(ctx, x, y, w, h, 6, -15855855);
      R2D.outline(ctx, x, y, w, h, 6, 419430399);
      R2D.textScaled(ctx, Lang.t("Предпросмотр", "Preview"), x + 6, y + 5, 0.7F, -9538949, false);
   }

   public static class KillEffect extends Module implements Previewable {
      public final Setting.Mode mode = this.add(
         new Setting.Mode(
            "mode",
            "Эффект",
            "Effect",
            0,
            "souls",
            "Душа улетает",
            "Soul rises",
            "lightning",
            "Молния",
            "Lightning",
            "blood",
            "Кровь",
            "Blood",
            "firework",
            "Фейерверк",
            "Firework",
            "hearts",
            "Сердечки",
            "Hearts",
            "ring",
            "Кольцо",
            "Ring"
         )
      );
      public final Setting.Mode color = this.add(CrystalModules.colorMode("color"));
      public final Setting.Color custom = (Setting.Color)this.add(new Setting.Color("custom", "Свой цвет", "Custom color", -6297345))
         .showIf(() -> this.color.is("custom"));
      public final Setting.Num amount = this.add(new Setting.Num("amount", "Количество частиц", "Particle amount", 40.0, 10.0, 150.0, 5.0));
      public final Setting.Bool sound = this.add(new Setting.Bool("sound", "Звук (у молнии — гром)", "Sound (thunder for lightning)", true));
      public final Setting.Bool text = this.add(new Setting.Bool("text", "Надпись «Убийство» на экране", "«Kill» text on screen", true));
      public final Setting.Bool players = this.add(new Setting.Bool("players_only", "Только игроки", "Players only", false));
      private class_1309 watched;
      private int watchedId = Integer.MIN_VALUE;
      private long textAt;
      private String textName = "";
      private int kills;

      public KillEffect() {
         super(
            "kill_effect",
            Category.ANIMATIONS,
            false,
            "Анимация убийства",
            "Kill Effects",
            "Эффект на месте убитого тобой: душа, молния, кровь, фейерверк, сердечки, кольцо",
            "Effect where your victim died: soul, lightning, blood, firework, hearts, ring"
         );
      }

      @Override
      public void onTick() {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            class_1309 t = Info.lastTarget;
            if (t != null && System.currentTimeMillis() - Info.lastHitTime < 4000L && t.method_5628() != this.watchedId) {
               this.watched = t;
            }

            if (this.watched != null && this.watched.method_5628() != this.watchedId && (this.watched.method_29504() || this.watched.method_6032() <= 0.0F)) {
               if (!this.players.value || this.watched instanceof class_1657) {
                  this.play(this.watched);
               }

               this.watchedId = this.watched.method_5628();
               this.watched = null;
            }

            if (this.watched != null && System.currentTimeMillis() - Info.lastHitTime > 6000L) {
               this.watched = null;
            }
         }
      }

      void play(class_1309 e) {
         class_243 c = e.method_5829().method_1005();
         int n = this.amount.i();
         this.kills++;
         this.textAt = System.currentTimeMillis();
         this.textName = e.method_5477().getString();
         String var4 = this.mode.get();
         switch (var4) {
            case "lightning":
               class_1538 l = new class_1538(class_1299.field_6112, mc.field_1687);
               l.method_5838(-424242 - this.kills);
               l.method_24203(e.method_23317(), e.method_23318(), e.method_23321());
               l.method_29498(true);
               if (!this.sound.value) {
                  l.method_5803(true);
               }

               mc.field_1687.method_53875(l);
               this.burst(c.field_1352, c.field_1351, c.field_1350, n / 2, 0.25F, 0.1F, 0.02F, 1, 22);
               break;
            case "blood":
               this.burst(c.field_1352, c.field_1351, c.field_1350, n, 0.22F, 0.18F, 0.06F, 0, 26);
               break;
            case "firework":
               this.burst(c.field_1352, c.field_1351 + 0.5, c.field_1350, n, 0.45F, 0.45F, 0.01F, 1, 34);
               break;
            case "hearts":
               for (int i = 0; i < Math.max(4, n / 6); i++) {
                  mc.field_1713
                     .method_3056(class_2398.field_11201, c.field_1352 + (Math.random() - 0.5), c.field_1351 + Math.random(), c.field_1350 + (Math.random() - 0.5), 0.0, 0.1, 0.0);
               }
               break;
            case "ring":
               for (int i = 0; i < n; i++) {
                  double a = i * Math.PI * 2.0 / n;
                  ParticleEngine.spawn(
                     c.field_1352,
                     e.method_23318() + 0.1,
                     c.field_1350,
                     (float)Math.cos(a) * 0.25F,
                     0.01F,
                     (float)Math.sin(a) * 0.25F,
                     24,
                     0.16F,
                     CrystalModules.colorOf(this.color, this.custom, (float)i / n),
                     0.0F,
                     0.92F,
                     true,
                     1
                  );
               }
               break;
            default:
               for (int i = 0; i < n; i++) {
                  ParticleEngine.spawn(
                     c.field_1352 + (Math.random() - 0.5) * 0.6,
                     e.method_23318() + Math.random() * e.method_17682(),
                     c.field_1350 + (Math.random() - 0.5) * 0.6,
                     (float)(Math.random() - 0.5) * 0.03F,
                     0.05F + (float)Math.random() * 0.06F,
                     (float)(Math.random() - 0.5) * 0.03F,
                     40 + (int)(Math.random() * 20.0),
                     0.15F,
                     CrystalModules.colorOf(this.color, this.custom, (float)i / n),
                     -0.002F,
                     0.98F,
                     true,
                     2
                  );
               }
         }

         if (this.sound.value && !this.mode.is("lightning")) {
            Sounds.play(Sounds.ON);
         }
      }

      private void burst(double x, double y, double z, int n, float spread, float up, float grav, int style, int life) {
         for (int i = 0; i < n; i++) {
            float vx = (float)(Math.random() - 0.5) * spread;
            float vy = (float)Math.random() * up + 0.04F;
            float vz = (float)(Math.random() - 0.5) * spread;
            int col = this.mode.is("blood") ? R2D.lerp(-5238758, -53184, (float)Math.random()) : CrystalModules.colorOf(this.color, this.custom, (float)i / n);
            ParticleEngine.spawn(x, y, z, vx, vy, vz, life + (int)(Math.random() * 10.0), 0.15F, col, grav, 0.93F, !this.mode.is("blood"), style);
         }
      }

      @Override
      public void renderOverlay(class_332 ctx, float delta) {
         if (this.text.value && this.textAt != 0L) {
            long age = System.currentTimeMillis() - this.textAt;
            if (age <= 1800L) {
               float a = age < 150L ? (float)age / 150.0F : (age > 1400L ? (float)(1800L - age) / 400.0F : 1.0F);
               float pop = age < 200L ? 1.6F - 0.4F * (float)age / 200.0F : 1.2F;
               String s = "☠ " + Lang.t("Убийство: ", "Kill: ") + this.textName + "  #" + this.kills;
               int sw = ctx.method_51421();
               R2D.textScaled(
                  ctx,
                  s,
                  sw / 2.0F - R2D.width(s) * pop / 2.0F,
                  ctx.method_51443() * 0.28F,
                  pop,
                  R2D.withAlpha(R2D.accent(0.0F), (int)(255.0F * a)),
                  true
               );
            }
         }
      }

      @Override
      public int previewHeight() {
         return 80;
      }

      @Override
      public void drawPreview(class_332 ctx, int x, int y, int w, int h) {
         FxModules.previewBox(ctx, x, y, w, h);
         long t = System.currentTimeMillis() % 2200L;
         int cx = x + w / 2;
         int fy = y + h - 10;
         if (t < 700L) {
            int al = t < 500L ? 255 : (int)(255.0F * (1.0F - (float)(t - 500L) / 200.0F));
            int body = R2D.withAlpha(t > 380L && t < 500L ? -49072 : -7695450, al);
            R2D.rect(ctx, cx - 4, fy - 32, 8, 8, body);
            R2D.rect(ctx, cx - 5, fy - 23, 10, 12, body);
            R2D.rect(ctx, cx - 5, fy - 11, 4, 11, body);
            R2D.rect(ctx, cx + 1, fy - 11, 4, 11, body);
         }

         if (t >= 500L) {
            float e = (float)(t - 500L) / 1700.0F;
            int n = Math.min(40, this.amount.i());
            Random r = new Random(7L);
            String var13 = this.mode.get();
            switch (var13) {
               case "lightning":
                  if (e < 0.25F) {
                     int bx = cx;
                     int by = y + 12;

                     for (int i = 0; i < 6; i++) {
                        int nx = bx + r.nextInt(9) - 4;
                        int ny = by + (fy - y - 12) / 6;
                        R2D.rect(ctx, Math.min(bx, nx), by, Math.abs(nx - bx) + 2, ny - by, R2D.withAlpha(-1510145, (int)(255.0F * (1.0F - e * 4.0F))));
                        bx = nx;
                        by = ny;
                     }

                     R2D.rect(ctx, x + 1, y + 1, w - 2, h - 2, R2D.withAlpha(-1, (int)(40.0F * (1.0F - e * 4.0F))));
                  }

                  for (int i = 0; i < n / 2; i++) {
                     dot(ctx, cx + (float)(r.nextGaussian() * 30.0 * e), fy - 16 - r.nextFloat() * 30.0F * e, 2, this.colorAt(i, n), 1.0F - e);
                  }
                  break;
               case "blood":
                  for (int i = 0; i < n; i++) {
                     float vx = (r.nextFloat() - 0.5F) * 60.0F;
                     float vy = -r.nextFloat() * 40.0F;
                     dot(ctx, cx + vx * e, fy - 16 + vy * e + 80.0F * e * e, 2, R2D.lerp(-5238758, -53184, r.nextFloat()), 1.0F - e);
                  }
                  break;
               case "firework":
                  for (int i = 0; i < n; i++) {
                     double a = r.nextFloat() * Math.PI * 2.0;
                     float sp = 20.0F + r.nextFloat() * 25.0F;
                     dot(ctx, cx + (float)Math.cos(a) * sp * e, fy - 30 + (float)Math.sin(a) * sp * e + 15.0F * e * e, 2, this.colorAt(i, n), 1.0F - e);
                  }
                  break;
               case "hearts":
                  for (int i = 0; i < 6; i++) {
                     float px = cx + (r.nextFloat() - 0.5F) * 40.0F;
                     float py = fy - 20 - e * 40.0F - r.nextFloat() * 10.0F;
                     R2D.textScaled(ctx, "❤", px, py, 1.2F, R2D.withAlpha(-45715, (int)(255.0F * (1.0F - e))), false);
                  }
                  break;
               case "ring":
                  int rr = (int)(6.0F + e * 40.0F);

                  for (int i = 0; i < n; i++) {
                     double a = i * Math.PI * 2.0 / n;
                     dot(ctx, cx + (float)Math.cos(a) * rr, fy - 2 + (float)Math.sin(a) * rr * 0.3F, 2, this.colorAt(i, n), 1.0F - e);
                  }
                  break;
               default:
                  for (int i = 0; i < n; i++) {
                     float px = cx + (r.nextFloat() - 0.5F) * 14.0F + (float)Math.sin(e * 8.0F + i) * 3.0F;
                     float py = fy - r.nextFloat() * 30.0F - e * 45.0F;
                     dot(ctx, px, py, 2, this.colorAt(i, n), 1.0F - e);
                  }
            }

            if (this.text.value && e < 0.8F) {
               R2D.textScaled(
                  ctx,
                  "☠ " + Lang.t("Убийство", "Kill"),
                  cx - R2D.width("☠ " + Lang.t("Убийство", "Kill")) * 0.4F,
                  y + 14,
                  0.8F,
                  R2D.withAlpha(R2D.accent(0.0F), (int)(255.0F * (1.0F - e))),
                  false
               );
            }
         }
      }

      private int colorAt(int i, int n) {
         return CrystalModules.colorOf(this.color, this.custom, (float)i / n);
      }

      private static void dot(class_332 ctx, float x, float y, int s, int col, float a) {
         if (!(a <= 0.0F)) {
            R2D.rect(ctx, (int)x, (int)y, s, s, R2D.withAlpha(col, (int)(255.0F * Math.min(1.0F, a))));
         }
      }
   }

   public static class SwordAnimation extends Module implements Previewable {
      public final Setting.Mode mode = this.add(
         new Setting.Mode(
            "mode",
            "Анимация",
            "Animation",
            1,
            "vanilla",
            "Как в игре",
            "Vanilla",
            "smooth",
            "Плавная",
            "Smooth",
            "block",
            "1.7 (блок-хит)",
            "1.7 block-hit",
            "chop",
            "Рубящая",
            "Chop",
            "stab",
            "Укол вперёд",
            "Stab",
            "slide",
            "Скольжение",
            "Slide",
            "spin",
            "Вращение",
            "Spin",
            "swank",
            "Swank",
            "Swank"
         )
      );
      public final Setting.Num strength = this.add(new Setting.Num("strength", "Сила взмаха", "Swing strength", 1.0, 0.3, 2.0, 0.05).suffix("x"));
      public final Setting.Bool swordsOnly = this.add(new Setting.Bool("swords_only", "Только мечи и топоры", "Swords and axes only", true));
      public static int applied;

      public SwordAnimation() {
         super(
            "sword_animation",
            Category.ANIMATIONS,
            false,
            "Анимация мечей",
            "Sword Animations",
            "8 видов взмаха мечом от первого лица: 1.7 блок-хит, рубящая, укол, вращение и другие",
            "8 first-person swing styles: 1.7 block-hit, chop, stab, spin and more"
         );
      }

      public static FxModules.SwordAnimation active(class_1799 stack) {
         if (!(Modules.get("sword_animation") instanceof FxModules.SwordAnimation s && s.isEnabled() && !s.mode.is("vanilla"))) {
            return null;
         } else {
            return s.swordsOnly.value && !stack.method_31573(class_3489.field_42611) && !stack.method_31573(class_3489.field_42612) ? null : s;
         }
      }

      public void apply(class_4587 ms, class_1306 arm, float p) {
         applied++;
         int i = arm == class_1306.field_6183 ? 1 : -1;
         float k = (float)this.strength.value;
         float s1 = class_3532.method_15374(p * p * (float) Math.PI);
         float s2 = class_3532.method_15374(class_3532.method_15355(p) * (float) Math.PI);
         String var8 = this.mode.get();
         switch (var8) {
            case "smooth":
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * (45.0F - s1 * 10.0F * k)));
               ms.method_22907(class_7833.field_40718.rotationDegrees(i * s2 * -10.0F * k));
               ms.method_22907(class_7833.field_40714.rotationDegrees(s2 * -45.0F * k));
               break;
            case "block":
               ms.method_46416(0.0F, 0.08F, 0.0F);
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * 45));
               ms.method_22907(class_7833.field_40718.rotationDegrees(i * (-20.0F - s2 * 20.0F * k)));
               ms.method_22907(class_7833.field_40714.rotationDegrees(-20.0F - s2 * 70.0F * k));
               break;
            case "chop":
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * 45));
               ms.method_22907(class_7833.field_40714.rotationDegrees(s2 * -110.0F * k));
               break;
            case "stab":
               ms.method_46416(0.0F, 0.0F, -0.45F * s2 * k);
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * 45));
               ms.method_22907(class_7833.field_40714.rotationDegrees(s2 * -15.0F * k));
               break;
            case "slide":
               ms.method_46416(-i * 0.25F * s2 * k, 0.0F, 0.0F);
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * (45.0F - s2 * 30.0F * k)));
               ms.method_22907(class_7833.field_40714.rotationDegrees(s2 * -25.0F * k));
               break;
            case "spin":
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * 45));
               ms.method_22907(class_7833.field_40714.rotationDegrees(-p * 360.0F));
               break;
            case "swank":
               ms.method_22907(class_7833.field_40716.rotationDegrees(i * (45.0F + s1 * 25.0F * k)));
               ms.method_22907(class_7833.field_40718.rotationDegrees(i * s2 * 30.0F * k));
               ms.method_22907(class_7833.field_40714.rotationDegrees(s2 * -55.0F * k));
         }

         ms.method_22907(class_7833.field_40716.rotationDegrees(i * -45));
      }

      @Override
      public int previewHeight() {
         return 74;
      }

      @Override
      public void drawPreview(class_332 ctx, int x, int y, int w, int h) {
         FxModules.previewBox(ctx, x, y, w, h);
         long t = System.currentTimeMillis() % 1100L;
         float p = Math.min(1.0F, (float)t / 450.0F);
         float k = (float)this.strength.value;
         float s1 = class_3532.method_15374(p * p * (float) Math.PI);
         float s2 = class_3532.method_15374(class_3532.method_15355(p) * (float) Math.PI);
         float ang = 0.0F;
         float dx = 0.0F;
         float dy = 0.0F;
         float sc = 1.0F;
         String modeKey = this.mode.get();
         switch (modeKey) {
            case "vanilla":
               ang = -s2 * 70.0F;
               dx = -s1 * 8.0F;
               dy = -s2 * 4.0F;
               break;
            case "smooth":
               ang = -s2 * 40.0F * k;
               break;
            case "block":
               ang = -20.0F - s2 * 70.0F * k;
               dy = 4.0F + s2 * 4.0F;
               break;
            case "chop":
               ang = -s2 * 110.0F * k;
               dy = s2 * 6.0F;
               break;
            case "stab":
               sc = 1.0F + s2 * 0.45F * k;
               dy = -s2 * 5.0F;
               break;
            case "slide":
               dx = -s2 * 18.0F * k;
               ang = -s2 * 25.0F * k;
               break;
            case "spin":
               ang = -p * 360.0F;
               break;
            case "swank":
               ang = -s2 * 55.0F * k;
               dx = s1 * 8.0F * k;
         }

         Matrix3x2fStack m = ctx.method_51448();
         int cx = x + w / 2;
         int cy = y + h / 2 + 6;
         m.pushMatrix();
         m.translate(cx + dx, cy + dy);
         m.rotate((float)Math.toRadians(ang));
         m.scale(2.4F * sc, 2.4F * sc);
         ctx.method_51427(new class_1799(class_1802.field_8802), -8, -8);
         m.popMatrix();
         R2D.textScaled(
            ctx, this.mode.label(this.mode.index), x + w - 6 - R2D.width(this.mode.label(this.mode.index)) * 0.7F, y + h - 10, 0.7F, R2D.accent(0.0F), false
         );
      }
   }
}
