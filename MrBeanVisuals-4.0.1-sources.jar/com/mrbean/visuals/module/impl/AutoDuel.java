package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Friends;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.LastServer;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_243;
import net.minecraft.class_2558.class_10609;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class AutoDuel extends Module {
   public class_304 key;
   public final Setting.Mode mode = this.add(
      new Setting.Mode(
         "mode",
         "Режим",
         "Mode",
         0,
         "key",
         "По клавише (игрок под прицелом)",
         "On key (aimed player)",
         "auto",
         "Авто: сам вызывает игроков рядом",
         "Auto: challenges nearby players"
      )
   );
   public final Setting.Mode kit = this.add(
      new Setting.Mode(
         "kit",
         "Режим дуэли (кит)",
         "Duel kit",
         0,
         "none",
         "Не выбирать (как в меню сервера)",
         "Don't pick (server default)",
         "Классик",
         "Классика",
         "Classic",
         "Шар",
         "Шары",
         "Balls / Spheres",
         "Тотем",
         "Тотемы",
         "Totems",
         "Незер",
         "Незерит",
         "Netherite",
         "Кристал",
         "Кристаллы",
         "Crystals",
         "Лук",
         "Лук",
         "Bow",
         "Меч",
         "Меч",
         "Sword",
         "custom",
         "Своё слово…",
         "Custom word…"
      )
   );
   public final Setting.Text kitCustom = (Setting.Text)this.add(new Setting.Text("kit_custom", "Слово из названия режима", "Word from kit name", ""))
      .showIf(() -> this.kit.is("custom"));
   public final Setting.Num interval = (Setting.Num)this.add(
         new Setting.Num("interval", "Интервал авто-вызова", "Auto interval", 4.0, 3.0, 60.0, 1.0).suffix(" с")
      )
      .showIf(() -> this.mode.is("auto"));
   public final Setting.Num autoRadius = (Setting.Num)this.add(
         new Setting.Num("auto_radius", "Радиус поиска", "Search radius", 30.0, 5.0, 100.0, 1.0).suffix(" бл")
      )
      .showIf(() -> this.mode.is("auto"));
   public final Setting.Num repeatAfter = (Setting.Num)this.add(
         new Setting.Num("repeat_after", "Повторно тому же игроку через", "Same player again after", 20.0, 5.0, 600.0, 5.0).suffix(" с")
      )
      .showIf(() -> this.mode.is("auto"));
   public final Setting.Text command = this.add(new Setting.Text("command", "Команда", "Command", "/duel {nick}"));
   public final Setting.Text bet = this.add(new Setting.Text("bet", "Ставка (пусто — без ставки)", "Bet (empty — none)", ""));
   public final Setting.Bool autoAccept = this.add(new Setting.Bool("auto_accept", "Принимать вызовы", "Accept challenges", true));
   public final Setting.Bool rematch = this.add(new Setting.Bool("rematch", "Реванш после боя", "Rematch after a fight", false));
   public final Setting.Num rematchDelay = (Setting.Num)this.add(
         new Setting.Num("rematch_delay", "Задержка реванша", "Rematch delay", 5.0, 2.0, 30.0, 1.0).suffix(" с")
      )
      .showIf(() -> this.rematch.value);
   public final Setting.Num range = this.add(new Setting.Num("range", "Дальность прицела", "Aim range", 40.0, 4.0, 100.0, 1.0).suffix(" бл"));
   public final Setting.Bool onlyRw = this.add(new Setting.Bool("only_rw", "Только на ReallyWorld", "Only on ReallyWorld", true));
   public final Setting.Bool hint = this.add(new Setting.Bool("hint", "Подсказка над хотбаром", "Hint above hotbar", true));
   private static final Pattern ACCEPT = Pattern.compile("/duels?\\s+accept\\s+([A-Za-z0-9_]{3,16})", 2);
   private static final Pattern WIN = Pattern.compile("Игрок\\s+([A-Za-z0-9_]{3,16})\\s+победил\\s+игрока\\s+([A-Za-z0-9_]{3,16})", 2);
   private static final Pattern ACCEPTED = Pattern.compile("Игрок\\s+([A-Za-z0-9_]{3,16})\\s+принял\\s+ваш\\s+запрос", 2);
   private final Map<String, Long> asked = new HashMap<>();
   private boolean inDuel;
   private long inDuelSince;
   private long nextAuto;
   private long lastSent;
   private String lastOpponent;
   private long rematchAt;
   private String pendingAccept;
   private long acceptAt;
   private String aimed;
   private boolean kitPicked;
   private long menuSeen;

   String kitWord() {
      return this.kit.is("custom") ? (this.kitCustom.value == null ? "" : this.kitCustom.value.trim()) : (this.kit.is("none") ? "" : this.kit.get());
   }

   private void pickKit(long now) {
      String w = this.kitWord().toLowerCase();
      if (!w.isEmpty() && !this.kitPicked && now - this.lastSent <= 6000L) {
         if (!(mc.field_1755 instanceof class_465<?> hs && mc.field_1761 != null)) {
            this.menuSeen = 0L;
         } else if (this.menuSeen == 0L) {
            this.menuSeen = now;
         } else if (now - this.menuSeen >= 250L) {
            class_1703 h = hs.method_17577();

            for (class_1735 slot : h.field_7761) {
               if (slot.field_7871 != mc.field_1724.method_31548() && slot.method_7681()) {
                  String name = slot.method_7677().method_7964().getString().toLowerCase();
                  if (name.contains(w)) {
                     String shown = slot.method_7677().method_7964().getString();
                     mc.field_1761.method_2906(h.field_7763, slot.field_7874, 0, class_1713.field_7790, mc.field_1724);
                     this.kitPicked = true;
                     Notifications.push(Lang.t("Режим выбран: ", "Kit selected: ") + shown, true);
                     return;
                  }
               }
            }

            if (now - this.menuSeen > 1500L) {
               this.kitPicked = true;
               Notifications.push(
                  Lang.t("В меню нет режима со словом «", "No kit containing «")
                     + this.kitWord()
                     + Lang.t("» — выберите «Своё слово»", "» — use «Custom word»"),
                  false
               );
            }
         }
      }
   }

   public AutoDuel() {
      super(
         "auto_duel",
         Category.UTILITIES,
         false,
         "Auto Duel",
         "Auto Duel",
         "ReallyWorld: вызов /duel по клавише или автоматически игрокам рядом, приём вызовов и реванш",
         "ReallyWorld only: /duel the player you aim at, accept challenges and rematch"
      );
   }

   private boolean allowedHere() {
      if (mc.method_1562() == null || mc.field_1724 == null) {
         return false;
      } else if (!this.onlyRw.value) {
         return true;
      } else {
         String a = LastServer.currentAddress(mc);
         return a.contains("reallyworld");
      }
   }

   private class_1657 target() {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         class_243 eye = mc.field_1724.method_33571();
         class_243 look = mc.field_1724.method_5828(1.0F);
         class_1657 best = null;
         double bestDot = Math.cos(Math.toRadians(5.0));

         for (class_1657 p : mc.field_1687.method_18456()) {
            if (p != mc.field_1724 && !p.method_7325() && !p.method_5767() && !Friends.is(p.method_7334().name())) {
               class_243 to = p.method_5829().method_1005().method_1020(eye);
               double d = to.method_1033();
               if (!(d > this.range.value) && !(d < 0.5)) {
                  double dot = to.method_1029().method_1026(look);
                  if (dot > bestDot && mc.field_1724.method_6057(p)) {
                     bestDot = dot;
                     best = p;
                  }
               }
            }
         }

         return best;
      } else {
         return null;
      }
   }

   public void challenge(String nick) {
      if (nick != null && nick.matches("[A-Za-z0-9_]{3,16}")) {
         long now = System.currentTimeMillis();
         if (now - this.lastSent >= 1000L) {
            String cmd = this.command.value != null && !this.command.value.isBlank() ? this.command.value : "/duel {nick}";
            String b = this.bet.value == null ? "" : this.bet.value.trim().replaceAll("[^0-9kKmMкКмМ.]", "");
            cmd = cmd.replace("{nick}", nick).replace("{bet}", b).replace("{kit}", this.kitWord());
            if (!this.command.value.contains("{bet}") && !b.isEmpty()) {
               cmd = cmd + " " + b;
            }

            cmd = cmd.trim();
            if (cmd.startsWith("/")) {
               cmd = cmd.substring(1);
            }

            mc.method_1562().method_45730(cmd);
            this.lastSent = now;
            this.lastOpponent = nick;
            this.asked.put(nick.toLowerCase(), now);
            this.kitPicked = false;
            Notifications.push(Lang.t("Вызов на дуэль: ", "Duel request: ") + nick, true);
         }
      }
   }

   @Override
   public void onTick() {
      if (!this.allowedHere()) {
         this.aimed = null;
         if (this.key != null) {
            while (this.key.method_1436()) {
               if (mc.field_1724 != null && mc.field_1755 == null) {
                  Notifications.push(Lang.t("Auto Duel работает только на ReallyWorld", "Auto Duel works on ReallyWorld only"), false);
               }
            }
         }
      } else {
         class_1657 t = this.target();
         this.aimed = t == null ? null : t.method_7334().name();
         if (this.key != null) {
            while (this.key.method_1436()) {
               if (mc.field_1755 == null) {
                  if (this.aimed != null) {
                     this.challenge(this.aimed);
                  } else {
                     Notifications.push(Lang.t("Наведитесь на игрока", "Aim at a player"), false);
                  }
               }
            }
         }

         long now = System.currentTimeMillis();
         this.pickKit(now);
         if (this.inDuel && now - this.inDuelSince > 300000L) {
            this.inDuel = false;
         }

         if (this.mode.is("auto") && !this.inDuel && now >= this.nextAuto && mc.field_1755 == null && this.pendingAccept == null) {
            this.nextAuto = now + (long)(this.interval.value * 1000.0);
            class_1657 best = null;
            double bd = this.autoRadius.value * this.autoRadius.value;

            for (class_1657 p : mc.field_1687.method_18456()) {
               if (p != mc.field_1724 && !p.method_7325() && !p.method_5767()) {
                  String n = p.method_7334().name();
                  if (n.matches("[A-Za-z0-9_]{3,16}") && !Friends.is(n)) {
                     Long t0 = this.asked.get(n.toLowerCase());
                     if (t0 == null || !(now - t0 < this.repeatAfter.value * 1000.0)) {
                        double d = p.method_5858(mc.field_1724);
                        if (d < bd) {
                           bd = d;
                           best = p;
                        }
                     }
                  }
               }
            }

            if (best != null) {
               this.challenge(best.method_7334().name());
            }
         }

         if (this.pendingAccept != null && now >= this.acceptAt) {
            mc.method_1562().method_45730(this.pendingAccept);
            Notifications.push(Lang.t("Дуэль принята", "Duel accepted"), true);
            this.pendingAccept = null;
         }

         if (this.rematchAt > 0L && now >= this.rematchAt) {
            this.rematchAt = 0L;
            if (this.rematch.value && this.lastOpponent != null) {
               this.challenge(this.lastOpponent);
            }
         }
      }
   }

   public void onMessage(class_2561 message) {
      if (this.isEnabled() && this.allowedHere()) {
         String plain = message.getString();
         if (this.autoAccept.value && this.pendingAccept == null) {
            String[] found = new String[]{null};
            message.method_27658((style, s) -> {
               if (style.method_10970() instanceof class_10609 rc && ACCEPT.matcher(rc.comp_3506()).find()) {
                  found[0] = rc.comp_3506();
               }

               return Optional.empty();
            }, class_2583.field_24360);
            if (found[0] == null) {
               Matcher mm = ACCEPT.matcher(plain);
               if (mm.find()) {
                  found[0] = mm.group(0);
               }
            }

            if (found[0] != null) {
               Matcher mm = ACCEPT.matcher(found[0]);
               if (mm.find()) {
                  this.lastOpponent = mm.group(1);
               }

               this.pendingAccept = found[0].startsWith("/") ? found[0].substring(1) : found[0];
               this.acceptAt = System.currentTimeMillis() + 300L;
            }
         }

         String me = mc.field_1724 == null ? "" : mc.field_1724.method_7334().name();
         Matcher acc = ACCEPTED.matcher(plain);
         if (acc.find()) {
            this.inDuel = true;
            this.inDuelSince = System.currentTimeMillis();
            this.lastOpponent = acc.group(1);
         }

         Matcher win = WIN.matcher(plain);
         if (win.find() && (win.group(1).equalsIgnoreCase(me) || win.group(2).equalsIgnoreCase(me))) {
            this.inDuel = false;
            String opp = win.group(1).equalsIgnoreCase(me) ? win.group(2) : win.group(1);
            this.lastOpponent = opp;
            this.nextAuto = System.currentTimeMillis() + (long)(this.interval.value * 1000.0);
            if (this.rematch.value) {
               this.rematchAt = System.currentTimeMillis() + (long)(this.rematchDelay.value * 1000.0);
            }
         }

         if (plain.contains("Этот игрок не найден") && this.lastOpponent != null) {
            this.asked.put(this.lastOpponent.toLowerCase(), System.currentTimeMillis());
         }
      }
   }

   @Override
   public void renderOverlay(class_332 ctx, float delta) {
      if (this.hint.value && this.mode.is("auto") && mc.field_1755 == null && this.allowedHere()) {
         long left = Math.max(0L, this.nextAuto - System.currentTimeMillis()) / 1000L;
         String s = "⚔ Auto Duel: "
            + (this.inDuel ? Lang.t("в бою", "in a duel") : Lang.t("следующий вызов через ", "next challenge in ") + left + Lang.t("с", "s"));
         int w = R2D.width(s) + 12;
         int x = ctx.method_51421() / 2 - w / 2;
         int y = ctx.method_51443() - 72;
         R2D.round(ctx, x, y, w, 14, 7, -1879048192);
         R2D.text(ctx, s, x + 6, y + 3, R2D.accent(0.0F), false);
      } else if (this.hint.value && mc.field_1755 == null && this.aimed != null && this.key != null) {
         String k = this.key.method_16007().getString();
         String s = "⚔ " + Lang.t("Дуэль: ", "Duel: ") + this.aimed + "  [" + k + "]";
         int w = R2D.width(s) + 12;
         int x = ctx.method_51421() / 2 - w / 2;
         int y = ctx.method_51443() - 72;
         R2D.round(ctx, x, y, w, 14, 7, -1879048192);
         R2D.text(ctx, s, x + 6, y + 3, R2D.accent(0.0F), false);
      }
   }
}
