package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;

public final class WorldModules {
   private WorldModules() {
   }

   public static void registerAll() {
      Modules.reg(new WorldModules.TimeChanger());
      Modules.reg(new WorldModules.Weather());
      Modules.reg(new WorldModules.SkyColor());
      Modules.reg(new WorldModules.Stars());
      Modules.reg(new WorldModules.SunMoon());
      Modules.reg(new WorldModules.Fog());
      Modules.reg(new WorldModules.Clouds());
      Modules.reg(new WorldModules.BiomeColorMod());
   }

   public static class BiomeColorMod extends Module {
      public final Setting.Bool grass = this.add(new Setting.Bool("grass", "Трава", "Grass", true));
      public final Setting.Color grassColor = (Setting.Color)this.add(new Setting.Color("grass_color", "Цвет травы", "Grass color", -10759333))
         .showIf(() -> this.grass.value);
      public final Setting.Bool foliage = this.add(new Setting.Bool("foliage", "Листва", "Foliage", true));
      public final Setting.Color foliageColor = (Setting.Color)this.add(new Setting.Color("foliage_color", "Цвет листвы", "Foliage color", -12599446))
         .showIf(() -> this.foliage.value);
      public final Setting.Bool water = this.add(new Setting.Bool("water", "Вода", "Water", false));
      public final Setting.Color waterColor = (Setting.Color)this.add(new Setting.Color("water_color", "Цвет воды", "Water color", -13712155))
         .showIf(() -> this.water.value);
      public final Setting.Num blend = this.add(new Setting.Num("blend", "Сила", "Strength", 60.0, 5.0, 100.0, 5.0).suffix("%"));
      private String lastState = "";

      public BiomeColorMod() {
         super(
            "biome_colors",
            Category.WORLD,
            false,
            "Цвета травы и воды",
            "Grass, Foliage & Water Colors",
            "Свои цвета травы, листвы и воды",
            "Custom grass, foliage and water colors"
         );
      }

      public int mix(int vanilla, int custom) {
         return R2D.lerp(vanilla | 0xFF000000, custom | 0xFF000000, this.blend.f() / 100.0F);
      }

      private String state() {
         return ""
            + this.isEnabled()
            + this.grass.value
            + this.grassColor.argb
            + this.foliage.value
            + this.foliageColor.argb
            + this.water.value
            + this.waterColor.argb
            + this.blend.value;
      }

      @Override
      public void onTick() {
         this.checkReload();
      }

      @Override
      public void onDisable() {
         this.checkReload();
      }

      @Override
      public void onEnable() {
         this.checkReload();
      }

      public void checkReload() {
         String s = this.state();
         if (!s.equals(this.lastState)) {
            boolean first = this.lastState.isEmpty();
            this.lastState = s;
            if (!first && mc.field_1769 != null && mc.field_1687 != null) {
               mc.field_1769.method_3279();
            }
         }
      }
   }

   public static class Clouds extends Module {
      public final Setting.Bool hide = this.add(new Setting.Bool("hide", "Скрыть облака", "Hide clouds", false));
      public final Setting.Bool customColor = (Setting.Bool)this.add(new Setting.Bool("custom_color", "Свой цвет", "Custom color", true))
         .showIf(() -> !this.hide.value);
      public final Setting.Color color = (Setting.Color)this.add(new Setting.Color("color", "Цвет облаков", "Cloud color", -6926))
         .showIf(() -> !this.hide.value && this.customColor.value);
      public final Setting.Num height = (Setting.Num)this.add(new Setting.Num("height", "Высота", "Height", 192.0, 100.0, 320.0, 4.0))
         .showIf(() -> !this.hide.value);

      public Clouds() {
         super("clouds", Category.WORLD, false, "Облака", "Custom Clouds", "Цвет и высота облаков", "Cloud color and height");
      }
   }

   public static class Fog extends Module {
      public final Setting.Bool noFog = this.add(new Setting.Bool("no_fog", "Убрать туман", "Remove fog", false));
      public final Setting.Num distance = (Setting.Num)this.add(
            new Setting.Num("distance", "Дальность тумана", "Fog distance", 100.0, 20.0, 300.0, 5.0).suffix("%")
         )
         .showIf(() -> !this.noFog.value);
      public final Setting.Bool customColor = this.add(new Setting.Bool("custom_color", "Свой цвет тумана", "Custom fog color", false));
      public final Setting.Color color = (Setting.Color)this.add(new Setting.Color("color", "Цвет тумана", "Fog color", -6372097))
         .showIf(() -> this.customColor.value);
      public final Setting.Bool themeColor = (Setting.Bool)this.add(new Setting.Bool("theme_color", "Взять цвет темы", "Use theme color", false))
         .showIf(() -> this.customColor.value);

      public Fog() {
         super("fog", Category.WORLD, false, "Туман", "Fog", "Цвет и плотность тумана", "Fog color and density");
      }

      public float mul() {
         return this.noFog.value ? 20.0F : this.distance.f() / 100.0F;
      }

      public int col() {
         return this.themeColor.value ? R2D.lerp(Modules.theme().accent(0.0F), -6372097, 0.5F) : this.color.argb;
      }
   }

   public static class SkyColor extends Module {
      public final Setting.Mode mode = this.add(
         new Setting.Mode("mode", "Режим", "Mode", 0, "theme", "Цвет темы", "Theme", "custom", "Свой цвет", "Custom", "rainbow", "Радужное небо", "Rainbow sky")
      );
      public final Setting.Color color = (Setting.Color)this.add(new Setting.Color("color", "Цвет неба", "Sky color", -9459457))
         .showIf(() -> this.mode.is("custom"));
      public final Setting.Num blend = this.add(new Setting.Num("blend", "Сила", "Strength", 60.0, 5.0, 100.0, 5.0).suffix("%"));
      public final Setting.Bool sunset = this.add(new Setting.Bool("sunset", "Красить закат", "Tint sunset", true));

      public SkyColor() {
         super(
            "sky_color",
            Category.WORLD,
            false,
            "Цвет неба",
            "Custom Sky Colors",
            "Своё небо: цвет темы, свой или радуга",
            "Custom sky: theme, custom or rainbow"
         );
      }

      public int apply(int vanilla) {
         String var3 = this.mode.get();

         int c = switch (var3) {
            case "custom" -> this.color.argb;
            case "rainbow" -> R2D.hsv((float)(System.currentTimeMillis() % 60000L / 60000.0), 0.45F, 1.0F);
            default -> R2D.lerp(Modules.theme().accent(0.0F), -7420417, 0.45F);
         };
         return R2D.lerp(vanilla | 0xFF000000, c | 0xFF000000, this.blend.f() / 100.0F);
      }
   }

   public static class Stars extends Module {
      public final Setting.Num brightness = this.add(new Setting.Num("brightness", "Яркость звёзд", "Star brightness", 150.0, 0.0, 300.0, 10.0).suffix("%"));
      public final Setting.Bool always = this.add(new Setting.Bool("always", "Звёзды и днём", "Stars during the day", false));

      public Stars() {
         super("stars", Category.WORLD, false, "Звёзды", "Star Brightness", "Яркость звёзд на небе", "Star brightness in the sky");
      }
   }

   public static class SunMoon extends Module {
      public final Setting.Num sunSize = this.add(new Setting.Num("sun_size", "Размер солнца", "Sun size", 100.0, 0.0, 300.0, 10.0).suffix("%"));
      public final Setting.Num moonSize = this.add(new Setting.Num("moon_size", "Размер луны", "Moon size", 100.0, 0.0, 300.0, 10.0).suffix("%"));

      public SunMoon() {
         super("sun_moon", Category.WORLD, false, "Солнце и луна", "Custom Sun & Moon", "Размер солнца и луны (0% — скрыть)", "Sun and moon size (0% hides)");
      }
   }

   public static class TimeChanger extends Module {
      public final Setting.Mode mode = this.add(
         new Setting.Mode("mode", "Режим", "Mode", 0, "fixed", "Фиксированное время", "Fixed time", "cycle", "Свой цикл", "Custom cycle")
      );
      public final Setting.Mode time = (Setting.Mode)this.add(
            new Setting.Mode(
               "time",
               "Время",
               "Time",
               0,
               "day",
               "День",
               "Day",
               "sunset",
               "Закат",
               "Sunset",
               "night",
               "Ночь",
               "Night",
               "sunrise",
               "Рассвет",
               "Sunrise",
               "midnight",
               "Полночь",
               "Midnight"
            )
         )
         .showIf(() -> this.mode.is("fixed"));
      public final Setting.Num cycleSpeed = (Setting.Num)this.add(
            new Setting.Num("cycle_speed", "Скорость цикла", "Cycle speed", 10.0, 1.0, 100.0, 1.0).suffix("x")
         )
         .showIf(() -> this.mode.is("cycle"));

      public TimeChanger() {
         super(
            "time_changer", Category.WORLD, false, "Время суток", "Time Appearance", "Своё время суток (только визуально)", "Custom time of day (visual only)"
         );
      }

      public long timeOfDay(long real) {
         if (this.mode.is("cycle")) {
            return (long)(System.currentTimeMillis() / 50.0 * this.cycleSpeed.value % 24000.0);
         } else {
            String var3 = this.time.get();

            return switch (var3) {
               case "sunset" -> 12500L;
               case "night" -> 15000L;
               case "sunrise" -> 23300L;
               case "midnight" -> 18000L;
               default -> 6000L;
            };
         }
      }
   }

   public static class Weather extends Module {
      public final Setting.Mode mode = this.add(
         new Setting.Mode("mode", "Погода", "Weather", 0, "clear", "Ясно", "Clear", "rain", "Дождь", "Rain", "thunder", "Гроза", "Thunder")
      );

      public Weather() {
         super("weather", Category.WORLD, false, "Погода", "Weather Appearance", "Своя погода на экране (сервер не меняется)", "Client-side weather appearance");
      }

      public float rain() {
         return this.mode.is("clear") ? 0.0F : 1.0F;
      }

      public float thunder() {
         return this.mode.is("thunder") ? 1.0F : 0.0F;
      }
   }
}
