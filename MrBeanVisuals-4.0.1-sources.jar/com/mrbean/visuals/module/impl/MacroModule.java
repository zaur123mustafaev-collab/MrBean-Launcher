package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Setting;
import java.util.ArrayDeque;
import net.minecraft.class_304;

public class MacroModule extends Module {
   public static final int SLOTS = 6;
   public final Setting.Text[] commands = new Setting.Text[6];
   public final class_304[] keys = new class_304[6];
   private final Setting.Num delay = this.add(new Setting.Num("delay", "Задержка между командами", "Delay between commands", 10.0, 2.0, 60.0, 1.0).suffix(" т"));
   private final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление", "Notification", true));
   private final ArrayDeque<String> queue = new ArrayDeque<>();
   private int wait;
   private long lastRun;

   public MacroModule() {
      super(
         "macros",
         Category.UTILITIES,
         true,
         "Макросы",
         "Macros",
         "Команды и сообщения на клавиши (клавиши — в «Управлении»)",
         "Commands and messages on hotkeys (bind in Controls)"
      );
      String[] defs = new String[]{"/home", "/spawn", "/kit", "/heal", "/fix all", "gg"};

      for (int i = 0; i < 6; i++) {
         this.commands[i] = this.add(new Setting.Text("cmd" + (i + 1), "Макрос " + (i + 1), "Macro " + (i + 1), defs[i]));
      }
   }

   @Override
   public boolean showInArray() {
      return false;
   }

   @Override
   public void onTick() {
      if (mc.field_1724 != null && mc.method_1562() != null) {
         for (int i = 0; i < 6; i++) {
            if (this.keys[i] != null) {
               while (this.keys[i].method_1436()) {
                  if (mc.field_1755 == null && System.currentTimeMillis() - this.lastRun >= 400L) {
                     this.lastRun = System.currentTimeMillis();
                     this.run(i);
                  }
               }
            }
         }

         if (this.wait > 0) {
            this.wait--;
         } else {
            String next = this.queue.poll();
            if (next != null) {
               if (next.startsWith("/")) {
                  mc.method_1562().method_45730(next.substring(1));
               } else {
                  mc.method_1562().method_45729(next);
               }

               this.wait = this.delay.i();
            }
         }
      } else {
         this.queue.clear();
      }
   }

   public void run(int slot) {
      String cmd = this.commands[slot].value;
      if (cmd != null && !cmd.isBlank()) {
         for (String part : cmd.split(";")) {
            if (!part.trim().isEmpty()) {
               this.queue.add(part.trim());
            }
         }

         if (this.notify.value) {
            Notifications.push(Lang.t("Макрос ", "Macro ") + (slot + 1) + ": " + cmd, true);
         }
      }
   }
}
