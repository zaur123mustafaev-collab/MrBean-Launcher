package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Mobile;

public class ThemeModule extends Module {
   public final Setting.Mode preset = this.add(
      new Setting.Mode(
         "preset",
         "Пресет",
         "Preset",
         0,
         "emerald",
         "Изумрудный",
         "Emerald Green",
         "purple",
         "Полночный фиолетовый",
         "Midnight Purple",
         "ocean",
         "Океан",
         "Ocean Blue",
         "cherry",
         "Вишнёвый",
         "Cherry Pink",
         "sunset",
         "Закат",
         "Sunset Orange",
         "amoled",
         "Тёмный AMOLED",
         "Dark AMOLED",
         "rgb",
         "RGB динамический",
         "RGB Dynamic",
         "custom",
         "Свой",
         "Custom"
      )
   );
   public final Setting.Color custom1 = (Setting.Color)this.add(new Setting.Color("custom1", "Свой цвет 1", "Custom color 1", -8591812))
      .showIf(() -> this.preset.is("custom"));
   public final Setting.Color custom2 = (Setting.Color)this.add(new Setting.Color("custom2", "Свой цвет 2", "Custom color 2", -598458))
      .showIf(() -> this.preset.is("custom"));
   public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость градиента", "Gradient speed", 1.0, 0.0, 4.0, 0.1));
   public final Setting.Num bgAlpha = this.add(new Setting.Num("bg_alpha", "Прозрачность панелей", "Panel opacity", 85.0, 30.0, 100.0, 1.0).suffix("%"));
   public final Setting.Bool blur = this.add(new Setting.Bool("blur", "Размытие фона в меню", "Menu background blur", true));
   public final Setting.Bool shadows = this.add(new Setting.Bool("shadows", "Мягкие тени", "Soft shadows", true));
   public final Setting.Bool animations = this.add(new Setting.Bool("animations", "Анимации интерфейса", "UI animations", true));
   public final Setting.Bool sounds = this.add(new Setting.Bool("sounds", "Звуки интерфейса", "UI sounds", true));
   public final Setting.Num soundVolume = (Setting.Num)this.add(
         new Setting.Num("sound_volume", "Громкость звуков", "Sound volume", 60.0, 0.0, 100.0, 5.0).suffix("%")
      )
      .showIf(() -> this.sounds.value);
   public final Setting.Mode menuStyle = this.add(
      new Setting.Mode("menu_style", "Вид меню", "Menu style", 0, "modern", "Новый (карточки)", "Modern (cards)", "classic", "Классический", "Classic")
   );
   public final Setting.Bool mobileShaders = (Setting.Bool)this.add(
         new Setting.Bool("mobile_shaders", "Шейдеры на телефоне (могут не работать)", "Shaders on phone (may not work)", false)
      )
      .showIf(Mobile::is);
   public final Setting.Num mobileItem = (Setting.Num)this.add(
         new Setting.Num("mobile_item", "Телефон: размер предмета в руке", "Phone: held item size", 65.0, 30.0, 100.0, 5.0).suffix("%")
      )
      .showIf(Mobile::is);
   public final Setting.Num mobileHud = (Setting.Num)this.add(
         new Setting.Num("mobile_hud", "Телефон: размер HUD и надписей", "Phone: HUD and text size", 70.0, 40.0, 100.0, 5.0).suffix("%")
      )
      .showIf(Mobile::is);
   public final Setting.Num mobileMenu = (Setting.Num)this.add(
         new Setting.Num("mobile_menu", "Телефон: размер меню", "Phone: menu size", 80.0, 50.0, 100.0, 5.0).suffix("%")
      )
      .showIf(Mobile::is);
   public final Setting.Bool menuButton = this.add(new Setting.Bool("menu_button", "Кнопка MrBean в меню паузы", "MrBean button in pause menu", true));
   public final Setting.Num guiScale = this.add(new Setting.Num("gui_scale", "Масштаб меню", "Menu scale", 100.0, 70.0, 140.0, 5.0).suffix("%"));
   private static final int[][] P = new int[][]{
      {-13703779, -6557078, -15854574},
      {-7643914, -2537745, -15659494},
      {-14501648, -12877066, -15986151},
      {-41054, -25911, -15200748},
      {-34280, -16051, -15265524},
      {-1, -6511697, -16777216},
      {-65536, -16711936, -15921644},
      {0, 0, -15855851}
   };

   public ThemeModule() {
      super("theme", Category.THEMES, true, "Тема оформления", "Theme", "Цвета интерфейса, HUD и эффектов", "Colors for the UI, HUD and effects");
   }

   @Override
   public boolean toggleable() {
      return false;
   }

   @Override
   public void setEnabled(boolean e) {
      super.setEnabled(true);
   }

   @Override
   public boolean showInArray() {
      return false;
   }

   private double time() {
      return !this.animations.value ? 0.0 : System.currentTimeMillis() % 1000000L / 1000.0 * this.speed.value * 0.3;
   }

   public int c1() {
      return this.preset.is("custom") ? this.custom1.argb | 0xFF000000 : P[this.preset.index][0];
   }

   public int c2() {
      return this.preset.is("custom") ? this.custom2.argb | 0xFF000000 : P[this.preset.index][1];
   }

   public int accent(float offset) {
      double t = this.time() + offset;
      if (this.preset.is("rgb")) {
         return R2D.hsv((float)(t % 1.0 + 1.0) % 1.0F, 0.7F, 1.0F);
      } else {
         float f = (float)((Math.sin(t * Math.PI * 2.0) + 1.0) / 2.0);
         return R2D.lerp(this.c1(), this.c2(), f);
      }
   }

   public int accentStatic() {
      return this.preset.is("rgb") ? this.accent(0.0F) : this.c1();
   }

   public int background() {
      int base = P[this.preset.index][2];
      return R2D.withAlpha(base, (int)(this.bgAlpha.value / 100.0 * 255.0));
   }

   public int panel() {
      return R2D.withAlpha(R2D.lerp(P[this.preset.index][2], -14013126, 0.35F), (int)(this.bgAlpha.value / 100.0 * 240.0));
   }

   public int panelHover() {
      return R2D.withAlpha(R2D.lerp(P[this.preset.index][2], -12960176, 0.5F), (int)(this.bgAlpha.value / 100.0 * 250.0));
   }
}
