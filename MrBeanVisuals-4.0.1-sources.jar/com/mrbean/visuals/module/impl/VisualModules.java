package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Previewable;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import org.joml.Matrix3x2fStack;

public final class VisualModules {
   private VisualModules() {
   }

   public static void registerAll() {
      Modules.reg(new VisualModules.Fullbright());
      Modules.reg(new VisualModules.Zoom());
      Modules.reg(new VisualModules.ColorGrade());
      Modules.reg(new VisualModules.Vignette());
      Modules.reg(new VisualModules.Bloom());
      Modules.reg(new VisualModules.MotionBlur());
      Modules.reg(new VisualModules.DepthOfField());
      Modules.reg(new VisualModules.NoHurtCam());
      Modules.reg(new VisualModules.NoBob());
      Modules.reg(new VisualModules.LowFire());
      Modules.reg(new VisualModules.StaticFov());
      Modules.reg(new VisualModules.HideScoreboard());
      Modules.reg(new VisualModules.CustomHotbar());
      Modules.reg(new VisualModules.CustomBars());
      Modules.reg(new VisualModules.BossBarStyle());
      Modules.reg(new VisualModules.CustomTooltip());
      Modules.reg(new VisualModules.SmoothChat());
      Modules.reg(new VisualModules.Crosshair());
      Modules.reg(new VisualModules.CooldownIndicator());
      Modules.reg(new VisualModules.HitMarker());
      Modules.reg(new VisualModules.Warnings());
   }

   public static <T extends Module> T get(String id, Class<T> c) {
      Module m = Modules.get(id);
      return c.isInstance(m) && m.isEnabled() ? c.cast(m) : null;
   }

   public static class Bloom extends Module {
      public final Setting.Num threshold = this.add(new Setting.Num("threshold", "Порог яркости", "Threshold", 60.0, 30.0, 95.0, 5.0).suffix("%"));
      public final Setting.Num intensity = this.add(new Setting.Num("intensity", "Сила свечения", "Intensity", 120.0, 10.0, 200.0, 10.0).suffix("%"));

      public Bloom() {
         super(
            "bloom",
            Category.VISUALS,
            false,
            "Свечение (Bloom)",
            "Bloom",
            "Яркие места мягко светятся (шейдер, нагружает видеокарту)",
            "Bright areas glow softly (shader, GPU heavy)"
         );
      }
   }

   public static class BossBarStyle extends Module {
      public final Setting.Num scale = this.add(new Setting.Num("scale", "Размер", "Size", 0.8, 0.4, 1.0, 0.05).suffix("x"));
      public final Setting.Bool hide = this.add(new Setting.Bool("hide", "Скрыть босс-бары", "Hide boss bars", false));

      public BossBarStyle() {
         super("boss_bar", Category.VISUALS, false, "Босс-бар", "Boss Bar", "Компактный или скрытый босс-бар", "Compact or hidden boss bar");
      }
   }

   public static class ColorGrade extends Module {
      public final Setting.Mode preset = this.add(
         new Setting.Mode(
            "preset",
            "Пресет",
            "Preset",
            0,
            "custom",
            "Свой",
            "Custom",
            "vivid",
            "Яркие цвета",
            "Vivid",
            "cinema",
            "Кино",
            "Cinematic",
            "warm",
            "Тёплый",
            "Warm",
            "cold",
            "Холодный",
            "Cold",
            "mono",
            "Чёрно-белый",
            "Black & White",
            "vintage",
            "Винтаж",
            "Vintage"
         )
      );
      public final Setting.Num saturation = (Setting.Num)this.add(
            new Setting.Num("saturation", "Насыщенность", "Saturation", 120.0, 0.0, 200.0, 5.0).suffix("%")
         )
         .showIf(() -> this.preset.is("custom"));
      public final Setting.Num contrast = (Setting.Num)this.add(new Setting.Num("contrast", "Контраст", "Contrast", 105.0, 50.0, 150.0, 5.0).suffix("%"))
         .showIf(() -> this.preset.is("custom"));
      public final Setting.Num brightness = (Setting.Num)this.add(new Setting.Num("brightness", "Яркость", "Brightness", 100.0, 50.0, 150.0, 5.0).suffix("%"))
         .showIf(() -> this.preset.is("custom"));
      public final Setting.Color tint = (Setting.Color)this.add(new Setting.Color("tint", "Оттенок", "Tint", -1)).showIf(() -> this.preset.is("custom"));
      public final Setting.Num tintAmount = (Setting.Num)this.add(
            new Setting.Num("tint_amount", "Сила оттенка", "Tint strength", 0.0, 0.0, 100.0, 5.0).suffix("%")
         )
         .showIf(() -> this.preset.is("custom"));

      public ColorGrade() {
         super(
            "color_grade",
            Category.VISUALS,
            false,
            "Цветокоррекция",
            "Color Grading",
            "Насыщенность, контраст, яркость и фильтры (шейдер)",
            "Saturation, contrast, brightness and filters (shader)"
         );
      }

      public float[] params() {
         String var1 = this.preset.get();

         return switch (var1) {
            case "vivid" -> new float[]{1.4F, 1.08F, 1.02F, 1.0F, 1.0F, 1.0F, 0.0F};
            case "cinema" -> new float[]{0.9F, 1.18F, 0.97F, 0.35F, 0.75F, 0.85F, 0.18F};
            case "warm" -> new float[]{1.1F, 1.03F, 1.02F, 1.0F, 0.75F, 0.45F, 0.18F};
            case "cold" -> new float[]{1.0F, 1.03F, 1.0F, 0.5F, 0.75F, 1.0F, 0.2F};
            case "mono" -> new float[]{0.0F, 1.1F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F};
            case "vintage" -> new float[]{0.6F, 0.95F, 1.03F, 1.0F, 0.85F, 0.6F, 0.3F};
            default -> new float[]{
               this.saturation.f() / 100.0F,
               this.contrast.f() / 100.0F,
               this.brightness.f() / 100.0F,
               (this.tint.argb >> 16 & 0xFF) / 255.0F,
               (this.tint.argb >> 8 & 0xFF) / 255.0F,
               (this.tint.argb & 0xFF) / 255.0F,
               this.tintAmount.f() / 100.0F
            };
         };
      }
   }

   public static class CooldownIndicator extends Module {
      final Setting.Mode style = this.add(new Setting.Mode("style", "Вид", "Style", 0, "arc", "Дуга", "Arc", "bar", "Полоска", "Bar"));

      public CooldownIndicator() {
         super("cooldown", Category.HUD, false, "Перезарядка удара", "Attack Cooldown", "Готовность удара под прицелом", "Attack readiness under the crosshair");
      }

      @Override
      public void renderOverlay(class_332 ctx, float d) {
         if (mc.field_1724 != null) {
            float p = mc.field_1724.method_7261(d);
            if (!(p >= 1.0F)) {
               int cx = mc.method_22683().method_4486() / 2;
               int cy = mc.method_22683().method_4502() / 2;
               if (this.style.is("bar")) {
                  R2D.round(ctx, cx - 12, cy + 10, 24, 3, 1, Integer.MIN_VALUE);
                  R2D.round(ctx, cx - 12, cy + 10, Math.max(2, (int)(24.0F * p)), 3, 1, R2D.accent(0.0F));
               } else {
                  for (int i = 0; i < 40.0F * p; i++) {
                     double a = (-Math.PI / 2) + i / 40.0 * Math.PI * 2.0;
                     R2D.rect(ctx, cx + (int)Math.round(Math.cos(a) * 9.0), cy + (int)Math.round(Math.sin(a) * 9.0), 1, 1, R2D.accent(i / 40.0F));
                  }
               }
            }
         }
      }
   }

   public static class Crosshair extends Module implements Previewable {
      public final Setting.Mode style = this.add(
         new Setting.Mode(
            "style",
            "Форма",
            "Shape",
            0,
            "cross",
            "Крест",
            "Cross",
            "dot",
            "Точка",
            "Dot",
            "cross_dot",
            "Крест + точка",
            "Cross + dot",
            "circle",
            "Круг",
            "Circle",
            "circle_dot",
            "Круг + точка",
            "Circle + dot",
            "t",
            "Т-образный",
            "T-shape",
            "x",
            "Косой крест (X)",
            "Diagonal (X)",
            "square",
            "Квадрат",
            "Square",
            "brackets",
            "Скобки [ ]",
            "Brackets",
            "chevron",
            "Уголок ^",
            "Chevron"
         )
      );
      public final Setting.Num size = this.add(new Setting.Num("size", "Длина линий", "Line length", 5.0, 1.0, 16.0, 1.0));
      public final Setting.Num gap = this.add(new Setting.Num("gap", "Зазор", "Gap", 2.0, 0.0, 10.0, 1.0));
      public final Setting.Num thickness = this.add(new Setting.Num("thickness", "Толщина", "Thickness", 1.0, 1.0, 4.0, 1.0));
      public final Setting.Num dotSize = this.add(new Setting.Num("dot_size", "Размер точки", "Dot size", 1.0, 1.0, 4.0, 1.0));
      public final Setting.Num opacity = this.add(new Setting.Num("opacity", "Непрозрачность", "Opacity", 100.0, 20.0, 100.0, 5.0).suffix("%"));
      public final Setting.Num rotation = this.add(new Setting.Num("rotation", "Поворот", "Rotation", 0.0, 0.0, 90.0, 5.0).suffix("°"));
      public final Setting.Bool dynamic = this.add(new Setting.Bool("dynamic", "Динамический (бег/прыжок)", "Dynamic (sprint/jump)", true));
      public final Setting.Bool spin = this.add(new Setting.Bool("spin", "Вращение", "Spin", false));
      public final Setting.Bool themeColor = this.add(new Setting.Bool("theme_color", "Цвет темы", "Theme color", true));
      public final Setting.Bool rainbow = (Setting.Bool)this.add(new Setting.Bool("rainbow", "Радуга", "Rainbow", false)).showIf(() -> !this.themeColor.value);
      public final Setting.Color color = (Setting.Color)this.add(new Setting.Color("color", "Цвет", "Color", -1))
         .showIf(() -> !this.themeColor.value && !this.rainbow.value);
      public final Setting.Bool targetColor = this.add(new Setting.Bool("target_color", "Другой цвет на цели", "Other color on target", true));
      public final Setting.Color targetCol = (Setting.Color)this.add(new Setting.Color("target_col", "Цвет на цели", "Target color", -50373))
         .showIf(() -> this.targetColor.value);
      public final Setting.Bool hitPulse = this.add(new Setting.Bool("hit_pulse", "Расширяется при ударе", "Expands on hit", true));
      public final Setting.Bool outline = this.add(new Setting.Bool("outline", "Обводка", "Outline", true));
      public final Setting.Color outlineCol = (Setting.Color)this.add(
            new Setting.Color("outline_col", "Цвет обводки", "Outline color", -1073741824).withAlpha()
         )
         .showIf(() -> this.outline.value);
      public final Setting.Bool thirdPerson = this.add(new Setting.Bool("third_person", "Показывать от 3-го лица", "Show in third person", false));
      private float dyn;
      private float pulse;
      private long lastHit;

      public Crosshair() {
         super(
            "crosshair",
            Category.HUD,
            false,
            "Свой прицел",
            "Custom Crosshair",
            "Прицел с 10 формами, цветами, обводкой, поворотом и реакцией на удар",
            "Crosshair with 10 shapes, colors, outline, rotation and hit reaction"
         );
      }

      @Override
      public void renderOverlay(class_332 ctx, float d) {
         if (mc.field_1724 != null && !mc.field_1690.field_1842) {
            if (this.thirdPerson.value || mc.field_1690.method_31044().method_31034()) {
               int cx = mc.method_22683().method_4486() / 2;
               int cy = mc.method_22683().method_4502() / 2;
               this.paint(ctx, cx, cy, mc.field_1692 instanceof class_1309, mc.field_1724.method_5624(), !mc.field_1724.method_24828());
            }
         }
      }

      @Override
      public int previewHeight() {
         return 70;
      }

      @Override
      public void drawPreview(class_332 ctx, int x, int y, int w, int h) {
         R2D.round(ctx, x, y, w, h, 6, -12957092);
         R2D.round(ctx, x, y + h / 2, w, h / 2, 6, -11637958);
         R2D.textScaled(ctx, Lang.t("Предпросмотр (каждые 2 с — «на цели»)", "Preview (every 2 s — «on target»)"), x + 6, y + 5, 0.7F, -2038804, false);
         boolean onTarget = System.currentTimeMillis() / 2000L % 2L == 1L;
         Matrix3x2fStack m = ctx.method_51448();
         m.pushMatrix();
         m.translate(x + w / 2.0F, y + h / 2.0F + 4.0F);
         m.scale(2.0F, 2.0F);
         this.paint(ctx, 0, 0, onTarget, false, false);
         m.popMatrix();
      }

      private void paint(class_332 ctx, int cx, int cy, boolean onTarget, boolean sprint, boolean air) {
         int col = this.themeColor.value
            ? R2D.accent(0.0F)
            : (this.rainbow.value ? R2D.hsv((float)(System.currentTimeMillis() % 3000L) / 3000.0F, 0.7F, 1.0F) : this.color.argb | 0xFF000000);
         if (this.targetColor.value && onTarget) {
            col = this.targetCol.argb | 0xFF000000;
         }

         col = R2D.withAlpha(col, (int)(255.0 * this.opacity.value / 100.0));
         int out = R2D.withAlpha(this.outlineCol.argb, (int)((this.outlineCol.argb >>> 24 & 0xFF) * this.opacity.value / 100.0));
         if (this.hitPulse.value && Info.lastHitTime != this.lastHit) {
            this.lastHit = Info.lastHitTime;
            if (System.currentTimeMillis() - this.lastHit < 200L) {
               this.pulse = 3.0F;
            }
         }

         this.pulse = R2D.approach(this.pulse, 0.0F, 0.25F);
         float t = this.dynamic.value ? (sprint ? 2 : 0) + (air ? 2 : 0) : 0.0F;
         this.dyn = R2D.approach(this.dyn, t, 0.3F);
         int s = this.size.i();
         int g = this.gap.i() + Math.round(this.dyn + this.pulse);
         int th = this.thickness.i();
         int ds = this.dotSize.i();
         float rot = (float)this.rotation.value
            + (this.spin.value ? (float)(System.currentTimeMillis() % 4000L) / 4000.0F * 360.0F : 0.0F)
            + (this.style.is("x") ? 45 : 0);
         Matrix3x2fStack m = ctx.method_51448();
         m.pushMatrix();
         m.translate(cx, cy);
         if (rot != 0.0F) {
            m.rotate((float)Math.toRadians(rot));
         }

         String st = this.style.get();
         switch (st) {
            case "dot":
               this.dot(ctx, ds + th - 1, col, out);
               break;
            case "circle":
            case "circle_dot":
               if (this.outline.value) {
                  R2D.ringCircle(ctx, 0, 0, s + g + 1, out);
                  R2D.ringCircle(ctx, 0, 0, s + g - 1, out);
               }

               R2D.ringCircle(ctx, 0, 0, s + g, col);
               if (st.equals("circle_dot")) {
                  this.dot(ctx, ds, col, out);
               }
               break;
            case "square": {
               int r = g + s;
               int[][] q = new int[][]{{-r, -r, 2 * r + th, th}, {-r, r, 2 * r + th, th}, {-r, -r, th, 2 * r + th}, {r, -r, th, 2 * r + th}};
               this.lines(ctx, q, col, out);
               if (ds > 1) {
                  this.dot(ctx, ds - 1, col, out);
               }
               break;
            }
            case "brackets": {
               int r = g + s;
               int l = Math.max(2, s / 2 + 1);
               int[][] q = new int[][]{
                  {-r, -r, th, 2 * r + th}, {-r, -r, l, th}, {-r, r, l, th}, {r, -r, th, 2 * r + th}, {r - l + th, -r, l, th}, {r - l + th, r, l, th}
               };
               this.lines(ctx, q, col, out);
               break;
            }
            case "chevron": {
               int n = s + 1;
               int[][] q = new int[n * 2][];

               for (int i = 0; i < n; i++) {
                  q[i * 2] = new int[]{-i - 1, g + i, th, th};
                  q[i * 2 + 1] = new int[]{i, g + i, th, th};
               }

               this.lines(ctx, q, col, out);
               break;
            }
            default: {
               boolean top = !st.equals("t");
               int h0 = th / 2;
               List<int[]> q = new ArrayList<>(List.of(new int[]{-g - s, -h0, s, th}, new int[]{g + 1, -h0, s, th}, new int[]{-h0, g + 1, th, s}));
               if (top) {
                  q.add(new int[]{-h0, -g - s, th, s});
               }

               this.lines(ctx, q.toArray(new int[0][]), col, out);
               if (st.equals("cross_dot")) {
                  this.dot(ctx, ds, col, out);
               }
            }
         }

         m.popMatrix();
      }

      private void lines(class_332 ctx, int[][] q, int col, int out) {
         if (this.outline.value) {
            for (int[] r : q) {
               R2D.rect(ctx, r[0] - 1, r[1] - 1, r[2] + 2, r[3] + 2, out);
            }
         }

         for (int[] r : q) {
            R2D.rect(ctx, r[0], r[1], r[2], r[3], col);
         }
      }

      private void dot(class_332 ctx, int r, int col, int out) {
         if (this.outline.value) {
            R2D.rect(ctx, -r - 1, -r - 1, r * 2 + 2, r * 2 + 2, out);
         }

         R2D.rect(ctx, -r, -r, r * 2, r * 2, col);
      }
   }

   public static class CustomBars extends Module {
      public final Setting.Bool numbers = this.add(new Setting.Bool("numbers", "Числа на полосках", "Numbers on bars", true));
      public final Setting.Bool xp = this.add(new Setting.Bool("xp", "Своя полоса опыта", "Custom XP bar", true));

      public CustomBars() {
         super(
            "custom_bars",
            Category.VISUALS,
            false,
            "Свои полоски HP/еды/брони",
            "Custom Status Bars",
            "Здоровье, еда, броня, воздух и опыт — аккуратными полосками",
            "Health, food, armor, air and XP as clean bars"
         );
      }

      private void bar(class_332 ctx, int x, int y, int w, float frac, int color, String label) {
         R2D.round(ctx, x, y, w, 7, 3, -1877994984);
         if (frac > 0.0F) {
            R2D.round(ctx, x, y, Math.max(4, (int)(w * Math.min(1.0F, frac))), 7, 3, color);
         }

         if (this.numbers.value) {
            R2D.textScaled(ctx, label, x + w / 2.0F - R2D.width(label) * 0.3F, y + 1, 0.6F, -1, true);
         }
      }

      public void renderStatus(class_332 ctx) {
         class_1657 p = mc.field_1724;
         if (p != null && mc.field_1761 != null && mc.field_1761.method_2908()) {
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();
            int x = sw / 2 - 91;
            int y = sh - 39;
            float hp = p.method_6032();
            float max = p.method_6063();
            float abs = p.method_6067();
            this.bar(ctx, x, y, 88, hp / max, R2D.healthColor(hp / max), String.format("%.0f/%.0f", hp, max) + (abs > 0.0F ? String.format(" +%.0f", abs) : ""));
            if (abs > 0.0F) {
               R2D.round(ctx, x, y + 5, (int)(88.0F * Math.min(1.0F, abs / max)), 2, 1, -11205);
            }

            int food = p.method_7344().method_7586();
            this.bar(ctx, x + 94, y, 88, food / 20.0F, -2056144, food + "/20");
            int armor = p.method_6096();
            if (armor > 0) {
               this.bar(ctx, x, y - 9, 88, armor / 20.0F, -7358242, Lang.t("Броня ", "Armor ") + armor);
            }

            int air = p.method_5669();
            int maxAir = p.method_5748();
            if (air < maxAir) {
               this.bar(ctx, x + 94, y - 9, 88, (float)Math.max(0, air) / maxAir, -11553793, Lang.t("Воздух", "Air"));
            }
         }
      }

      public void renderXp(class_332 ctx) {
         class_1657 p = mc.field_1724;
         if (p != null) {
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();
            int x = sw / 2 - 91;
            int y = sh - 29;
            R2D.round(ctx, x, y, 182, 4, 2, -1877994984);
            R2D.round(ctx, x, y, Math.max(3, (int)(182.0F * p.field_7510)), 4, 2, -8591812);
            if (p.field_7520 > 0) {
               String s = String.valueOf(p.field_7520);
               R2D.text(ctx, s, sw / 2 - R2D.width(s) / 2, y - 9, -8323296, true);
            }
         }
      }
   }

   public static class CustomHotbar extends Module {
      public final Setting.Bool animated = this.add(new Setting.Bool("animated", "Анимация выбора слота", "Animated selection", true));
      public final Setting.Bool numbers = this.add(new Setting.Bool("numbers", "Номера слотов", "Slot numbers", false));
      public final Setting.Num radius = this.add(new Setting.Num("radius", "Скругление", "Corner radius", 4.0, 0.0, 8.0, 1.0));
      public float selX = -1.0F;

      public CustomHotbar() {
         super(
            "custom_hotbar",
            Category.VISUALS,
            false,
            "Свой хотбар",
            "Custom Hotbar",
            "Скруглённый хотбар в цветах темы с плавным выбором",
            "Rounded themed hotbar with smooth selection"
         );
      }

      public void render(class_332 ctx, class_9779 tc) {
         class_1657 p = mc.field_1724;
         if (p != null) {
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();
            int x = sw / 2 - 91;
            int y = sh - 22;
            R2D.panel(ctx, x, y, 182, 22, this.radius.i(), R2D.bg(), true, 0);

            for (int i = 0; i < 9; i++) {
               R2D.round(ctx, x + 2 + i * 20, y + 2, 18, 18, Math.max(0, this.radius.i() - 2), 587202559);
            }

            int sel = p.method_31548().method_67532();
            float target = x + 1 + sel * 20;
            this.selX = !(this.selX < 0.0F) && this.animated.value ? R2D.approach(this.selX, target, 0.45F) : target;
            R2D.round(ctx, (int)this.selX, y + 1, 20, 20, Math.max(0, this.radius.i() - 1), R2D.withAlpha(R2D.accent(0.0F), 90));
            R2D.outline(ctx, (int)this.selX, y + 1, 20, 20, Math.max(0, this.radius.i() - 1), R2D.accent(0.0F));

            for (int i = 0; i < 9; i++) {
               class_1799 st = p.method_31548().method_5438(i);
               int ix = x + 3 + i * 20;
               int iy = y + 3;
               if (!st.method_7960()) {
                  ctx.method_51423(p, st, ix, iy, i + 1);
                  ctx.method_51431(mc.field_1772, st, ix, iy);
               }

               if (this.numbers.value) {
                  R2D.textScaled(ctx, String.valueOf(i + 1), ix - 1, iy - 1, 0.5F, -1593835521, false);
               }
            }

            class_1799 off = p.method_6079();
            if (!off.method_7960()) {
               boolean left = mc.field_1690.method_42552().method_41753() == class_1306.field_6183;
               int ox = left ? x - 26 : x + 186;
               R2D.panel(ctx, ox, y, 22, 22, this.radius.i(), R2D.bg(), true, 0);
               ctx.method_51423(p, off, ox + 3, y + 3, 10);
               ctx.method_51431(mc.field_1772, off, ox + 3, y + 3);
            }
         }
      }
   }

   public static class CustomTooltip extends Module {
      public final Setting.Bool border = this.add(new Setting.Bool("border", "Цветная рамка", "Accent border", true));

      public CustomTooltip() {
         super(
            "custom_tooltip",
            Category.VISUALS,
            true,
            "Свои подсказки",
            "Custom Tooltips",
            "Тёмные скруглённые подсказки предметов",
            "Dark rounded item tooltips"
         );
      }

      public void render(class_332 ctx, int x, int y, int w, int h) {
         R2D.shadow(ctx, x - 3, y - 3, w + 6, h + 6, 6, 1610612736);
         R2D.round(ctx, x - 3, y - 3, w + 6, h + 6, 4, -267382248);
         if (this.border.value) {
            R2D.outline(ctx, x - 3, y - 3, w + 6, h + 6, 4, R2D.withAlpha(R2D.accent(0.0F), 200));
         }
      }
   }

   public static class DepthOfField extends Module {
      public final Setting.Num strength = this.add(new Setting.Num("strength", "Сила", "Strength", 50.0, 10.0, 100.0, 5.0).suffix("%"));
      public final Setting.Num focus = this.add(new Setting.Num("focus", "Дистанция фокуса", "Focus distance", 8.0, 1.0, 64.0, 1.0).suffix(" m"));

      public DepthOfField() {
         super(
            "dof",
            Category.VISUALS,
            false,
            "Глубина резкости",
            "Depth of Field",
            "Размытие далёких объектов (шейдер, нагружает видеокарту)",
            "Blurs distant objects (shader, GPU heavy)"
         );
      }
   }

   public static class Fullbright extends Module {
      public final Setting.Num gamma = this.add(new Setting.Num("gamma", "Яркость", "Brightness", 1600.0, 100.0, 1600.0, 50.0).suffix("%"));
      public final Setting.Bool smooth = this.add(
         new Setting.Bool("smooth", "Плавная смена яркости", "Fade brightness smoothly", true)
      );
      /** Гамма, которую сейчас видит LightmapMixin; -1 — ещё не считана, ставим без перехода. */
      public double smoothed = -1.0;

      public Fullbright() {
         super(
            "fullbright",
            Category.UTILITIES,
            false,
            "Яркость (гамма)",
            "Fullbright / Gamma",
            "Полный свет во всём мире, видно в темноте. Только у вас на клиенте, для остальных освещение не меняется",
            "Full light everywhere, see in the dark. Client-side only, other players' lighting is untouched"
         );
      }

      @Override
      public void onDisable() {
         if (!this.smooth.value) {
            this.smoothed = -1.0;
         }
      }
   }

   public static class HideScoreboard extends Module {
      public HideScoreboard() {
         super("hide_scoreboard", Category.VISUALS, false, "Скрыть скорборд", "Hide Scoreboard", "Убирает таблицу справа", "Hides the sidebar scoreboard");
      }
   }

   public static class HitMarker extends Module {
      private long last;

      public HitMarker() {
         super("hitmarker", Category.HUD, true, "Хитмаркер", "Hit Marker", "Отметка у прицела при попадании", "Marker near the crosshair on hit");
      }

      public void onHit() {
         this.last = System.currentTimeMillis();
      }

      @Override
      public void renderOverlay(class_332 ctx, float d) {
         long dt = System.currentTimeMillis() - this.last;
         if (dt <= 300L) {
            int a = (int)(255.0F * (1.0F - (float)dt / 300.0F));
            int cx = mc.method_22683().method_4486() / 2;
            int cy = mc.method_22683().method_4502() / 2;
            int c = R2D.withAlpha(-1, a);

            for (int i = 4; i < 9; i++) {
               for (int sx = -1; sx <= 1; sx += 2) {
                  for (int sy = -1; sy <= 1; sy += 2) {
                     R2D.rect(ctx, cx + sx * i, cy + sy * i, 1, 1, c);
                  }
               }
            }
         }
      }
   }

   public static class LowFire extends Module {
      public final Setting.Mode mode = this.add(new Setting.Mode("mode", "Огонь на экране", "Screen fire", 1, "low", "Ниже", "Lower", "hide", "Убрать", "Hide"));
      public final Setting.Num offset = (Setting.Num)this.add(new Setting.Num("offset", "Насколько ниже", "Lower by", 0.3, 0.1, 0.6, 0.05))
         .showIf(() -> this.mode.is("low"));
      public final Setting.Bool entities = this.add(new Setting.Bool("entities", "Убрать огонь на игроках и мобах", "Hide fire on players and mobs", true));
      public final Setting.Bool particles = this.add(new Setting.Bool("particles", "Убрать частицы пламени", "Hide flame particles", true));

      public LowFire() {
         super(
            "low_fire",
            Category.VISUALS,
            true,
            "Без огня (PvP)",
            "No Fire (PvP)",
            "Убирает огонь с экрана, с горящих игроков и мобов и частицы пламени",
            "Removes fire from the screen, burning entities and flame particles"
         );
      }

      public static VisualModules.LowFire get() {
         return Modules.get("low_fire") instanceof VisualModules.LowFire f && f.isEnabled() ? f : null;
      }
   }

   public static class MotionBlur extends Module {
      public final Setting.Num strength = this.add(new Setting.Num("strength", "Сила размытия", "Strength", 50.0, 10.0, 90.0, 5.0).suffix("%"));

      public MotionBlur() {
         super(
            "motion_blur",
            Category.VISUALS,
            false,
            "Размытие в движении",
            "Motion Blur",
            "Смазывание кадра при поворотах (шейдер)",
            "Frame blending when turning (shader)"
         );
      }
   }

   public static class NoBob extends Module {
      public NoBob() {
         super("no_bob", Category.VISUALS, false, "Без покачивания", "No View Bobbing", "Камера не качается при ходьбе", "Camera does not bob while walking");
      }
   }

   public static class NoHurtCam extends Module {
      public NoHurtCam() {
         super(
            "no_hurt_cam", Category.VISUALS, true, "Без тряски урона", "No Hurt Cam", "Убирает тряску камеры при получении урона", "Removes hurt camera shake"
         );
      }
   }

   public static class SmoothChat extends Module {
      public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость", "Speed", 1.0, 0.3, 3.0, 0.1).suffix("x"));
      public float offset;

      public SmoothChat() {
         super("smooth_chat", Category.VISUALS, true, "Плавный чат", "Smooth Chat", "Новые сообщения плавно выезжают", "New messages slide in smoothly");
      }

      public void onMessage() {
         this.offset = 9.0F;
      }

      public void frame() {
         this.offset = Math.max(0.0F, this.offset - 0.6F * this.speed.f() * mc.method_61966().method_60636() * 3.0F);
      }
   }

   public static class StaticFov extends Module {
      public StaticFov() {
         super(
            "static_fov",
            Category.VISUALS,
            false,
            "Стабильный FOV",
            "Static FOV",
            "Угол обзора не меняется от бега и эффектов",
            "FOV does not change from sprinting or effects"
         );
      }
   }

   public static class Vignette extends Module {
      public final Setting.Num strength = this.add(new Setting.Num("strength", "Сила", "Strength", 40.0, 5.0, 100.0, 5.0).suffix("%"));

      public Vignette() {
         super("vignette", Category.VISUALS, false, "Виньетка", "Vignette", "Затемнение по краям экрана (шейдер)", "Darkened screen edges (shader)");
      }
   }

   public static class Warnings extends Module {
      final Setting.Num hp = this.add(new Setting.Num("hp", "Порог HP", "HP threshold", 8.0, 2.0, 16.0, 1.0));
      final Setting.Num dura = this.add(new Setting.Num("durability", "Порог прочности", "Durability threshold", 15.0, 5.0, 50.0, 5.0).suffix("%"));
      final Setting.Bool vignette = this.add(new Setting.Bool("vignette", "Красная рамка", "Red border", true));

      public Warnings() {
         super("warnings", Category.HUD, true, "Предупреждения", "Warnings", "Мало HP, ломается броня или инструмент", "Low HP, breaking armor or tool");
      }

      @Override
      public void renderOverlay(class_332 ctx, float d) {
         class_746 p = mc.field_1724;
         if (p != null && !p.method_68878() && !p.method_7325()) {
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();
            int line = 0;
            if (p.method_6032() <= this.hp.value && !Modules.on(Modules.get("hp_alert"))) {
               float pulse = (float)(Math.sin(System.currentTimeMillis() / 150.0) + 1.0) / 2.0F;
               if (this.vignette.value) {
                  for (int i = 0; i < 10; i++) {
                     int c = R2D.argb((int)((30.0F + 50.0F * pulse) * (10 - i) / 10.0F), 255, 0, 0);
                     R2D.rect(ctx, 0, i * 2, sw, 2, c);
                     R2D.rect(ctx, 0, sh - i * 2 - 2, sw, 2, c);
                     R2D.rect(ctx, i * 2, 0, 2, sh, c);
                     R2D.rect(ctx, sw - i * 2 - 2, 0, 2, sh, c);
                  }
               }

               this.warn(ctx, sw, sh, line++, "⚠ " + Lang.t("МАЛО HP: ", "LOW HP: ") + String.format("%.1f", p.method_6032()), R2D.lerp(-48060, -1, pulse));
            }

            Module var16 = Modules.get("durability_warning");
            boolean own = var16 instanceof Module && var16.isEnabled();
            if (!own) {
               for (class_1304 s : new class_1304[]{
                  class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6173
               }) {
                  class_1799 st = p.method_6118(s);
                  if (!st.method_7960() && st.method_7963()) {
                     float f = 1.0F - (float)st.method_7919() / st.method_7936();
                     if (f * 100.0F <= this.dura.value) {
                        this.warn(
                           ctx,
                           sw,
                           sh,
                           line++,
                           "⚠ " + Lang.t("Ломается: ", "Breaking: ") + st.method_7964().getString() + " " + Math.round(f * 100.0F) + "%",
                           -22016
                        );
                     }
                  }
               }
            }
         }
      }

      private void warn(class_332 ctx, int sw, int sh, int line, String s, int color) {
         int w = R2D.width(s) + 12;
         int x = sw / 2 - w / 2;
         int y = sh / 2 - 50 - line * 16;
         R2D.panel(ctx, x, y, w, 14, 4, R2D.bg(), true, 0);
         R2D.text(ctx, s, sw / 2 - R2D.width(s) / 2, y + 3, color);
      }
   }

   public static class Zoom extends Module {
      public final Setting.Num factor = this.add(new Setting.Num("factor", "Кратность", "Zoom factor", 4.0, 1.5, 15.0, 0.5).suffix("x"));
      public final Setting.Bool smooth = this.add(new Setting.Bool("smooth", "Плавная камера", "Smooth camera", true));
      public final Setting.Bool scroll = this.add(new Setting.Bool("scroll", "Колёсико меняет зум", "Scroll to adjust", true));
      public final Setting.Bool hideHand = this.add(new Setting.Bool("hide_hand", "Прятать руку", "Hide hand", true));
      public double current = 1.0;
      public double scrollMul = 1.0;

      public Zoom() {
         super("zoom", Category.VISUALS, true, "Зум", "Zoom", "Приближение на клавишу C (меняется в «Управлении»)", "Zoom on C (rebind in Controls)");
      }

      @Override
      public boolean showInArray() {
         return false;
      }

      public boolean active() {
         return this.isEnabled() && MrBeanClient.zoomKey != null && MrBeanClient.zoomKey.method_1434() && mc.field_1755 == null;
      }
   }
}
