package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;

public final class AnimationModules {
   private AnimationModules() {
   }

   public static void registerAll() {
      Modules.reg(new AnimationModules.HandView());
      Modules.reg(new AnimationModules.ItemSwitch());
      Modules.reg(new AnimationModules.EatAnimation());
      Modules.reg(new AnimationModules.InventoryAnim());
      Modules.reg(new AnimationModules.SmoothCamera());
   }

   public static class EatAnimation extends Module {
      public final Setting.Mode mode = this.add(
         new Setting.Mode("mode", "Еда и питьё", "Eating", 0, "none", "Без покачивания", "No shaking", "vanilla", "Как в игре", "Vanilla")
      );

      public EatAnimation() {
         super(
            "eat_animation",
            Category.ANIMATIONS,
            false,
            "Анимация еды",
            "Eating Animation",
            "Убирает тряску предмета при еде",
            "Removes item shaking while eating"
         );
      }
   }

   public static class HandView extends Module {
      public final Setting.Num x = this.add(new Setting.Num("x", "Сдвиг X", "Offset X", 0.0, -1.0, 1.0, 0.02));
      public final Setting.Num y = this.add(new Setting.Num("y", "Сдвиг Y", "Offset Y", 0.0, -1.0, 1.0, 0.02));
      public final Setting.Num z = this.add(new Setting.Num("z", "Сдвиг Z", "Offset Z", 0.0, -1.0, 1.0, 0.02));
      public final Setting.Num scale = this.add(new Setting.Num("scale", "Размер", "Scale", 1.0, 0.3, 1.5, 0.05).suffix("x"));
      public final Setting.Num rotX = this.add(new Setting.Num("rot_x", "Наклон", "Pitch", 0.0, -90.0, 90.0, 5.0).suffix("°"));
      public final Setting.Num rotY = this.add(new Setting.Num("rot_y", "Поворот", "Yaw", 0.0, -90.0, 90.0, 5.0).suffix("°"));

      public HandView() {
         super(
            "hand_view",
            Category.ANIMATIONS,
            false,
            "Положение руки",
            "Hand Customization",
            "Положение, размер и поворот предмета в руке",
            "Position, size and rotation of the held item"
         );
      }
   }

   public static class InventoryAnim extends Module {
      public final Setting.Mode style = this.add(
         new Setting.Mode("style", "Стиль", "Style", 0, "scale", "Увеличение", "Scale", "slide", "Выезд снизу", "Slide up", "fade", "Проявление", "Fade")
      );
      public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость", "Speed", 1.0, 0.3, 3.0, 0.1).suffix("x"));
      public long openedAt;

      public InventoryAnim() {
         super(
            "inventory_anim",
            Category.ANIMATIONS,
            true,
            "Анимация инвентаря",
            "Inventory Animation",
            "Плавное открытие сундуков и инвентаря",
            "Smooth container opening"
         );
      }

      public float progress() {
         float t = (float)(System.currentTimeMillis() - this.openedAt) / (220.0F / this.speed.f());
         t = Math.max(0.0F, Math.min(1.0F, t));
         return 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
      }
   }

   public static class ItemSwitch extends Module {
      public final Setting.Mode mode = this.add(
         new Setting.Mode("mode", "Смена предмета", "Item switching", 0, "none", "Без опускания руки", "No hand lowering", "vanilla", "Как в игре", "Vanilla")
      );

      public ItemSwitch() {
         super(
            "item_switch",
            Category.ANIMATIONS,
            false,
            "Анимация смены предмета",
            "Item Switch Animation",
            "Рука не дёргается при смене слота",
            "No hand dip when switching slots"
         );
      }
   }

   public static class SmoothCamera extends Module {
      public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость", "Speed", 1.0, 0.3, 3.0, 0.1).suffix("x"));
      public float factor = 1.0F;
      private boolean lastFirst = true;

      public SmoothCamera() {
         super(
            "smooth_perspective",
            Category.ANIMATIONS,
            true,
            "Плавная смена вида",
            "Smooth Camera Transitions",
            "Камера плавно отъезжает при F5",
            "Camera eases out on F5"
         );
      }

      @Override
      public void onTick() {
         boolean first = mc.field_1690.method_31044().method_31034();
         if (this.lastFirst && !first) {
            this.factor = 0.05F;
         }

         this.lastFirst = first;
      }

      public float frame() {
         this.factor = Math.min(1.0F, this.factor + (1.0F - this.factor) * 0.12F * this.speed.f() * mc.method_61966().method_60636());
         if (this.factor > 0.995F) {
            this.factor = 1.0F;
         }

         return this.factor;
      }
   }
}
