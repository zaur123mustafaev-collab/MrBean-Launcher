package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.net.BadgeNetwork;
import com.mrbean.visuals.render.World3D;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_12249;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_9064;
import org.joml.Matrix4f;

public class PlayerBadge extends Module {
   private static final class_2960 BADGE_TEXTURE = class_2960.method_60655("mrbeanvisuals", "textures/badge.png");
   private static final float LABEL_SCALE = 0.025F;
   private final class_1921 layer = class_12249.method_76022(BADGE_TEXTURE);
   private final Setting.Num size = this.add(new Setting.Num("size", "Размер бейджа", "Badge size", 11.0, 5.0, 30.0, 1.0).suffix("px"));
   private final Setting.Num gap = this.add(new Setting.Num("gap", "Отступ от ника", "Gap to name", 2.0, 0.0, 20.0, 1.0).suffix("px"));
   private final Setting.Num opacity = this.add(
      new Setting.Num("opacity", "Прозрачность", "Opacity", 100.0, 20.0, 100.0, 1.0).suffix("%")
   );

   public PlayerBadge() {
      super(
         "player_badge",
         Category.VISUALS,
         true,
         "Бейдж Visuals",
         "Visuals Badge",
         "Логотип MrBean Visuals рядом с ником проверенных игроков (сервер подтверждает по UUID)",
         "MrBean Visuals logo next to the nametag of server-verified users (UUID based)"
      );
   }

   public void renderWorld(class_4587 ms, class_4598 buf, class_4184 cam, class_243 cameraPos, float tickDelta) {
      if (!this.isEnabled()) {
         return;
      }

      Set<UUID> verified = BadgeNetwork.verified();
      if (verified.isEmpty()) {
         return;
      }

      class_310 mc = class_310.method_1551();
      class_327 tr = mc.field_1772;
      float side = this.size.f() * 0.025F;
      float offset = this.gap.f() * 0.025F;
      int alpha = (int)(255.0F * this.opacity.f() / 100.0F) << 24 | 0xFFFFFF;
      class_4588 vc = buf.method_73477(this.layer);

      for (class_1657 p : mc.field_1687.method_18456()) {
         if (p != mc.field_1724 && !p.method_7325() && verified.contains(p.method_5667()) && !p.method_5756(mc.field_1724)) {
            class_243 anchor = p.method_56072().method_55675(class_9064.field_47745, 0, p.method_61415(tickDelta));
            if (anchor == null) {
               anchor = new class_243(0.0, p.method_17682() + 0.5, 0.0);
            }

            float centerY = -tr.field_2000 * 0.025F / 2.0F;
            float textHalf = tr.method_27525(p.method_5476()) * 0.025F / 2.0F;
            float centerX = -(textHalf + offset + side / 2.0F);
            class_243 pos = p.method_30950(tickDelta).method_1031(anchor.field_1352, anchor.field_1351 + 0.5, anchor.field_1350).method_1020(cameraPos);
            ms.method_22903();
            ms.method_46416((float)pos.field_1352, (float)pos.field_1351, (float)pos.field_1350);
            ms.method_22907(cam.method_23767());
            Matrix4f m = ms.method_23760().method_23761();
            float hw = side / 2.0F;
            World3D.vtxUV(vc, m, centerX - hw, centerY - hw, 0.0F, 0.0F, 1.0F, alpha);
            World3D.vtxUV(vc, m, centerX + hw, centerY - hw, 0.0F, 1.0F, 1.0F, alpha);
            World3D.vtxUV(vc, m, centerX + hw, centerY + hw, 0.0F, 1.0F, 0.0F, alpha);
            World3D.vtxUV(vc, m, centerX - hw, centerY + hw, 0.0F, 0.0F, 0.0F, alpha);
            ms.method_22909();
         }
      }

      buf.method_22994(this.layer);
   }
}
