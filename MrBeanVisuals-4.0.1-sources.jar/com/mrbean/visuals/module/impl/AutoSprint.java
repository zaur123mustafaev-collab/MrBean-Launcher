package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_1294;
import net.minecraft.class_332;
import net.minecraft.class_746;

public class AutoSprint extends Module {
   public final Setting.Mode mode = this.add(
      new Setting.Mode("mode", "Режим", "Mode", 0, "always", "Всегда бежать", "Always sprint", "toggle", "Вкл/выкл клавишей бега", "Toggle with sprint key")
   );
   public final Setting.Bool indicator = this.add(new Setting.Bool("indicator", "Значок над хотбаром", "Indicator above hotbar", true));
   private boolean toggled = true;
   private boolean lastKey;

   public AutoSprint() {
      super(
         "auto_sprint",
         Category.UTILITIES,
         false,
         "Авто-спринт",
         "Auto Sprint",
         "Автоматически бежит, когда идёшь вперёд",
         "Sprints automatically while moving forward"
      );
   }

   private boolean canSprint() {
      class_746 p = mc.field_1724;
      return p == null
         ? false
         : mc.field_1690.field_1894.method_1434()
            && !p.method_5715()
            && !p.field_5976
            && !p.method_6115()
            && (p.method_7344().method_7586() > 6 || p.method_31549().field_7478)
            && !p.method_6059(class_1294.field_5919)
            && !p.method_5799()
            && !p.method_6128();
   }

   @Override
   public void onTick() {
      if (mc.field_1724 != null) {
         if (this.mode.is("toggle")) {
            boolean k = mc.field_1690.field_1867.method_1434();
            if (k && !this.lastKey && mc.field_1755 == null) {
               this.toggled = !this.toggled;
            }

            this.lastKey = k;
            if (!this.toggled) {
               return;
            }
         }

         if (this.canSprint()) {
            mc.field_1724.method_5728(true);
         }
      }
   }

   public boolean active() {
      return this.isEnabled() && (!this.mode.is("toggle") || this.toggled);
   }

   @Override
   public void renderOverlay(class_332 ctx, float delta) {
      if (this.indicator.value && mc.field_1724 != null && !mc.field_1690.field_1842) {
         boolean running = mc.field_1724.method_5624();
         String s = this.active() ? (running ? Lang.t("Бег", "Sprinting") : Lang.t("Авто-спринт", "Auto Sprint")) : Lang.t("Спринт выкл", "Sprint off");
         int sw = mc.method_22683().method_4486();
         int sh = mc.method_22683().method_4502();
         int w = R2D.width(s) + 14;
         int x = sw / 2 + 92;
         int y = sh - 20;

         for (Module m : Modules.all()) {
            if (m instanceof HudModule hm && hm.isEnabled() && hm.sw > 0 && x < hm.sx + hm.sw && x + w > hm.sx && y < hm.sy + hm.sh && y + 14 > hm.sy) {
               y = Math.min(y, hm.sy - 16);
            }
         }

         R2D.round(ctx, x, y, w, 14, 4, R2D.bg());
         R2D.circle(ctx, x + 6, y + 7, 2, this.active() ? (running ? R2D.accent(0.0F) : -5196608) : -42396);
         R2D.text(ctx, s, x + 11, y + 3, -1);
      }
   }
}
