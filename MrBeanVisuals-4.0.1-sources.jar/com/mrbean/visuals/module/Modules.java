package com.mrbean.visuals.module;

import com.mrbean.visuals.module.cosmetic.ChinaHat;
import com.mrbean.visuals.module.impl.ThemeModule;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Modules {
   private static final List<Module> ALL = new ArrayList<>();
   private static final Map<String, Module> BY_ID = new LinkedHashMap<>();
   private static ThemeModule theme;
   public static ChinaHat chinaHat;

   private Modules() {
   }

   public static <T extends Module> T reg(T m) {
      if (BY_ID.containsKey(m.id)) {
         throw new IllegalStateException("Duplicate module id " + m.id);
      } else {
         ALL.add(m);
         BY_ID.put(m.id, m);
         return m;
      }
   }

   public static void init() {
      theme = reg(new ThemeModule());
      chinaHat = reg(new ChinaHat());
      ModuleList.registerAll();
   }

   public static List<Module> all() {
      return ALL;
   }

   public static Module get(String id) {
      return BY_ID.get(id);
   }

   public static List<Module> of(Category c) {
      List<Module> l = new ArrayList<>();

      for (Module m : ALL) {
         if (m.category == c) {
            l.add(m);
         }
      }

      return l;
   }

   public static ThemeModule theme() {
      return theme;
   }

   public static boolean on(Module m) {
      return m != null && m.isEnabled();
   }
}
