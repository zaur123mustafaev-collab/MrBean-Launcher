package com.mrbean.visuals.module;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.Sounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class Module {
   protected static final class_310 mc = class_310.method_1551();
   public final String id;
   private final String ru;
   private final String en;
   private final String descRu;
   private final String descEn;
   public final Category category;
   public final List<Setting> settings = new ArrayList<>();
   private boolean enabled;
   private final boolean defEnabled;
   public float anim;
   public int bind = -1;

   public Module(String id, Category category, boolean defEnabled, String ru, String en, String descRu, String descEn) {
      this.id = id;
      this.category = category;
      this.ru = ru;
      this.en = en;
      this.descRu = descRu;
      this.descEn = descEn;
      this.enabled = defEnabled;
      this.defEnabled = defEnabled;
      this.anim = defEnabled ? 1.0F : 0.0F;
   }

   public String name() {
      return Lang.t(this.ru, this.en);
   }

   public String description() {
      return Lang.t(this.descRu, this.descEn);
   }

   public String searchText() {
      return (this.ru + " " + this.en + " " + this.descRu + " " + this.descEn + " " + this.id).toLowerCase();
   }

   protected <T extends Setting> T add(T s) {
      this.settings.add(s);
      return s;
   }

   public Setting setting(String id) {
      for (Setting s : this.settings) {
         if (s.id.equals(id)) {
            return s;
         }
      }

      return null;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean e) {
      if (e != this.enabled) {
         this.enabled = e;

         try {
            if (e) {
               this.onEnable();
            } else {
               this.onDisable();
            }
         } catch (Exception var3) {
         }
      }
   }

   public void toggle() {
      this.setEnabled(!this.enabled);
      Notifications.toggle(this.name(), this.enabled);
      Sounds.play(this.enabled ? Sounds.ON : Sounds.OFF);
   }

   public void resetSettings() {
      for (Setting s : this.settings) {
         s.reset();
      }

      this.setEnabled(this.defEnabled);
   }

   public boolean toggleable() {
      return true;
   }

   public void onBindPress() {
      this.toggle();
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void onTick() {
   }

   public void renderOverlay(class_332 ctx, float delta) {
   }

   public boolean showInArray() {
      return true;
   }
}
