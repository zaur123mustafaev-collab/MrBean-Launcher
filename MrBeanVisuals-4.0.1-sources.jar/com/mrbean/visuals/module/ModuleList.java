package com.mrbean.visuals.module;

import com.mrbean.visuals.module.cosmetic.Cosmetics;
import com.mrbean.visuals.module.cosmetic.Nameplate;
import com.mrbean.visuals.module.hud.HudElements;
import com.mrbean.visuals.module.impl.AnimationModules;
import com.mrbean.visuals.module.impl.AutoDuel;
import com.mrbean.visuals.module.impl.AutoSprint;
import com.mrbean.visuals.module.impl.CrystalModules;
import com.mrbean.visuals.module.impl.Emotes;
import com.mrbean.visuals.module.impl.FxModules;
import com.mrbean.visuals.module.impl.HelperModules;
import com.mrbean.visuals.module.impl.MacroModule;
import com.mrbean.visuals.module.impl.MainMenuModule;
import com.mrbean.visuals.module.impl.MarkersModules;
import com.mrbean.visuals.module.impl.ParticleModules;
import com.mrbean.visuals.module.impl.PerformanceModule;
import com.mrbean.visuals.module.impl.PlayerBadge;
import com.mrbean.visuals.module.impl.PveModules;
import com.mrbean.visuals.module.impl.RvModules;
import com.mrbean.visuals.module.impl.UtilityModules;
import com.mrbean.visuals.module.impl.VisualModules;
import com.mrbean.visuals.module.impl.WorldModules;

final class ModuleList {
   private ModuleList() {
   }

   static void registerAll() {
      Modules.reg(new Cosmetics.Halo());
      Modules.reg(new Cosmetics.Wings(false));
      Modules.reg(new Cosmetics.Wings(true));
      Modules.reg(new Cosmetics.Crown());
      Modules.reg(new Cosmetics.Aura());
      Modules.reg(new Cosmetics.Cape());
      Modules.reg(new Cosmetics.Companion());
      Modules.reg(new Cosmetics.Trail());
      Modules.reg(new Cosmetics.MoveParticles());
      Modules.reg(new Nameplate());
      HudElements.registerAll();
      VisualModules.registerAll();
      WorldModules.registerAll();
      ParticleModules.registerAll();
      AnimationModules.registerAll();
      Modules.reg(new PerformanceModule());
      Modules.reg(new PlayerBadge());
      Modules.reg(new Emotes.EmoteModule());
      Modules.reg(new AutoSprint());
      Modules.reg(new MacroModule());
      Modules.reg(new AutoDuel());
      Modules.reg(new MainMenuModule());
      CrystalModules.registerAll();
      HelperModules.registerAll();
      RvModules.registerAll();
      UtilityModules.registerAll();
      PveModules.registerAll();
      MarkersModules.registerAll();
      FxModules.registerAll();
   }
}
