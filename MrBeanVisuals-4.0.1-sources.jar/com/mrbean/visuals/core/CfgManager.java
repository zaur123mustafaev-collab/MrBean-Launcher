package com.mrbean.visuals.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mrbean.visuals.MrBeanClient;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class CfgManager {
   public static final int FORMAT = 1;
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
   private static final Set<String> RESERVED = Set.of(
      "con",
      "prn",
      "aux",
      "nul",
      "com1",
      "com2",
      "com3",
      "com4",
      "com5",
      "com6",
      "com7",
      "com8",
      "com9",
      "lpt1",
      "lpt2",
      "lpt3",
      "lpt4",
      "lpt5",
      "lpt6",
      "lpt7",
      "lpt8",
      "lpt9"
   );
   public static String active = "";

   private CfgManager() {
   }

   public static Path dir() {
      return Config.dir().resolve("configs");
   }

   public static String clean(String raw) {
      if (raw == null) {
         return null;
      } else {
         String n = raw.trim();
         if (n.isEmpty() || n.length() > 32) {
            return null;
         } else if (!n.matches("[\\p{L}\\p{N}_\\-]+")) {
            return null;
         } else {
            return RESERVED.contains(n.toLowerCase(Locale.ROOT)) ? null : n;
         }
      }
   }

   private static Path file(String name) {
      return dir().resolve(name + ".json");
   }

   public static boolean exists(String name) {
      String n = clean(name);
      return n != null && Files.exists(file(n));
   }

   public static JsonObject bundle() {
      JsonObject o = Config.profileJson();
      o.add("elements", Config.hudJson().get("elements"));
      JsonObject keys = new JsonObject();

      for (class_304 kb : MrBeanClient.modKeys()) {
         keys.addProperty(kb.method_1431(), kb.method_1428());
      }

      o.add("keybinds", keys);
      JsonObject ui = new JsonObject();
      ui.addProperty("language", Lang.english ? "en" : "ru");
      o.add("interface", ui);
      o.addProperty("format", 1);
      o.addProperty("saved", LocalDateTime.now().toString());
      return o;
   }

   private static void apply(JsonObject o) {
      Config.applyProfile(o);
      if (o.has("keybinds") && o.get("keybinds").isJsonObject()) {
         JsonObject keys = o.getAsJsonObject("keybinds");
         boolean changed = false;

         for (class_304 kb : MrBeanClient.modKeys()) {
            if (keys.has(kb.method_1431())) {
               try {
                  kb.method_1422(class_3675.method_15981(keys.get(kb.method_1431()).getAsString()));
                  changed = true;
               } catch (Exception var7) {
               }
            }
         }

         if (changed) {
            class_304.method_1426();

            try {
               class_310.method_1551().field_1690.method_1640();
            } catch (Exception var6) {
            }
         }
      }

      if (o.has("interface") && o.get("interface").isJsonObject()) {
         JsonObject ui = o.getAsJsonObject("interface");
         if (ui.has("language")) {
            Lang.english = "en".equals(ui.get("language").getAsString());
         }
      }
   }

   public static CfgManager.Result save(String raw) {
      String n = clean(raw);
      if (n == null) {
         return new CfgManager.Result(
            false, Lang.t("Недопустимое имя. Можно буквы, цифры, _ и -, до 32 символов", "Invalid name. Letters, digits, _ and -, up to 32 chars")
         );
      } else {
         try {
            Files.createDirectories(dir());
            JsonObject bundle = bundle();
            JsonObject old = parse(file(n));
            if (old != null && old.has("fav")) {
               bundle.add("fav", old.get("fav"));
            }

            write(file(n), bundle);
            active = n;
            Config.save();
            return new CfgManager.Result(true, Lang.t("Конфиг «" + n + "» сохранён", "Config “" + n + "” saved"));
         } catch (Exception var3) {
            MrBeanClient.LOG.error("cfg save", var3);
            return new CfgManager.Result(false, Lang.t("Не удалось сохранить: ", "Save failed: ") + var3.getMessage());
         }
      }
   }

   public record Info(String name, boolean fav, int funcs, int hud, int binds, long modified) {
   }

   public static CfgManager.Info info(String raw) {
      String n = clean(raw);
      if (n == null) {
         return null;
      } else {
         Path p = file(n);
         if (!Files.exists(p)) {
            return null;
         } else {
            JsonObject o = parse(p);
            boolean fav = o != null && o.has("fav") && o.get("fav").getAsBoolean();
            long mod = 0L;

            try {
               mod = Files.getLastModifiedTime(p).toMillis();
            } catch (Exception var8) {
            }

            return new CfgManager.Info(n, fav, countEnabled(o, "modules"), countEnabled(o, "elements"), countBinds(o), mod);
         }
      }
   }

   private static int countEnabled(JsonObject o, String key) {
      if (o != null && o.has(key) && o.get(key).isJsonObject()) {
         int c = 0;

         for (Entry<String, JsonElement> e : o.getAsJsonObject(key).entrySet()) {
            JsonElement v = e.getValue();
            if (v.isJsonObject() && v.getAsJsonObject().has("enabled") && v.getAsJsonObject().get("enabled").getAsBoolean()) {
               c++;
            }
         }

         return c;
      } else {
         return 0;
      }
   }

   private static int countBinds(JsonObject o) {
      if (o != null && o.has("keybinds") && o.get("keybinds").isJsonObject()) {
         int c = 0;

         for (Entry<String, JsonElement> e : o.getAsJsonObject("keybinds").entrySet()) {
            try {
               if (!e.getValue().getAsString().endsWith("unknown")) {
                  c++;
               }
            } catch (Exception var5) {
            }
         }

         return c;
      } else {
         return 0;
      }
   }

   public static CfgManager.Result setFav(String raw, boolean value) {
      String n = clean(raw);
      if (n == null || !Files.exists(file(n))) {
         return new CfgManager.Result(false, Lang.t("Нет такого конфига", "No such config"));
      } else {
         JsonObject o = parse(file(n));
         if (o == null) {
            return new CfgManager.Result(false, Lang.t("Конфиг повреждён", "Config is corrupted"));
         } else {
            o.addProperty("fav", value);
            write(file(n), o);
            return new CfgManager.Result(
               true, value ? Lang.t("«" + n + "» в избранном", "“" + n + "” favourited") : Lang.t("«" + n + "» убран из избранного", "“" + n + "” unfavourited")
            );
         }
      }
   }

   public static String code(String raw) {
      String n = clean(raw);
      if (n != null && Files.exists(file(n))) {
         try {
            byte[] json = Files.readAllBytes(file(n));
            ByteArrayOutputStream bo = new ByteArrayOutputStream();

            try (GZIPOutputStream gz = new GZIPOutputStream(bo)) {
               gz.write(json);
            }

            return "MBV1" + Base64.getUrlEncoder().encodeToString(bo.toByteArray());
         } catch (Exception var5) {
            MrBeanClient.LOG.error("cfg code", var5);
            return null;
         }
      } else {
         return null;
      }
   }

   public static CfgManager.Result importCode(String raw, String code) {
      String n = clean(raw);
      if (n == null) {
         return new CfgManager.Result(
            false, Lang.t("Недопустимое имя. Можно буквы, цифры, _ и -, до 32 символов", "Invalid name. Letters, digits, _ and -, up to 32 chars")
         );
      } else if (code != null && !code.isBlank()) {
         try {
            String b = code.trim().replaceAll("\\s", "");
            if (b.startsWith("MBV1")) {
               b = b.substring(4);
            }

            byte[] gz = Base64.getUrlDecoder().decode(b);
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            try (GZIPInputStream in = new GZIPInputStream(new ByteArrayInputStream(gz))) {
               in.transferTo(out);
            }

            JsonElement e = JsonParser.parseString(out.toString(StandardCharsets.UTF_8));
            if (!e.isJsonObject()) {
               return new CfgManager.Result(false, Lang.t("Код испорчен", "Code is broken"));
            } else {
               JsonObject o = e.getAsJsonObject();
               if (!o.has("modules") && !o.has("elements")) {
                  return new CfgManager.Result(false, Lang.t("Это не конфиг MrBean Visuals", "Not a MrBean Visuals config"));
               } else {
                  o.addProperty("fav", false);
                  Files.createDirectories(dir());
                  write(file(n), o);
                  return new CfgManager.Result(true, Lang.t("Конфиг «" + n + "» импортирован", "Config “" + n + "” imported"));
               }
            }
         } catch (Exception var7) {
            return new CfgManager.Result(false, Lang.t("Код не читается: ", "Bad code: ") + var7.getMessage());
         }
      } else {
         return new CfgManager.Result(false, Lang.t("Вставь код конфига", "Paste a config code"));
      }
   }

   private static JsonObject parse(Path p) {
      try {
         JsonElement e = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8));
         return e != null && e.isJsonObject() ? e.getAsJsonObject() : null;
      } catch (Exception var3) {
         return null;
      }
   }

   public static CfgManager.Result load(String raw) {
      String n = clean(raw);
      if (n != null && Files.exists(file(n))) {
         JsonObject o = read(file(n));
         if (o == null) {
            return new CfgManager.Result(
               false,
               Lang.t(
                  "Конфиг «" + n + "» повреждён — копия сохранена как .broken, настройки не тронуты",
                  "Config “" + n + "” is corrupted — kept a .broken copy, settings unchanged"
               )
            );
         } else if (!o.has("modules") && !o.has("elements")) {
            return new CfgManager.Result(false, Lang.t("Это не конфиг MrBean Visuals", "Not a MrBean Visuals config"));
         } else {
            apply(o);
            active = n;
            Config.save();
            return new CfgManager.Result(true, Lang.t("Конфиг «" + n + "» загружен", "Config “" + n + "” loaded"));
         }
      } else {
         return new CfgManager.Result(false, Lang.t("Конфиг «" + raw + "» не найден. Список: .cfg list", "Config “" + raw + "” not found. See .cfg list"));
      }
   }

   public static CfgManager.Result delete(String raw) {
      String n = clean(raw);
      if (n != null && Files.exists(file(n))) {
         try {
            Files.delete(file(n));
            if (n.equals(active)) {
               active = "";
               Config.save();
            }

            return new CfgManager.Result(true, Lang.t("Конфиг «" + n + "» удалён", "Config “" + n + "” deleted"));
         } catch (Exception var3) {
            return new CfgManager.Result(false, var3.getMessage());
         }
      } else {
         return new CfgManager.Result(false, Lang.t("Нет такого конфига", "No such config"));
      }
   }

   public static CfgManager.Result rename(String rawOld, String rawNew) {
      String a = clean(rawOld);
      String b = clean(rawNew);
      if (a == null || !Files.exists(file(a))) {
         return new CfgManager.Result(false, Lang.t("Нет такого конфига", "No such config"));
      } else if (b == null) {
         return new CfgManager.Result(false, Lang.t("Недопустимое новое имя", "Invalid new name"));
      } else if (Files.exists(file(b))) {
         return new CfgManager.Result(false, Lang.t("Конфиг «" + b + "» уже есть", "Config “" + b + "” already exists"));
      } else {
         try {
            Files.move(file(a), file(b));
            if (a.equals(active)) {
               active = b;
               Config.save();
            }

            return new CfgManager.Result(true, Lang.t("«" + a + "» → «" + b + "»", "“" + a + "” → “" + b + "”"));
         } catch (Exception var5) {
            return new CfgManager.Result(false, var5.getMessage());
         }
      }
   }

   public static List<String> list() {
      List<String> out = new ArrayList<>();

      try {
         Files.createDirectories(dir());

         try (Stream<Path> s = Files.list(dir())) {
            s.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
               String f = p.getFileName().toString();
               out.add(f.substring(0, f.length() - 5));
            });
         }
      } catch (Exception var6) {
      }

      out.sort(String::compareToIgnoreCase);
      return out;
   }

   public static void autoload() {
      if (!active.isEmpty()) {
         if (!Files.exists(file(active))) {
            active = "";
         } else {
            JsonObject o = read(file(active));
            if (o != null) {
               apply(o);
               MrBeanClient.LOG.info("Загружен конфиг {}", active);
            }
         }
      }
   }

   public static void autosave() {
      if (!active.isEmpty() && Files.exists(file(active))) {
         write(file(active), bundle());
      }
   }

   private static JsonObject read(Path p) {
      try {
         JsonElement e = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8));
         if (e != null && e.isJsonObject()) {
            return e.getAsJsonObject();
         } else {
            throw new IllegalStateException("not an object");
         }
      } catch (Exception var4) {
         try {
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
            Files.copy(p, p.resolveSibling(p.getFileName() + ".broken-" + stamp), StandardCopyOption.REPLACE_EXISTING);
         } catch (Exception var3) {
         }

         MrBeanClient.LOG.warn("Повреждённый конфиг {}", p.getFileName());
         return null;
      }
   }

   private static void write(Path p, JsonObject o) {
      try {
         Files.createDirectories(p.getParent());
         Path tmp = p.resolveSibling(p.getFileName() + ".tmp");
         Files.writeString(tmp, GSON.toJson(o), StandardCharsets.UTF_8);

         try {
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (Exception var4) {
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (Exception var5) {
         MrBeanClient.LOG.error("Не удалось записать {}", p, var5);
      }
   }

   public record Result(boolean ok, String message) {
   }
}
