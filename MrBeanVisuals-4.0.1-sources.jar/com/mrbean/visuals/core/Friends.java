package com.mrbean.visuals.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public final class Friends {
   private static final Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

   private Friends() {
   }

   public static boolean valid(String n) {
      return n != null && n.matches("[A-Za-z0-9_]{3,16}");
   }

   public static boolean is(String n) {
      return n != null && names.contains(n);
   }

   public static boolean add(String n) {
      return valid(n) && names.add(n);
   }

   public static boolean remove(String n) {
      return names.remove(n);
   }

   public static void clear() {
      names.clear();
   }

   public static List<String> all() {
      return new ArrayList<>(names);
   }

   public static boolean toggle(String n) {
      if (is(n)) {
         remove(n);
         return false;
      } else {
         add(n);
         return true;
      }
   }

   static String norm(String n) {
      return n.toLowerCase(Locale.ROOT);
   }
}
