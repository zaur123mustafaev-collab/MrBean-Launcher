package com.mrbean.visuals.core;

import com.mrbean.visuals.gui.Screens;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.impl.Emotes;
import com.mrbean.visuals.net.EmoteNetwork;
import com.mrbean.visuals.render.R2D;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

public final class ChatCommands {
   private ChatCommands() {
   }

   public static boolean allow(String message) {
      if (message == null) {
         return true;
      } else {
         String m = message.trim();
         String low = m.toLowerCase();
         if (!low.equals(".cfg")
            && !low.startsWith(".cfg ")
            && !low.equals(".friend")
            && !low.startsWith(".friend ")
            && !low.equals(".emote")
            && !low.startsWith(".emote ")
            && !low.equals(".emotebind")
            && !low.startsWith(".emotebind ")
            && !low.equals(".help")
            && !low.equals(".mrbean")
            && !low.equals(".menu")
            && !low.equals(".gui")) {
            return true;
         } else {
            class_310 mc = class_310.method_1551();
            mc.execute(() -> {
               try {
                  mc.field_1705.method_1743().method_1803(m);
               } catch (Exception var3x) {
               }

               handle(m.split("\\s+"));
            });
            return false;
         }
      }
   }

   static void handle(String[] a) {
      if (a[0].equalsIgnoreCase(".menu") || a[0].equalsIgnoreCase(".gui")) {
         class_310 mc = class_310.method_1551();
         mc.method_63588(() -> mc.method_1507(Screens.menu()));
      } else if (a[0].equalsIgnoreCase(".help") || a[0].equalsIgnoreCase(".mrbean") || a.length == 1) {
         help();
      } else if (a[0].equalsIgnoreCase(".friend")) {
         friend(a);
      } else if (a[0].equalsIgnoreCase(".emote")) {
         emote(a);
      } else if (a[0].equalsIgnoreCase(".emotebind")) {
         emoteBind(a);
      } else {
         String sub = a[1].toLowerCase();
         switch (sub) {
            case "save":
               if (a.length < 3) {
                  usage(".cfg save <имя>");
               } else {
                  out(CfgManager.save(a[2]));
               }
               break;
            case "load":
               if (a.length < 3) {
                  usage(".cfg load <имя>");
               } else {
                  out(CfgManager.load(a[2]));
               }
               break;
            case "delete":
            case "del":
            case "remove":
               if (a.length < 3) {
                  usage(".cfg delete <имя>");
               } else {
                  out(CfgManager.delete(a[2]));
               }
               break;
            case "rename":
               if (a.length < 4) {
                  usage(".cfg rename <старое> <новое>");
               } else {
                  out(CfgManager.rename(a[2], a[3]));
               }
               break;
            case "list":
            case "ls":
               List<String> l = CfgManager.list();
               if (l.isEmpty()) {
                  say(Lang.t("Конфигов пока нет. Сохраните: .cfg save <имя>", "No configs yet. Save one: .cfg save <name>"), -4670004);
                  return;
               }

               say(Lang.t("Конфиги (" + l.size() + "):", "Configs (" + l.size() + "):"), -1);

               for (String n : l) {
                  say(
                     (n.equals(CfgManager.active) ? " ● " : " ○ ") + n + (n.equals(CfgManager.active) ? Lang.t("  (активный)", "  (active)") : ""),
                     n.equals(CfgManager.active) ? R2D.accent(0.0F) : -3091234
                  );
               }
               break;
            default:
               help();
         }
      }
   }

   private static void emote(String[] a) {
      if (a.length < 2) {
         usage(".emote <" + Emotes.ids() + "> [ник] · .emote stop");
      } else if (a[1].equalsIgnoreCase("stop") || a[1].equalsIgnoreCase("стоп") || a[1].equals("off") || a[1].equals("выкл")) {
         String err = Emotes.stopSelf();
         say(err == null ? Lang.t("Эмоция выключена", "Emote stopped") : err, err == null ? -11870592 : -38037);
      } else {
         Emotes.EmoteModule em = Emotes.module();
         float speed = em == null ? 1.0F : em.speed.f();
         boolean other = a.length >= 3;
         String err = other ? Emotes.playOn(a[2], a[1], speed) : Emotes.playSelf(a[1], speed);
         boolean ok = err == null;
         say(
            ok
               ? Lang.t("Эмоция: ", "Emote: ") + a[1]
                  + (other
                     ? Lang.t(" у ", " on ") + a[2]
                     : EmoteNetwork.supported()
                        ? ""
                        : Lang.t(" — только тебе (сервер не передаёт эмоции)", " — only you (server doesn't relay emotes)"))
               : err,
            ok ? -11870592 : -38037
         );
      }
   }

   private static void emoteBind(String[] a) {
      if (a.length < 2) {
         String list = Emotes.bindList();
         say(
            Lang.t(
               "Бинды эмоций: " + (list.isEmpty() ? "ни одна не назначена" : list) + ". .emotebind <эмоция> <клавиша>",
               "Emote binds: " + (list.isEmpty() ? "none set" : list) + ". .emotebind <emote> <key>"
            ),
            -8588644
         );
         say(" " + Emotes.ids(), -6643532);
      } else {
         Setting.Key k = Emotes.bindOf(a[1]);
         if (k == null) {
            say(Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + Emotes.ids(), -38037);
         } else if (a.length < 3) {
            usage(".emotebind " + a[1] + " <клавиша|none>");
         } else {
            int code = keyCode(a[2]);
            if (code == -2) {
               say(
                  Lang.t("Не понимаю клавишу «" + a[2] + "». Примеры: f, g, 3, f5, space, mouse4, none", "Unknown key \"" + a[2] + "\". Try: f, g, 3, f5, space, mouse4, none"),
                  -38037
               );
            } else {
               k.value = code;
               Config.markDirty();
               say(Lang.t("Бинд: ", "Bind: ") + a[1] + " → " + k.display(), code >= 0 ? -11870592 : -6643532);
               Sounds.play(Sounds.ON);
            }
         }
      }
   }

   /** Имя клавиши -> код GLFW (у мыши код = 1000 + кнопка). -1 = снять, -2 = не распознано. */
   private static int keyCode(String s) {
      String q = s.trim().toLowerCase();
      if (q.isEmpty()) {
         return -2;
      } else if (!q.equals("none") && !q.equals("off") && !q.equals("unbind") && !q.equals("-")) {
         if (q.startsWith("mouse") && q.length() > 5 || q.matches("m[1-5]")) {
            int n = Character.getNumericValue(q.charAt(q.length() - 1));
            return n >= 1 && n <= 5 ? 1000 + n - 1 : -2;
         } else if (q.matches("f\\d{1,2}")) {
            int n = Integer.parseInt(q.substring(1));
            return n >= 1 && n <= 25 ? 289 + n : -2;
         } else if (q.length() == 1) {
            char c = q.charAt(0);
            if (c >= 'a' && c <= 'z') {
               return c - 'a' + 65;
            } else if (c >= '0' && c <= '9') {
               return 48 + (c - '0');
            } else {
               switch (c) {
                  case '-':
                     return 45;
                  case '=':
                     return 61;
                  case ',':
                     return 44;
                  case '.':
                     return 46;
                  case '/':
                     return 47;
                  case '[':
                     return 91;
                  case ']':
                     return 93;
                  case '\\':
                     return 92;
                  case '`':
                     return 96;
                  case ';':
                     return 59;
                  case '\'':
                     return 39;
               }

               return -2;
            }
         } else {
            switch (q) {
               case "space":
                  return 32;
               case "enter":
               case "return":
                  return 257;
               case "tab":
                  return 258;
               case "esc":
               case "escape":
                  return 256;
               case "backspace":
                  return 259;
               case "insert":
                  return 260;
               case "delete":
               case "del":
                  return 261;
               case "right":
                  return 262;
               case "left":
                  return 263;
               case "down":
                  return 264;
               case "up":
                  return 265;
               case "pageup":
                  return 266;
               case "pagedown":
                  return 267;
               case "home":
                  return 268;
               case "end":
                  return 269;
               case "shift":
               case "lshift":
               case "rshift":
                  return q.equals("shift") ? 340 : (q.equals("rshift") ? 344 : 340);
               case "ctrl":
               case "lctrl":
               case "rctrl":
                  return q.equals("rctrl") ? 345 : 341;
               case "alt":
               case "lalt":
               case "ralt":
                  return q.equals("ralt") ? 346 : 342;
               case "caps":
               case "caps_lock":
                  return 280;
            }

            return -2;
         }
      } else {
         return -1;
      }
   }

   private static void friend(String[] a) {
      if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
         List<String> l = Friends.all();
         say(Lang.t("Друзья (" + l.size() + "): ", "Friends (" + l.size() + "): ") + (l.isEmpty() ? "—" : String.join(", ", l)), -8588644);
      } else if (a.length < 3) {
         usage(".friend add|remove <ник>");
      } else {
         boolean ok = a[1].equalsIgnoreCase("add") ? Friends.add(a[2]) : Friends.remove(a[2]);
         say(
            ok
               ? (a[1].equalsIgnoreCase("add") ? Lang.t("Друг добавлен: ", "Friend added: ") : Lang.t("Друг удалён: ", "Friend removed: ")) + a[2]
               : Lang.t("Не получилось (ник 3–16 символов или уже в списке)", "Failed (nick 3–16 chars or already listed)"),
            ok ? -11870592 : -38037
         );
         if (ok) {
            Config.save();
         }
      }
   }

   private static void help() {
      say(Lang.t("Команды MrBean Visuals (не уходят на сервер):", "MrBean Visuals commands (never sent to the server):"), -1);
      say(" .cfg save <имя>  —  " + Lang.t("сохранить всё", "save everything"), -3091234);
      say(" .cfg load <имя>  —  " + Lang.t("загрузить", "load"), -3091234);
      say(" .cfg list  —  " + Lang.t("список", "list"), -3091234);
      say(" .cfg delete <имя>  —  " + Lang.t("удалить", "delete"), -3091234);
      say(" .cfg rename <старое> <новое>  —  " + Lang.t("переименовать", "rename"), -3091234);
      say(" .friend add/remove/list <ник>  —  " + Lang.t("друзья", "friends"), -3091234);
      say(" .emote <имя> [ник]  —  " + Lang.t("эмоция: " + Emotes.ids(), "emote: " + Emotes.ids()), -3091234);
      say(" .emote stop  —  " + Lang.t("выключить зацикленную эмоцию", "stop the looping emote"), -3091234);
      say(
         " .emotebind <имя> <клавиша|none>  —  " + Lang.t("своя клавиша на каждую эмоцию", "a separate key per emote"),
         -3091234
      );
      say(" .menu  —  " + Lang.t("открыть меню (для телефона)", "open the menu (for phones)"), -3091234);
   }

   private static void usage(String u) {
      say(Lang.t("Использование: ", "Usage: ") + u, -20448);
   }

   private static void out(CfgManager.Result r) {
      say(r.message(), r.ok() ? -11870592 : -38037);
      Sounds.play(r.ok() ? Sounds.ON : Sounds.OFF);
   }

   private static void say(String s, int color) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1705 != null) {
         class_5250 prefix = class_2561.method_43470("[MrBean] ").method_27694(st -> st.method_27703(class_5251.method_27717(R2D.accent(0.0F) & 16777215)).method_10982(true));
         mc.field_1705.method_1743().method_1812(prefix.method_10852(class_2561.method_43470(s).method_27694(st -> st.method_27703(class_5251.method_27717(color & 16777215)).method_10982(false))));
      }
   }
}
