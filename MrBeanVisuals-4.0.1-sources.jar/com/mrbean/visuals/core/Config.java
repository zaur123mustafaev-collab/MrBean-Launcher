package com.mrbean.visuals.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.module.impl.MacroModule;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class Config {
   public static final int VERSION = 2;
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
   public static String profile = "default";
   public static String hudPreset = "default";
   public static boolean firstRunDone = false;
   public static String lastAccountNote = "";
   private static int dirtyTicks = -1;
   private static final Map<String, String> V1_IDS = Map.ofEntries(
      Map.entry("Ватермарка", "watermark"),
      Map.entry("Список модулей", "array_list"),
      Map.entry("Координаты", "coords"),
      Map.entry("Клавиши", "keystrokes"),
      Map.entry("Броня", "armor"),
      Map.entry("Эффекты", "potions"),
      Map.entry("FPS", "fps"),
      Map.entry("Пинг", "ping"),
      Map.entry("Скорость", "speed"),
      Map.entry("CPS", "cps"),
      Map.entry("Часы", "clock"),
      Map.entry("Цель", "target_hud"),
      Map.entry("Счётчик предметов", "item_counter"),
      Map.entry("Комбо", "combo"),
      Map.entry("Дистанция удара", "reach_display"),
      Map.entry("Перезарядка удара", "cooldown"),
      Map.entry("Предупреждения", "warnings"),
      Map.entry("Прицел", "crosshair"),
      Map.entry("Хитмаркер", "hitmarker"),
      Map.entry("Авто-спринт", "toggle_sprint"),
      Map.entry("Уровень света", "light_level"),
      Map.entry("День мира", "day_counter"),
      Map.entry("Точка смерти", "death_coords"),
      Map.entry("Сытость", "hunger"),
      Map.entry("Инструмент", "tool_info"),
      Map.entry("Яркость", "fullbright"),
      Map.entry("Зум", "zoom"),
      Map.entry("Без тряски урона", "no_hurt_cam"),
      Map.entry("Без покачивания", "no_bob"),
      Map.entry("Меньше огня", "low_fire"),
      Map.entry("Без дождя", "weather"),
      Map.entry("Время суток", "time_changer"),
      Map.entry("Скрыть скорборд", "hide_scoreboard"),
      Map.entry("Стабильный FOV", "static_fov"),
      Map.entry("Макросы", "macros")
   );

   private Config() {
   }

   public static Path dir() {
      return FabricLoader.getInstance().getConfigDir().resolve("mrbeanvisuals");
   }

   private static Path global() {
      return dir().resolve("global.json");
   }

   public static Path profilesDir() {
      return dir().resolve("profiles");
   }

   public static Path hudDir() {
      return dir().resolve("hud");
   }

   public static Path exportsDir() {
      return dir().resolve("exports");
   }

   private static Path oldFile() {
      return FabricLoader.getInstance().getConfigDir().resolve("mrbeanvisuals.json");
   }

   private static JsonObject read(Path p) {
      if (!Files.exists(p)) {
         return null;
      } else {
         try {
            JsonElement e = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8));
            if (e != null && e.isJsonObject()) {
               return e.getAsJsonObject();
            } else {
               throw new IOException("not an object");
            }
         } catch (Exception var4) {
            try {
               String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
               Files.copy(p, p.resolveSibling(p.getFileName() + ".broken-" + stamp), StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception var3) {
            }

            MrBeanClient.LOG.warn("Повреждённый конфиг {} — использую значения по умолчанию", p.getFileName());
            Notifications.push(Lang.t("Конфиг повреждён — сброшен", "Config was corrupted — reset"), false);
            return null;
         }
      }
   }

   private static void write(Path p, JsonObject o) {
      try {
         Files.createDirectories(p.getParent());
         Path tmp = p.resolveSibling(p.getFileName() + ".tmp");
         Files.writeString(tmp, GSON.toJson(o), StandardCharsets.UTF_8);

         try {
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (Exception var4) {
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (Exception var5) {
         MrBeanClient.LOG.error("Не удалось сохранить {}", p, var5);
      }
   }

   private static JsonObject moduleToJson(Module m) {
      JsonObject o = new JsonObject();
      o.addProperty("enabled", m.isEnabled());
      if (m.bind >= 0) {
         o.addProperty("bind", m.bind);
      }

      JsonObject s = new JsonObject();

      for (Setting st : m.settings) {
         String v = st.save();
         if (v != null) {
            s.addProperty(st.id, v);
         }
      }

      o.add("settings", s);
      if (m instanceof HudModule h) {
         o.addProperty("fx", h.fx);
         o.addProperty("fy", h.fy);
      }

      return o;
   }

   private static void moduleFromJson(Module m, JsonObject o) {
      try {
         if (o.has("enabled")) {
            m.setEnabled(o.get("enabled").getAsBoolean());
         }

         m.bind = o.has("bind") ? o.get("bind").getAsInt() : -1;
         if (o.has("settings")) {
            JsonObject s = o.getAsJsonObject("settings");

            for (Setting st : m.settings) {
               if (s.has(st.id)) {
                  try {
                     st.load(s.get(st.id).getAsString());
                  } catch (Exception var6) {
                  }
               }
            }
         }

         if (m instanceof HudModule h && o.has("fx")) {
            h.fx = clamp01(o.get("fx").getAsDouble());
            h.fy = clamp01(o.get("fy").getAsDouble());
         }
      } catch (Exception var7) {
         MrBeanClient.LOG.warn("Не удалось загрузить настройки модуля {}", m.id);
      }
   }

   private static double clamp01(double v) {
      return Double.isNaN(v) ? 0.0 : Math.max(0.0, Math.min(1.0, v));
   }

   public static JsonObject profileJson() {
      JsonObject root = new JsonObject();
      root.addProperty("version", 2);
      JsonObject mods = new JsonObject();

      for (Module m : Modules.all()) {
         if (!(m instanceof HudModule)) {
            mods.add(m.id, moduleToJson(m));
         }
      }

      root.add("modules", mods);
      return root;
   }

   public static JsonObject hudJson() {
      JsonObject root = new JsonObject();
      root.addProperty("version", 2);
      JsonObject mods = new JsonObject();

      for (Module m : Modules.all()) {
         if (m instanceof HudModule) {
            mods.add(m.id, moduleToJson(m));
         }
      }

      root.add("elements", mods);
      return root;
   }

   public static void applyProfile(JsonObject root) {
      if (root != null) {
         JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : null;
         if (mods != null) {
            for (Module m : Modules.all()) {
               if (!(m instanceof HudModule) && mods.has(m.id)) {
                  moduleFromJson(m, mods.getAsJsonObject(m.id));
               }
            }
         }

         if (root.has("elements")) {
            applyHud(root);
         }
      }
   }

   public static void applyHud(JsonObject root) {
      if (root != null && root.has("elements")) {
         JsonObject els = root.getAsJsonObject("elements");

         for (Module m : Modules.all()) {
            if (m instanceof HudModule && els.has(m.id)) {
               moduleFromJson(m, els.getAsJsonObject(m.id));
            }
         }
      }
   }

   public static void load() {
      JsonObject g = read(global());
      if (g != null) {
         if (g.has("language")) {
            Lang.english = "en".equals(g.get("language").getAsString());
         }

         if (g.has("profile")) {
            profile = safeName(g.get("profile").getAsString());
         }

         if (g.has("hudPreset")) {
            hudPreset = safeName(g.get("hudPreset").getAsString());
         }

         if (g.has("firstRunDone")) {
            firstRunDone = g.get("firstRunDone").getAsBoolean();
         }

         if (g.has("friends")) {
            Friends.clear();

            for (JsonElement e : g.getAsJsonArray("friends")) {
               Friends.add(e.getAsString());
            }
         }

         if (g.has("activeCfg")) {
            String c = CfgManager.clean(g.get("activeCfg").getAsString());
            CfgManager.active = c == null ? "" : c;
         }
      } else if (Files.exists(oldFile())) {
         migrateV1();
      }

      applyProfile(read(profilesDir().resolve(profile + ".json")));
      applyHud(read(hudDir().resolve(hudPreset + ".json")));
      CfgManager.autoload();
   }

   public static void save() {
      JsonObject g = new JsonObject();
      g.addProperty("version", 2);
      g.addProperty("language", Lang.english ? "en" : "ru");
      g.addProperty("profile", profile);
      g.addProperty("hudPreset", hudPreset);
      g.addProperty("firstRunDone", firstRunDone);
      g.addProperty("activeCfg", CfgManager.active);
      JsonArray fr = new JsonArray();

      for (String f : Friends.all()) {
         fr.add(f);
      }

      g.add("friends", fr);
      write(global(), g);
      CfgManager.autosave();
      write(profilesDir().resolve(profile + ".json"), profileJson());
      write(hudDir().resolve(hudPreset + ".json"), hudJson());
      dirtyTicks = -1;
   }

   public static void markDirty() {
      dirtyTicks = 40;
   }

   public static void tick() {
      if (dirtyTicks > 0 && --dirtyTicks == 0) {
         save();
      }
   }

   public static String safeName(String s) {
      String n = s == null ? "" : s.replaceAll("[^\\p{L}\\p{N}_\\- ]", "").trim();
      return n.isEmpty() ? "default" : n.substring(0, Math.min(32, n.length()));
   }

   public static List<String> list(Path dir) {
      List<String> out = new ArrayList<>();

      try {
         Files.createDirectories(dir);

         try (Stream<Path> s = Files.list(dir)) {
            s.filter(p -> p.toString().endsWith(".json")).forEach(p -> {
               String n = p.getFileName().toString();
               out.add(n.substring(0, n.length() - 5));
            });
         }
      } catch (Exception var7) {
      }

      if (!out.contains("default")) {
         out.add(0, "default");
      }

      out.sort(String::compareToIgnoreCase);
      return out;
   }

   public static void switchProfile(String name) {
      save();
      profile = safeName(name);
      JsonObject o = read(profilesDir().resolve(profile + ".json"));
      if (o != null) {
         applyProfile(o);
      }

      save();
   }

   public static void switchHudPreset(String name) {
      save();
      hudPreset = safeName(name);
      JsonObject o = read(hudDir().resolve(hudPreset + ".json"));
      if (o != null) {
         applyHud(o);
      }

      save();
   }

   public static void deleteProfile(Path dir, String name) {
      if (!"default".equals(name)) {
         try {
            Files.deleteIfExists(dir.resolve(safeName(name) + ".json"));
         } catch (Exception var3) {
         }
      }
   }

   public static Path export() {
      JsonObject o = profileJson();
      o.add("elements", hudJson().get("elements"));
      o.addProperty("exported", LocalDateTime.now().toString());
      String name = "mrbean-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".json";
      Path p = exportsDir().resolve(name);
      write(p, o);
      return p;
   }

   public static String exportString() {
      JsonObject o = profileJson();
      o.add("elements", hudJson().get("elements"));
      return new Gson().toJson(o);
   }

   public static boolean importString(String json) {
      try {
         JsonObject o = JsonParser.parseString(json).getAsJsonObject();
         if (!o.has("modules") && !o.has("elements")) {
            return false;
         } else {
            applyProfile(o);
            save();
            return true;
         }
      } catch (Exception var2) {
         return false;
      }
   }

   public static Path latestExport() {
      try {
         Path var1;
         try (Stream<Path> s = Files.list(exportsDir())) {
            var1 = s.filter(p -> p.toString().endsWith(".json")).max((a, b) -> {
               try {
                  return Files.getLastModifiedTime(a).compareTo(Files.getLastModifiedTime(b));
               } catch (IOException var3) {
                  return 0;
               }
            }).orElse(null);
         }

         return var1;
      } catch (Exception var5) {
         return null;
      }
   }

   public static boolean importFile(Path p) {
      try {
         return importString(Files.readString(p, StandardCharsets.UTF_8));
      } catch (Exception var2) {
         return false;
      }
   }

   public static void resetAll() {
      for (Module m : Modules.all()) {
         m.resetSettings();
      }

      for (Module m : Modules.all()) {
         if (m instanceof HudModule h) {
            h.resetPosition();
         }
      }

      save();
   }

   private static void migrateV1() {
      JsonObject old = read(oldFile());
      if (old != null) {
         try {
            JsonObject mods = old.has("modules") ? old.getAsJsonObject("modules") : new JsonObject();

            for (Entry<String, JsonElement> e : mods.entrySet()) {
               String id = V1_IDS.get(e.getKey());
               Module m = id == null ? null : Modules.get(id);
               if (m != null && e.getValue().isJsonObject()) {
                  JsonObject o = e.getValue().getAsJsonObject();
                  if (o.has("enabled")) {
                     m.setEnabled(o.get("enabled").getAsBoolean());
                  }

                  if (m instanceof HudModule h && o.has("x")) {
                     int x = o.get("x").getAsInt();
                     int y = o.get("y").getAsInt();
                     if (x >= 0) {
                        h.fx = clamp01(x / 400.0);
                     }

                     if (y >= 0) {
                        h.fy = clamp01(y / 230.0);
                     }
                  }
               }
            }

            if (old.has("macros") && Modules.get("macros") instanceof MacroModule mm) {
               JsonArray arr = old.getAsJsonArray("macros");

               for (int i = 0; i < Math.min(arr.size(), mm.commands.length); i++) {
                  mm.commands[i].value = arr.get(i).getAsString();
               }
            }

            firstRunDone = true;
            Files.move(oldFile(), oldFile().resolveSibling("mrbeanvisuals.json.migrated"), StandardCopyOption.REPLACE_EXISTING);
            MrBeanClient.LOG.info("Настройки v1 перенесены в новый формат");
            save();
         } catch (Exception var10) {
            MrBeanClient.LOG.warn("Миграция v1 не удалась", var10);
         }
      }
   }
}
