package com.mrbean.visuals.gui;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.ThemeModule;
import net.minecraft.class_437;

public final class Screens {
   private Screens() {
   }

   public static class_437 menu() {
      ThemeModule t = Modules.theme();
      return (class_437)(t != null && t.menuStyle.is("classic") ? new MenuScreen() : new ClickGuiScreen());
   }

   public static class_437 hudEditor(class_437 parent) {
      return new HudEditorScreen(parent);
   }

   public static class_437 wizard(class_437 parent) {
      return new WizardScreen(parent);
   }

   public static boolean isMenu(class_437 s) {
      return s instanceof MenuScreen || s instanceof ClickGuiScreen || s instanceof HudEditorScreen || s instanceof WizardScreen;
   }
}
