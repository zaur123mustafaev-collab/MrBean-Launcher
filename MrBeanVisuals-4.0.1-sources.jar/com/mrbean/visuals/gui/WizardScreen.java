package com.mrbean.visuals.gui;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.preview.CosmeticPreview;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.module.impl.PerformanceModule;
import com.mrbean.visuals.module.impl.ThemeModule;
import com.mrbean.visuals.optimize.OptMods;
import com.mrbean.visuals.optimize.OptimizationScreen;
import com.mrbean.visuals.render.R2D;
import java.util.Set;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class WizardScreen extends class_437 {
   private final class_437 parent;
   private final Ui ui = new Ui();
   private int step;
   private float stepAnim = 1.0F;
   private float shownStep;
   private final OptimizationScreen opt;
   private int hudLayout = 1;
   private static final int STEPS = 6;
   private static final String[][] LAYOUTS = new String[][]{
      {"watermark", "coords", "fps"},
      {"watermark", "array_list", "coords", "keystrokes", "armor", "potions", "fps", "combo", "target_hud", "item_counter", "death_coords"},
      {"watermark", "array_list", "coords", "keystrokes", "armor", "potions", "fps", "ping", "cps", "combo", "target_hud", "item_counter", "death_coords"},
      {
            "watermark",
            "array_list",
            "coords",
            "compass",
            "keystrokes",
            "armor",
            "potions",
            "fps",
            "ping",
            "cps",
            "clock",
            "memory",
            "biome",
            "session_timer",
            "speed",
            "combo",
            "target_hud",
            "item_counter",
            "death_coords",
            "light_level"
      }
   };

   public WizardScreen(class_437 parent) {
      super(class_2561.method_43470("MrBean Visuals"));
      this.parent = parent;
      this.opt = new OptimizationScreen(parent);
   }

   public boolean method_25421() {
      return false;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.ui.begin(context, mouseX, mouseY);
      int w = Math.min(470, this.field_22789 - 20);
      int h = Math.min(330, this.field_22790 - 20);
      int x = (this.field_22789 - w) / 2;
      int y = (this.field_22790 - h) / 2;
      R2D.panel(context, x, y, w, h, 12, -233893609, true, 587202559);
      R2D.accentBar(context, x + 10, y, w - 20, 1);
      String[] names = new String[]{
         Lang.t("Тема", "Theme"), Lang.t("Скорость", "Performance"), Lang.t("Моды", "Mods"), "HUD", Lang.t("Косметика", "Cosmetics"), Lang.t("Готово", "Done")
      };
      int px = x + 16;
      int pw = w - 32;
      this.shownStep = R2D.approach(this.shownStep, this.step, 0.25F);
      R2D.round(context, px, y + 14, pw, 3, 1, 822083583);
      R2D.round(context, px, y + 14, Math.max(3, (int)(pw * this.shownStep / 5.0F)), 3, 1, R2D.accent(0.0F));

      for (int i = 0; i < 6; i++) {
         int cx = px + pw * i / 5;
         boolean done = i <= this.step;
         R2D.circle(context, cx, y + 15, 5, done ? R2D.accent(i * 0.1F) : -14012868);
         R2D.textScaled(context, names[i], cx - R2D.width(names[i]) * 0.35F, y + 23, 0.7F, i == this.step ? -1 : -9735802, false);
      }

      this.stepAnim = R2D.approach(this.stepAnim, 1.0F, 0.2F);
      int cy = y + 38;
      int ch = h - 38 - 30;
      context.method_51448().pushMatrix();
      context.method_51448().translate((1.0F - this.stepAnim) * 20.0F, 0.0F);
      float a = R2D.alpha;
      R2D.alpha = this.stepAnim;
      switch (this.step) {
         case 0:
            this.stepTheme(context, x + 16, cy, w - 32, ch);
            break;
         case 1:
            this.stepPerformance(context, x + 16, cy, w - 32, ch);
            break;
         case 2:
            this.opt.drawBody(this.ui, context, x + 16, cy, w - 32, ch, false);
            break;
         case 3:
            this.stepHud(context, x + 16, cy, w - 32, ch);
            break;
         case 4:
            this.stepCosmetics(context, x + 16, cy, w - 32, ch);
            break;
         default:
            this.stepDone(context, x + 16, cy, w - 32, ch);
      }

      R2D.alpha = a;
      context.method_51448().popMatrix();
      int by = y + h - 24;
      if (this.step > 0 && this.ui.button("w_back", x + 16, by, 70, 16, "‹ " + Lang.ui("ui.back"), 0)) {
         this.go(this.step - 1);
      }

      if (this.step < 5) {
         if (this.ui.button("w_skip", x + w - 186, by, 80, 16, Lang.ui("ui.skip"), 2)) {
            this.finish();
         }

         if (this.ui.button("w_next", x + w - 100, by, 84, 16, Lang.ui("ui.next") + " ›", 1)) {
            this.go(this.step + 1);
         }
      } else if (this.ui.button("w_finish", x + w - 120, by, 104, 16, "✔ " + Lang.ui("ui.finish"), 1)) {
         this.finish();
      }

      this.ui.end();
   }

   private void go(int s) {
      this.step = Math.max(0, Math.min(5, s));
      this.stepAnim = 0.0F;
      this.ui.closeOverlay();
      if (this.step == 2 && OptMods.entries.isEmpty()) {
         OptMods.check();
      }
   }

   private void title(class_332 ctx, int x, int y, String t, String sub) {
      R2D.textScaled(ctx, t, x, y, 1.35F, -1, false);
      int yy = y + 16;

      for (String l : Ui.wrap(sub, 420)) {
         R2D.text(ctx, l, x, yy, -6643532, false);
         yy += 10;
      }
   }

   private void stepTheme(class_332 ctx, int x, int y, int w, int h) {
      this.title(
         ctx,
         x,
         y,
         Lang.ui("ui.welcome"),
         Lang.t(
            "Выбери оформление. Его всегда можно поменять в меню (правый Shift) → «Темы».",
            "Pick a look. You can change it any time in the menu (Right Shift) → Themes."
         )
      );
      int li = this.ui.segmented("w_lang", x + w - 130, y, 130, new String[]{"Русский", "English"}, Lang.english ? 1 : 0);
      if (li == 1 != Lang.english) {
         Lang.english = li == 1;
      }

      ThemeModule t = Modules.theme();
      int cols = 4;
      int gap = 6;
      int cw = (w - gap * 3) / cols;
      int chh = 40;
      int yy = y + 40;
      int saved = t.preset.index;

      for (int i = 0; i < t.preset.ids.length; i++) {
         int cx = x + i % cols * (cw + gap);
         int cyy = yy + i / cols * (chh + gap);
         t.preset.index = i;
         int c1 = t.accent(0.0F);
         int c2 = t.accent(0.5F);
         t.preset.index = saved;
         boolean sel = i == saved;
         R2D.round(ctx, cx, cyy, cw, chh, 8, this.ui.hover(cx, cyy, cw, chh) ? this.ui.panelHover() : this.ui.panelColor());
         R2D.hGradient(ctx, cx + 6, cyy + 6, cw - 12, 12, c1, c2);
         R2D.text(ctx, t.preset.label(i), cx + 6, cyy + 25, sel ? -1 : -6643532, false);
         if (sel) {
            R2D.outline(ctx, cx, cyy, cw, chh, 8, R2D.accent(0.0F));
         }

         if (this.ui.clicked(cx, cyy, cw, chh)) {
            t.preset.index = i;
            saved = i;
         }
      }

      int ay = yy + 2 * (chh + gap) + 4;
      R2D.text(ctx, Lang.t("Анимации интерфейса", "UI animations"), x, ay + 2, -1183755, false);
      t.animations.value = this.ui.toggle("w_anim", x + w - 22, ay, t.animations.value);
      R2D.text(ctx, Lang.t("Размытие фона в меню", "Menu background blur"), x, ay + 20, -1183755, false);
      t.blur.value = this.ui.toggle("w_blur", x + w - 22, ay + 18, t.blur.value);
   }

   private void stepPerformance(class_332 ctx, int x, int y, int w, int h) {
      this.title(
         ctx,
         x,
         y,
         Lang.t("Производительность", "Performance"),
         Lang.t(
            "Выбери баланс между FPS и красотой. Можно включить автоподбор — мод сам замерит FPS через 15 секунд игры.",
            "Choose between FPS and visuals. Auto mode measures your FPS after 15 seconds and picks a preset."
         )
      );
      PerformanceModule p = (PerformanceModule)Modules.get("performance");
      String[][] info = new String[][]{
         {Lang.t("Максимум FPS", "Maximum FPS"), Lang.t("Для слабых ПК: без шейдеров и атмосферных частиц", "For weak PCs: no shaders or ambient particles")},
         {Lang.t("Баланс", "Balanced"), Lang.t("Рекомендуется: красиво и быстро", "Recommended: pretty and fast")},
         {Lang.t("Красиво", "Beautiful"), Lang.t("Цветокоррекция, виньетка, больше частиц", "Color grading, vignette, more particles")},
         {Lang.t("Ультра-визуалы", "Ultra Visuals"), Lang.t("Всё включено, включая свечение (Bloom)", "Everything on, including bloom")}
      };
      int yy = y + 42;

      for (int i = 0; i < info.length; i++) {
         boolean sel = p.preset.index == i;
         int cy = yy + i * 30;
         R2D.round(ctx, x, cy, w, 26, 7, this.ui.hover(x, cy, w, 26) ? this.ui.panelHover() : this.ui.panelColor());
         if (sel) {
            R2D.outline(ctx, x, cy, w, 26, 7, R2D.accent(0.0F));
         }

         R2D.circle(ctx, x + 12, cy + 13, 4, sel ? R2D.accent(0.0F) : -12960176);
         R2D.text(ctx, info[i][0], x + 24, cy + 4, -1, false);
         R2D.textScaled(ctx, info[i][1], x + 24, cy + 15, 0.75F, -6643532, false);
         if (this.ui.clicked(x, cy, w, 26)) {
            p.preset.index = i;
            p.applyPreset(false);
         }
      }

      yy += 124;
      R2D.text(ctx, Lang.t("Автоподбор по FPS", "Automatic preset"), x, yy + 2, -1183755, false);
      p.auto.value = this.ui.toggle("w_auto", x + w - 22, yy, p.auto.value);
      R2D.text(ctx, Lang.t("Режим слабого ПК", "Low-performance mode"), x, yy + 20, -1183755, false);
      p.lowEnd.value = this.ui.toggle("w_low", x + w - 22, yy + 18, p.lowEnd.value);
   }

   private void stepHud(class_332 ctx, int x, int y, int w, int h) {
      this.title(
         ctx,
         x,
         y,
         "HUD",
         Lang.t(
            "Выбери набор элементов на экране. Потом их можно двигать в «Редакторе HUD».", "Pick a HUD layout. You can move elements later in the HUD Editor."
         )
      );
      String[] names = new String[]{Lang.t("Минимальный", "Minimal"), Lang.t("Стандартный", "Standard"), "PvP", Lang.t("Полный", "Full")};
      int idx = this.ui.segmented("w_hud", x, y + 40, w, names, this.hudLayout);
      if (idx != this.hudLayout) {
         this.hudLayout = idx;
      }

      Set<String> on = Set.of(LAYOUTS[this.hudLayout]);
      int yy = y + 64;
      int cols = 3;
      int cw = (w - 12) / cols;
      int n = 0;

      for (Module m : Modules.all()) {
         if (m instanceof HudModule && on.contains(m.id)) {
            int cx = x + n % cols * (cw + 6);
            int cy = yy + n / cols * 14;
            R2D.text(ctx, "§a✔ §f" + m.name(), cx, cy, -1, false);
            n++;
         }
      }

      int by = yy + (n + cols - 1) / cols * 14 + 8;
      if (this.ui.button("w_apply_hud", x, by, 150, 16, Lang.t("Применить набор", "Apply layout"), 1)) {
         this.applyHud();
      }

      if (this.field_22787.field_1687 != null && this.ui.button("w_hud_editor", x + 156, by, 150, 16, "✥ " + Lang.ui("ui.hud_editor"), 0)) {
         this.applyHud();
         this.field_22787.method_1507(Screens.hudEditor(this));
      }
   }

   private void applyHud() {
      Set<String> on = Set.of(LAYOUTS[this.hudLayout]);

      for (Module m : Modules.all()) {
         if (m instanceof HudModule hm) {
            hm.setEnabled(on.contains(m.id));
         }
      }

      Notifications.push(Lang.t("HUD-набор применён", "HUD layout applied"), true);
   }

   private void stepCosmetics(class_332 ctx, int x, int y, int w, int h) {
      this.title(
         ctx,
         x,
         y,
         Lang.t("Косметика", "Cosmetics"),
         Lang.t(
            "Включи то, что нравится. Видно только у тебя на экране — игре и серверам это не мешает.",
            "Turn on what you like. Client-side only — it does not affect gameplay or servers."
         )
      );
      String[] ids = new String[]{
         "china_hat", "halo", "crown", "angel_wings", "devil_wings", "cape", "aura", "companion", "trail", "move_particles", "nameplate"
      };
      int lw = this.field_22787.field_1724 != null ? w - 130 : w;
      int yy = y + 40;

      for (String id : ids) {
         Module m = Modules.get(id);
         if (m != null) {
            R2D.text(ctx, m.name(), x, yy + 2, m.isEnabled() ? -1 : -6643532, false);
            boolean nv = this.ui.toggle("w_c:" + id, x + lw - 26, yy, m.isEnabled());
            if (nv != m.isEnabled()) {
               m.setEnabled(nv);
            }

            yy += 16;
         }
      }

      if (this.field_22787.field_1724 != null) {
         float yaw = (float)(System.currentTimeMillis() % 12000L) / 12000.0F * 360.0F;
         int ox = (int)ctx.method_51448().m20();
         int oy = (int)ctx.method_51448().m21();
         R2D.round(ctx, x + w - 120, y + 40, 120, 170, 8, 1073741824);
         CosmeticPreview.draw(ctx, x + w - 120 + ox, y + 44 + oy, x + w + ox, y + 206 + oy, 42.0F, yaw, null);
      }
   }

   private void stepDone(class_332 ctx, int x, int y, int w, int h) {
      this.title(ctx, x, y, Lang.t("Всё готово!", "All set!"), Lang.t("MrBean Visuals настроен. Главные клавиши:", "MrBean Visuals is ready. Main keys:"));
      String[][] keys = new String[][]{
         {"Правый Shift", Lang.t("меню мода", "mod menu")},
         {"C", Lang.t("зум (колёсико — сила)", "zoom (scroll to adjust)")},
         {Lang.t("Редактор HUD", "HUD Editor"), Lang.t("кнопка в меню", "button in the menu")}
      };
      int yy = y + 40;

      for (String[] k : keys) {
         int kw = R2D.width(k[0]) + 12;
         R2D.round(ctx, x, yy, kw, 14, 4, -14671058);
         R2D.text(ctx, k[0], x + 6, yy + 3, R2D.accent(0.0F), false);
         R2D.text(ctx, k[1], x + kw + 8, yy + 3, -1183755, false);
         yy += 20;
      }

      if (OptMods.restartNeeded) {
         R2D.text(ctx, "⚠ " + Lang.ui("ui.restart_needed"), x, yy + 6, -11174, false);
      }
   }

   private void finish() {
      Config.firstRunDone = true;
      Config.save();
      this.field_22787.method_1507(this.parent);
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      if (input.comp_4795() == 256) {
         if (this.ui.overlayOpen()) {
            this.ui.closeOverlay();
         } else {
            this.finish();
         }

         return true;
      } else {
         return super.method_25404(input);
      }
   }
}
