package com.mrbean.visuals.gui.ui;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Sounds;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.lwjgl.glfw.GLFW;

public final class Ui {
   private final class_310 mc = class_310.method_1551();
   public class_332 ctx;
   public double mx;
   public double my;
   public boolean mouseDown;
   private boolean clickPending;
   private int clickButton;
   private double clickX;
   private double clickY;
   private boolean overlayGetsClick;
   public String focus;
   private final List<Character> chars = new ArrayList<>();
   private final List<Integer> keys = new ArrayList<>();
   public String drag;
   private final Map<String, Float> anims = new HashMap<>();
   public String overlayId;
   private int[] overlayRect = new int[4];
   private int[] overlayRectNext;
   private Consumer<Ui> overlayDraw;
   private String tooltip;
   public int screenW = -1;
   public double scroll;
   private final float[] hsv = new float[3];
   private boolean inOverlay;
   public static final int TEXT = -1183755;
   public static final int MUTED = -6643532;
   public static final int DIM = -9735802;

   public List<Character> chars() {
      return this.chars;
   }

   public List<Integer> keys() {
      return this.keys;
   }

   public void begin(class_332 ctx, double mx, double my) {
      this.ctx = ctx;
      this.mx = mx;
      this.my = my;
      this.tooltip = null;
      this.overlayRectNext = null;
      this.overlayGetsClick = false;
      if (this.clickPending && this.overlayId != null) {
         if (R2D.inside(this.clickX, this.clickY, this.overlayRect[0], this.overlayRect[1], this.overlayRect[2], this.overlayRect[3])) {
            this.overlayGetsClick = true;
         } else {
            this.overlayId = null;
            this.overlayDraw = null;
            this.clickPending = false;
         }
      }
   }

   public void end() {
      if (this.overlayId != null && this.overlayDraw != null) {
         this.ctx.method_51448().pushMatrix();
         this.overlayDraw.accept(this);
         this.ctx.method_51448().popMatrix();
         if (this.overlayRectNext != null) {
            this.overlayRect = this.overlayRectNext;
         }
      }

      if (this.tooltip != null && this.drag == null) {
         List<String> lines = wrap(this.tooltip, 210);
         int w = 0;

         for (String l : lines) {
            w = Math.max(w, R2D.width(l));
         }

         w += 10;
         int h = lines.size() * 10 + 6;
         int sw = this.screenW > 0 ? this.screenW : this.ctx.method_51421();
         int x = (int)Math.max(2.0, Math.min(this.mx + 10.0, (double)(sw - w - 4)));
         int y = (int)Math.max(2.0, this.my - h - 4.0);
         R2D.panel(this.ctx, x, y, w, h, 4, -267382248, true, R2D.withAlpha(R2D.accent(0.0F), 120));

         for (int i = 0; i < lines.size(); i++) {
            R2D.text(this.ctx, lines.get(i), x + 5, y + 4 + i * 10, -2038804, false);
         }
      }

      this.clickPending = false;
      Sounds.flush();
      this.chars.clear();
      this.keys.clear();
      this.scroll = 0.0;
   }

   public static List<String> wrap(String s, int width) {
      List<String> out = new ArrayList<>();
      StringBuilder line = new StringBuilder();

      for (String word : s.split(" ")) {
         if (line.length() > 0 && R2D.width(line + " " + word) > width) {
            out.add(line.toString());
            line.setLength(0);
         }

         if (line.length() > 0) {
            line.append(' ');
         }

         line.append(word);
      }

      if (line.length() > 0) {
         out.add(line.toString());
      }

      return out;
   }

   public void offsetY(double d) {
      this.my += d;
      this.clickY += d;
   }

   public void onClick(double x, double y, int button) {
      this.clickPending = true;
      this.clickX = x;
      this.clickY = y;
      this.clickButton = button;
      if (button == 0) {
         this.mouseDown = true;
      }
   }

   public void onRelease() {
      this.mouseDown = false;
      if (this.drag != null) {
         Config.markDirty();
      }

      this.drag = null;
   }

   public void onChar(char c) {
      this.chars.add(c);
   }

   public void onKey(int key) {
      this.keys.add(key);
   }

   public void onScroll(double v) {
      this.scroll += v;
   }

   public boolean overlayOpen() {
      return this.overlayId != null;
   }

   public void closeOverlay() {
      this.overlayId = null;
      this.overlayDraw = null;
   }

   public boolean hover(int x, int y, int w, int h) {
      return this.overlayId != null
            && R2D.inside(this.mx, this.my, this.overlayRect[0], this.overlayRect[1], this.overlayRect[2], this.overlayRect[3])
            && !this.inOverlay
         ? false
         : R2D.inside(this.mx, this.my, x, y, w, h);
   }

   public boolean clicked(int x, int y, int w, int h) {
      return this.clickedBtn(x, y, w, h, 0);
   }

   public boolean rightClicked(int x, int y, int w, int h) {
      return this.clickedBtn(x, y, w, h, 1);
   }

   private boolean clickedBtn(int x, int y, int w, int h, int btn) {
      if (!this.clickPending || this.clickButton != btn) {
         return false;
      } else if (this.overlayGetsClick != this.inOverlay) {
         return false;
      } else if (!R2D.inside(this.clickX, this.clickY, x, y, w, h)) {
         return false;
      } else {
         this.clickPending = false;
         this.sound();
         return true;
      }
   }

   public boolean pressedIn(int x, int y, int w, int h) {
      if (!this.clickPending || this.clickButton != 0 || this.overlayGetsClick != this.inOverlay) {
         return false;
      } else if (!R2D.inside(this.clickX, this.clickY, x, y, w, h)) {
         return false;
      } else {
         this.clickPending = false;
         return true;
      }
   }

   public void sound() {
      Sounds.click();
   }

   public float anim(String id, float target, float speed) {
      float v = this.anims.getOrDefault(id, target);
      v = R2D.approach(v, target, speed);
      this.anims.put(id, v);
      return v;
   }

   public void setAnim(String id, float v) {
      this.anims.put(id, v);
   }

   public void tooltip(String s) {
      this.tooltip = s;
   }

   public int panelColor() {
      return Modules.theme().panel();
   }

   public int panelHover() {
      return Modules.theme().panelHover();
   }

   public boolean button(String id, int x, int y, int w, int h, String label, int style) {
      boolean hov = this.hover(x, y, w, h);
      float t = this.anim("btn:" + id, hov ? 1.0F : 0.0F, 0.3F);
      int bg;
      switch (style) {
         case 1:
            R2D.round(this.ctx, x, y, w, h, 5, R2D.accent(0.0F));
            if (t > 0.0F) {
               R2D.round(this.ctx, x, y, w, h, 5, R2D.withAlpha(-1, (int)(40.0F * t)));
            }

            R2D.text(this.ctx, label, x + w / 2 - R2D.width(label) / 2, y + h / 2 - 4, -15921134, false);
            return this.clicked(x, y, w, h);
         case 2:
            bg = R2D.withAlpha(-1, (int)(18.0F * t));
            break;
         case 3:
            bg = R2D.lerp(this.panelColor(), -10871258, t);
            break;
         default:
            bg = R2D.lerp(this.panelColor(), this.panelHover(), t);
      }

      R2D.round(this.ctx, x, y, w, h, 5, bg);
      if (style != 2) {
         R2D.outline(this.ctx, x, y, w, h, 5, R2D.lerp(419430399, R2D.withAlpha(style == 3 ? -42396 : R2D.accent(0.0F), 160), t));
      }

      R2D.text(this.ctx, label, x + w / 2 - R2D.width(label) / 2, y + h / 2 - 4, style == 3 ? R2D.lerp(-1183755, -34172, t) : -1183755, false);
      return this.clicked(x, y, w, h);
   }

   public boolean toggle(String id, int x, int y, boolean value) {
      int w = 22;
      int h = 12;
      float t = this.anim("tg:" + id, value ? 1.0F : 0.0F, 0.35F);
      boolean hov = this.hover(x - 2, y - 2, w + 4, h + 4);
      R2D.round(this.ctx, x, y, w, h, 6, R2D.lerp(-12960176, R2D.accent(0.0F), t));
      if (hov) {
         R2D.round(this.ctx, x, y, w, h, 6, 419430399);
      }

      R2D.circle(this.ctx, (int)(x + 6 + (w - 12) * t), y + 6, 4, -1);
      return this.clicked(x - 2, y - 2, w + 4, h + 4) ? !value : value;
   }

   public void slider(String id, int x, int y, int w, Setting.Num s) {
      boolean hov = this.hover(x - 2, y - 4, w + 4, 12);
      if (this.pressedIn(x - 3, y - 5, w + 6, 14)) {
         this.drag = id;
      }

      if (id.equals(this.drag)) {
         if (!this.mouseDown) {
            this.drag = null;
         } else {
            s.set(s.min + (s.max - s.min) * Math.max(0.0, Math.min(1.0, (this.mx - x) / w)));
         }
      }

      if (hov && this.scroll != 0.0 && GLFW.glfwGetKey(this.mc.method_22683().method_4490(), 340) == 1) {
         s.set(s.value + Math.signum(this.scroll) * s.step);
         this.scroll = 0.0;
         Config.markDirty();
      }

      float f = (float)s.frac();
      float t = this.anim("sl:" + id, !hov && !id.equals(this.drag) ? 0.0F : 1.0F, 0.3F);
      R2D.round(this.ctx, x, y, w, 3, 1, -12960176);
      int fw = Math.max(3, (int)(w * f));

      for (int i = 0; i < fw; i += 2) {
         R2D.rect(this.ctx, x + i, y, Math.min(2, fw - i), 3, R2D.accent((float)i / w * 0.5F));
      }

      int kr = 3 + (int)(t * 1.5F);
      if (t > 0.0F) {
         R2D.circle(this.ctx, x + (int)(w * f), y + 1, kr + 3, R2D.withAlpha(R2D.accent(0.0F), (int)(50.0F * t)));
      }

      R2D.circle(this.ctx, x + (int)(w * f), y + 1, kr, -1);
   }

   public void dropdown(String id, int x, int y, int w, Setting.Mode m) {
      boolean open = id.equals(this.overlayId);
      boolean hov = this.hover(x, y, w, 14);
      float t = this.anim("dd:" + id, !hov && !open ? 0.0F : 1.0F, 0.3F);
      R2D.round(this.ctx, x, y, w, 14, 4, R2D.lerp(this.panelColor(), this.panelHover(), t));
      R2D.outline(this.ctx, x, y, w, 14, 4, open ? R2D.accent(0.0F) : R2D.lerp(419430399, 1090519039, t));
      String label = m.label();

      while (R2D.width(label) > w - 16 && label.length() > 2) {
         label = label.substring(0, label.length() - 2);
      }

      R2D.text(this.ctx, label, x + 5, y + 3, -1183755, false);
      R2D.text(this.ctx, open ? "▴" : "▾", x + w - 9, y + 3, -6643532, false);
      if (this.clicked(x, y, w, 14)) {
         if (open) {
            this.closeOverlay();
            return;
         }

         this.overlayId = id;
         int oy = y + 16;
         int ow = Math.max(w, 90);
         int itemH = 13;
         int max = Math.min(m.ids.length, 9);
         this.overlayRect = new int[]{x, oy, ow, max * 13 + 4};
         double[] scrollOff = new double[]{Math.max(0, m.index - max + 1)};
         this.overlayDraw = ui -> {
            int sh = ui.ctx.method_51443();
            int h = max * 13 + 4;
            int oy2 = oy + h > sh - 4 ? y - h - 2 : oy;
            ui.overlayRectNext = new int[]{x, oy2, ow, h};
            ui.inOverlay = true;
            R2D.panel(ui.ctx, x, oy2, ow, h, 5, -166455776, true, R2D.withAlpha(R2D.accent(0.0F), 140));
            if (ui.scroll != 0.0 && R2D.inside(ui.mx, ui.my, x, oy2, ow, h)) {
               scrollOff[0] = Math.max(0.0, Math.min((double)(m.ids.length - max), scrollOff[0] - Math.signum(ui.scroll)));
               ui.scroll = 0.0;
            }

            int start = (int)scrollOff[0];

            for (int i = start; i < Math.min(m.ids.length, start + max); i++) {
               int iy = oy2 + 2 + (i - start) * 13;
               boolean hv = R2D.inside(ui.mx, ui.my, x + 2, iy, ow - 4, 13);
               if (hv) {
                  R2D.round(ui.ctx, x + 2, iy, ow - 4, 13, 3, 587202559);
               }

               if (i == m.index) {
                  R2D.rect(ui.ctx, x + 3, iy + 3, 2, 7, R2D.accent(0.0F));
               }

               R2D.text(ui.ctx, m.label(i), x + 8, iy + 3, i == m.index ? R2D.accent(0.0F) : -1183755, false);
               if (ui.clicked(x + 2, iy, ow - 4, 13)) {
                  m.index = i;
                  Config.markDirty();
                  ui.closeOverlay();
                  break;
               }
            }

            ui.inOverlay = false;
         };
      }
   }

   public void colorButton(String id, int x, int y, Setting.Color c) {
      boolean open = id.equals(this.overlayId);
      R2D.round(this.ctx, x, y, 22, 12, 4, -14671058);
      R2D.round(this.ctx, x + 1, y + 1, 20, 10, 3, c.argb | (c.alpha ? 0 : -16777216));
      R2D.outline(this.ctx, x, y, 22, 12, 4, open ? R2D.accent(0.0F) : 1090519039);
      if (this.clicked(x - 2, y - 2, 26, 16)) {
         if (open) {
            this.closeOverlay();
            return;
         }

         this.overlayId = id;
         R2D.rgbToHsb(c.argb >> 16 & 0xFF, c.argb >> 8 & 0xFF, c.argb & 0xFF, this.hsv);
         float[] h = new float[]{this.hsv[0], this.hsv[1], this.hsv[2]};
         int pw = 130;
         int ph = c.alpha ? 128 : 116;
         int sw = this.ctx.method_51421();
         int sh = this.ctx.method_51443();
         int ox = Math.min(sw - 130 - 4, x - 130 + 22);
         int oy = y + 16 + ph > sh ? y - ph - 4 : y + 16;
         this.overlayRect = new int[]{ox, oy, 130, ph};
         String[] dragPart = new String[]{null};
         this.overlayDraw = ui -> {
            ui.inOverlay = true;
            class_332 g = ui.ctx;
            R2D.panel(g, ox, oy, 130, ph, 6, -166455776, true, R2D.withAlpha(R2D.accent(0.0F), 140));
            int sx = ox + 6;
            int sy = oy + 6;
            int sw2 = 118;
            int sh2 = 64;

            for (int i = 0; i < sw2; i++) {
               int top = R2D.hsv(h[0], (float)i / sw2, 1.0F);
               g.method_25296(sx + i, sy, sx + i + 1, sy + sh2, top, -16777216);
            }

            R2D.ringCircle(g, sx + (int)(h[1] * sw2), sy + (int)((1.0F - h[2]) * sh2), 3, -1);
            int hy = sy + sh2 + 5;

            for (int i = 0; i < sw2; i++) {
               R2D.rect(g, sx + i, hy, 1, 7, R2D.hsv((float)i / sw2, 1.0F, 1.0F));
            }

            R2D.rect(g, sx + (int)(h[0] * sw2) - 1, hy - 1, 2, 9, -1);
            int ay = hy + 11;
            if (c.alpha) {
               for (int i = 0; i < sw2; i++) {
                  R2D.rect(g, sx + i, ay, 1, 7, R2D.lerp(-14671840, c.argb | 0xFF000000, (float)i / sw2));
               }

               R2D.rect(g, sx + (int)((c.argb >>> 24) / 255.0F * sw2) - 1, ay - 1, 2, 9, -1);
               ay += 11;
            }

            int[] presets = new int[]{R2D.accent(0.0F), Modules.theme().c2(), -1, -15658735, -42396, -20448, -7078, -11870592, -14494738, -7643914};

            for (int i = 0; i < presets.length; i++) {
               int px = sx + i * 12;
               R2D.round(g, px, ay, 10, 10, 3, presets[i]);
               if (ui.clicked(px, ay, 10, 10)) {
                  int a = c.argb & 0xFF000000;
                  c.argb = presets[i] & 16777215 | (c.alpha ? a : -16777216);
                  R2D.rgbToHsb(c.argb >> 16 & 0xFF, c.argb >> 8 & 0xFF, c.argb & 0xFF, h);
                  Config.markDirty();
               }
            }

            R2D.text(g, String.format("#%06X", c.argb & 16777215), sx, ay + 13, -6643532, false);
            if (ui.pressedIn(sx, sy, sw2, sh2)) {
               dragPart[0] = "sv";
            } else if (ui.pressedIn(sx, hy - 1, sw2, 9)) {
               dragPart[0] = "h";
            } else if (c.alpha && ui.pressedIn(sx, hy + 10, sw2, 9)) {
               dragPart[0] = "a";
            }

            if (dragPart[0] != null) {
               if (!ui.mouseDown) {
                  dragPart[0] = null;
                  Config.markDirty();
               } else {
                  float fx = (float)Math.max(0.0, Math.min(1.0, (ui.mx - sx) / sw2));
                  String var23 = dragPart[0];
                  switch (var23) {
                     case "sv":
                        h[1] = fx;
                        h[2] = 1.0F - (float)Math.max(0.0, Math.min(1.0, (ui.my - sy) / sh2));
                        break;
                     case "h":
                        h[0] = fx;
                        break;
                     case "a":
                        c.argb = c.argb & 16777215 | (int)(fx * 255.0F) << 24;
                  }

                  if (!dragPart[0].equals("a")) {
                     int rgb = R2D.hsbToRgb(h[0], h[1], h[2]) & 16777215;
                     c.argb = (c.alpha ? c.argb & 0xFF000000 : -16777216) | rgb;
                  }
               }
            }

            ui.inOverlay = false;
         };
      }
   }

   public String textField(String id, int x, int y, int w, String value, String placeholder, int maxLen) {
      boolean focused = id.equals(this.focus);
      boolean hov = this.hover(x, y, w, 14);
      R2D.round(this.ctx, x, y, w, 14, 4, -15395041);
      R2D.outline(this.ctx, x, y, w, 14, 4, focused ? R2D.accent(0.0F) : (hov ? 1358954495 : 587202559));
      if (this.clicked(x, y, w, 14)) {
         this.focus = id;
      } else if (this.clickPending && focused && this.clickButton == 0) {
         this.focus = null;
      }

      String v = value;
      if (focused) {
         for (char ch : this.chars) {
            if (v.length() < maxLen && ch >= ' ') {
               v = v + ch;
            }
         }

         for (int k : this.keys) {
            if (k == 259 && !v.isEmpty()) {
               v = v.substring(0, v.length() - 1);
            }

            if (k == 257 || k == 335) {
               this.focus = null;
            }
         }

         if (!v.equals(value)) {
            Config.markDirty();
         }
      }

      String shown = v;

      while (R2D.width(shown) > w - 10 && shown.length() > 1) {
         shown = shown.substring(1);
      }

      this.ctx.method_44379(x + 2, y, x + w - 2, y + 14);
      if (v.isEmpty() && !focused) {
         R2D.text(this.ctx, placeholder, x + 5, y + 3, -9735802, false);
      } else {
         R2D.text(this.ctx, shown, x + 5, y + 3, -1183755, false);
      }

      if (focused && System.currentTimeMillis() / 500L % 2L == 0L) {
         R2D.rect(this.ctx, x + 6 + R2D.width(shown), y + 3, 1, 9, R2D.accent(0.0F));
      }

      this.ctx.method_44380();
      return v;
   }

   public int segmented(String id, int x, int y, int w, String[] items, int selected) {
      int h = 16;
      R2D.round(this.ctx, x, y, w, h, 5, -15395041);
      float iw = (float)w / items.length;
      float a = this.anim("seg:" + id, selected, 0.3F);
      R2D.round(this.ctx, (int)(x + 2 + iw * a), y + 2, (int)iw - 4, h - 4, 4, R2D.accent(0.0F));
      int res = selected;

      for (int i = 0; i < items.length; i++) {
         int ix = (int)(x + iw * i);
         boolean sel = Math.abs(a - i) < 0.5F;
         String l = items[i];

         while (R2D.width(l) > iw - 6.0F && l.length() > 2) {
            l = l.substring(0, l.length() - 2);
         }

         R2D.text(this.ctx, l, ix + (int)iw / 2 - R2D.width(l) / 2, y + 4, sel ? -15921134 : -6643532, false);
         if (this.clicked(ix, y, (int)iw, h)) {
            res = i;
         }
      }

      return res;
   }

   public int settingRow(String prefix, Setting s, int x, int y, int w) {
      String id = prefix + s.id;
      int h;
      if (s instanceof Setting.Num n) {
         R2D.text(this.ctx, n.name(), x, y + 1, -1183755, false);
         String v = n.display();
         R2D.text(this.ctx, v, x + w - R2D.width(v), y + 1, R2D.accent(0.0F), false);
         this.slider(id, x, y + 13, w, n);
         h = 22;
      } else if (s instanceof Setting.Bool b) {
         R2D.text(this.ctx, b.name(), x, y + 2, -1183755, false);
         boolean nv = this.toggle(id, x + w - 22, y, b.value);
         if (nv != b.value) {
            b.value = nv;
            Config.markDirty();
         }

         h = 16;
      } else if (s instanceof Setting.Mode m) {
         R2D.text(this.ctx, m.name(), x, y + 3, -1183755, false);
         int dw = Math.min(120, w / 2);
         this.dropdown(id, x + w - dw, y, dw, m);
         h = 18;
      } else if (s instanceof Setting.Color c) {
         R2D.text(this.ctx, c.name(), x, y + 2, -1183755, false);
         this.colorButton(id, x + w - 22, y, c);
         h = 16;
      } else if (s instanceof Setting.Text t) {
         R2D.text(this.ctx, t.name(), x, y + 3, -1183755, false);
         int tw = Math.min(170, w * 2 / 3);
         t.value = this.textField(id, x + w - tw, y, tw, t.value, "", t.maxLen);
         h = 18;
      } else if (s instanceof Setting.Key k) {
         R2D.text(this.ctx, k.name(), x, y + 3, -1183755, false);
         this.keyField(id, x, y, w, k);
         h = 18;
      } else if (s instanceof Setting.Action a) {
         if (this.button(id, x, y, w, 15, a.name(), 0)) {
            a.run.run();
         }

         h = 19;
      } else {
         h = 0;
      }

      return h;
   }

   public void keyField(String id, int x, int y, int w, Setting.Key k) {
      boolean focused = id.equals(this.focus);
      if (focused) {
         Iterator label = this.keys.iterator();
         if (label.hasNext()) {
            int key = (Integer)label.next();
            if (key != 259 && key != 261) {
               k.value = key;
            } else {
               k.value = -1;
            }

            this.focus = null;
            Config.markDirty();
            Sounds.play(Sounds.ON);
         }

         if (this.focus != null && this.clickPending && this.clickButton >= 2) {
            k.value = 1000 + this.clickButton;
            this.focus = null;
            Config.markDirty();
            this.clickPending = false;
         }
      }

      String labelx = id.equals(this.focus) ? L("Нажмите клавишу…", "Press a key…") : k.display();
      int cw = Math.max(46, R2D.width(labelx) + 14);
      int cx = x + w - cw;
      boolean hov = this.hover(cx, y, cw, 14);
      R2D.round(this.ctx, cx, y, cw, 14, 4, id.equals(this.focus) ? R2D.withAlpha(R2D.accent(0.0F), 90) : (hov ? 1090519039 : 587202559));
      R2D.text(this.ctx, labelx, cx + cw / 2 - R2D.width(labelx) / 2, y + 3, k.value < 0 && !id.equals(this.focus) ? -9735802 : -1183755, false);
      if (hov) {
         this.tooltip(L("Клик — назначить (клавиша или боковая кнопка мыши). Backspace — убрать", "Click to bind (key or side mouse button). Backspace clears"));
      }

      if (this.clicked(cx, y, cw, 14)) {
         this.focus = id;
      } else if (id.equals(this.focus) && this.clickPending && this.clickButton == 0) {
         this.focus = null;
      } else if (hov && this.clickPending && this.clickButton == 1) {
         k.value = -1;
         Config.markDirty();
      }
   }

   public static String L(String ru, String en) {
      return Lang.t(ru, en);
   }
}
