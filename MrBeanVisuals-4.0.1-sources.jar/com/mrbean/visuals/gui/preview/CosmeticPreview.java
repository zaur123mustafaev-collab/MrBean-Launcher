package com.mrbean.visuals.gui.preview;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mrbean.visuals.mixin.DrawContextAccessor;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.cosmetic.PlayerCosmetic;
import com.mrbean.visuals.render.World3D;
import java.util.UUID;
import net.fabricmc.fabric.api.client.rendering.v1.SpecialGuiElementRegistry;
import net.minecraft.class_1068;
import net.minecraft.class_11239;
import net.minecraft.class_11256;
import net.minecraft.class_2960;
import net.minecraft.class_308.class_11274;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_4608;
import net.minecraft.class_5601;
import net.minecraft.class_5602;
import net.minecraft.class_591;
import net.minecraft.class_7833;
import net.minecraft.class_7920;
import net.minecraft.class_8030;
import net.minecraft.class_8685;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4fStack;

public final class CosmeticPreview {
   @Nullable
   public static class_8030 clip;
   private static class_591 wide;
   private static class_591 slim;

   private CosmeticPreview() {
   }

   public static void register() {
      SpecialGuiElementRegistry.register(ctx -> new CosmeticPreview.Renderer(ctx.vertexConsumers()));
   }

   public static void draw(class_332 ctx, int x1, int y1, int x2, int y2, float scale, float yaw, @Nullable String only) {
      draw(ctx, x1, y1, x2, y2, scale, yaw, only, clip);
   }

   public static void draw(class_332 ctx, int x1, int y1, int x2, int y2, float scale, float yaw, @Nullable String only, @Nullable class_8030 scissor) {
      class_8030 bounds = class_11256.method_71535(x1, y1, x2, y2, scissor);
      if (bounds != null) {
         ((DrawContextAccessor)ctx).mrbean$getState().method_70922(new CosmeticPreview.State(x1, y1, x2, y2, scale, yaw, only, scissor, bounds));
      }
   }

   static final class Renderer extends class_11239<CosmeticPreview.State> {
      private final PlayerCosmetic.Ctx c = new PlayerCosmetic.Ctx();

      Renderer(class_4598 vc) {
         super(vc);
      }

      public Class<CosmeticPreview.State> method_70903() {
         return CosmeticPreview.State.class;
      }

      protected String method_70906() {
         return "mrbeanvisuals_cosmetic_preview";
      }

      protected void render(CosmeticPreview.State st, class_4587 ms) {
         class_310 mc = class_310.method_1551();
         mc.field_1773.method_71114().method_71034(class_11274.field_60029);
         int sf = mc.method_22683().method_4495();
         Matrix4fStack mv = RenderSystem.getModelViewStack();
         mv.pushMatrix();
         float s = st.comp_4133() * sf;
         mv.rotateAround(class_7833.field_40714.rotationDegrees(-12.0F), 0.0F, s * -1.0F, 0.0F);
         ms.method_22907(class_7833.field_40716.rotationDegrees(-st.yaw()));
         ms.method_46416(0.0F, -1.601F, 0.0F);
         class_8685 skin = mc.field_1724 != null
            ? mc.field_1724.method_52814()
            : class_1068.method_4648(mc.method_1548().method_44717() == null ? UUID.randomUUID() : mc.method_1548().method_44717());
         boolean isSlim = skin.comp_1629() == class_7920.field_41122;
         if (CosmeticPreview.wide == null) {
            CosmeticPreview.wide = new class_591(mc.method_31974().method_32072(class_5602.field_27577), false);
            CosmeticPreview.slim = new class_591(
               mc.method_31974().method_32072(new class_5601(class_2960.method_60656("player_slim"), "main")), true
            );
         }

         class_591 model = isSlim ? CosmeticPreview.slim : CosmeticPreview.wide;
         class_2960 tex = skin.comp_1626().comp_3627();
         model.method_60879(ms, this.field_59933.method_73477(model.method_23500(tex)), 15728880, class_4608.field_21444);
         this.field_59933.method_22993();
         ms.method_22903();
         ms.method_46416(0.0F, 1.501F, 0.0F);
         ms.method_22905(-1.0F, -1.0F, 1.0F);
         this.c.player = mc.field_1724;
         this.c.matrices = ms;
         this.c.buffers = this.field_59933;
         this.c.delta = 1.0F;
         this.c.headTop = 1.8F;
         this.c.neck = 1.53F;
         this.c.bodyYaw = 0.0F;
         this.c.headYaw = 0.0F;
         this.c.pitch = 0.0F;
         this.c.sneaking = false;
         this.c.self = true;
         this.c.firstPerson = false;
         this.c.preview = true;
         this.c.time = System.currentTimeMillis() % 3600000L / 1000.0;
         this.c.speed = 0.0F;

         for (Module m : Modules.all()) {
            if (m instanceof PlayerCosmetic pc && (st.only() != null ? m.id.equals(st.only()) : m.isEnabled())) {
               ms.method_22903();

               try {
                  pc.draw(this.c);
               } catch (Exception var15) {
               }

               ms.method_22909();
            }
         }

         this.field_59933.method_22994(World3D.normalLayer());
         this.field_59933.method_22994(World3D.glowLayer());
         this.field_59933.method_22993();
         ms.method_22909();
         mv.popMatrix();
      }
   }

   public record State(
      int x1, int y1, int x2, int y2, float scale, float yaw, @Nullable String only, @Nullable class_8030 scissorArea, @Nullable class_8030 bounds
   ) implements class_11256 {
   }
}
