package com.mrbean.visuals.gui;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.ThemeModule;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;

public final class Sounds {
   public static class_3414 CLICK = reg("ui.click");
   public static class_3414 ON = reg("ui.on");
   public static class_3414 OFF = reg("ui.off");
   public static class_3414 OPEN = reg("ui.open");
   public static class_3414 CLOSE = reg("ui.close");
   private static long lastPlay;
   private static boolean clickPending;

   private Sounds() {
   }

   private static class_3414 reg(String name) {
      return class_3414.method_47908(class_2960.method_60655("mrbeanvisuals", name));
   }

   public static void click() {
      clickPending = true;
   }

   public static void flush() {
      if (clickPending) {
         clickPending = false;
         play(CLICK);
      }
   }

   public static void play(class_3414 e) {
      if (e != CLICK) {
         clickPending = false;
      }

      if (e != null) {
         ThemeModule t = Modules.theme();
         if (t == null || t.sounds.value) {
            float vol = t == null ? 0.6F : (float)(t.soundVolume.value / 100.0);
            if (!(vol <= 0.001F)) {
               long now = System.currentTimeMillis();
               if (e != CLICK || now - lastPlay >= 35L) {
                  lastPlay = now;

                  try {
                     class_310.method_1551().method_1483().method_4873(class_1109.method_4757(e, 1.0F, vol));
                  } catch (Exception var6) {
                  }
               }
            }
         }
      }
   }
}
