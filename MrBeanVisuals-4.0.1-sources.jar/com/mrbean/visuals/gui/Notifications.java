package com.mrbean.visuals.gui;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Mobile;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class Notifications {
   private static final List<Notifications.N> list = new ArrayList<>();
   private static final long LIFE = 2200L;
   public static boolean enabled = true;

   private Notifications() {
   }

   public static void push(String text, boolean on) {
      add(text, on, false);
   }

   public static void toggle(String text, boolean on) {
      add(text, on, true);
   }

   private static void add(String text, boolean on, boolean status) {
      if (enabled) {
         synchronized (list) {
            list.add(new Notifications.N(text, on, status));
            if (list.size() > 5) {
               list.remove(0);
            }
         }
      }
   }

   public static void render(class_332 ctx) {
      class_310 mc = class_310.method_1551();
      float ms = Mobile.hud();
      int sw = (int)(mc.method_22683().method_4486() / ms);
      int sh = (int)(mc.method_22683().method_4502() / ms);
      int y = sh - 34;
      ctx.method_51448().pushMatrix();
      ctx.method_51448().scale(ms, ms);

      try {
         synchronized (list) {
            for (int k = list.size() - 1; k >= 0; k--) {
               Notifications.N n = list.get(k);
               long age = System.currentTimeMillis() - n.start;
               n.slide = R2D.approach(n.slide, age > 2200L ? 0.0F : 1.0F, 0.25F);
               String status = n.on ? Lang.ui("ui.enabled") : Lang.ui("ui.disabled");
               int w = Math.max(120, R2D.width(n.text) + 40);
               int x = (int)(sw - (w + 6) * n.slide);
               int ph = n.status ? 26 : 18;
               R2D.panel(ctx, x, y, w, ph, 6, R2D.bg(), true, 553648127);
               int dot = n.on ? R2D.accent(0.0F) : -42396;
               R2D.circle(ctx, x + 12, y + ph / 2, 4, dot);
               R2D.text(ctx, n.text, x + 22, y + (n.status ? 4 : 5), -1);
               if (n.status) {
                  R2D.text(ctx, status, x + 22, y + 14, -6643532, false);
               }

               float p = Math.min(1.0F, (float)age / 2200.0F);
               R2D.rect(ctx, x + 4, y + ph - 2, (int)((w - 8) * (1.0F - p)), 1, R2D.accent(0.0F));
               y -= ph + 4;
            }

            list.removeIf(nx -> System.currentTimeMillis() - nx.start > 2200L && nx.slide < 0.02F);
         }
      } finally {
         ctx.method_51448().popMatrix();
      }
   }

   private static final class N {
      final String text;
      final boolean on;
      final boolean status;
      final long start = System.currentTimeMillis();
      float slide;

      N(String t, boolean on, boolean status) {
         this.text = t;
         this.on = on;
         this.status = status;
      }
   }
}
