package com.mrbean.visuals.gui;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.impl.Emotes;
import com.mrbean.visuals.render.R2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_490;
import org.jetbrains.annotations.Nullable;

/**
 * Каталог эмоций: слева все эмоции кубами, в центре живой предпросмотр — модель игрока танцует
 * выбранную позу, справа настройки (звук, громкость, цикл, авто-вид на лицо) и кнопки выбранной
 * эмоции. Поиск и разделы сверху. Игру не ставит на паузу, чтобы предпросмотр было видно.
 * Все позы и звуки уже есть в Emotes — экран только их показывает и дёргает module().
 */
public class EmoteCatalogScreen extends class_437 {
   private final Ui ui = new Ui();
   private final class_437 parent;
   private String search = "";
   private int tab;
   private double scroll;
   private double scrollTarget;
   private int contentHeight;
   private float open;
   private boolean closing;
   @Nullable
   private String hoverId;
   @Nullable
   private String selectedId;
   private static final int CUBE_H = 56;
   private static final int FAV_TAB = 1;

   public EmoteCatalogScreen(class_437 parent) {
      super(class_2561.method_43470(Lang.t("Каталог эмоций", "Emote catalog")));
      this.parent = parent;
   }

   public boolean method_25421() {
      return false;
   }

   protected void method_25426() {
      Sounds.play(Sounds.OPEN);
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      if (this.field_22787.field_1687 == null) {
         this.method_57728(context, deltaTicks);
      } else {
         context.method_25296(0, 0, this.field_22789, this.field_22790, R2D.argb(110, 3, 4, 6), R2D.argb(160, 2, 3, 5));
      }
   }

   public void method_25394(class_332 ctx, int mouseX, int mouseY, float deltaTicks) {
      this.open = R2D.approach(this.open, 1.0F, 0.22F);
      int w = Math.min(this.field_22789 - 20, 480);
      int h = Math.min(this.field_22790 - 20, 300);
      int x = (this.field_22789 - w) / 2;
      int y = (this.field_22790 - h) / 2;
      Emotes.EmoteModule em = Emotes.module();
      List<Emotes.Def> list = this.list(em);
      this.ui.screenW = this.field_22789;
      this.ui.begin(ctx, mouseX, mouseY);
      float oldA = R2D.alpha;
      R2D.alpha = this.open;
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(0.0F, (1.0F - this.open) * 8.0F);
      this.ui.offsetY((double)((1.0F - this.open) * -8.0F));
      R2D.panel(ctx, x, y, w, h, 8, -166455776, true, R2D.withAlpha(R2D.accent(0.0F), 120));
      R2D.logo(ctx, x + 10, y + 7, 18);
      R2D.textScaled(ctx, Lang.t("Каталог эмоций", "Emote catalog"), x + 32, y + 9, 1.05F, -1, false);
      String count = list.size() + " " + Lang.t("из ", "of ") + Emotes.all().size();
      R2D.textScaled(ctx, count, x + w - R2D.width(count) * 0.75F - 30.0F, y + 11, 0.75F, Ui.DIM, false);
      if (this.ui.button("close", x + w - 22, y + 6, 16, 14, "✕", 2)) {
         this.method_25419();
      }

      this.search = this.ui.textField("q", x + 10, y + 28, w - 20, this.search, "⌕ " + Lang.t("Поиск эмоции…", "Search emotes…"), 24);
      this.tab = this.ui.segmented("tabs", x + 10, y + 46, w - 20, this.tabNames(), this.tab);
      int ly = y + 66;
      int lh = h - 66 - 16;
      int leftW = 208;
      int midW = 118;
      int lx = x + 10;
      int mx = lx + leftW + 8;
      int rx = mx + midW + 8;
      int rightW = w - 20 - leftW - midW - 16;
      this.hoverId = null;
      this.cubes(ctx, em, list, lx, ly, leftW, lh);
      this.preview(ctx, em, mx, ly, midW, lh);
      this.settings(ctx, em, rx, ly, rightW, lh);
      String hint = Lang.t(
         "ЛКМ по кубу — играть · ПКМ — в избранное · ESC — закрыть",
         "LMB cube — play · RMB — favourite · ESC — close"
      );
      R2D.textScaled(ctx, hint, x + w / 2.0F - R2D.width(hint) * 0.68F / 2.0F, y + h - 12, 0.68F, Ui.DIM, false);
      String target = this.hoverId != null ? this.hoverId : this.selectedId;
      if (!this.closing && target != null && em != null && em.isEnabled() && this.field_22787.field_1724 != null) {
         em.preview(target);
      }

      ctx.method_51448().popMatrix();
      R2D.alpha = oldA;
      this.ui.end();
   }

   /** Сетка кубов эмоций: ЛКМ — сыграть, ПКМ — избранное, наведение — предпросмотр в центре. */
   private void cubes(class_332 ctx, @Nullable Emotes.EmoteModule em, List<Emotes.Def> list, int x, int y, int w, int h) {
      int cw = (w - 4) / 2;
      int rows = (list.size() + 1) / 2;
      this.contentHeight = rows * (CUBE_H + 4) + 4;
      if (this.ui.scroll != 0.0 && R2D.inside(this.ui.mx, this.ui.my, x, y, w, h)) {
         this.scrollTarget = this.scrollTarget - this.ui.scroll * 22.0;
         this.ui.scroll = 0.0;
      }

      this.scrollTarget = Math.max(0.0, Math.min((double)Math.max(0, this.contentHeight - h + 4), this.scrollTarget));
      this.scroll = R2D.approach((float)this.scroll, (float)this.scrollTarget, 0.35F);
      ctx.method_44379(x - 2, y - 2, x + w + 4, y + h + 2);
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(0.0F, (float)-this.scroll);
      this.ui.offsetY(this.scroll);

      for (int i = 0; i < list.size(); i++) {
         this.cube(ctx, em, list.get(i), x + (i % 2) * (cw + 4), y + 2 + (i / 2) * (CUBE_H + 4), cw, CUBE_H);
      }

      if (list.isEmpty()) {
         String none = Lang.t("Ничего не найдено", "Nothing found");
         R2D.text(ctx, none, x + w / 2 - R2D.width(none) / 2, y + 20, Ui.DIM, false);
      }

      ctx.method_51448().popMatrix();
      ctx.method_44380();
      this.ui.offsetY(-this.scroll);
      if (this.contentHeight > h) {
         int bh = Math.max(16, (int)((float)(h * h) / this.contentHeight));
         int by = y + (int)((float)(h - bh) * ((float)this.scroll / (float)Math.max(1, this.contentHeight - h + 4)));
         R2D.round(ctx, x + w - 3, by, 2, bh, 1, R2D.accent(0.0F));
      }
   }

   private void cube(class_332 ctx, @Nullable Emotes.EmoteModule em, Emotes.Def d, int x, int y, int w, int h) {
      boolean hov = this.ui.hover(x, y, w, h);
      boolean fav = em != null && em.isFav(d.id());
      boolean on = em != null && d.id().equals(em.active());
      boolean sel = d.id().equals(this.selectedId);
      float t = this.ui.anim("cube:" + d.id(), hov || sel || on ? 1.0F : 0.0F, 0.3F);
      R2D.round(ctx, x, y, w, h, 7, R2D.lerp(-14277082, on ? -14869470 : -15395041, t));
      R2D.outline(ctx, x, y, w, h, 7, on || sel ? R2D.withAlpha(R2D.accent(0.0F), 200) : R2D.withAlpha(587202559, (int)(60.0F + 140.0F * t)));
      float hue = (float)Math.max(0, Emotes.groups().indexOf(d.group())) * 0.15F;
      R2D.round(ctx, x + 5, y + 5, 20, 20, 6, R2D.withAlpha(R2D.accent(hue), 70));
      String icon = Emotes.groupIcon(d.group());
      R2D.textScaled(ctx, icon, x + 15 - R2D.width(icon) * 0.9F / 2.0F, y + 9, 0.9F, -1, false);
      R2D.textScaled(ctx, Lang.t(d.ru(), d.en()), x + 29, y + 6, 0.8F, hov ? -1 : Ui.TEXT, false);
      String sub = String.format(Locale.ROOT, "%.1f", d.seconds()) + Lang.t("с", "s") + (d.sound() == null ? "" : " · ♪");
      R2D.textScaled(ctx, sub, x + 29, y + 16, 0.62F, Ui.DIM, false);
      if (fav) {
         R2D.textScaled(ctx, "★", x + w - 12, y + 5, 0.8F, R2D.accent(0.1F), false);
      }

      if (on) {
         R2D.textScaled(ctx, "∞", x + w - 12, y + h - 12, 0.8F, R2D.accent(0.0F), false);
      }

      Setting.Key bind = Emotes.bindOf(d.id());
      if (bind != null && bind.value >= 0) {
         R2D.textScaled(ctx, bind.display(), x + 5, y + h - 11, 0.6F, R2D.withAlpha(R2D.accent(0.35F), 200), false);
      }

      if (hov) {
         this.hoverId = d.id();
      }

      if (this.ui.clicked(x, y, w, h)) {
         this.play(em, d);
      } else if (this.ui.rightClicked(x, y, w, h) && em != null) {
         Sounds.play(em.toggleFav(d.id()) ? Sounds.ON : Sounds.OFF);
      }
   }

   /** Танцующий предпросмотр: модель игрока с текущей позой эмоции, как в инвентаре vanilla. */
   private void preview(class_332 ctx, @Nullable Emotes.EmoteModule em, int x, int y, int w, int h) {
      R2D.round(ctx, x, y, w, h, 8, R2D.withAlpha(-16777216, 90));
      R2D.outline(ctx, x, y, w, h, 8, R2D.withAlpha(587202559, 120));
      R2D.textScaled(ctx, Lang.t("Предпросмотр", "Preview"), x + 8, y + 6, 0.72F, Ui.MUTED, false);
      if (this.field_22787.field_1724 == null) {
         String need = Lang.t("Зайди в мир", "Join a world");
         R2D.textScaled(ctx, need, x + w / 2.0F - R2D.width(need) * 0.7F / 2.0F, y + h / 2.0F, 0.7F, Ui.DIM, false);
      } else {
         int px = x + 6;
         int py = y + 16;
         int pw = w - 12;
         int ph = h - 16 - 26;
         class_490.method_2486(
            ctx, px, py, px + pw, py + ph, (int)(ph * 0.42F), 0.0F, (float)(px + pw / 2), (float)(py + ph / 2), this.field_22787.field_1724
         );
      }

      Emotes.Def d = this.selectedId == null ? null : Emotes.def(this.selectedId);
      if (d == null) {
         String idle = Lang.t("Наведи на эмоцию", "Hover an emote");
         R2D.textScaled(ctx, idle, x + w / 2.0F - R2D.width(idle) * 0.62F / 2.0F, y + h - 14, 0.62F, Ui.DIM, false);
      } else {
         float hue = (float)Math.max(0, Emotes.groups().indexOf(d.group())) * 0.15F;
         R2D.textScaled(ctx, Emotes.groupIcon(d.group()) + " " + Lang.t(d.ru(), d.en()), x + 8, y + h - 14, 0.68F, R2D.accent(hue), false);
      }
   }

   /** Настройки эмоций и кнопки выбранной эмоции. */
   private void settings(class_332 ctx, @Nullable Emotes.EmoteModule em, int x, int y, int w, int h) {
      R2D.round(ctx, x, y, w, h, 8, R2D.withAlpha(-16777216, 90));
      R2D.outline(ctx, x, y, w, h, 8, R2D.withAlpha(587202559, 120));
      R2D.textScaled(ctx, Lang.t("Настройки", "Settings"), x + 8, y + 6, 0.72F, Ui.MUTED, false);
      if (em == null) {
         String need = Lang.t("Модуль выключен", "Module is off");
         R2D.textScaled(ctx, need, x + w / 2.0F - R2D.width(need) * 0.66F / 2.0F, y + h / 2.0F, 0.66F, Ui.DIM, false);
         return;
      }

      int sy = y + 20;
      R2D.textScaled(ctx, Lang.t("Звук", "Sound"), x + 8, sy + 1, 0.7F, Ui.TEXT, false);
      boolean snd = this.ui.toggle("set_snd", x + w - 30, sy, em.sounds.value);
      if (snd != em.sounds.value) {
         em.sounds.value = snd;
         Config.markDirty();
         Sounds.play(snd ? Sounds.ON : Sounds.OFF);
      }

      sy += 16;
      R2D.textScaled(ctx, Lang.t("Громкость", "Volume"), x + 8, sy, 0.66F, Ui.DIM, false);
      sy += 9;
      this.ui.slider("set_vol", x + 8, sy, w - 16, em.soundVolume);
      sy += 14;
      R2D.textScaled(ctx, Lang.t("Цикл", "Loop"), x + 8, sy + 1, 0.7F, Ui.TEXT, false);
      boolean loop = this.ui.toggle("set_loop", x + w - 30, sy, em.loopSel.value);
      if (loop != em.loopSel.value) {
         em.loopSel.value = loop;
         Config.markDirty();
         Sounds.play(loop ? Sounds.ON : Sounds.OFF);
      }

      sy += 16;
      R2D.textScaled(ctx, Lang.t("Авто-F5 на лицо", "Auto face view"), x + 8, sy + 1, 0.7F, Ui.TEXT, false);
      boolean face = this.ui.toggle("set_face", x + w - 30, sy, em.autoFace.value);
      if (face != em.autoFace.value) {
         em.autoFace.value = face;
         Config.markDirty();
         Sounds.play(face ? Sounds.ON : Sounds.OFF);
      }

      sy += 18;
      R2D.rect(ctx, x + 8, sy, w - 16, 1, 352321535);
      sy += 6;
      Emotes.Def d = this.selectedId == null ? null : Emotes.def(this.selectedId);
      if (d == null) {
         String pick = Lang.t("Выбери эмоцию слева", "Pick an emote on the left");
         R2D.textScaled(ctx, pick, x + 8, sy + 2, 0.62F, Ui.DIM, false);
         return;
      }

      boolean on = d.id().equals(em.active());
      if (this.ui.button("act_play", x + 8, sy, w - 16, 16, on ? "∞ " + Lang.t("Стоп", "Stop") : "▶ " + Lang.t("Играть", "Play"), 0)) {
         this.play(em, d);
      }

      sy += 20;
      if (d.sound() != null && this.ui.button("act_snd", x + 8, sy, w - 16, 16, "♪ " + Lang.t("Прослушать", "Listen"), 2)) {
         this.listen(d);
      }

      sy += 20;
      boolean fav = em.isFav(d.id());
      if (this.ui.button("act_fav", x + 8, sy, w - 16, 16, fav ? "★ " + Lang.t("В избранном", "Favourited") : "☆ " + Lang.t("В избранное", "Favourite"), 2)) {
         Sounds.play(em.toggleFav(d.id()) ? Sounds.ON : Sounds.OFF);
      }

      sy += 20;
      Setting.Key bind = Emotes.bindOf(d.id());
      String key = bind != null && bind.value >= 0 ? bind.display() : Lang.t("нет бинда", "no bind");
      R2D.textScaled(ctx, Lang.t("Клавиша: ", "Key: ") + key, x + 8, sy + 2, 0.62F, Ui.DIM, false);
   }

   private void play(@Nullable Emotes.EmoteModule em, Emotes.Def d) {
      if (em == null || !em.isEnabled()) {
         Notifications.push(Lang.t("Включи модуль «Эмоции»", "Enable the Emotes module"), false);
         Sounds.play(Sounds.OFF);
      } else if (this.field_22787.field_1724 == null) {
         Notifications.push(Lang.t("Сначала зайди в мир", "Join a world first"), false);
         Sounds.play(Sounds.OFF);
      } else {
         em.restoreAfterPreview();
         Sounds.play(Sounds.CLICK);
         em.start(d.id());
         this.selectedId = d.id();
         this.method_25419();
         return;
      }
   }

   private void listen(Emotes.Def d) {
      if (Emotes.listen(d)) {
         Sounds.play(Sounds.CLICK);
      } else {
         Emotes.EmoteModule em = Emotes.module();
         Notifications.push(
            em != null && em.soundVolume.value <= 0.0
               ? Lang.t("Громкость эмоций равна нулю", "Emote volume is zero")
               : Lang.t("У этой эмоции нет звука", "This emote has no sound"),
            false
         );
      }
   }

   private String[] tabNames() {
      List<String> l = new ArrayList<>();
      l.add(Lang.t("Все", "All"));
      l.add("★");

      for (String g : Emotes.groups()) {
         l.add(Lang.t(Emotes.groupRu(g), Emotes.groupEn(g)));
      }

      return l.toArray(new String[0]);
   }

   @Nullable
   private String tabGroup() {
      int i = this.tab - 2;
      List<String> gs = Emotes.groups();
      return i >= 0 && i < gs.size() ? gs.get(i) : null;
   }

   private List<Emotes.Def> list(@Nullable Emotes.EmoteModule em) {
      List<Emotes.Def> out;
      if (this.tab == FAV_TAB) {
         out = em == null ? new ArrayList<>() : em.favDefs();
      } else {
         out = Emotes.of(this.tabGroup());
      }

      String q = this.search.trim().toLowerCase(Locale.ROOT);
      if (!q.isEmpty()) {
         List<Emotes.Def> f = new ArrayList<>();

         for (Emotes.Def d : out) {
            if (d.id().contains(q) || d.ru().toLowerCase(Locale.ROOT).contains(q) || d.en().toLowerCase(Locale.ROOT).contains(q)) {
               f.add(d);
            }
         }

         out = f;
      }

      return out;
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      int k = input.comp_4795();
      if (this.ui.focus != null) {
         if (k == 256) {
            this.ui.focus = null;
            return true;
         }

         this.ui.onKey(k);
         return true;
      } else if (k != 256 && k != 66) {
         return super.method_25404(input);
      } else {
         this.method_25419();
         return true;
      }
   }

   public boolean method_25400(class_11905 input) {
      String s = input.method_74226();
      if (this.ui.focus == null && s != null && !s.isBlank()) {
         this.ui.focus = "q";
      }

      if (s != null) {
         for (char ch : s.toCharArray()) {
            this.ui.onChar(ch);
         }
      }

      return true;
   }

   public void method_25419() {
      if (!this.closing) {
         this.closing = true;
         Sounds.play(Sounds.CLOSE);
         Emotes.stopListen();
         Emotes.EmoteModule em = Emotes.module();
         if (em != null) {
            em.restoreAfterPreview();
            em.catalogClosed();
         }

         this.field_22787.method_1507(this.parent);
      }
   }
}
