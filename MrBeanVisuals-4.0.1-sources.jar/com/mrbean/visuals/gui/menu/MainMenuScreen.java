package com.mrbean.visuals.gui.menu;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Screens;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.impl.MainMenuModule;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import com.mrbean.visuals.util.LastServer;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_412;
import net.minecraft.class_426;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_4749;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_642.class_8678;

public class MainMenuScreen extends class_437 {
   private final Ui ui = new Ui();
   private static boolean firstShown;
   private final boolean intro;
   private long openedAt;
   private static final String[][] TIPS = new String[][]{
      {"Правый Shift — меню MrBean Visuals", "Right Shift opens the MrBean Visuals menu"},
      {"Китайская шляпа и крылья — в разделе «Косметика»", "China Hat and wings live in Cosmetics"},
      {"HUD двигается мышкой: кнопка «HUD» в меню", "Drag HUD elements: the HUD button in the menu"},
      {"Мало FPS? Оптимизация → пресет «Максимум FPS»", "Low FPS? Performance → Maximum FPS preset"},
      {"Смена аккаунта — карточка справа вверху", "Switch accounts with the card top-right"},
      {"Auto Duel для ReallyWorld — раздел «Утилиты»", "Auto Duel for ReallyWorld — Utilities"}
   };

   public MainMenuScreen() {
      super(class_2561.method_43470("MrBean Visuals"));
      MainMenuModule m = MenuBackground.module();
      this.intro = !firstShown && (m == null || m.intro.value);
      firstShown = true;
   }

   protected void method_25426() {
      if (this.openedAt == 0L) {
         this.openedAt = System.currentTimeMillis();
      }
   }

   public boolean method_25422() {
      return false;
   }

   public boolean method_25421() {
      return false;
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.method_57728(context, deltaTicks);
   }

   private float since() {
      return (float)(System.currentTimeMillis() - this.openedAt) / 1000.0F;
   }

   private float stagger(float delay, float dur) {
      float t = (this.since() - delay) / dur;
      t = Math.max(0.0F, Math.min(1.0F, t));
      return 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      super.method_25394(context, mouseX, mouseY, deltaTicks);
      MainMenuModule m = MenuBackground.module();
      this.ui.begin(context, mouseX, mouseY);
      float oldA = R2D.alpha;
      int pw = 172;
      int px = 14;
      int py = 14;
      int ph = this.field_22790 - 28;
      float pIn = this.stagger(0.05F, 0.55F);
      int pxA = px - (int)((1.0F - pIn) * 60.0F);
      R2D.alpha = pIn;
      R2D.shadow(context, pxA, py, pw, ph, 10, 1610612736);
      R2D.round(context, pxA, py, pw, ph, 10, R2D.withAlpha(0x0C0E14, 248));
      R2D.outline(context, pxA, py, pw, ph, 10, 486539263);
      R2D.accentBar(context, pxA + 12, py + 1, pw - 24, 1);
      float lIn = this.stagger(0.2F, 0.6F);
      R2D.alpha = lIn;
      float bob = (float)Math.sin(this.since() * 2.0) * 1.2F;
      R2D.logo(context, pxA + 12, (int)(py + 14 + bob), 26);
      context.method_51448().pushMatrix();
      context.method_51448().translate(pxA + 42, py + 15);
      float ls = 1.9F * (0.85F + 0.15F * lIn);
      context.method_51448().scale(ls, ls);
      R2D.gradientText(context, "MrBean", 0, 0, 0.07F, true);
      context.method_51448().popMatrix();
      R2D.textScaled(context, spaced("VISUALS"), pxA + 43, py + 33, 0.8F, -4670004, false);
      R2D.textScaled(context, "v" + com.mrbean.visuals.MrBeanClient.VERSION + "  ·  Minecraft 1.21.11", pxA + 14, py + 46, 0.7F, -9735802, false);
      String[][] items = new String[][]{
         {"▶", Lang.t("Одиночная игра", "Singleplayer")},
         {"☰", Lang.t("Мультиплеер", "Multiplayer")},
         {"✦", "MrBean Visuals"},
         {"⚙", Lang.t("Настройки", "Options")}
      };
      int bx = pxA + 12;
      int bw = pw - 24;
      int top = py + 64;
      int avail = ph - (top - py) - 64;
      int bh = Math.max(16, Math.min(24, avail / 5 - 5));
      int gap = Math.max(3, Math.min(6, bh / 4));

      for (int i = 0; i < items.length; i++) {
         float in = this.stagger(0.3F + i * 0.07F, 0.45F);
         int by = top + i * (bh + gap);
         int off = (int)((1.0F - in) * -30.0F);
         R2D.alpha = in;
         if (this.menuButton("m" + i, bx + off, by, bw, bh, items[i][0], items[i][1], i == 0)) {
            this.ui.sound();
            this.open(i);
         }
      }

      float in2 = this.stagger(0.3F + items.length * 0.07F, 0.45F);
      R2D.alpha = in2;
      int by2 = top + items.length * (bh + gap);
      int half = (bw - gap) / 2;
      if (this.menuButton("lang", bx, by2, half, bh, "Aa", Lang.t("Язык", "Language"), false)) {
         this.ui.sound();
         this.field_22787.method_1507(new class_426(this, this.field_22787.field_1690, this.field_22787.method_1526()));
      }

      if (this.menuButton("quit", bx + half + gap, by2, half, bh, "✕", Lang.t("Выход", "Quit"), false)) {
         this.ui.sound();
         this.field_22787.method_1592();
      }

      R2D.alpha = pIn;
      R2D.textScaled(context, "Fabric · " + this.field_22787.method_47599() + " FPS", pxA + 14, py + ph - 24, 0.7F, -9735802, false);
      R2D.textScaled(
         context, "Copyright Mojang AB. " + Lang.t("Не официальный продукт", "Not an official product"), pxA + 14, py + ph - 14, 0.62F, -11183510, false
      );
      if (m == null || m.accountCard.value) {
         float aIn = this.stagger(0.45F, 0.5F);
         R2D.alpha = aIn;
         int aw = 158;
         int ah = 38;
         int ax = this.field_22789 - aw - 14 + (int)((1.0F - aIn) * 40.0F);
         int ay = 14;
         boolean hov = this.ui.hover(ax, ay, aw, ah);
         float ht = this.ui.anim("acc", hov ? 1.0F : 0.0F, 0.25F);
         R2D.shadow(context, ax, ay, aw, ah, 8, 1342177280);
         R2D.round(context, ax, ay, aw, ah, 8, R2D.lerp(R2D.withAlpha(0x0C0E14, 248), R2D.withAlpha(0x1A1D28, 252), ht));
         R2D.outline(context, ax, ay, aw, ah, 8, R2D.lerp(486539263, R2D.withAlpha(R2D.accent(0.0F), 170), ht));
         SkinHeads.drawSelf(context, ax + 8, ay + 7, 24);
         String name = this.field_22787.method_1548().method_1676();
         R2D.text(context, name, ax + 38, ay + 8, -1183755, false);
         boolean ms = Info.microsoftAccount();
         R2D.textScaled(context, ms ? "● Microsoft" : "● " + Lang.t("Офлайн", "Offline"), ax + 38, ay + 21, 0.75F, ms ? -11870592 : -20448, false);
         String sw = Lang.t("Сменить ›", "Switch ›");
         R2D.textScaled(context, sw, ax + aw - 8 - R2D.width(sw) * 0.75F, ay + 21, 0.75F, R2D.lerp(-6643532, R2D.accent(0.0F), ht), false);
         if (this.ui.clicked(ax, ay, aw, ah)) {
            this.ui.sound();
            this.field_22787.method_1507(new AccountScreen(this));
         }
      }

      LastServer.Entry last = LastServer.get();
      if (last != null) {
         float sIn = this.stagger(0.55F, 0.5F);
         R2D.alpha = sIn;
         int sw2 = 178;
         int sh = 34;
         int sx = this.field_22789 - sw2 - 14 + (int)((1.0F - sIn) * 40.0F);
         int sy = this.field_22790 - sh - 14;
         boolean hov = this.ui.hover(sx, sy, sw2, sh);
         float ht = this.ui.anim("last", hov ? 1.0F : 0.0F, 0.25F);
         R2D.round(context, sx, sy, sw2, sh, 8, R2D.lerp(R2D.withAlpha(0x0C0E14, 248), R2D.withAlpha(0x1A1D28, 252), ht));
         R2D.outline(context, sx, sy, sw2, sh, 8, R2D.lerp(486539263, R2D.withAlpha(R2D.accent(0.0F), 170), ht));
         R2D.round(context, sx + 6, sy + 6, 22, 22, 6, R2D.withAlpha(R2D.accent(0.0F), (int)(60.0F + 60.0F * ht)));
         R2D.text(context, "▶", sx + 14, sy + 13, -1, false);
         R2D.textScaled(context, Lang.t("Продолжить игру", "Continue playing"), sx + 34, sy + 7, 0.72F, -6643532, false);
         R2D.text(context, trim(last.name(), sw2 - 44), sx + 34, sy + 18, -1183755, false);
         if (this.ui.clicked(sx, sy, sw2, sh)) {
            this.ui.sound();
            class_642 info = new class_642(last.name(), last.address(), class_8678.field_45611);
            class_412.method_36877(this, this.field_22787, class_639.method_2950(last.address()), info, false, null);
         }
      }

      if (m == null || m.tips.value) {
         int idx = (int)(this.since() / 5.0F) % TIPS.length;
         float ph2 = this.since() % 5.0F;
         float a = Math.min(1.0F, Math.min(ph2 / 0.5F, (5.0F - ph2) / 0.5F)) * this.stagger(0.8F, 0.6F);
         R2D.alpha = a;
         String tip = Lang.t(TIPS[idx][0], TIPS[idx][1]);
         int cx = (pxA + pw + this.field_22789) / 2;
         int tw = R2D.width(tip) + 22;
         R2D.round(context, cx - tw / 2, this.field_22790 - 30, tw, 16, 8, R2D.withAlpha(0x000000, 226));
         R2D.circle(context, cx - tw / 2 + 9, this.field_22790 - 22, 2, R2D.accent(0.0F));
         R2D.text(context, tip, cx - tw / 2 + 15, this.field_22790 - 26, -2564890, false);
      }

      R2D.alpha = oldA;
      this.ui.end();
      if (this.intro) {
         float f = 1.0F - this.stagger(0.0F, 0.9F);
         if (f > 0.01F) {
            context.method_25294(0, 0, this.field_22789, this.field_22790, R2D.argb((int)(255.0F * f), 0, 0, 0));
         }
      }
   }

   private static String spaced(String s) {
      StringBuilder b = new StringBuilder();

      for (char c : s.toCharArray()) {
         b.append(c).append(' ');
      }

      return b.toString().trim();
   }

   private static String trim(String s, int w) {
      if (R2D.width(s) <= w) {
         return s;
      } else {
         while (s.length() > 1 && R2D.width(s + "…") > w) {
            s = s.substring(0, s.length() - 1);
         }

         return s + "…";
      }
   }

   private boolean menuButton(String id, int x, int y, int w, int h, String icon, String label, boolean primary) {
      boolean hov = this.ui.hover(x, y, w, h);
      float t = this.ui.anim("mb:" + id, hov ? 1.0F : 0.0F, 0.22F);
      int base = primary ? R2D.withAlpha(R2D.accent(0.0F), 46) : 352321535;
      R2D.round(this.ctx(), x, y, w, h, 6, R2D.lerp(base, R2D.withAlpha(R2D.accent(0.0F), 70), t));
      if (t > 0.02F) {
         R2D.outline(this.ctx(), x, y, w, h, 6, R2D.withAlpha(R2D.accent(0.0F), (int)(150.0F * t)));
      }

      int barH = (int)((h - 8) * (0.35F + 0.65F * t));
      R2D.round(this.ctx(), x + 3, y + (h - barH) / 2, 2, barH, 1, R2D.withAlpha(R2D.accent(0.0F), primary ? 255 : (int)(90.0F + 165.0F * t)));
      int tx = x + 10 + (int)(3.0F * t);
      R2D.text(this.ctx(), icon, tx, y + h / 2 - 4, !primary && !(t > 0.5F) ? -6643532 : R2D.accent(0.0F), false);
      R2D.text(this.ctx(), label, tx + 14, y + h / 2 - 4, R2D.lerp(-2235926, -1, t), false);
      if (w > 100) {
         R2D.text(this.ctx(), "›", x + w - 10 - (int)(3.0F * (1.0F - t)), y + h / 2 - 4, R2D.withAlpha(-1, (int)(220.0F * t)), false);
      }

      return this.ui.clicked(x, y, w, h);
   }

   private class_332 ctx() {
      return this.ui.ctx;
   }

   private void open(int i) {
      switch (i) {
         case 0:
            this.field_22787.method_1507(new class_526(this));
            break;
         case 1:
            this.field_22787.method_1507((class_437)(this.field_22787.field_1690.field_21840 ? new class_500(this) : new class_4749(this)));
            break;
         case 2:
            this.field_22787.method_1507(Screens.menu());
            break;
         case 3:
            this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690));
      }
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25404(class_11908 input) {
      if (MrBeanClient.menuKey.method_1417(input)) {
         this.field_22787.method_1507(Screens.menu());
         return true;
      } else {
         return super.method_25404(input);
      }
   }
}
