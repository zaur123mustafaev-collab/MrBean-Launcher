package com.mrbean.visuals.gui.menu;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1068;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

public final class SkinHeads {
   private static final class_310 mc = class_310.method_1551();
   private static final Map<String, class_2960> loaded = new ConcurrentHashMap<>();
   private static final Map<String, Boolean> loading = new ConcurrentHashMap<>();
   private static final Map<String, Boolean> legacy = new ConcurrentHashMap<>();
   private static Supplier<class_8685> self;
   private static final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8L)).build();

   private SkinHeads() {
   }

   public static UUID offlineUuid(String nick) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + nick).getBytes(StandardCharsets.UTF_8));
   }

   static UUID parse(String uuid) {
      try {
         if (uuid.length() == 32) {
            uuid = uuid.replaceFirst("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5");
         }

         return UUID.fromString(uuid);
      } catch (Exception var2) {
         return new UUID(0L, 0L);
      }
   }

   public static void drawSelf(class_332 ctx, int x, int y, int size) {
      try {
         if (mc.field_1724 != null) {
            class_7532.method_52722(ctx, mc.field_1724.method_52814(), x, y, size);
            return;
         }

         if (self == null) {
            self = mc.method_1582().method_73544(mc.method_53462(), true);
         }

         class_7532.method_52722(ctx, self.get(), x, y, size);
      } catch (Exception var5) {
         class_7532.method_52722(ctx, class_1068.method_62620(), x, y, size);
      }
   }

   public static void draw(class_332 ctx, String uuid, String skinUrl, int x, int y, int size) {
      class_2960 id = skinUrl != null && !skinUrl.isEmpty() ? loaded.get(skinUrl) : null;
      if (id != null) {
         class_7532.method_44445(ctx, id, x, y, size, !legacy.containsKey(skinUrl), false, -1);
      } else {
         if (skinUrl != null && skinUrl.startsWith("http") && skinUrl.contains("textures.minecraft.net") && loading.putIfAbsent(skinUrl, true) == null) {
            load(skinUrl);
         }

         class_7532.method_52722(ctx, class_1068.method_4648(parse(uuid)), x, y, size);
      }
   }

   public static void drawOffline(class_332 ctx, String nick, int x, int y, int size) {
      class_7532.method_52722(ctx, class_1068.method_4648(offlineUuid(nick)), x, y, size);
   }

   private static void load(String url) {
      String https = url.replaceFirst("^http://", "https://");
      http.sendAsync(HttpRequest.newBuilder(URI.create(https)).timeout(Duration.ofSeconds(10L)).build(), BodyHandlers.ofByteArray()).thenAccept(r -> {
         if (r.statusCode() == 200) {
            try {
               class_1011 raw = class_1011.method_49277(r.body());
               class_1011 img = raw;
               if (raw.method_4323() == 32) {
                  legacy.put(url, true);
                  img = new class_1011(64, 64, true);

                  for (int yy = 0; yy < 32; yy++) {
                     for (int xx = 0; xx < 64; xx++) {
                        img.method_61941(xx, yy, raw.method_61940(xx, yy));
                     }
                  }

                  raw.close();
               }

               class_1011 fin = img;
               mc.execute(() -> {
                  class_2960 id = class_2960.method_60655("mrbeanvisuals", "skins/" + Integer.toHexString(url.hashCode()));
                  mc.method_1531().method_4616(id, new class_1043(() -> "mrbean_skin", fin));
                  loaded.put(url, id);
               });
            } catch (Exception var6) {
            }
         }
      });
   }
}
