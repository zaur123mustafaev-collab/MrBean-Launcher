package com.mrbean.visuals.gui.menu;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.MainMenuModule;
import com.mrbean.visuals.render.R2D;
import java.util.Random;
import net.minecraft.class_332;

public final class MenuBackground {
   private static final int MAX = 200;
   private static final float[] px = new float[200];
   private static final float[] py = new float[200];
   private static final float[] vx = new float[200];
   private static final float[] vy = new float[200];
   private static final float[] sz = new float[200];
   private static final float[] ph = new float[200];
   private static boolean init;
   private static long last;
   private static final Random rnd = new Random();

   private MenuBackground() {
   }

   public static MainMenuModule module() {
      return Modules.get("main_menu") instanceof MainMenuModule m ? m : null;
   }

   public static boolean enabled() {
      MainMenuModule m = module();
      return m != null && m.isEnabled();
   }

   private static void spawn(int i, int w, int h, boolean anywhere) {
      px[i] = rnd.nextFloat() * w;
      py[i] = anywhere ? rnd.nextFloat() * h : h + 4;
      vx[i] = (rnd.nextFloat() - 0.5F) * 6.0F;
      vy[i] = -(4.0F + rnd.nextFloat() * 10.0F);
      sz[i] = 0.6F + rnd.nextFloat() * 1.6F;
      ph[i] = rnd.nextFloat() * 6.28F;
   }

   public static void draw(class_332 ctx, int w, int h, double mouseX, double mouseY, float strength) {
      MainMenuModule m = module();
      long now = System.nanoTime();
      float dt = last == 0L ? 0.0F : Math.min(0.1F, (float)(now - last) / 1.0E9F);
      last = now;
      float t = (float)(System.currentTimeMillis() % 1000000L) / 1000.0F;
      ctx.method_25296(0, 0, w, h, R2D.argb((int)(70.0F * strength), 6, 7, 12), R2D.argb((int)(200.0F * strength), 4, 5, 9));
      if (m == null || m.glow.value) {
         int c1 = R2D.accent(0.0F);
         int c2 = R2D.accent(0.5F);
         int gx1 = (int)(w * (0.25 + 0.12F * Math.sin(t * 0.21)));
         int gy1 = (int)(h * (0.35F + 0.1F * Math.cos(t * 0.17)));
         int gx2 = (int)(w * (0.78F + 0.1F * Math.cos(t * 0.19)));
         int gy2 = (int)(h * (0.7F + 0.12F * Math.sin(t * 0.23)));
         int r = (int)(Math.max(w, h) * 0.38F);

         for (int k = 4; k >= 1; k--) {
            int rr = r * k / 4;
            R2D.circle(ctx, gx1, gy1, rr, R2D.withAlpha(c1, (int)(9.0F * strength)));
            R2D.circle(ctx, gx2, gy2, rr, R2D.withAlpha(c2, (int)(8.0F * strength)));
         }
      }

      if (m == null || m.particles.value) {
         int n = m == null ? 70 : Math.min(200, m.count.i());
         if (!init) {
            for (int i = 0; i < 200; i++) {
               spawn(i, w, h, true);
            }

            init = true;
         }

         for (int i = 0; i < n; i++) {
            float dx = px[i] - (float)mouseX;
            float dy = py[i] - (float)mouseY;
            float d2 = dx * dx + dy * dy;
            if (d2 < 3600.0F && d2 > 1.0F) {
               float f = (3600.0F - d2) / 3600.0F * 60.0F * dt;
               float d = (float)Math.sqrt(d2);
               px[i] = px[i] + dx / d * f;
               py[i] = py[i] + dy / d * f;
            }

            px[i] = px[i] + (vx[i] + (float)Math.sin(t * 0.8 + ph[i]) * 4.0F) * dt;
            py[i] = py[i] + vy[i] * dt;
            if (py[i] < -6.0F || px[i] < -10.0F || px[i] > w + 10) {
               spawn(i, w, h, false);
            }

            float tw = 0.55F + 0.45F * (float)Math.sin(t * 2.2 + ph[i] * 3.0F);
            int col = R2D.accent(i * 0.013F);
            int a = (int)(200.0F * tw * Math.min(1.0F, (h - py[i]) / 40.0F) * strength);
            int r = Math.max(1, Math.round(sz[i]));
            R2D.circle(ctx, (int)px[i], (int)py[i], r + 2, R2D.withAlpha(col, a / 6));
            R2D.circle(ctx, (int)px[i], (int)py[i], r, R2D.withAlpha(R2D.lerp(col, -1, 0.4F), a));
         }
      }
   }
}
