package com.mrbean.visuals.gui.menu;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import com.mrbean.visuals.util.LauncherBridge;
import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class AccountScreen extends class_437 {
   private final class_437 parent;
   private final Ui ui = new Ui();
   private float open;
   private String nick;
   private String confirm;
   private long confirmAt;
   private String restarting;

   public AccountScreen(class_437 parent) {
      super(class_2561.method_43470(Lang.t("Управление аккаунтами", "Manage accounts")));
      this.parent = parent;
      this.nick = LauncherBridge.offlineNick();
      if (this.nick == null || this.nick.isEmpty()) {
         this.nick = class_310.method_1551().method_1548().method_1676();
      }
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      if (this.field_22787.field_1687 == null) {
         this.method_57728(context, deltaTicks);
      } else {
         context.method_25294(0, 0, this.field_22789, this.field_22790, -1610612736);
      }
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      super.method_25394(context, mouseX, mouseY, deltaTicks);
      this.open = R2D.approach(this.open, 1.0F, 0.18F);
      if (this.confirm != null && System.currentTimeMillis() - this.confirmAt > 4000L) {
         this.confirm = null;
      }

      this.ui.begin(context, mouseX, mouseY);
      float oldA = R2D.alpha;
      R2D.alpha = this.open;
      boolean bridge = LauncherBridge.available();
      List<LauncherBridge.Account> list = LauncherBridge.accounts();
      int rows = Math.max(1, list.size());
      int w = 280;
      int rowH = 30;
      int h = 116 + rows * (rowH + 4) + 64 + 30 + (LauncherBridge.msBlocked() ? 26 : 0);
      h = Math.min(h, this.field_22790 - 20);
      int x = this.field_22789 / 2 - w / 2;
      int y = this.field_22790 / 2 - h / 2 + (int)((1.0F - this.open) * 16.0F);
      R2D.shadow(context, x, y, w, h, 12, 1879048192);
      R2D.round(context, x, y, w, h, 10, -468972012);
      R2D.outline(context, x, y, w, h, 10, 587202559);
      R2D.accentBar(context, x + 14, y + 1, w - 28, 1);
      R2D.gradientText(context, Lang.t("Управление аккаунтами", "Manage accounts"), x + 14, y + 12, 0.04F, false);
      int cy = y + 30;
      R2D.round(context, x + 12, cy, w - 24, 34, 7, R2D.withAlpha(R2D.accent(0.0F), 34));
      SkinHeads.drawSelf(context, x + 19, cy + 6, 22);
      R2D.text(context, this.field_22787.method_1548().method_1676(), x + 48, cy + 7, -1183755, false);
      boolean ms = Info.microsoftAccount();
      R2D.textScaled(
         context,
         (ms ? "● Microsoft" : "● " + Lang.t("Офлайн", "Offline")) + "  ·  " + Lang.t("сейчас в игре", "playing now"),
         x + 48,
         cy + 20,
         0.72F,
         ms ? -11870592 : -20448,
         false
      );
      int yy = cy + 44;
      if (!bridge) {
         for (String line : Ui.wrap(
            Lang.t(
               "Смена аккаунта работает, когда игра запущена через MrBean Launcher. Там же добавляются аккаунты Microsoft (вход по коду).",
               "Switching works when the game is started from MrBean Launcher, where Microsoft accounts are added (code sign-in)."
            ),
            w - 28
         )) {
            R2D.text(context, line, x + 14, yy, -6643532, false);
            yy += 10;
         }

         yy += 6;
      } else {
         R2D.textScaled(context, Lang.t("АККАУНТЫ MICROSOFT", "MICROSOFT ACCOUNTS"), x + 14, yy, 0.7F, -9735802, false);
         yy += 10;
         if (list.isEmpty()) {
            R2D.text(context, Lang.t("Пока нет — нажмите «Добавить аккаунт»", "None yet — press “Add account”"), x + 14, yy + 8, -6643532, false);
            yy += rowH + 4;
         }

         String cur = LauncherBridge.currentUuid();

         for (LauncherBridge.Account a : list) {
            boolean active = a.uuid().equals(cur);
            boolean hov = this.ui.hover(x + 12, yy, w - 24, rowH);
            float t = this.ui.anim("row:" + a.uuid(), hov ? 1.0F : 0.0F, 0.25F);
            R2D.round(context, x + 12, yy, w - 24, rowH, 6, R2D.lerp(285212671, 520093695, t));
            SkinHeads.draw(context, a.uuid(), a.skin(), x + 18, yy + 5, 20);
            R2D.text(context, a.name(), x + 46, yy + 5, -1183755, false);
            String st = active ? Lang.t("Активен", "Active") : (a.needsLogin() ? Lang.t("Нужен вход", "Sign-in needed") : "Microsoft ✓");
            R2D.textScaled(context, st, x + 46, yy + 17, 0.72F, active ? R2D.accent(0.0F) : (a.needsLogin() ? -20448 : -11870592), false);
            if (!active) {
               String id = "sw:" + a.uuid();
               if (this.ui.button(id, x + w - 24 - 70, yy + 7, 66, 16, Lang.t("Сменить", "Switch"), 1)) {
                  this.ui.sound();
                  this.restarting = a.name();
                  if (!LauncherBridge.switchTo(a.uuid())) {
                     this.restarting = null;
                     this.fail();
                  }
               }
            }

            yy += rowH + 4;
         }

         yy += 2;
         if (LauncherBridge.msBlocked()) {
            R2D.round(context, x + 12, yy, w - 24, 22, 5, 822063136);
            R2D.textScaled(
               context,
               Lang.t("Вход Microsoft ждёт одобрения приложения от Mojang.", "Microsoft sign-in is waiting for Mojang app approval."),
               x + 18,
               yy + 4,
               0.7F,
               -15008,
               false
            );
            R2D.textScaled(
               context,
               Lang.t("Пока добавить аккаунт нельзя — играйте с офлайн-ником ниже.", "Until then, play with an offline nickname below."),
               x + 18,
               yy + 13,
               0.7F,
               -15008,
               false
            );
            yy += 26;
         }

         String addLabel = "add".equals(this.confirm)
            ? Lang.t("Игра закроется → код в лаунчере. Нажмите ещё раз", "Game closes → code in launcher. Click again")
            : "+ " + Lang.t("Добавить аккаунт Microsoft", "Add Microsoft account");
         if (this.ui.button("add", x + 12, yy, w - 24, 18, addLabel, "add".equals(this.confirm) ? 1 : 0)) {
            this.ui.sound();
            if ("add".equals(this.confirm)) {
               this.restarting = Lang.t("новым аккаунтом", "a new account");
               if (!LauncherBridge.addAccount()) {
                  this.restarting = null;
                  this.fail();
               }
            } else {
               this.confirm = "add";
               this.confirmAt = System.currentTimeMillis();
            }
         }

         yy += 26;
         R2D.textScaled(context, Lang.t("ОФЛАЙН-НИК", "OFFLINE NICKNAME"), x + 14, yy, 0.7F, -9735802, false);
         yy += 10;
         this.nick = this.ui.textField("nick", x + 12, yy, w - 24 - 100, this.nick, "Nick", 16);
         boolean valid = LauncherBridge.validNick(this.nick);
         if (this.ui.button("off", x + w - 12 - 94, yy, 94, 14, Lang.t("Играть офлайн", "Play offline"), 0)) {
            this.ui.sound();
            if (!valid) {
               Notifications.push(Lang.t("Ник: 3–16 символов, латиница, цифры и _", "Nick: 3–16 chars, letters, digits and _"), false);
            } else {
               this.restarting = this.nick;
               if (!LauncherBridge.switchOffline(this.nick)) {
                  this.restarting = null;
                  this.fail();
               }
            }
         }

         yy += 22;
      }

      if (this.ui.button("back", x + w / 2 - 50, y + h - 26, 100, 16, Lang.t("Назад", "Back"), 2)) {
         this.ui.sound();
         this.method_25419();
      }

      if (this.restarting != null) {
         context.method_25294(0, 0, this.field_22789, this.field_22790, -1073741824);
         String t1 = Lang.t("Перезапуск с ", "Restarting with ") + this.restarting + "…";
         String t2 = Lang.t("Игра закроется, MrBean Launcher сам запустит её снова", "The game closes and MrBean Launcher starts it again");
         R2D.text(context, t1, this.field_22789 / 2 - R2D.width(t1) / 2, this.field_22790 / 2 - 8, -1, false);
         R2D.text(context, t2, this.field_22789 / 2 - R2D.width(t2) / 2, this.field_22790 / 2 + 6, -6643532, false);
      }

      R2D.alpha = oldA;
      this.ui.end();
   }

   private void fail() {
      Notifications.push(Lang.t("Не удалось связаться с лаунчером", "Could not reach the launcher"), false);
   }

   public void method_25419() {
      this.field_22787.method_1507(this.parent);
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25404(class_11908 input) {
      if (this.ui.focus != null) {
         if (input.comp_4795() == 256) {
            this.ui.focus = null;
            return true;
         } else {
            this.ui.onKey(input.comp_4795());
            return true;
         }
      } else {
         return super.method_25404(input);
      }
   }

   public boolean method_25400(class_11905 input) {
      String s = input.method_74226();
      if (s != null) {
         for (char ch : s.toCharArray()) {
            this.ui.onChar(ch);
         }
      }

      return true;
   }
}
