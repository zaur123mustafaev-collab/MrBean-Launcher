package com.mrbean.visuals.net;

import com.mrbean.visuals.module.impl.Emotes;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedDeque;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/**
 * Отправка и приём эмоций через сервер. Сервер должен знать каналы — это MrBeanServerBridge
 * (Fabric) или MrBeanBadgePlugin (Paper). Без них эмоция остаётся локальной, как и раньше.
 */
public final class EmoteNetwork {
   private static final ConcurrentLinkedDeque<EmoteProtocol.Show> INBOUND = new ConcurrentLinkedDeque<>();
   private static boolean registered;
   private static long lastSend;

   private EmoteNetwork() {
   }

   public static void registerPayloads() {
      if (!registered) {
         registered = true;
         PayloadTypeRegistry.playC2S().register(EmoteProtocol.Play.ID, EmoteProtocol.Play.CODEC);
         PayloadTypeRegistry.playS2C().register(EmoteProtocol.Show.ID, EmoteProtocol.Show.CODEC);
      }
   }

   public static void init() {
      registerPayloads();
      ClientPlayNetworking.registerGlobalReceiver(EmoteProtocol.Show.ID, (payload, context) -> {
         // при выключенном модуле очередь никто не разбирает — не копим её (раньше росла бесконечно)
         Emotes.EmoteModule em = Emotes.module();
         if (em != null && em.isEnabled() && em.watchOthers.get()
            && payload.player() != null && Emotes.def(EmoteProtocol.id(payload.emote())) != null && INBOUND.size() < 256) {
            INBOUND.addLast(payload);
         }
      });
      ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> clear());
      ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> clear());
   }

   /** Сервер принимает наш канал эмоций? */
   public static boolean supported() {
      return ClientPlayNetworking.canSend(EmoteProtocol.Play.ID);
   }

   public static void send(String emote, float speed) {
      send(emote, speed, false);
   }

   public static void send(String emote, float speed, boolean loop) {
      if (emote != null && supported() && System.currentTimeMillis() - lastSend > 400L) {
         lastSend = System.currentTimeMillis();
         ClientPlayNetworking.send(new EmoteProtocol.Play(EmoteProtocol.encode(emote, loop), Math.max(0.2F, Math.min(3.0F, speed))));
      }
   }

   /** Остановку шлём всегда и сразу: иначе лимит подавит её сразу после старта. */
   public static void sendStop(String emote) {
      if (emote != null && supported()) {
         lastSend = System.currentTimeMillis();
         ClientPlayNetworking.send(new EmoteProtocol.Play(EmoteProtocol.encodeStop(emote), 1.0F));
      }
   }

   /** Разбирает очередь на клиентском тике: из сетевого потока мир трогать нельзя. */
   public static void applyInbound() {
      EmoteProtocol.Show s;
      class_310 mc = class_310.method_1551();

      while ((s = INBOUND.pollFirst()) != null) {
         if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
         }

         Emotes.EmoteModule em = Emotes.module();
         if (em == null || !em.isEnabled() || !em.watchOthers.get()) {
            clear();
            return;
         }

         UUID who = s.player();
         if (!who.equals(mc.field_1724.method_5667())) {
            class_1657 p = mc.field_1687.method_18470(who);
            if (p != null && !p.method_7325()) {
               String wire = s.emote();
               if (EmoteProtocol.isStop(wire)) {
                  Emotes.stop(p.method_5628());
               } else {
                  // NaN/Infinity из пакета давали NaN в углах модели — игрок пропадал; новая эмоция заменяет текущую
                  float speed = Float.isFinite(s.speed()) ? Math.max(0.2F, Math.min(3.0F, s.speed())) : 1.0F;
                  Emotes.play(p.method_5628(), EmoteProtocol.id(wire), speed, EmoteProtocol.isLoop(wire), true);
               }
            }
         }
      }
   }

   public static void clear() {
      INBOUND.clear();
   }
}
