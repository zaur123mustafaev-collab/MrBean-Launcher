package com.mrbean.visuals.net;

import com.mrbean.visuals.MrBeanClient;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class BadgeNetwork {
   private static volatile Set<UUID> verified = Collections.emptySet();
   private static boolean registered;

   private BadgeNetwork() {
   }

   public static void registerPayloads() {
      if (!registered) {
         registered = true;
         PayloadTypeRegistry.playC2S().register(BadgeProtocol.Handshake.ID, BadgeProtocol.Handshake.CODEC);
         PayloadTypeRegistry.playS2C().register(BadgeProtocol.VerifiedList.ID, BadgeProtocol.VerifiedList.CODEC);
      }
   }

   public static void init() {
      registerPayloads();
      ClientPlayNetworking.registerGlobalReceiver(BadgeProtocol.VerifiedList.ID, (payload, context) -> {
         Set<UUID> next = new HashSet<>(payload.players());
         if (context.player() != null) {
            next.remove(context.player().method_5667());
         }

         verified = Collections.unmodifiableSet(next);
      });
      ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
         verified = Collections.emptySet();
         if (ClientPlayNetworking.canSend(BadgeProtocol.Handshake.ID)) {
            ClientPlayNetworking.send(new BadgeProtocol.Handshake(MrBeanClient.VERSION));
         }
      });
      ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> verified = Collections.emptySet());
   }

   public static Set<UUID> verified() {
      return verified;
   }

   public static boolean isVerified(UUID id) {
      return verified.contains(id);
   }
}
