package com.mrbean.visuals.net;

import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Пакеты эмоций. Клиент шлёт Play, сервер разворачивает его в Show всем, кто поддержал канал.
 * Тот же формат, что в MrBeanServerBridge и MrBeanBadgePlugin — менять вместе.
 * Поле emote — строка, в ней же передаётся цикл и остановка: "dance", "dance~L", "!dance".
 * Старые серверы без правок ретранслируют строку как есть, а старый клиент её просто не узнает.
 */
public final class EmoteProtocol {
   public static final class_2960 PLAY_ID = class_2960.method_60655("mrbeanvisuals", "emote");
   public static final class_2960 SHOW_ID = class_2960.method_60655("mrbeanvisuals", "emote_show");
   private static final String LOOP = "~L";
   private static final String STOP = "!";

   private EmoteProtocol() {
   }

   public static String encode(String id, boolean loop) {
      return loop ? id + LOOP : id;
   }

   public static String encodeStop(String id) {
      return STOP + id;
   }

   public static boolean isStop(String wire) {
      return wire != null && wire.startsWith(STOP);
   }

   public static boolean isLoop(String wire) {
      return wire != null && wire.endsWith(LOOP);
   }

   /** Id эмоции из сетевого поля, без служебных суффиксов. */
   public static String id(String wire) {
      if (wire == null) {
         return "";
      } else {
         String s = wire.startsWith(STOP) ? wire.substring(STOP.length()) : wire;
         return s.endsWith(LOOP) ? s.substring(0, s.length() - LOOP.length()) : s;
      }
   }

   public record Play(String emote, float speed) implements class_8710 {
      public static final class_9154<Play> ID = new class_9154<>(EmoteProtocol.PLAY_ID);
      public static final class_9139<class_9129, Play> CODEC = class_9139.method_56437(
         Play::write, buf -> new Play(buf.method_10800(64), buf.readFloat())
      );

      private static void write(class_2540 buf, Play p) {
         buf.method_10814(p.emote());
         buf.method_52941(p.speed());
      }

      @Override
      public class_9154<? extends class_8710> method_56479() {
         return ID;
      }
   }

   public record Show(UUID player, String emote, float speed) implements class_8710 {
      public static final class_9154<Show> ID = new class_9154<>(EmoteProtocol.SHOW_ID);
      public static final class_9139<class_9129, Show> CODEC = class_9139.method_56437(
         Show::write, buf -> new Show(buf.method_10790(), buf.method_10800(64), buf.readFloat())
      );

      private static void write(class_2540 buf, Show p) {
         buf.method_10797(p.player());
         buf.method_10814(p.emote());
         buf.method_52941(p.speed());
      }

      @Override
      public class_9154<? extends class_8710> method_56479() {
         return ID;
      }
   }
}
