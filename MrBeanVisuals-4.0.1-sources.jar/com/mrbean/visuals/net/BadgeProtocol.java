package com.mrbean.visuals.net;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class BadgeProtocol {
   public static final class_2960 HANDSHAKE_ID = class_2960.method_60655("mrbeanvisuals", "handshake");
   public static final class_2960 BADGE_ID = class_2960.method_60655("mrbeanvisuals", "badge");

   private BadgeProtocol() {
   }

   public record Handshake(String version) implements class_8710 {
      public static final class_9154<Handshake> ID = new class_9154<>(BadgeProtocol.HANDSHAKE_ID);
      public static final class_9139<class_9129, Handshake> CODEC = class_9139.method_56437(
         Handshake::write, buf -> new Handshake(buf.method_10800(64))
      );

      private static void write(class_2540 buf, Handshake p) {
         buf.method_10814(p.version());
      }

      @Override
      public class_9154<? extends class_8710> method_56479() {
         return ID;
      }
   }

   public record VerifiedList(List<UUID> players) implements class_8710 {
      public static final class_9154<VerifiedList> ID = new class_9154<>(BadgeProtocol.BADGE_ID);
      public static final class_9139<class_9129, VerifiedList> CODEC = class_9139.method_56437(
         VerifiedList::write, VerifiedList::read
      );

      private static void write(class_2540 buf, VerifiedList p) {
         buf.method_10804(p.players().size());

         for (UUID id : p.players()) {
            buf.method_10797(id);
         }
      }

      private static VerifiedList read(class_2540 buf) {
         ArrayList<UUID> list = new ArrayList<>();
         int n = buf.method_10816();

         for (int i = 0; i < n; i++) {
            list.add(buf.method_10790());
         }

         return new VerifiedList(list);
      }

      @Override
      public class_9154<? extends class_8710> method_56479() {
         return ID;
      }
   }
}
