package com.mrbean.visuals.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Опрос Chromium-браузера через DevTools Protocol: что сейчас играет во вкладках, название трека
 * из Media Session и кадр страницы для мини-экранчика. Работает только если браузер запущен с
 * --remote-debugging-port. Опрашивается исключительно localhost; при недоступности браузера модуль
 * молча показывает своё состояние и не шумит в логах.
 */
public final class ChromeMedia {
   public record Media(String title, String artist, String url, String docTitle, boolean playing, float pos, float dur, boolean live) {
      public String text() {
         if (!this.playing) {
            return "";
         } else {
            String t = this.title.isEmpty() ? this.docTitle : this.title;
            return this.artist.isEmpty() ? t : t + " — " + this.artist;
         }
      }
   }

   private static final String EXPRESSION = "(function(){try{var m=(navigator.mediaSession&&navigator.mediaSession.metadata)||null;"
      + "var v=document.querySelectorAll('video');var b=null;"
      + "for(var i=0;i<v.length;i++){var e=v[i];if(!e.paused&&!e.ended&&e.readyState>1){b=e;break;}}"
      + "if(!b){var a=document.querySelectorAll('audio');for(var j=0;j<a.length;j++){if(!a[j].paused&&!a[j].ended){b=a[j];break;}}}"
      + "var d=b?(b.duration||0):0;if(!isFinite(d)||d<=0){d=0;}"
      + "return JSON.stringify({t:m&&m.title?m.title:'',ar:m&&m.artist?m.artist:'',dt:document.title||'',u:location.href||'',"
      + "p:!!b,d:d,c:b?(b.currentTime||0):0});"
      + "}catch(e){return JSON.stringify({t:'',ar:'',dt:'',u:'',p:false,d:0,c:0});}})()";
   private static final HttpClient HTTP = HttpClient.newBuilder()
      .version(HttpClient.Version.HTTP_1_1)
      .connectTimeout(java.time.Duration.ofMillis(800))
      .build();
   private static final Media EMPTY = new Media("", "", "", "", false, 0.0F, 0.0F, false);
   private static volatile Media media = EMPTY;
   private static volatile byte[] frame;
   private static volatile String state = "—";
   private static volatile String shotNote = "кадр ждём";
   private static volatile int fps;
   private static volatile boolean wantFrame;
   private static volatile boolean on;
   private static int refs;
   private static int port = 9222;
   private static Thread worker;
   private static Session sess;
   private static String sessWs = "";

   private ChromeMedia() {
   }

   public static Media media() {
      return media;
   }

   public static String state() {
      return state;
   }

   /** Последний кадр играющего видео, null — нового нет. */
   public static byte[] takeFrame() {
      byte[] f = frame;
      frame = null;
      return f;
   }

   public static void setDebugPort(int p) {
      if (p != port) {
         port = p;
         state = "—";
      }
   }

   public static void wantFrame(boolean b) {
      wantFrame = b;
      fps = 0;
      if (!b) {
         frame = null;
      } else {
         shotNote = "кадр ждём";
      }
   }

   public static synchronized void acquire() {
      refs++;
      if (on) {
         return;
      }

      on = true;
      worker = new Thread(ChromeMedia::loop, "mrbean-chrome-media");
      worker.setDaemon(true);
      worker.start();
   }

   public static synchronized void release() {
      refs = Math.max(0, refs - 1);

      if (refs == 0) {
         on = false;
         media = EMPTY;
         state = "—";
         frame = null;
      }
   }

   public static boolean running() {
      return on;
   }

   /**
    * Chrome с 136 версии игнорирует --remote-debugging-port в профиле по умолчанию, поэтому поднимаем
    * отдельное окно с своим --user-data-dir: чужие вкладки не трогаем, ничего не закрываем.
    * Блокирующий вызов — запускать только вне игрового потока.
    */
   public static String connect(int p, String dir) {
      File exe = browser();

      if (exe == null) {
         return "не найден Chrome или Edge";
      } else if (reachable(p)) {
         return "уже на связи, порт " + p;
      }

      try {
         new File(dir).mkdirs();
         List<String> cmd = new ArrayList();
         cmd.add("cmd");
         cmd.add("/c");
         cmd.add("start");
         cmd.add("");
         cmd.add(exe.getAbsolutePath());
         cmd.add("--remote-debugging-port=" + p);
         cmd.add("--user-data-dir=" + dir);
         cmd.add("--no-first-run");
         cmd.add("--no-default-browser-check");
         cmd.add("--restore-last-session");
         new ProcessBuilder(cmd).start();

         for (int i = 0; i < 60 && !reachable(p); i++) {
            Thread.sleep(500L);
         }

         return reachable(p)
            ? "окно с портом " + p + " открыто — запускай видео в нём"
            : "порт " + p + " так и не открылся";
      } catch (Exception var6) {
         return "не вышло: " + var6.getClass().getSimpleName();
      }
   }

   private static File browser() {
      String[] roots = {System.getenv("ProgramFiles"), System.getenv("ProgramFiles(x86)"), System.getenv("LOCALAPPDATA")};
      String[] names = {"Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe"};

      for (String name : names) {
         for (String root : roots) {
            if (root != null && !root.isEmpty()) {
               File f = new File(root + "/" + name);
               if (f.isFile()) {
                  return f;
               }
            }
         }
      }

      return null;
   }

   private static boolean reachable(int p) {
      try {
         HttpRequest req = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + p + "/json/version"))
            .timeout(java.time.Duration.ofMillis(700))
            .GET()
            .build();
         return HTTP.send(req, HttpResponse.BodyHandlers.ofString()).statusCode() == 200;
      } catch (Exception var3) {
         return false;
      }
   }

   private static void loop() {
      while (on) {
         try {
            poll();
            Thread.sleep(wantFrame ? 120L : 600L);
         } catch (InterruptedException var2) {
            return;
         } catch (Exception var3) {
            state = "переподключаюсь к браузеру";
            fps = 0;
            detach();
            try {
               Thread.sleep(2500L);
            } catch (InterruptedException var1) {
               return;
            }
         }
      }

      detach();
   }

   private static void poll() throws Exception {
      String body;

      try {
         body = get("/json/list");
      } catch (Exception var6) {
         media = EMPTY;
         state = "порт " + port + " закрыт → «Подключить Chrome»";
         detach();
         return;
      }

      JsonArrayHolder tabs = JsonArrayHolder.parse(body);

      if (tabs == null) {
         state = "порт " + port + " не отвечает";
         media = EMPTY;
         detach();
         return;
      }

      Media found = null;
      String best = "";
      String first = "";
      int checked = 0;

      for (JsonObject t : tabs.items) {
         if (checked >= 6) {
            break;
         }

         String ws = str(t, "webSocketDebuggerUrl");
         if (ws.isEmpty() || !"page".equals(str(t, "type"))) {
            continue;
         }

         checked++;
         if (first.isEmpty()) {
            first = ws;
         }

         // Chrome держит на вкладке только одно отладочное соединение, поэтому текущую цель
         // опрашиваем через постоянную сессию, а остальные — короткими.
         M m = ws.equals(sessWs) && sess != null ? sess.evaluate() : peek(ws);

         if (m == null) {
            continue;
         }

         if (m.playing && found == null) {
            found = m.toMedia();
            best = ws;
         } else if (found == null && !m.title.isEmpty()) {
            found = m.toMedia();
         }
      }

      media = found == null ? EMPTY : found;
      String base = "вкладок: " + checked + (media.playing() ? " · играет" : " · тишина");

      if (!wantFrame) {
         detach();
         state = base;
      } else {
         attach(best.isEmpty() ? first : best);

         if (sess != null) {
            sess.pump();
         }

         state = base + " · " + shotNote + (fps > 0 ? " " + fps + " к/с" : "");
      }
   }

   private static M peek(String ws) {
      Session s = null;

      try {
         s = new Session(ws);
         return s.evaluate();
      } catch (Exception var4) {
         return null;
      } finally {
         if (s != null) {
            s.close();
         }
      }
   }

   /** Постоянная сессия на вкладку с картинкой: один раз включили скринкаст, дальше только читаем кадры. */
   private static void attach(String ws) {
      if (ws.isEmpty() && sess == null) {
         return;
      }

      if (sess != null && ws.equals(sessWs)) {
         return;
      }

      detach();

      if (ws.isEmpty()) {
         return;
      }

      try {
         Session s = new Session(ws);
         s.startCast(360);
         boolean keep;
         synchronized (ChromeMedia.class) {
            keep = on && wantFrame;
            if (keep) {
               sess = s;
               sessWs = ws;
            }
         }

         if (keep) {
            shotNote = "поток кадров";
         } else {
            s.stopCast();
            s.close();
         }
      } catch (Exception var3) {
         shotNote = "кадр не идёт";
      }
   }

   private static void detach() {
      Session s;
      synchronized (ChromeMedia.class) {
         s = sess;
         sess = null;
         sessWs = "";
      }

      if (s != null) {
         s.stopCast();
         s.close();
      }
   }

   /** Одно соединение с вкладкой: опрос и снимок живут в нём же. */
   private static final class Session {
      private final WebSocket socket;
      private final Collector c = new Collector();
      private int nextId;
      private long lastFrame;

      Session(String ws) throws Exception {
         this.socket = HTTP.newWebSocketBuilder()
            .connectTimeout(java.time.Duration.ofMillis(1200L))
            .buildAsync(URI.create(ws), this.c)
            .get(1200L, TimeUnit.MILLISECONDS);
      }

      M evaluate() throws Exception {
         String res = this.call(
               "Runtime.evaluate", "{\"expression\":" + quote(EXPRESSION) + ",\"returnByValue\":true}", 1100L
            );
         JsonObject o = JsonParser.parseString(res).getAsJsonObject();
         JsonObject r = o.has("result") ? o.getAsJsonObject("result") : o;
         if (!r.has("result")) {
            return null;
         } else {
            JsonObject inner = r.getAsJsonObject("result");
            if (!inner.has("value")) {
               return null;
            } else {
               JsonObject v = JsonParser.parseString(inner.get("value").getAsString()).getAsJsonObject();
               M m = new M();
               m.title = str(v, "t");
               m.artist = str(v, "ar");
               m.docTitle = str(v, "dt");
               m.url = str(v, "u");
               m.playing = v.has("p") && v.get("p").getAsBoolean();
               m.dur = v.has("d") ? v.get("d").getAsFloat() : 0.0F;
               m.pos = v.has("c") ? v.get("c").getAsFloat() : 0.0F;
               return m;
            }
         }
      }

      /** Читает кадры ~секунду: скринкаст приходит сам, просто ждём и подтверждаем каждый. */
      void pump() throws Exception {
         long until = System.currentTimeMillis() + 950L;
         int n = 0;

         while (System.currentTimeMillis() < until) {
            String ev = this.event(200L);

            if (ev != null && this.handle(ev)) {
               n++;
            }
         }

         if (n > 0) {
            fps = n;
         }
      }

      private boolean handle(String ev) {
         try {
            JsonObject o = JsonParser.parseString(ev).getAsJsonObject();
            JsonObject p = o.getAsJsonObject("params");
            int sid = p.getAsJsonObject("metadata").get("sessionId").getAsInt();
            byte[] img = Base64.getDecoder().decode(p.get("data").getAsString());
            long t = System.currentTimeMillis();
            boolean fresh = img.length > 8 && img.length < 4000000 && t - this.lastFrame > 70L;

            if (fresh) {
               frame = img;
               this.lastFrame = t;
            }

            this.ack(sid);
            return fresh;
         } catch (Exception var6) {
            return false;
         }
      }

      private String call(String method, String params, long timeoutMs) throws Exception {
         int id = ++this.nextId;
         CompletableFuture<String> waiting = this.c.expect(id);
         String req = params == null
               ? "{\"id\":" + id + ",\"method\":\"" + method + "\"}"
               : "{\"id\":" + id + ",\"method\":\"" + method + "\",\"params\":" + params + "}";
         this.socket.sendText(req, true).get(timeoutMs, TimeUnit.MILLISECONDS);
         String res = waiting.get(timeoutMs, TimeUnit.MILLISECONDS);

         if (res == null) {
            throw new IllegalStateException("браузер молчит");
         } else {
            JsonObject o = JsonParser.parseString(res).getAsJsonObject();
            if (o.has("error")) {
               throw new IllegalStateException("браузер отказал");
            } else {
               return res;
            }
         }
      }

      void close() {
         try {
            this.socket.sendClose(1000, "done").get(300L, TimeUnit.MILLISECONDS);
         } catch (Exception var2) {
         }
      }

      void startCast(int max) throws Exception {
         this.call("Page.enable", null, 1500L);
         this.call(
               "Page.startScreencast",
               "{\"format\":\"png\",\"maxWidth\":" + max + ",\"maxHeight\":" + max + ",\"everyNthFrame\":1}",
               2000L
            );
      }

      void stopCast() {
         try {
            this.call("Page.stopScreencast", null, 800L);
         } catch (Exception var2) {
         }
      }

      String event(long timeoutMs) throws Exception {
         return this.c.event(timeoutMs);
      }

      void ack(int sessionId) {
         try {
            this.socket.sendText("{\"id\":" + ++this.nextId + ",\"method\":\"Page.screencastFrameAck\",\"params\":{\"sessionId\":" + sessionId + "}}", true)
               .get(600L, TimeUnit.MILLISECONDS);
         } catch (Exception var3) {
         }
      }
   }

   private static String get(String path) throws Exception {
      HttpRequest req = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path)).timeout(java.time.Duration.ofMillis(900)).GET().build();
      HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
      return r.statusCode() == 200 ? r.body() : null;
   }

   private static String quote(String s) {
      StringBuilder sb = new StringBuilder("\"");

      for (int i = 0; i < s.length(); i++) {
         char c = s.charAt(i);
         if (c == '"' || c == '\\') {
            sb.append('\\').append(c);
         } else if (c == '\n') {
            sb.append("\\n");
         } else if (c < ' ') {
            sb.append(String.format("\\u%04x", (int)c));
         } else {
            sb.append(c);
         }
      }

      return sb.append('"').toString();
   }

   private static String str(JsonObject o, String k) {
      return o != null && o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : "";
   }

   private static final class M {
      String title = "";
      String artist = "";
      String docTitle = "";
      String url = "";
      boolean playing;
      float dur;
      float pos;

      Media toMedia() {
         boolean live = this.playing && this.dur <= 0.0F;
         return new Media(this.title, this.artist, this.url, this.docTitle, this.playing, this.pos, this.dur, live);
      }
   }

   /** Обёртка над массивом вкладок, чтобы не тянуть gson ТипToken ради одного списка. */
   private static final class JsonArrayHolder {
      final List<JsonObject> items = new ArrayList<>();

      static JsonArrayHolder parse(String body) {
         if (body == null) {
            return null;
         } else {
            JsonArrayHolder h = new JsonArrayHolder();

            try {
               com.google.gson.JsonElement e = JsonParser.parseString(body);
               if (e.isJsonArray()) {
                  for (com.google.gson.JsonElement x : e.getAsJsonArray()) {
                     if (x.isJsonObject()) {
                        h.items.add(x.getAsJsonObject());
                     }
                  }

                  return h;
               }
            } catch (Exception var3) {
            }

            return null;
         }
      }
   }

   private static final class Collector implements WebSocket.Listener {
      private final StringBuilder buf = new StringBuilder();
      private final Map<Integer, CompletableFuture<String>> waiting = new ConcurrentHashMap<>();
      private final java.util.concurrent.BlockingQueue<String> events = new java.util.concurrent.LinkedBlockingQueue<>();

      CompletableFuture<String> expect(int id) {
         CompletableFuture<String> f = new CompletableFuture<>();
         this.waiting.put(id, f);
         return f;
      }

      /** Очередное событие браузера (кадр скринкаста), null — таймаут. */
      String event(long timeoutMs) throws Exception {
         return this.events.poll(timeoutMs, TimeUnit.MILLISECONDS);
      }

      public void onOpen(WebSocket s) {
         s.request(1);
      }

      public CompletionStage<?> onText(WebSocket s, CharSequence data, boolean last) {
         this.buf.append(data);

         if (last) {
            String txt = this.buf.toString();
            this.buf.setLength(0);

            try {
               JsonObject o = JsonParser.parseString(txt).getAsJsonObject();
               if (o.has("id")) {
                  CompletableFuture<String> f = this.waiting.remove(Integer.valueOf(o.get("id").getAsInt()));
                  if (f != null && (o.has("result") || o.has("error"))) {
                     f.complete(txt);
                  }
               } else if (o.has("method") && "Page.screencastFrame".equals(o.get("method").getAsString())) {
                  this.events.offer(txt);
               }
            } catch (Exception var5) {
            }
         }

         s.request(1);
         return null;
      }

      public void onError(WebSocket s, Throwable error) {
         this.failAll(error);
      }

      public CompletionStage<?> onClose(WebSocket s, int statusCode, String reason) {
         this.failAll(new IllegalStateException("соединение закрыто"));
         return null;
      }

      private void failAll(Throwable cause) {
         for (CompletableFuture<String> f : this.waiting.values()) {
            f.completeExceptionally(cause);
         }

         this.waiting.clear();
      }
   }
}
