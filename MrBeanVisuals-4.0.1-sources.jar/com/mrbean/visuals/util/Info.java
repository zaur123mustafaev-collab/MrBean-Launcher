package com.mrbean.visuals.util;

import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mrbean.visuals.module.impl.UtilityModules;
import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_640;

public final class Info {
   private static final class_310 mc = class_310.method_1551();
   private static final Deque<Long> leftClicks = new ArrayDeque<>();
   private static final Deque<Long> rightClicks = new ArrayDeque<>();
   public static double bps;
   private static double lastX;
   private static double lastZ;
   private static boolean hasLast;
   public static class_1309 lastTarget;
   public static long lastTargetTime;
   public static double lastReach;
   public static int combo;
   public static long lastHitTime;
   private static int lastHurtTime;
   public static long lastHurtAt;
   private static final Map<UUID, Integer> POPS = new HashMap<>();
   public static long sessionStart = System.currentTimeMillis();
   public static String deathPos;
   public static boolean deathAnnounced = true;
   private static boolean wasDead;
   private static final long[] frameNanos = new long[240];
   private static int frameIdx;
   private static int frameCount;
   private static long lastFrame;
   public static final float[] fpsHistory = new float[120];
   private static int fpsHistIdx;
   private static long lastFpsSample;
   private static double cpuLoad = -1.0;
   private static long lastCpuSample;

   private Info() {
   }

   public static void onTotemPop(class_1297 e) {
      POPS.merge(e.method_5667(), 1, Integer::sum);
   }

   public static int pops(class_1297 e) {
      return e == null ? 0 : POPS.getOrDefault(e.method_5667(), 0);
   }

   public static void onClick(int button) {
      long now = System.currentTimeMillis();
      if (button == 0) {
         leftClicks.addLast(now);
      } else if (button == 1) {
         rightClicks.addLast(now);
      }
   }

   private static int count(Deque<Long> q) {
      long now = System.currentTimeMillis();

      while (!q.isEmpty() && now - q.peekFirst() > 1000L) {
         q.pollFirst();
      }

      return q.size();
   }

   public static int cpsLeft() {
      return count(leftClicks);
   }

   public static int cpsRight() {
      return count(rightClicks);
   }

   public static int ping() {
      if (mc.field_1724 != null && mc.method_1562() != null) {
         class_640 e = mc.method_1562().method_2871(mc.field_1724.method_5667());
         return e == null ? 0 : e.method_2959();
      } else {
         return 0;
      }
   }

   public static String server() {
      if (mc.method_1558() != null) {
         return mc.method_1558().field_3761;
      } else {
         return mc.method_1542() ? "Одиночная игра" : "—";
      }
   }

   public static void onAttack(class_1309 target) {
      if (mc.field_1724 != null) {
         UtilityModules.PvpHelper.onAttack();
         lastReach = Math.sqrt(target.method_5829().method_49271(mc.field_1724.method_33571()));
         long now = System.currentTimeMillis();
         if (target != lastTarget || now - lastHitTime > 3000L) {
            combo = 0;
         }

         combo++;
         lastHitTime = now;
         lastTarget = target;
         lastTargetTime = now;
      }
   }

   public static void tick() {
      if (mc.field_1724 == null) {
         hasLast = false;
      } else {
         double x = mc.field_1724.method_23317();
         double z = mc.field_1724.method_23321();
         if (hasLast) {
            double d = Math.hypot(x - lastX, z - lastZ) * 20.0;
            bps = bps * 0.6 + d * 0.4;
         }

         lastX = x;
         lastZ = z;
         hasLast = true;
         int ht = mc.field_1724.field_6235;
         if (ht > lastHurtTime) {
            combo = 0;
            lastHurtAt = System.currentTimeMillis();
         }

         lastHurtTime = ht;
         if (System.currentTimeMillis() - lastHitTime > 3000L) {
            combo = 0;
         }

         boolean dead = mc.field_1724.method_29504();
         if (dead && !wasDead) {
            POPS.remove(mc.field_1724.method_5667());
         }

         if (dead && !wasDead) {
            String dim = mc.field_1687 == null ? "" : " §7(" + mc.field_1687.method_27983().method_29177().method_12832() + ")";
            deathPos = String.format("%d %d %d", mc.field_1724.method_31477(), mc.field_1724.method_31478(), mc.field_1724.method_31479()) + dim;
            deathAnnounced = false;
         }

         wasDead = dead;
      }
   }

   public static void frame() {
      long now = System.nanoTime();
      if (lastFrame != 0L) {
         frameNanos[frameIdx] = now - lastFrame;
         frameIdx = (frameIdx + 1) % frameNanos.length;
         frameCount = Math.min(frameCount + 1, frameNanos.length);
      }

      lastFrame = now;
      if (now - lastFpsSample > 250000000L) {
         lastFpsSample = now;
         fpsHistory[fpsHistIdx] = mc.method_47599();
         fpsHistIdx = (fpsHistIdx + 1) % fpsHistory.length;
      }

      if (now - lastCpuSample > 1000000000L) {
         lastCpuSample = now;

         try {
            if (Mobile.is()) {
               cpuLoad = -1.0;
               return;
            }

            if (ManagementFactory.getOperatingSystemMXBean() instanceof OperatingSystemMXBean sun) {
               cpuLoad = sun.getProcessCpuLoad();
            }
         } catch (Throwable var4) {
            cpuLoad = -1.0;
         }
      }
   }

   public static int fpsHistoryIndex() {
      return fpsHistIdx;
   }

   public static double avgFps() {
      if (frameCount == 0) {
         return mc.method_47599();
      } else {
         long sum = 0L;

         for (int i = 0; i < frameCount; i++) {
            sum += frameNanos[i];
         }

         return sum == 0L ? 0.0 : frameCount * 1.0E9 / sum;
      }
   }

   public static double frameTimeMs() {
      double f = avgFps();
      return f <= 0.0 ? 0.0 : 1000.0 / f;
   }

   public static double worstFrameMs() {
      long max = 0L;

      for (int i = 0; i < frameCount; i++) {
         max = Math.max(max, frameNanos[i]);
      }

      return max / 1000000.0;
   }

   public static long usedMemMb() {
      Runtime r = Runtime.getRuntime();
      return (r.totalMemory() - r.freeMemory()) / 1048576L;
   }

   public static long maxMemMb() {
      return Runtime.getRuntime().maxMemory() / 1048576L;
   }

   public static double cpu() {
      return cpuLoad;
   }

   public static String gpu() {
      try {
         GpuDevice d = RenderSystem.tryGetDevice();
         return d == null ? "?" : d.getRenderer();
      } catch (Throwable var1) {
         return "?";
      }
   }

   public static boolean microsoftAccount() {
      class_320 s = mc.method_1548();
      String t = s.method_1674();
      return t != null && t.length() > 40 && s.method_38741().isPresent();
   }

   public static class_1309 currentTarget() {
      if (mc.field_1692 instanceof class_1309 le && le.method_5805()) {
         return le;
      } else {
         return lastTarget != null
               && lastTarget.method_5805()
               && System.currentTimeMillis() - lastTargetTime < 4000L
               && mc.field_1724 != null
               && lastTarget.method_5739(mc.field_1724) < 12.0F
            ? lastTarget
            : null;
      }
   }
}
