package com.mrbean.visuals.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mrbean.visuals.MrBeanClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;

public final class LauncherBridge {
   private static long loadedAt = -1L;
   private static boolean available;
   private static Path requestFile;
   private static String currentUuid;
   private static String offlineNick = "";
   private static boolean msBlocked;
   private static final List<LauncherBridge.Account> accounts = new ArrayList<>();

   private LauncherBridge() {
   }

   private static Path file() {
      return FabricLoader.getInstance().getConfigDir().resolve("mrbeanvisuals").resolve("launcher_accounts.json");
   }

   public static synchronized void refresh() {
      long now = System.currentTimeMillis();
      if (loadedAt <= 0L || now - loadedAt >= 2000L) {
         loadedAt = now;
         accounts.clear();
         available = false;
         requestFile = null;
         currentUuid = null;

         try {
            if (System.getProperty("mrbean.launcher") == null) {
               return;
            }

            Path f = file();
            if (!Files.exists(f)) {
               return;
            }

            JsonObject j = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            if (j.has("request")) {
               requestFile = Path.of(j.get("request").getAsString());
            }

            if (j.has("current") && !j.get("current").isJsonNull()) {
               currentUuid = j.get("current").getAsString();
            }

            if (j.has("offlineNick")) {
               offlineNick = j.get("offlineNick").getAsString();
            }

            msBlocked = j.has("msBlocked") && j.get("msBlocked").getAsBoolean();

            for (JsonElement e : j.has("accounts") ? j.getAsJsonArray("accounts") : new JsonArray()) {
               JsonObject a = e.getAsJsonObject();
               accounts.add(
                  new LauncherBridge.Account(str(a, "name"), str(a, "uuid"), str(a, "skin"), true, a.has("needsLogin") && a.get("needsLogin").getAsBoolean())
               );
            }

            available = requestFile != null;
         } catch (Exception var8) {
         }
      }
   }

   private static String str(JsonObject o, String k) {
      return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
   }

   public static boolean available() {
      refresh();
      return available;
   }

   public static List<LauncherBridge.Account> accounts() {
      refresh();
      return accounts;
   }

   public static String offlineNick() {
      refresh();
      return offlineNick;
   }

   public static boolean msBlocked() {
      refresh();
      return msBlocked;
   }

   public static String currentUuid() {
      refresh();
      return currentUuid;
   }

   public static boolean switchTo(String uuid) {
      return send("select", uuid, null);
   }

   public static boolean switchOffline(String nick) {
      return send("offline", null, nick);
   }

   public static boolean addAccount() {
      return send("add", null, null);
   }

   private static boolean send(String action, String uuid, String nick) {
      refresh();
      if (!available) {
         MrBeanClient.LOG.warn("[Аккаунты] лаунчер недоступен — игра запущена не через MrBean Launcher");
         return false;
      } else {
         try {
            JsonObject r = new JsonObject();
            r.addProperty("action", action);
            if (uuid != null) {
               r.addProperty("uuid", uuid);
            }

            if (nick != null) {
               r.addProperty("nick", nick);
            }

            r.addProperty("time", System.currentTimeMillis());
            Files.writeString(requestFile, new Gson().toJson(r), StandardCharsets.UTF_8);
            MrBeanClient.LOG.info("[Аккаунты] запрос лаунчеру: {} → {}, игра перезапустится", action, requestFile);
            class_310.method_1551().method_1592();
            return true;
         } catch (Exception var4) {
            MrBeanClient.LOG.error("[Аккаунты] не удалось записать запрос", var4);
            return false;
         }
      }
   }

   public static boolean validNick(String n) {
      return n != null && n.matches("[A-Za-z0-9_]{3,16}");
   }

   public record Account(String name, String uuid, String skin, boolean microsoft, boolean needsLogin) {
   }
}
