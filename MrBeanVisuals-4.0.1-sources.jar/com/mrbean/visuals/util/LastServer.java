package com.mrbean.visuals.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_642;

public final class LastServer {
   private static LastServer.Entry cached;
   private static boolean loaded;

   private LastServer() {
   }

   private static Path file() {
      return FabricLoader.getInstance().getConfigDir().resolve("mrbeanvisuals").resolve("last_server.json");
   }

   public static LastServer.Entry get() {
      if (!loaded) {
         loaded = true;

         try {
            if (Files.exists(file())) {
               JsonObject j = JsonParser.parseString(Files.readString(file(), StandardCharsets.UTF_8)).getAsJsonObject();
               cached = new LastServer.Entry(j.get("name").getAsString(), j.get("address").getAsString());
            }
         } catch (Exception var1) {
         }
      }

      return cached;
   }

   public static void remember(class_310 mc) {
      class_642 si = mc.method_1558();
      if (si != null && si.field_3761 != null && !si.method_2994()) {
         cached = new LastServer.Entry(si.field_3752 != null && !si.field_3752.isBlank() ? si.field_3752 : si.field_3761, si.field_3761);
         loaded = true;

         try {
            Files.createDirectories(file().getParent());
            JsonObject j = new JsonObject();
            j.addProperty("name", cached.name());
            j.addProperty("address", cached.address());
            Files.writeString(file(), j.toString(), StandardCharsets.UTF_8);
         } catch (Exception var3) {
         }
      }
   }

   public static String currentAddress(class_310 mc) {
      class_642 si = mc.method_1558();
      return si != null && si.field_3761 != null ? si.field_3761.toLowerCase() : "";
   }

   public record Entry(String name, String address) {
   }
}
