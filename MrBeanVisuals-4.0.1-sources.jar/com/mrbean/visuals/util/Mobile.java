package com.mrbean.visuals.util;

import com.mrbean.visuals.module.Modules;
import java.io.File;

public final class Mobile {
   private static Boolean cached;

   private Mobile() {
   }

   public static boolean is() {
      if (cached != null) {
         return cached;
      } else {
         boolean m = false;

         try {
            String force = System.getProperty("mrbean.mobile");
            if (force != null) {
               m = Boolean.parseBoolean(force);
            } else {
               m = new File("/system/build.prop").exists()
                  || System.getenv("POJAV_RENDERER") != null
                  || System.getenv("POJAV_NATIVEDIR") != null
                  || System.getProperty("java.vendor", "").toLowerCase().contains("android")
                  || System.getProperty("java.home", "").startsWith("/data/");
            }
         } catch (Throwable var2) {
         }

         return cached = m;
      }
   }

   public static float item() {
      return is() ? (float)(Modules.theme().mobileItem.value / 100.0) : 1.0F;
   }

   public static float hud() {
      return is() ? (float)(Modules.theme().mobileHud.value / 100.0) : 1.0F;
   }

   public static float menu() {
      return is() ? (float)(Modules.theme().mobileMenu.value / 100.0) : 1.0F;
   }
}
