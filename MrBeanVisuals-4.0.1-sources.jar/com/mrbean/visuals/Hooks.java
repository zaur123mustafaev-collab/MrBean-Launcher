package com.mrbean.visuals;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.gui.Screens;
import com.mrbean.visuals.gui.menu.MainMenuScreen;
import com.mrbean.visuals.test.AutoTest;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_442;

public final class Hooks {
   private static boolean wizardShown;

   private Hooks() {
   }

   public static void onTick(class_310 mc) {
      while (MrBeanClient.menuKey.method_1436()) {
         if (mc.field_1755 == null) {
            mc.method_1507(Screens.menu());
         }
      }

      while (MrBeanClient.hudEditorKey.method_1436()) {
         if (mc.field_1755 == null) {
            mc.method_1507(Screens.hudEditor(null));
         }
      }

      if (!Config.firstRunDone && !wizardShown && !AutoTest.active() && (mc.field_1755 instanceof class_442 || mc.field_1755 instanceof MainMenuScreen)
         )
       {
         wizardShown = true;
         mc.method_1507(Screens.wizard(mc.field_1755));
      }
   }

   public static void beforeHud(class_332 ctx, float delta) {
   }

   public static boolean menuOpen() {
      return Screens.isMenu(class_310.method_1551().field_1755);
   }
}
