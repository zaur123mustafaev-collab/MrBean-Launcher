package com.mrbean.visuals.optimize;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class OptimizationScreen extends class_437 {
   private final class_437 parent;
   private final Ui ui = new Ui();
   private double scroll;
   private boolean confirm;

   public OptimizationScreen(class_437 parent) {
      super(class_2561.method_43470("Optimization"));
      this.parent = parent;
   }

   protected void method_25426() {
      if (OptMods.entries.isEmpty() || OptMods.entries.stream().allMatch(e -> e.state == OptMods.State.CHECKING)) {
         OptMods.check();
      }
   }

   public boolean method_25421() {
      return false;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      int w = Math.min(460, this.field_22789 - 20);
      int h = Math.min(320, this.field_22790 - 20);
      int x = (this.field_22789 - w) / 2;
      int y = (this.field_22790 - h) / 2;
      this.ui.begin(context, mouseX, mouseY);
      R2D.panel(context, x, y, w, h, 10, -267382248, true, 587202559);
      int used = this.drawBody(this.ui, context, x + 10, y + 8, w - 20, h - 16, true);
      this.ui.end();
   }

   public int drawBody(Ui ui, class_332 ctx, int x, int y, int w, int h, boolean standalone) {
      int yy = y;
      if (standalone) {
         R2D.textScaled(ctx, Lang.t("Оптимизационные моды", "Optimization mods"), x, y + 2, 1.25F, -1, false);
         if (ui.button("opt_back", x + w - 60, y, 60, 14, Lang.ui("ui.back"), 2)) {
            this.field_22787.method_1507(this.parent);
         }

         yy = y + 18;
      }

      String env = "Minecraft " + OptMods.mcVersion + " · Fabric " + OptMods.loaderVersion + " · Java " + OptMods.javaVersion;
      R2D.text(ctx, env + (OptMods.javaOk ? "  §a✔" : "  §c✖ Java 21+"), x, yy, -6643532, false);
      yy += 11;
      R2D.textScaled(
         ctx,
         Lang.t(
            "Моды скачиваются напрямую с Modrinth и проверяются по SHA-512. Ничего не ставится без твоего согласия.",
            "Mods are downloaded directly from Modrinth and verified with SHA-512. Nothing is installed without your consent."
         ),
         x,
         yy,
         0.75F,
         -9735802,
         false
      );
      yy += 10;
      int listH = h - (yy - y) - 52;
      ctx.method_44379(x - 2, yy, x + w + 2, yy + listH);
      if (ui.scroll != 0.0 && R2D.inside(ui.mx, ui.my, x, yy, w, listH)) {
         this.scroll = Math.max(0.0, this.scroll - ui.scroll * 16.0);
         ui.scroll = 0.0;
      }

      double oy = ui.my;
      ui.my = ui.my + this.scroll;
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(0.0F, (float)(-this.scroll));
      int ly = yy + 2;

      for (OptMods.Entry e : OptMods.entries) {
         R2D.round(ctx, x, ly, w, 24, 6, OptimizationScreen.Modulesish.panel());
         boolean selectable = e.state == OptMods.State.AVAILABLE || e.state == OptMods.State.UPDATE;
         if (selectable) {
            boolean nv = ui.toggle("opt:" + e.slug, x + 6, ly + 6, e.selected);
            if (nv != e.selected) {
               e.selected = nv;
            }
         } else {
            R2D.text(ctx, icon(e.state), x + 12, ly + 8, color(e.state), false);
         }

         R2D.text(ctx, e.name + (e.dependency ? Lang.t(" §7(зависимость)", " §7(dependency)") : ""), x + 34, ly + 3, -1, false);
         R2D.textScaled(ctx, e.desc(), x + 34, ly + 14, 0.75F, -6643532, false);
         String st = label(e) + (e.note.isEmpty() ? "" : " · " + e.note);
         if (R2D.width(st) > w / 2) {
            st = st.substring(0, Math.min(st.length(), 40)) + "…";
         }

         R2D.text(ctx, st, x + w - 6 - R2D.width(st), ly + 8, color(e.state), false);
         ly += 27;
      }

      ctx.method_51448().popMatrix();
      ui.my = oy;
      ctx.method_44380();
      int contentH = ly - yy;
      this.scroll = Math.min(this.scroll, (double)Math.max(0, contentH - listH));
      yy += listH + 4;
      R2D.round(ctx, x, yy, w, 3, 1, 1090519039);
      if (OptMods.busy) {
         R2D.round(ctx, x, yy, Math.max(3, (int)(w * OptMods.progress)), 3, 1, R2D.accent(0.0F));
      }

      R2D.text(ctx, OptMods.status, x, yy + 6, OptMods.restartNeeded ? -11174 : -6643532, false);
      yy += 18;
      long count = OptMods.entries.stream().filter(e -> e.selected && (e.state == OptMods.State.AVAILABLE || e.state == OptMods.State.UPDATE)).count();
      long size = OptMods.entries
         .stream()
         .filter(e -> e.selected && (e.state == OptMods.State.AVAILABLE || e.state == OptMods.State.UPDATE))
         .mapToLong(e -> e.size)
         .sum();
      String miss = OptMods.missingDependency();
      if (miss != null) {
         R2D.textScaled(ctx, Lang.t("Нужна зависимость: ", "Missing dependency: ") + miss, x + 260, yy - 10, 0.75F, -34172, false);
      }

      String ib = this.confirm
         ? Lang.t("Подтвердить установку ", "Confirm install ") + count + Lang.t(" шт.", "")
         : Lang.t("Установить выбранные (", "Install selected (") + count + ", " + String.format("%.1f", size / 1048576.0) + " MB)";
      if (!OptMods.busy && count > 0L && miss == null && ui.button("opt_install", x, yy, 200, 16, ib, 1)) {
         if (!this.confirm) {
            this.confirm = true;
         } else {
            this.confirm = false;
            OptMods.install();
         }
      }

      if (!OptMods.busy && ui.button("opt_check", x + 206, yy, 90, 16, Lang.t("Проверить", "Re-check"), 0)) {
         OptMods.check();
      }

      if (!OptMods.busy && ui.button("opt_restore", x + 302, yy, w - 302, 16, Lang.t("Откатить последнюю", "Undo last install"), 3)) {
         String r = OptMods.restoreLast();
         OptMods.status = r;
         Notifications.push(r, true);
         OptMods.check();
      }

      return yy + 18 - y;
   }

   private static String icon(OptMods.State s) {
      return switch (s) {
         case INSTALLED, DONE -> "✔";
         case CHECKING -> "…";
         case NO_VERSION -> "–";
         case INCOMPATIBLE, ERROR -> "✖";
         default -> "•";
      };
   }

   private static int color(OptMods.State s) {
      return switch (s) {
         case INSTALLED, DONE -> -11870592;
         default -> -2038804;
         case NO_VERSION -> -6643532;
         case INCOMPATIBLE, ERROR -> -34172;
         case UPDATE -> -11174;
      };
   }

   private static String label(OptMods.Entry e) {
      return switch (e.state) {
         case INSTALLED -> Lang.t("установлен ", "installed ") + (e.installedVersion == null ? "" : e.installedVersion);
         case DONE -> Lang.t("установлен", "installed");
         case CHECKING -> Lang.t("проверка…", "checking…");
         case NO_VERSION -> Lang.t("нет версии", "no version");
         case INCOMPATIBLE -> Lang.t("несовместим", "incompatible");
         case ERROR -> Lang.t("ошибка", "error");
         case UPDATE -> Lang.t("есть обновление", "update available");
         case AVAILABLE -> e.versionNumber == null ? "" : e.versionNumber;
      };
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      if (input.comp_4795() == 256) {
         this.field_22787.method_1507(this.parent);
         return true;
      } else {
         return super.method_25404(input);
      }
   }

   static final class Modulesish {
      static int panel() {
         return Modules.theme().panel();
      }
   }
}
