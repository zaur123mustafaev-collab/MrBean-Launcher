package com.mrbean.visuals.optimize;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_155;

public final class OptMods {
   public static final String API = "https://api.modrinth.com/v2";
   private static final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15L)).followRedirects(Redirect.NORMAL).build();
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   public static final List<OptMods.Entry> entries = new ArrayList<>();
   public static volatile String status = "";
   public static volatile boolean busy;
   public static volatile float progress;
   public static volatile boolean restartNeeded;
   public static String mcVersion = "?";
   public static String loaderVersion = "?";
   public static int javaVersion;
   public static boolean javaOk;
   public static boolean loaderOk;

   private OptMods() {
   }

   private static void define() {
      entries.clear();
      entries.add(
         new OptMods.Entry(
            "sodium", "Sodium", "Новый движок рендера — обычно самый большой прирост FPS", "Modern rendering engine — usually the biggest FPS gain"
         )
      );
      entries.add(new OptMods.Entry("lithium", "Lithium", "Оптимизация физики, ИИ мобов и тиков", "Optimizes physics, mob AI and ticking"));
      entries.add(new OptMods.Entry("ferrite-core", "FerriteCore", "Меньше потребление оперативной памяти", "Reduces memory usage"));
      entries.add(new OptMods.Entry("immediatelyfast", "ImmediatelyFast", "Быстрее рисует HUD, текст и предметы", "Faster HUD, text and item rendering"));
      entries.add(new OptMods.Entry("entityculling", "Entity Culling", "Не рисует невидимых мобов и сущности", "Skips rendering of hidden entities"));
      entries.add(new OptMods.Entry("moreculling", "More Culling", "Не рисует скрытые части блоков", "Culls hidden block faces"));
      entries.add(new OptMods.Entry("modernfix", "ModernFix", "Быстрее запуск и меньше памяти", "Faster startup and lower memory"));
      entries.add(new OptMods.Entry("dynamic-fps", "Dynamic FPS", "Снижает FPS, когда окно свёрнуто", "Lowers FPS when the game is in the background"));
      entries.add(new OptMods.Entry("sodium-extra", "Sodium Extra", "Дополнительные графические настройки для Sodium", "Extra graphics options for Sodium"));
      entries.add(new OptMods.Entry("reeses-sodium-options", "Reese's Sodium Options", "Удобное меню настроек Sodium", "Better Sodium options screen"));

      for (OptMods.Entry e : entries) {
         e.selected = true;
      }
   }

   private static String get(String url) throws Exception {
      HttpRequest r = HttpRequest.newBuilder(URI.create(url))
         .timeout(Duration.ofSeconds(25L))
         .header("User-Agent", "MrBeanVisuals/3.5.0 (minecraft mod)")
         .GET()
         .build();
      HttpResponse<String> resp = http.send(r, BodyHandlers.ofString());
      if (resp.statusCode() / 100 != 2) {
         throw new Exception("HTTP " + resp.statusCode());
      } else {
         return resp.body();
      }
   }

   private static String post(String url, String json) throws Exception {
      HttpRequest r = HttpRequest.newBuilder(URI.create(url))
         .timeout(Duration.ofSeconds(25L))
         .header("User-Agent", "MrBeanVisuals/3.5.0")
         .header("Content-Type", "application/json")
         .POST(BodyPublishers.ofString(json))
         .build();
      HttpResponse<String> resp = http.send(r, BodyHandlers.ofString());
      if (resp.statusCode() / 100 != 2) {
         throw new Exception("HTTP " + resp.statusCode());
      } else {
         return resp.body();
      }
   }

   private static String enc(String s) {
      return URLEncoder.encode(s, StandardCharsets.UTF_8);
   }

   public static Path modsDir() {
      return FabricLoader.getInstance().getGameDir().resolve("mods");
   }

   private static String hash(Path p, String alg) throws Exception {
      MessageDigest md = MessageDigest.getInstance(alg);

      try (InputStream in = Files.newInputStream(p)) {
         byte[] buf = new byte[65536];

         int n;
         while ((n = in.read(buf)) > 0) {
            md.update(buf, 0, n);
         }
      }

      return HexFormat.of().formatHex(md.digest());
   }

   public static CompletableFuture<Void> check() {
      if (busy) {
         return CompletableFuture.completedFuture(null);
      } else {
         busy = true;
         progress = 0.0F;
         if (entries.isEmpty()) {
            define();
         }

         for (OptMods.Entry e : entries) {
            e.state = OptMods.State.CHECKING;
            e.note = "";
            e.installedFile = null;
         }

         return CompletableFuture.runAsync(
            () -> {
               try {
                  mcVersion = class_155.method_16673().comp_4025();
                  loaderVersion = FabricLoader.getInstance()
                     .getModContainer("fabricloader")
                     .map(c -> c.getMetadata().getVersion().getFriendlyString())
                     .orElse("?");
                  loaderOk = true;
                  javaVersion = Runtime.version().feature();
                  javaOk = javaVersion >= 21;
                  status = Lang.t("Ищу установленные моды…", "Looking for installed mods…");
                  Map<String, Path> byHash = new LinkedHashMap<>();
                  Files.createDirectories(modsDir());

                  try (Stream<Path> s = Files.list(modsDir())) {
                     for (Path p : s.filter(px -> px.toString().endsWith(".jar")).toList()) {
                        byHash.put(hash(p, "SHA-1"), p);
                     }
                  }

                  Map<String, String[]> installed = new LinkedHashMap<>();
                  if (!byHash.isEmpty()) {
                     JsonObject req = new JsonObject();
                     JsonArray arr = new JsonArray();
                     byHash.keySet().forEach(arr::add);
                     req.add("hashes", arr);
                     req.addProperty("algorithm", "sha1");
                     JsonObject resp = JsonParser.parseString(post("https://api.modrinth.com/v2/version_files", GSON.toJson(req))).getAsJsonObject();

                     for (Map.Entry<String, JsonElement> exxx : resp.entrySet()) {
                        JsonObject v = exxx.getValue().getAsJsonObject();
                        installed.put(
                           v.get("project_id").getAsString(),
                           new String[]{byHash.get(exxx.getKey()).getFileName().toString(), v.get("version_number").getAsString()}
                        );
                     }
                  }

                  boolean optifine = FabricLoader.getInstance().isModLoaded("optifabric");
                  int i = 0;

                  for (OptMods.Entry exx : new ArrayList<>(entries)) {
                     status = Lang.t("Проверяю ", "Checking ") + exx.name + "…";
                     progress = (float)(i++) / entries.size();
                     resolve(exx, installed, optifine);
                  }

                  for (OptMods.Entry ex : new ArrayList<>(entries)) {
                     if (ex.state == OptMods.State.AVAILABLE || ex.state == OptMods.State.UPDATE) {
                        for (String dep : ex.requiredDeps) {
                           if (!dep.equals("P7dR8mSH") && !installed.containsKey(dep) && !entries.stream().anyMatch(x -> dep.equals(x.projectId))) {
                              JsonObject proj = JsonParser.parseString(get("https://api.modrinth.com/v2/project/" + dep)).getAsJsonObject();
                              OptMods.Entry d = new OptMods.Entry(
                                 proj.get("slug").getAsString(), proj.get("title").getAsString(), "Нужен для " + ex.name, "Required by " + ex.name
                              );
                              d.dependency = true;
                              d.selected = true;
                              entries.add(d);
                              resolve(d, installed, optifine);
                           }
                        }
                     }
                  }

                  status = Lang.t("Готово. Выбери моды и нажми «Установить».", "Done. Pick mods and press Install.");
               } catch (Exception var17) {
                  MrBeanClient.LOG.warn("Проверка оптимизационных модов не удалась", var17);
                  status = Lang.t("Нет связи с Modrinth: ", "Cannot reach Modrinth: ") + var17.getMessage();

                  for (OptMods.Entry ex : entries) {
                     if (ex.state == OptMods.State.CHECKING) {
                        ex.state = OptMods.State.ERROR;
                     }
                  }
               } finally {
                  busy = false;
                  progress = 1.0F;
               }
            }
         );
      }
   }

   private static void resolve(OptMods.Entry e, Map<String, String[]> installed, boolean optifine) {
      try {
         String url = "https://api.modrinth.com/v2/project/"
            + e.slug
            + "/version?game_versions="
            + enc("[\"" + mcVersion + "\"]")
            + "&loaders="
            + enc("[\"fabric\"]");
         JsonArray vers = JsonParser.parseString(get(url)).getAsJsonArray();
         if (vers.isEmpty()) {
            e.state = OptMods.State.NO_VERSION;
            e.selected = false;
            e.note = Lang.t("нет версии для ", "no version for ") + mcVersion;
            return;
         }

         JsonObject v = vers.get(0).getAsJsonObject();
         e.projectId = v.get("project_id").getAsString();
         e.versionId = v.get("id").getAsString();
         e.versionNumber = v.get("version_number").getAsString();
         JsonObject file = null;

         for (JsonElement f : v.getAsJsonArray("files")) {
            if (f.getAsJsonObject().get("primary").getAsBoolean()) {
               file = f.getAsJsonObject();
            }
         }

         if (file == null) {
            file = v.getAsJsonArray("files").get(0).getAsJsonObject();
         }

         e.url = file.get("url").getAsString();
         e.fileName = file.get("filename").getAsString();
         e.sha512 = file.getAsJsonObject("hashes").get("sha512").getAsString();
         e.size = file.get("size").getAsLong();
         e.requiredDeps.clear();
         e.incompatible.clear();

         for (JsonElement d : v.getAsJsonArray("dependencies")) {
            JsonObject dd = d.getAsJsonObject();
            if (dd.has("project_id") && !dd.get("project_id").isJsonNull()) {
               String type = dd.get("dependency_type").getAsString();
               if (type.equals("required")) {
                  e.requiredDeps.add(dd.get("project_id").getAsString());
               }

               if (type.equals("incompatible")) {
                  e.incompatible.add(dd.get("project_id").getAsString());
               }
            }
         }

         String[] inst = installed.get(e.projectId);
         if (inst != null) {
            e.installedFile = inst[0];
            e.installedVersion = inst[1];
            if (inst[1].equals(e.versionNumber)) {
               e.state = OptMods.State.INSTALLED;
               e.selected = false;
            } else {
               e.state = OptMods.State.UPDATE;
               e.note = inst[1] + " → " + e.versionNumber;
            }
         } else {
            e.state = OptMods.State.AVAILABLE;
         }

         for (String inc : e.incompatible) {
            if (installed.containsKey(inc)) {
               e.state = OptMods.State.INCOMPATIBLE;
               e.selected = false;
               e.note = Lang.t("конфликт с установленным модом", "conflicts with an installed mod");
            }
         }

         if (optifine && (e.slug.startsWith("sodium") || e.slug.equals("reeses-sodium-options") || e.slug.equals("immediatelyfast"))) {
            e.state = OptMods.State.INCOMPATIBLE;
            e.selected = false;
            e.note = Lang.t("несовместим с OptiFine", "incompatible with OptiFine");
         }
      } catch (Exception var11) {
         e.state = OptMods.State.ERROR;
         e.selected = false;
         e.note = var11.getMessage();
      }
   }

   public static String missingDependency() {
      for (OptMods.Entry e : entries) {
         if (e.selected) {
            for (String d : e.requiredDeps) {
               OptMods.Entry dep = entries.stream().filter(x -> d.equals(x.projectId)).findFirst().orElse(null);
               if (dep != null && !dep.selected && dep.state != OptMods.State.INSTALLED) {
                  return e.name + " → " + dep.name;
               }
            }
         }
      }

      return null;
   }

   public static CompletableFuture<Void> install() {
      if (busy) {
         return CompletableFuture.completedFuture(null);
      } else {
         busy = true;
         progress = 0.0F;
         List<OptMods.Entry> todo = entries.stream()
            .filter(e -> e.selected && (e.state == OptMods.State.AVAILABLE || e.state == OptMods.State.UPDATE))
            .toList();
         return CompletableFuture.runAsync(
            () -> {
               String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
               Path backup = Config.dir().resolve("opt_backup").resolve(stamp);
               JsonObject manifest = new JsonObject();
               JsonArray added = new JsonArray();
               JsonArray replaced = new JsonArray();
               int ok = 0;

               try {
                  Files.createDirectories(backup);

                  for (int i = 0; i < todo.size(); i++) {
                     OptMods.Entry e = todo.get(i);
                     status = Lang.t("Скачиваю ", "Downloading ") + e.name + " (" + (i + 1) + "/" + todo.size() + ")…";
                     progress = (float)i / todo.size();

                     try {
                        Path tmp = Files.createTempFile("mrbean-opt", ".jar");
                        HttpRequest r = HttpRequest.newBuilder(URI.create(e.url))
                           .timeout(Duration.ofMinutes(3L))
                           .header("User-Agent", "MrBeanVisuals/3.5.0")
                           .GET()
                           .build();
                        HttpResponse<Path> resp = http.send(r, BodyHandlers.ofFile(tmp));
                        if (resp.statusCode() / 100 != 2) {
                           throw new Exception("HTTP " + resp.statusCode());
                        }

                        String got = hash(tmp, "SHA-512");
                        if (!got.equalsIgnoreCase(e.sha512)) {
                           Files.deleteIfExists(tmp);
                           throw new Exception(Lang.t("контрольная сумма не совпала", "checksum mismatch"));
                        }

                        if (e.installedFile != null) {
                           Path old = modsDir().resolve(e.installedFile);
                           if (Files.exists(old)) {
                              Files.move(old, backup.resolve(e.installedFile), StandardCopyOption.REPLACE_EXISTING);
                              replaced.add(e.installedFile);
                           }
                        }

                        Path dest = modsDir().resolve(e.fileName);
                        Files.move(tmp, dest, StandardCopyOption.REPLACE_EXISTING);

                        try {
                           Files.setPosixFilePermissions(dest, PosixFilePermissions.fromString("rw-r--r--"));
                        } catch (Exception var20) {
                        }

                        added.add(e.fileName);
                        e.state = OptMods.State.DONE;
                        e.note = Lang.t("установлен, нужен перезапуск", "installed, restart needed");
                        ok++;
                     } catch (Exception var21) {
                        e.state = OptMods.State.ERROR;
                        e.note = var21.getMessage();
                        MrBeanClient.LOG.warn("Не удалось установить {}", e.name, var21);
                     }
                  }

                  manifest.add("added", added);
                  manifest.add("replaced", replaced);
                  manifest.addProperty("date", stamp);
                  Files.writeString(backup.resolve("manifest.json"), GSON.toJson(manifest));
                  restartNeeded = ok > 0;
                  status = ok == todo.size()
                     ? Lang.t("Готово! ", "Done! ") + Lang.ui("ui.restart_needed")
                     : Lang.t("Установлено ", "Installed ") + ok + "/" + todo.size() + Lang.t(". Ошибки — в списке.", ". See errors in the list.");
               } catch (Exception var22) {
                  status = Lang.t("Ошибка установки: ", "Install error: ") + var22.getMessage();
               } finally {
                  busy = false;
                  progress = 1.0F;
               }
            }
         );
      }
   }

   public static String restoreLast() {
      try {
         Path root = Config.dir().resolve("opt_backup");
         if (!Files.exists(root)) {
            return Lang.t("Нет резервных копий", "No backups");
         } else {
            Path last;
            try (Stream<Path> s = Files.list(root)) {
               last = s.filter(x$0 -> Files.isDirectory(x$0)).max(Path::compareTo).orElse(null);
            }

            if (last != null && Files.exists(last.resolve("manifest.json"))) {
               JsonObject m = JsonParser.parseString(Files.readString(last.resolve("manifest.json"))).getAsJsonObject();
               int n = 0;

               for (JsonElement e : m.getAsJsonArray("added")) {
                  if (Files.deleteIfExists(modsDir().resolve(e.getAsString()))) {
                     n++;
                  }
               }

               for (JsonElement ex : m.getAsJsonArray("replaced")) {
                  Path b = last.resolve(ex.getAsString());
                  if (Files.exists(b)) {
                     Files.move(b, modsDir().resolve(ex.getAsString()), StandardCopyOption.REPLACE_EXISTING);
                  }
               }

               Files.move(last, last.resolveSibling(last.getFileName() + "-restored"), StandardCopyOption.REPLACE_EXISTING);
               restartNeeded = true;
               return Lang.t("Откат выполнен (удалено модов: ", "Restored (removed mods: ") + n + "). " + Lang.ui("ui.restart_needed");
            } else {
               return Lang.t("Нет резервных копий", "No backups");
            }
         }
      } catch (Exception var9) {
         return Lang.t("Не удалось откатить: ", "Restore failed: ") + var9.getMessage();
      }
   }

   public static final class Entry {
      public final String slug;
      public final String name;
      public final String descRu;
      public final String descEn;
      public String projectId;
      public String versionId;
      public String versionNumber;
      public String fileName;
      public String url;
      public String sha512;
      public long size;
      public String installedFile;
      public String installedVersion;
      public OptMods.State state = OptMods.State.CHECKING;
      public boolean selected;
      public boolean dependency;
      public String note = "";
      public final List<String> requiredDeps = new ArrayList<>();
      public final List<String> incompatible = new ArrayList<>();

      Entry(String slug, String name, String ru, String en) {
         this.slug = slug;
         this.name = name;
         this.descRu = ru;
         this.descEn = en;
      }

      public String desc() {
         return Lang.t(this.descRu, this.descEn);
      }
   }

   public static enum State {
      CHECKING,
      INSTALLED,
      UPDATE,
      AVAILABLE,
      NO_VERSION,
      INCOMPATIBLE,
      ERROR,
      DONE;
   }
}
