package com.mrbean.visuals.render;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import com.mrbean.visuals.util.Mobile;
import java.util.Arrays;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_9922;
import net.minecraft.class_9960;

public final class PostFx {
   private static final class_310 mc = class_310.method_1551();
   private static final class_2960 PARAMS = class_2960.method_60655("mrbeanvisuals", "textures/effect/params.png");
   private static class_1043 params;
   private static final float[] last = new float[16];
   private static final float[] cur = new float[16];
   public static long lastNanos;

   private PostFx() {
   }

   private static void ensureParams() {
      if (params == null) {
         params = new class_1043(() -> "mrbeanvisuals_params", new class_1011(4, 1, false));
         mc.method_1531().method_4616(PARAMS, params);
         Arrays.fill(last, -1.0F);
      }
   }

   private static int b(float v) {
      return Math.max(0, Math.min(255, Math.round(v * 255.0F)));
   }

   private static void upload() {
      boolean changed = false;

      for (int i = 0; i < 16; i++) {
         if (Math.abs(cur[i] - last[i]) > 0.001F) {
            changed = true;
            break;
         }
      }

      if (changed) {
         System.arraycopy(cur, 0, last, 0, 16);
         class_1011 img = params.method_4525();

         for (int px = 0; px < 4; px++) {
            int r = b(cur[px * 4]);
            int g = b(cur[px * 4 + 1]);
            int bl = b(cur[px * 4 + 2]);
            int a = b(cur[px * 4 + 3]);
            img.method_61941(px, 0, a << 24 | r << 16 | g << 8 | bl);
         }

         params.method_4524();
      }
   }

   private static boolean on(String id) {
      Module m = Modules.get(id);
      return m != null && m.isEnabled();
   }

   public static void render(class_9922 pool) {
      if (mc.field_1687 != null) {
         if (!Mobile.is() || Modules.theme().mobileShaders.value) {
            boolean grade = on("color_grade");
            boolean vig = on("vignette");
            boolean bloom = on("bloom");
            boolean motion = on("motion_blur");
            boolean dof = on("dof");
            if (grade || vig || bloom || motion || dof) {
               long t0 = System.nanoTime();
               ensureParams();
               Arrays.fill(cur, 0.0F);
               if (grade) {
                  float[] p = ((VisualModules.ColorGrade)Modules.get("color_grade")).params();
                  cur[0] = p[0] / 2.0F;
                  cur[1] = p[1] / 2.0F;
                  cur[2] = p[2] / 2.0F;
                  cur[4] = p[3];
                  cur[5] = p[4];
                  cur[6] = p[5];
                  cur[7] = p[6];
                  cur[13] = 1.0F;
               } else {
                  cur[0] = 0.5F;
                  cur[1] = 0.5F;
                  cur[2] = 0.5F;
               }

               if (vig) {
                  cur[3] = ((VisualModules.Vignette)Modules.get("vignette")).strength.f() / 100.0F;
               }

               if (bloom) {
                  VisualModules.Bloom m = (VisualModules.Bloom)Modules.get("bloom");
                  cur[8] = m.threshold.f() / 100.0F;
                  cur[9] = m.intensity.f() / 200.0F;
               }

               if (motion) {
                  cur[10] = ((VisualModules.MotionBlur)Modules.get("motion_blur")).strength.f() / 100.0F;
               }

               if (dof) {
                  VisualModules.DepthOfField m = (VisualModules.DepthOfField)Modules.get("dof");
                  cur[11] = m.strength.f() / 100.0F;
                  cur[12] = m.focus.f() / 64.0F;
               }

               upload();
               if (dof) {
                  run("dof", pool);
               }

               if (bloom) {
                  run("bloom", pool);
               }

               if (motion) {
                  run("motion_blur", pool);
               }

               if (grade || vig) {
                  run("grade", pool);
               }

               lastNanos = System.nanoTime() - t0;
            }
         }
      }
   }

   private static void run(String name, class_9922 pool) {
      try {
         class_279 p = mc.method_62887().method_62941(class_2960.method_60655("mrbeanvisuals", name), class_9960.field_53902);
         if (p != null) {
            p.method_1258(mc.method_1522(), pool);
         }
      } catch (Exception var6) {
         MrBeanClient.LOG.error("Пост-эффект {} не работает", name, var6);

         String id = switch (name) {
            case "grade" -> "color_grade";
            case "motion_blur" -> "motion_blur";
            default -> name;
         };
         Module m = Modules.get(id);
         if (m != null) {
            m.setEnabled(false);
         }

         Notifications.push(Lang.t("Эффект не поддерживается: ", "Effect not supported: ") + name, false);
      }
   }
}
