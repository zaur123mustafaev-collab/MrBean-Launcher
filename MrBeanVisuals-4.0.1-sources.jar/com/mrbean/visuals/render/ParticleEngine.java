package com.mrbean.visuals.render;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class ParticleEngine {
   private static final class_310 mc = class_310.method_1551();
   public static final int CAPACITY = 4096;
   public static int limit = 1500;
   public static float sizeMul = 1.0F;
   public static final int STYLE_PLAIN = 0;
   public static final int STYLE_SPARKLE = 1;
   public static final int STYLE_FIREFLY = 2;
   public static final int STYLE_LEAF = 3;
   public static final int STYLE_SNOW = 4;
   private static final double[] x = new double[4096];
   private static final double[] y = new double[4096];
   private static final double[] z = new double[4096];
   private static final double[] px = new double[4096];
   private static final double[] py = new double[4096];
   private static final double[] pz = new double[4096];
   private static final float[] vx = new float[4096];
   private static final float[] vy = new float[4096];
   private static final float[] vz = new float[4096];
   private static final float[] size = new float[4096];
   private static final float[] gravity = new float[4096];
   private static final float[] drag = new float[4096];
   private static final float[] phase = new float[4096];
   private static final int[] color = new int[4096];
   private static final int[] life = new int[4096];
   private static final int[] maxLife = new int[4096];
   private static final int[] style = new int[4096];
   private static final boolean[] glow = new boolean[4096];
   private static int count;
   private static final Vector3f right = new Vector3f();
   private static final Vector3f up = new Vector3f();

   private ParticleEngine() {
   }

   public static int count() {
      return count;
   }

   public static void clear() {
      count = 0;
   }

   public static boolean spawn(
      double sx, double sy, double sz, float svx, float svy, float svz, int lifeTicks, float sz0, int argb, float grav, float dr, boolean glowing, int st
   ) {
      if (count >= Math.min(limit, 4096)) {
         return false;
      } else {
         int i = count++;
         x[i] = px[i] = sx;
         y[i] = py[i] = sy;
         z[i] = pz[i] = sz;
         vx[i] = svx;
         vy[i] = svy;
         vz[i] = svz;
         life[i] = 0;
         maxLife[i] = Math.max(1, lifeTicks);
         size[i] = sz0;
         color[i] = argb;
         gravity[i] = grav;
         drag[i] = dr;
         glow[i] = glowing;
         style[i] = st;
         phase[i] = (float)(Math.random() * Math.PI * 2.0);
         return true;
      }
   }

   public static void tick() {
      if (!mc.method_1493()) {
         int i = 0;

         while (i < count) {
            if (++life[i] >= maxLife[i]) {
               remove(i);
            } else {
               px[i] = x[i];
               py[i] = y[i];
               pz[i] = z[i];
               if (style[i] == 2) {
                  float t = life[i] * 0.08F + phase[i];
                  vx[i] = vx[i] + (float)Math.sin(t * 1.3) * 0.004F;
                  vz[i] = vz[i] + (float)Math.cos(t * 1.1) * 0.004F;
                  vy[i] = vy[i] + (float)Math.sin(t * 0.7) * 0.002F;
               } else if (style[i] == 3 || style[i] == 4) {
                  float t = life[i] * 0.1F + phase[i];
                  vx[i] = vx[i] + (float)Math.sin(t) * 0.003F;
                  vz[i] = vz[i] + (float)Math.cos(t * 0.8) * 0.003F;
               }

               vy[i] = vy[i] - gravity[i];
               vx[i] = vx[i] * drag[i];
               vy[i] = vy[i] * drag[i];
               vz[i] = vz[i] * drag[i];
               x[i] = x[i] + vx[i];
               y[i] = y[i] + vy[i];
               z[i] = z[i] + vz[i];
               i++;
            }
         }
      }
   }

   private static void remove(int i) {
      int l = --count;
      if (i != l) {
         x[i] = x[l];
         y[i] = y[l];
         z[i] = z[l];
         px[i] = px[l];
         py[i] = py[l];
         pz[i] = pz[l];
         vx[i] = vx[l];
         vy[i] = vy[l];
         vz[i] = vz[l];
         size[i] = size[l];
         gravity[i] = gravity[l];
         drag[i] = drag[l];
         phase[i] = phase[l];
         color[i] = color[l];
         life[i] = life[l];
         maxLife[i] = maxLife[l];
         style[i] = style[l];
         glow[i] = glow[l];
      }
   }

   public static void render(class_4587 ms, class_4598 buf, class_243 cam, float td) {
      if (count != 0) {
         Quaternionf rot = mc.field_1773.method_19418().method_23767();
         right.set(1.0F, 0.0F, 0.0F).rotate(rot);
         up.set(0.0F, 1.0F, 0.0F).rotate(rot);
         Matrix4f m = ms.method_23760().method_23761();

         for (int pass = 0; pass < 2; pass++) {
            class_4588 vc = null;

            for (int i = 0; i < count; i++) {
               if (glow[i] == (pass == 1)) {
                  if (vc == null) {
                     vc = buf.method_73477(pass == 1 ? World3D.glowLayer() : World3D.normalLayer());
                  }

                  float lf = (life[i] + td) / maxLife[i];
                  float alphaK = lf < 0.15F ? lf / 0.15F : (lf > 0.7F ? (1.0F - lf) / 0.3F : 1.0F);
                  float s = size[i] * sizeMul;
                  if (style[i] == 1) {
                     s *= 0.6F + 0.4F * (float)Math.abs(Math.sin((life[i] + td) * 0.4 + phase[i]));
                  }

                  if (style[i] == 2) {
                     alphaK *= 0.5F + 0.5F * (float)Math.abs(Math.sin((life[i] + td) * 0.15 + phase[i]));
                  }

                  int c = R2D.mulAlpha(color[i], Math.max(0.0F, Math.min(1.0F, alphaK)));
                  float ix = (float)(px[i] + (x[i] - px[i]) * td - cam.field_1352);
                  float iy = (float)(py[i] + (y[i] - py[i]) * td - cam.field_1351);
                  float iz = (float)(pz[i] + (z[i] - pz[i]) * td - cam.field_1350);
                  World3D.billboard(vc, m, ix, iy, iz, s, right.x, right.y, right.z, up.x, up.y, up.z, c);
               }
            }
         }
      }
   }
}
