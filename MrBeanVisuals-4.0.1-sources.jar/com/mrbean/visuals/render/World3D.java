package com.mrbean.visuals.render;

import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import org.joml.Matrix4f;

public final class World3D {
   private World3D() {
   }

   public static class_1921 normalLayer() {
      return class_12249.method_76023();
   }

   public static class_1921 glowLayer() {
      return class_12249.method_76003();
   }

   public static void vtx(class_4588 vc, Matrix4f m, float x, float y, float z, int argb) {
      vc.method_22918(m, x, y, z).method_1336(argb >> 16 & 0xFF, argb >> 8 & 0xFF, argb & 0xFF, argb >>> 24);
   }

   public static void cone(class_4588 vc, Matrix4f m, float r, float h, int seg, World3D.ColorFn fn) {
      for (int i = 0; i < seg; i++) {
         float a0 = (float)i / seg;
         float a1 = (float)(i + 1) / seg;
         double t0 = a0 * Math.PI * 2.0;
         double t1 = a1 * Math.PI * 2.0;
         float x0 = (float)Math.cos(t0) * r;
         float z0 = (float)Math.sin(t0) * r;
         float x1 = (float)Math.cos(t1) * r;
         float z1 = (float)Math.sin(t1) * r;
         float am = (a0 + a1) / 2.0F;
         vtx(vc, m, 0.0F, h, 0.0F, fn.color(am, 0.0F));
         vtx(vc, m, 0.0F, h, 0.0F, fn.color(am, 0.0F));
         vtx(vc, m, x1, 0.0F, z1, fn.color(a1, 1.0F));
         vtx(vc, m, x0, 0.0F, z0, fn.color(a0, 1.0F));
      }
   }

   public static void ring(class_4588 vc, Matrix4f m, float y, float rIn, float rOut, int seg, World3D.ColorFn fn) {
      for (int i = 0; i < seg; i++) {
         float a0 = (float)i / seg;
         float a1 = (float)(i + 1) / seg;
         double t0 = a0 * Math.PI * 2.0;
         double t1 = a1 * Math.PI * 2.0;
         float c0 = (float)Math.cos(t0);
         float s0 = (float)Math.sin(t0);
         float c1 = (float)Math.cos(t1);
         float s1 = (float)Math.sin(t1);
         vtx(vc, m, c0 * rIn, y, s0 * rIn, fn.color(a0, 0.0F));
         vtx(vc, m, c1 * rIn, y, s1 * rIn, fn.color(a1, 0.0F));
         vtx(vc, m, c1 * rOut, y, s1 * rOut, fn.color(a1, 1.0F));
         vtx(vc, m, c0 * rOut, y, s0 * rOut, fn.color(a0, 1.0F));
      }
   }

   public static void cylinder(class_4588 vc, Matrix4f m, float r, float y0, float y1, int seg, World3D.ColorFn fn) {
      for (int i = 0; i < seg; i++) {
         float a0 = (float)i / seg;
         float a1 = (float)(i + 1) / seg;
         double t0 = a0 * Math.PI * 2.0;
         double t1 = a1 * Math.PI * 2.0;
         float x0 = (float)Math.cos(t0) * r;
         float z0 = (float)Math.sin(t0) * r;
         float x1 = (float)Math.cos(t1) * r;
         float z1 = (float)Math.sin(t1) * r;
         vtx(vc, m, x0, y0, z0, fn.color(a0, 0.0F));
         vtx(vc, m, x1, y0, z1, fn.color(a1, 0.0F));
         vtx(vc, m, x1, y1, z1, fn.color(a1, 1.0F));
         vtx(vc, m, x0, y1, z0, fn.color(a0, 1.0F));
      }
   }

   public static void torus(class_4588 vc, Matrix4f m, float R, float r, int seg, int sides, World3D.ColorFn fn) {
      for (int i = 0; i < seg; i++) {
         float a0 = (float)i / seg;
         float a1 = (float)(i + 1) / seg;
         double u0 = a0 * Math.PI * 2.0;
         double u1 = a1 * Math.PI * 2.0;

         for (int j = 0; j < sides; j++) {
            double v0 = (double)j / sides * Math.PI * 2.0;
            double v1 = (double)(j + 1) / sides * Math.PI * 2.0;
            float shade0 = (float)(0.75 + 0.25 * Math.sin(v0));
            float shade1 = (float)(0.75 + 0.25 * Math.sin(v1));
            float[] p00 = tp(R, r, u0, v0);
            float[] p10 = tp(R, r, u1, v0);
            float[] p11 = tp(R, r, u1, v1);
            float[] p01 = tp(R, r, u0, v1);
            vtx(vc, m, p00[0], p00[1], p00[2], R2D.brighten(fn.color(a0, shade0), shade0));
            vtx(vc, m, p10[0], p10[1], p10[2], R2D.brighten(fn.color(a1, shade0), shade0));
            vtx(vc, m, p11[0], p11[1], p11[2], R2D.brighten(fn.color(a1, shade1), shade1));
            vtx(vc, m, p01[0], p01[1], p01[2], R2D.brighten(fn.color(a0, shade1), shade1));
         }
      }
   }

   private static float[] tp(float R, float r, double u, double v) {
      double cx = R + r * Math.cos(v);
      return new float[]{(float)(cx * Math.cos(u)), (float)(r * Math.sin(v)), (float)(cx * Math.sin(u))};
   }

   public static void quad(class_4588 vc, Matrix4f m, float[] a, float[] b, float[] c, float[] d, int ca, int cb, int cc, int cd) {
      vtx(vc, m, a[0], a[1], a[2], ca);
      vtx(vc, m, b[0], b[1], b[2], cb);
      vtx(vc, m, c[0], c[1], c[2], cc);
      vtx(vc, m, d[0], d[1], d[2], cd);
   }

   public static void cube(class_4588 vc, Matrix4f m, float s, int top, int side, int bottom) {
      float h = s / 2.0F;
      float[][] p = new float[][]{{-h, -h, -h}, {h, -h, -h}, {h, h, -h}, {-h, h, -h}, {-h, -h, h}, {h, -h, h}, {h, h, h}, {-h, h, h}};
      quad(vc, m, p[3], p[2], p[6], p[7], top, top, top, top);
      quad(vc, m, p[0], p[1], p[5], p[4], bottom, bottom, bottom, bottom);
      int s1 = R2D.brighten(side, 0.9F);
      int s2 = R2D.brighten(side, 0.75F);
      quad(vc, m, p[0], p[1], p[2], p[3], s1, s1, s1, s1);
      quad(vc, m, p[4], p[5], p[6], p[7], s1, s1, s1, s1);
      quad(vc, m, p[0], p[4], p[7], p[3], s2, s2, s2, s2);
      quad(vc, m, p[1], p[5], p[6], p[2], s2, s2, s2, s2);
   }

   public static void vtxUV(class_4588 vc, Matrix4f m, float x, float y, float z, float u, float v, int argb) {
      vc.method_22918(m, x, y, z)
        .method_22913(u, v)
        .method_22922(class_4608.field_21444)
        .method_60803(0xF000F0)
        .method_1336(argb >> 16 & 0xFF, argb >> 8 & 0xFF, argb & 0xFF, argb >>> 24)
        .method_22914(0.0F, 0.0F, 1.0F);
   }

   public static void billboard(
      class_4588 vc, Matrix4f m, float x, float y, float z, float size, float rx, float ry, float rz, float ux, float uy, float uz, int color
   ) {
      float h = size / 2.0F;
      vtx(vc, m, x - rx * h - ux * h, y - ry * h - uy * h, z - rz * h - uz * h, color);
      vtx(vc, m, x + rx * h - ux * h, y + ry * h - uy * h, z + rz * h - uz * h, color);
      vtx(vc, m, x + rx * h + ux * h, y + ry * h + uy * h, z + rz * h + uz * h, color);
      vtx(vc, m, x - rx * h + ux * h, y - ry * h + uy * h, z - rz * h + uz * h, color);
   }

   public interface ColorFn {
      int color(float var1, float var2);
   }
}
