package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.WorldModules;
import net.minecraft.class_12076;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_9975.class})
public class SkyRenderingMixin {
   @Inject(
      method = {"method_74926"},
      at = {@At("TAIL")}
   )
   private void mrbean$sky(class_638 world, float tickDelta, class_4184 camera, class_12076 state, CallbackInfo ci) {
      if (Modules.get("sky_color") instanceof WorldModules.SkyColor s && s.isEnabled()) {
         state.field_63097 = s.apply(state.field_63097);
         if (s.sunset.value) {
            state.field_63095 = s.apply(state.field_63095) & 16777215 | state.field_63095 & 0xFF000000;
         }
      }

      if (Modules.get("stars") instanceof WorldModules.Stars st && st.isEnabled()) {
         float b = st.always.value ? Math.max(state.field_63094, 0.5F) : state.field_63094;
         state.field_63094 = Math.min(1.0F, b * st.brightness.f() / 100.0F);
      }
   }

   @ModifyArg(
      method = {"method_62303"},
      at = {@At(
         value = "INVOKE",
         target = "Lorg/joml/Matrix4fStack;scale(FFF)Lorg/joml/Matrix4f;"
      )},
      index = 0,
      require = 0
   )
   private float mrbean$sunX(float v) {
      return v * sun();
   }

   @ModifyArg(
      method = {"method_62303"},
      at = {@At(
         value = "INVOKE",
         target = "Lorg/joml/Matrix4fStack;scale(FFF)Lorg/joml/Matrix4f;"
      )},
      index = 2,
      require = 0
   )
   private float mrbean$sunZ(float v) {
      return v * sun();
   }

   @ModifyArg(
      method = {"method_62304"},
      at = {@At(
         value = "INVOKE",
         target = "Lorg/joml/Matrix4fStack;scale(FFF)Lorg/joml/Matrix4f;"
      )},
      index = 0,
      require = 0
   )
   private float mrbean$moonX(float v) {
      return v * moon();
   }

   @ModifyArg(
      method = {"method_62304"},
      at = {@At(
         value = "INVOKE",
         target = "Lorg/joml/Matrix4fStack;scale(FFF)Lorg/joml/Matrix4f;"
      )},
      index = 2,
      require = 0
   )
   private float mrbean$moonZ(float v) {
      return v * moon();
   }

   private static float sun() {
      return Modules.get("sun_moon") instanceof WorldModules.SunMoon s && s.isEnabled() ? Math.max(1.0E-4F, s.sunSize.f() / 100.0F) : 1.0F;
   }

   private static float moon() {
      return Modules.get("sun_moon") instanceof WorldModules.SunMoon s && s.isEnabled() ? Math.max(1.0E-4F, s.moonSize.f() / 100.0F) : 1.0F;
   }
}
