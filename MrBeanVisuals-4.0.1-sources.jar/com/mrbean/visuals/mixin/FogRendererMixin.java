package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.WorldModules;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_758.class})
public class FogRendererMixin {
   @Inject(
      method = {"method_62185"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void mrbean$fogColor(class_4184 camera, float tickDelta, class_638 world, int viewDistance, float skyDarkness, CallbackInfoReturnable<Vector4f> cir) {
      if (Modules.get("fog") instanceof WorldModules.Fog f && f.isEnabled() && f.customColor.value) {
         int c = f.col();
         Vector4f v = (Vector4f)cir.getReturnValue();
         cir.setReturnValue(new Vector4f((c >> 16 & 0xFF) / 255.0F, (c >> 8 & 0xFF) / 255.0F, (c & 0xFF) / 255.0F, v.w));
      }
   }

   private static float mrbean$mul() {
      return Modules.get("fog") instanceof WorldModules.Fog f && f.isEnabled() ? f.mul() : 1.0F;
   }

   /**
    * Туман окружения (ordinal 0/1) несёт и слепоту/темноту, и туман под водой, в лаве и снегу.
    * Его трогаем только на открытом воздухе без этих эффектов — иначе «убрать туман» работал бы как анти-слепота.
    */
   private static float mrbean$envMul() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null
         || mc.field_1724.method_6059(class_1294.field_5919)
         || mc.field_1724.method_6059(class_1294.field_38092)
         || mc.field_1773.method_19418().method_19334() != class_5636.field_27888) {
         return 1.0F;
      } else {
         return mrbean$mul();
      }
   }

   @ModifyVariable(
      method = {"method_71110"},
      at = {@At("HEAD")},
      ordinal = 0,
      argsOnly = true
   )
   private float mrbean$envStart(float v) {
      return v * mrbean$envMul();
   }

   @ModifyVariable(
      method = {"method_71110"},
      at = {@At("HEAD")},
      ordinal = 1,
      argsOnly = true
   )
   private float mrbean$envEnd(float v) {
      return v * mrbean$envMul();
   }

   @ModifyVariable(
      method = {"method_71110"},
      at = {@At("HEAD")},
      ordinal = 2,
      argsOnly = true
   )
   private float mrbean$rdStart(float v) {
      return v * mrbean$mul();
   }

   @ModifyVariable(
      method = {"method_71110"},
      at = {@At("HEAD")},
      ordinal = 3,
      argsOnly = true
   )
   private float mrbean$rdEnd(float v) {
      return v * mrbean$mul();
   }
}
