package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.AnimationModules;
import com.mrbean.visuals.module.impl.FxModules;
import com.mrbean.visuals.util.Mobile;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_759.class})
public class HeldItemRendererMixin {
   @Shadow
   private class_1799 field_4047;
   @Shadow
   private class_1799 field_4048;
   @Shadow
   private float field_4043;
   @Shadow
   private float field_4053;
   @Shadow
   private float field_4052;
   @Shadow
   private float field_4051;
   @Unique
   private class_1799 mrbean$current = class_1799.field_8037;

   @Inject(
      method = {"method_3228"},
      at = {@At("HEAD")}
   )
   private void mrbean$handHead(
      class_742 player,
      float tickDelta,
      float pitch,
      class_1268 hand,
      float swing,
      class_1799 item,
      float equip,
      class_4587 ms,
      class_11659 queue,
      int light,
      CallbackInfo ci
   ) {
      ms.method_22903();
      if (Modules.get("hand_view") instanceof AnimationModules.HandView h && h.isEnabled()) {
         boolean right = hand == class_1268.field_5808 == (player.method_6068() == class_1306.field_6183);
         int side = right ? 1 : -1;
         ms.method_46416(h.x.f() * side, h.y.f(), h.z.f());
         ms.method_22907(class_7833.field_40714.rotationDegrees(h.rotX.f()));
         ms.method_22907(class_7833.field_40716.rotationDegrees(h.rotY.f() * side));
         float s = h.scale.f();
         ms.method_22905(s, s, s);
      }
   }

   @Inject(
      method = {"method_3228"},
      at = {@At("RETURN")}
   )
   private void mrbean$handTail(
      class_742 player,
      float tickDelta,
      float pitch,
      class_1268 hand,
      float swing,
      class_1799 item,
      float equip,
      class_4587 ms,
      class_11659 queue,
      int light,
      CallbackInfo ci
   ) {
      ms.method_22909();
   }

   @Inject(
      method = {"method_3233"},
      at = {@At("HEAD")},
      require = 0
   )
   private void mrbean$mobileItemHead(
      class_1309 e, class_1799 stack, class_811 mode, class_4587 ms, class_11659 q, int light, CallbackInfo ci
   ) {
      ms.method_22903();
      if (mode.method_29998()) {
         float f = Mobile.item();
         if (f != 1.0F) {
            ms.method_22905(f, f, f);
         }
      }
   }

   @Inject(
      method = {"method_3233"},
      at = {@At("RETURN")},
      require = 0
   )
   private void mrbean$mobileItemTail(
      class_1309 e, class_1799 stack, class_811 mode, class_4587 ms, class_11659 q, int light, CallbackInfo ci
   ) {
      ms.method_22909();
   }

   @Inject(
      method = {"method_3220"},
      at = {@At("TAIL")}
   )
   private void mrbean$noEquip(CallbackInfo ci) {
      if (Modules.get("item_switch") instanceof AnimationModules.ItemSwitch s && s.isEnabled() && s.mode.is("none")) {
         class_746 p = class_310.method_1551().field_1724;
         if (p != null) {
            this.field_4047 = p.method_6047();
            this.field_4048 = p.method_6079();
         }

         this.field_4043 = 1.0F;
         this.field_4053 = 1.0F;
         this.field_4052 = 1.0F;
         this.field_4051 = 1.0F;
      }
   }

   @Inject(
      method = {"method_3228"},
      at = {@At("HEAD")}
   )
   private void mrbean$rememberItem(
      class_742 player,
      float tickDelta,
      float pitch,
      class_1268 hand,
      float swing,
      class_1799 item,
      float equip,
      class_4587 ms,
      class_11659 queue,
      int light,
      CallbackInfo ci
   ) {
      this.mrbean$current = item;
   }

   @Inject(
      method = {"method_65816"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void mrbean$swing(float swingProgress, class_4587 ms, int armX, class_1306 arm, CallbackInfo ci) {
      FxModules.SwordAnimation a = FxModules.SwordAnimation.active(this.mrbean$current);
      if (a != null) {
         a.apply(ms, arm, swingProgress);
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_3218"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$eat(class_4587 ms, float tickDelta, class_1306 arm, class_1799 stack, class_1657 player, CallbackInfo ci) {
      if (Modules.get("eat_animation") instanceof AnimationModules.EatAnimation e && e.isEnabled() && e.mode.is("none")) {
         ci.cancel();
      }
   }
}
