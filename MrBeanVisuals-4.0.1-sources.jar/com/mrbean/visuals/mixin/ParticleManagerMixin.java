package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.impl.CrystalModules;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_702.class})
public class ParticleManagerMixin {
   @Inject(
      method = {"method_3056"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void mrbean$explosion(class_2394 effect, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<class_703> cir) {
      class_2396<?> t = effect.method_10295();
      VisualModules.LowFire nf = VisualModules.LowFire.get();
      if (nf == null
         || !nf.particles.value
         || t != class_2398.field_11240 && t != class_2398.field_27783 && t != class_2398.field_22246 && t != class_2398.field_11239) {
         boolean emitter = t == class_2398.field_11221;
         if (emitter || t == class_2398.field_11236) {
            CrystalModules.Explosions fx = CrystalModules.Explosions.get();
            if (fx != null && fx.onExplosionParticle(x, y, z, emitter)) {
               cir.setReturnValue(null);
            }
         }
      } else {
         cir.setReturnValue(null);
      }
   }
}
