package com.mrbean.visuals.mixin;

import com.mrbean.visuals.gui.menu.MenuBackground;
import com.mrbean.visuals.module.impl.MainMenuModule;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_4264.class})
public abstract class PressableWidgetMixin extends class_12230 {
   @Unique
   private float mrbean$hover;

   public PressableWidgetMixin(int x, int y, int w, int h, class_2561 t) {
      super(x, y, w, h, t);
   }

   @Inject(
      method = {"method_75794"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void mrbean$drawButton(class_332 ctx, CallbackInfo ci) {
      MainMenuModule m = MenuBackground.module();
      class_310 mc = class_310.method_1551();
      if (m != null && m.isEnabled() && m.otherScreens.value && mc.field_1755 != null && !(mc.field_1755 instanceof class_465)) {
         boolean hov = this.field_22763 && (this.method_49606() || this.method_25370());
         this.mrbean$hover = this.mrbean$hover + ((hov ? 1.0F : 0.0F) - this.mrbean$hover) * 0.25F;
         float t = this.mrbean$hover;
         int x = this.method_46426();
         int y = this.method_46427();
         int w = this.method_25368();
         int h = this.method_25364();
         float old = R2D.alpha;
         R2D.alpha = old * this.field_22765;
         int r = Math.min(6, h / 3);
         if (!this.field_22763) {
            R2D.round(ctx, x, y, w, h, r, 1880101400);
            R2D.outline(ctx, x, y, w, h, r, 352321535);
         } else {
            int acc = R2D.accent(0.0F);
            R2D.round(ctx, x, y, w, h, r, R2D.lerp(-1072556768, R2D.withAlpha(R2D.lerp(-15592160, acc, 0.28F), 224), t));
            R2D.outline(ctx, x, y, w, h, r, R2D.lerp(721420287, R2D.withAlpha(acc, 200), t));
            if (t > 0.02F) {
               R2D.rect(ctx, x + w / 2 - (int)(w * 0.35F * t), y + h - 1, (int)(w * 0.7F * t), 1, R2D.withAlpha(acc, (int)(255.0F * t)));
            }
         }

         R2D.alpha = old;
         ci.cancel();
      }
   }
}
