package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_11224;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_11224.class})
public class ExperienceBarMixin {
   @Inject(
      method = {"method_70865"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$xp(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.get("custom_bars") instanceof VisualModules.CustomBars b && b.isEnabled() && b.xp.value) {
         b.renderXp(ctx);
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_70868"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$xpLevel(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.get("custom_bars") instanceof VisualModules.CustomBars b && b.isEnabled() && b.xp.value) {
         ci.cancel();
      }
   }
}
