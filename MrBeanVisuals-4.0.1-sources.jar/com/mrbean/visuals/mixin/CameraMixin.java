package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.AnimationModules;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_4184.class})
public class CameraMixin {
   @Inject(
      method = {"method_19318"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void mrbean$smoothPerspective(float distance, CallbackInfoReturnable<Float> cir) {
      if (Modules.get("smooth_perspective") instanceof AnimationModules.SmoothCamera c && c.isEnabled()) {
         cir.setReturnValue(cir.getReturnValueF() * c.frame());
      }
   }
}
