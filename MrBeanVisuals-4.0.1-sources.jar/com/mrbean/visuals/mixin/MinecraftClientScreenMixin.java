package com.mrbean.visuals.mixin;

import com.mrbean.visuals.gui.menu.MainMenuScreen;
import com.mrbean.visuals.gui.menu.MenuBackground;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({class_310.class})
public class MinecraftClientScreenMixin {
   @ModifyVariable(
      method = {"method_1507"},
      at = {@At("HEAD")},
      argsOnly = true
   )
   private class_437 mrbean$mainMenu(class_437 screen) {
      return (class_437)(screen != null && screen.getClass() == class_442.class && MenuBackground.enabled() ? new MainMenuScreen() : screen);
   }
}
