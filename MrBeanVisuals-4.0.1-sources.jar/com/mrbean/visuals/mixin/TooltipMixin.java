package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_8002;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_8002.class})
public class TooltipMixin {
   @Inject(
      method = {"method_47946"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void mrbean$tooltip(class_332 ctx, int x, int y, int w, int h, class_2960 texture, CallbackInfo ci) {
      if (Modules.get("custom_tooltip") instanceof VisualModules.CustomTooltip t && t.isEnabled()) {
         t.render(ctx, x, y, w, h);
         ci.cancel();
      }
   }
}
