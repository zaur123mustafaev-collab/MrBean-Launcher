package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_897.class})
public class EntityFireMixin {
   @Inject(
      method = {"method_62354"},
      at = {@At("TAIL")},
      require = 0
   )
   private void mrbean$noFire(class_1297 entity, class_10017 state, float tickDelta, CallbackInfo ci) {
      VisualModules.LowFire nf = VisualModules.LowFire.get();
      if (nf != null && nf.entities.value) {
         state.field_53335 = false;
      }
   }
}
