package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.WorldModules;
import net.minecraft.class_638.class_5271;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_5271.class})
public class ClientWorldPropertiesMixin {
   @Inject(
      method = {"method_217"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void mrbean$time(CallbackInfoReturnable<Long> cir) {
      if (Modules.get("time_changer") instanceof WorldModules.TimeChanger t && t.isEnabled()) {
         cir.setReturnValue(t.timeOfDay(cir.getReturnValueJ()));
      }
   }
}
