package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_1058;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_4603.class})
public class OverlayMixin {
   @Inject(
      method = {"method_23070"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void mrbean$fireHead(class_4587 matrices, class_4597 vc, class_1058 sprite, CallbackInfo ci) {
      if (Modules.get("low_fire") instanceof VisualModules.LowFire f && f.isEnabled()) {
         if (f.mode.is("hide")) {
            ci.cancel();
            return;
         }

         matrices.method_22903();
         matrices.method_22904(0.0, -f.offset.value, 0.0);
      }
   }

   @Inject(
      method = {"method_23070"},
      at = {@At("TAIL")}
   )
   private static void mrbean$fireTail(class_4587 matrices, class_4597 vc, class_1058 sprite, CallbackInfo ci) {
      if (Modules.get("low_fire") instanceof VisualModules.LowFire f && f.isEnabled() && !f.mode.is("hide")) {
         matrices.method_22909();
      }
   }
}
