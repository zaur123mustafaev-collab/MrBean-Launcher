package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.WorldModules;
import net.minecraft.class_243;
import net.minecraft.class_4063;
import net.minecraft.class_9955;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_9955.class})
public class CloudRendererMixin {
   @Inject(
      method = {"method_62168"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$hide(int color, class_4063 mode, float height, class_243 cam, long time, float tickDelta, CallbackInfo ci) {
      if (Modules.get("clouds") instanceof WorldModules.Clouds c && c.isEnabled() && c.hide.value) {
         ci.cancel();
      }
   }

   @ModifyVariable(
      method = {"method_62168"},
      at = {@At("HEAD")},
      ordinal = 0,
      argsOnly = true
   )
   private int mrbean$color(int color) {
      return Modules.get("clouds") instanceof WorldModules.Clouds c && c.isEnabled() && c.customColor.value
         ? color & 0xFF000000 | c.color.argb & 16777215
         : color;
   }

   @ModifyVariable(
      method = {"method_62168"},
      at = {@At("HEAD")},
      ordinal = 0,
      argsOnly = true
   )
   private float mrbean$height(float height) {
      return Modules.get("clouds") instanceof WorldModules.Clouds c && c.isEnabled() ? c.height.f() : height;
   }
}
