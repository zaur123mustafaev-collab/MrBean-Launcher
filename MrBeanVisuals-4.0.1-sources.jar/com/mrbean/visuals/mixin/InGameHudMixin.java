package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.hud.HudElements;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_329.class})
public class InGameHudMixin {
   @Inject(
      method = {"method_1736"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$crosshair(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.on(Modules.get("crosshair"))) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_55803"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$scoreboard(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.on(Modules.get("hide_scoreboard"))) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_1759"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$hotbar(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.get("custom_hotbar") instanceof VisualModules.CustomHotbar h && h.isEnabled()) {
         h.render(ctx, tick);
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_1760"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$bars(class_332 ctx, CallbackInfo ci) {
      if (Modules.get("custom_bars") instanceof VisualModules.CustomBars b && b.isEnabled()) {
         b.renderStatus(ctx);
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_55800"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$actionBar(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.on(Modules.get("action_bar"))) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_1758"},
      at = {@At("TAIL")}
   )
   private void mrbean$captureActionBar(class_2561 message, boolean tinted, CallbackInfo ci) {
      HudElements.ActionBar.message = message;
      HudElements.ActionBar.remaining = 60;
   }

   @Inject(
      method = {"method_70837"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$bossBarHead(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.get("boss_bar") instanceof VisualModules.BossBarStyle b && b.isEnabled()) {
         if (b.hide.value) {
            ci.cancel();
            return;
         }

         float s = b.scale.f();
         int sw = ctx.method_51421();
         ctx.method_51448().pushMatrix();
         ctx.method_51448().translate(sw / 2.0F * (1.0F - s), 0.0F);
         ctx.method_51448().scale(s, s);
      }
   }

   @Inject(
      method = {"method_70837"},
      at = {@At("TAIL")}
   )
   private void mrbean$bossBarTail(class_332 ctx, class_9779 tick, CallbackInfo ci) {
      if (Modules.get("boss_bar") instanceof VisualModules.BossBarStyle b && b.isEnabled() && !b.hide.value) {
         ctx.method_51448().popMatrix();
      }
   }
}
