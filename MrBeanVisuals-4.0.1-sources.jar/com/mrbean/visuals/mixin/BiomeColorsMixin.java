package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.WorldModules;
import net.minecraft.class_1163;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1163.class})
public class BiomeColorsMixin {
   private static WorldModules.BiomeColorMod mrbean$m() {
      return Modules.get("biome_colors") instanceof WorldModules.BiomeColorMod b && b.isEnabled() ? b : null;
   }

   @Inject(
      method = {"method_4962"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void mrbean$grass(class_1920 world, class_2338 pos, CallbackInfoReturnable<Integer> cir) {
      WorldModules.BiomeColorMod m = mrbean$m();
      if (m != null && m.grass.value) {
         cir.setReturnValue(m.mix(cir.getReturnValueI(), m.grassColor.argb));
      }
   }

   @Inject(
      method = {"method_4966"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void mrbean$foliage(class_1920 world, class_2338 pos, CallbackInfoReturnable<Integer> cir) {
      WorldModules.BiomeColorMod m = mrbean$m();
      if (m != null && m.foliage.value) {
         cir.setReturnValue(m.mix(cir.getReturnValueI(), m.foliageColor.argb));
      }
   }

   @Inject(
      method = {"method_4961"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void mrbean$water(class_1920 world, class_2338 pos, CallbackInfoReturnable<Integer> cir) {
      WorldModules.BiomeColorMod m = mrbean$m();
      if (m != null && m.water.value) {
         cir.setReturnValue(m.mix(cir.getReturnValueI(), m.waterColor.argb));
      }
   }
}
