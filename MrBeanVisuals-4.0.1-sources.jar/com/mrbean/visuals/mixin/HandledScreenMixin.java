package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.AnimationModules;
import com.mrbean.visuals.render.R2D;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_465.class})
public class HandledScreenMixin {
   @Inject(
      method = {"method_25426"},
      at = {@At("HEAD")}
   )
   private void mrbean$opened(CallbackInfo ci) {
      if (Modules.get("inventory_anim") instanceof AnimationModules.InventoryAnim a) {
         a.openedAt = System.currentTimeMillis();
      }
   }

   @Inject(
      method = {"method_25394"},
      at = {@At("HEAD")}
   )
   private void mrbean$head(class_332 ctx, int mx, int my, float delta, CallbackInfo ci) {
      ctx.method_51448().pushMatrix();
      if (Modules.get("inventory_anim") instanceof AnimationModules.InventoryAnim a && a.isEnabled() && Modules.theme().animations.value) {
         float p = a.progress();
         if (p >= 1.0F) {
            return;
         }

         int w = ctx.method_51421();
         int h = ctx.method_51443();
         String var10 = a.style.get();
         switch (var10) {
            case "slide":
               ctx.method_51448().translate(0.0F, (1.0F - p) * h * 0.25F);
               break;
            case "fade":
               R2D.alpha = p;
               break;
            default:
               float s = 0.85F + 0.15F * p;
               ctx.method_51448().translate(w / 2.0F * (1.0F - s), h / 2.0F * (1.0F - s));
               ctx.method_51448().scale(s, s);
         }
      }
   }

   @Inject(
      method = {"method_25394"},
      at = {@At("TAIL")}
   )
   private void mrbean$tail(class_332 ctx, int mx, int my, float delta, CallbackInfo ci) {
      ctx.method_51448().popMatrix();
      R2D.alpha = 1.0F;
   }
}
