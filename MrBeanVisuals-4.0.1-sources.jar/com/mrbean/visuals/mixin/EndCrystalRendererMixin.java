package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.impl.CrystalModules;
import net.minecraft.class_10014;
import net.minecraft.class_11659;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_12249;
import net.minecraft.class_1511;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3879;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_892;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_892.class})
public class EndCrystalRendererMixin {
   private static final class_2960 MRBEAN_TEX = class_2960.method_60656("textures/entity/end_crystal/end_crystal.png");

   @Redirect(
      method = {"method_3908"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      )},
      require = 0
   )
   private <S> void mrbean$submit(
      class_11659 q,
      class_3879<? super S> model,
      S state,
      class_4587 ms,
      class_1921 layer,
      int light,
      int overlay,
      int outline,
      class_11792 crumbling
   ) {
      CrystalModules.Render r = CrystalModules.Render.get();
      if (r == null) {
         q.method_73489(model, state, ms, layer, light, overlay, outline, crumbling);
      } else {
         float s = (float)r.scale.value;
         if (s != 1.0F) {
            ms.method_46416(0.0F, 0.5F, 0.0F);
            ms.method_22905(s, s, s);
            ms.method_46416(0.0F, -0.5F, 0.0F);
         }

         int tint = r.tintColor();
         class_1921 use = tint >>> 24 < 255 ? class_12249.method_76000(MRBEAN_TEX) : layer;
         q.method_73490(model, state, ms, use, light, overlay, tint, null, outline, crumbling);
      }
   }

   @Inject(
      method = {"method_62417"},
      at = {@At("TAIL")},
      require = 0
   )
   private void mrbean$spin(class_1511 e, class_10014 st, float td, CallbackInfo ci) {
      CrystalModules.Render r = CrystalModules.Render.get();
      if (r != null) {
         st.field_53328 = st.field_53328 * (float)r.spin.value;
      }
   }

   @Inject(
      method = {"method_3907"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void mrbean$distance(class_1511 e, class_4604 f, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
      CrystalModules.Render r = CrystalModules.Render.get();
      class_4184 cam = class_310.method_1551().field_1773.method_19418();
      if (r != null && cam != null && e.method_5707(cam.method_71156()) > r.distance.value * r.distance.value) {
         cir.setReturnValue(false);
      }
   }
}
