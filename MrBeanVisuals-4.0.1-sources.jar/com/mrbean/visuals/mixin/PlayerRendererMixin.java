package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.cosmetic.Nameplate;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1007.class})
public class PlayerRendererMixin {
   @Inject(
      method = {"method_62604"},
      at = {@At("TAIL")}
   )
   private void mrbean$nameplate(class_11890 entity, class_10055 state, float delta, CallbackInfo ci) {
      if (Modules.get("nameplate") instanceof Nameplate np && np.isEnabled()) {
         if (state.field_53337 != null && entity instanceof class_1657 p) {
            state.field_53337 = np.style(p, state.field_53337);
         }
      }
   }

   @Inject(
      method = {"method_74935"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$ownLabel(class_11890 entity, double dist, CallbackInfoReturnable<Boolean> cir) {
      class_310 mc = class_310.method_1551();
      if (entity == mc.field_1724
         && Modules.get("nameplate") instanceof Nameplate np
         && np.isEnabled()
         && np.showOwn.value
         && !mc.field_1690.method_31044().method_31034()
         && !mc.field_1690.field_1842) {
         cir.setReturnValue(true);
      }
   }
}
