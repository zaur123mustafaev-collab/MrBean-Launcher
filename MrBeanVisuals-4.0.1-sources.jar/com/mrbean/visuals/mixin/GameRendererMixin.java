package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import com.mrbean.visuals.render.PostFx;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import net.minecraft.class_9920;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_757.class})
public abstract class GameRendererMixin {
   @Shadow
   private float field_4019;
   @Shadow
   private float field_3999;
   @Shadow
   @Final
   private class_9920 field_53066;
   @Unique
   private boolean mrbean$smoothSet;
   @Unique
   private boolean mrbean$prevSmooth;

   @Inject(
      method = {"method_3196"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void mrbean$zoom(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
      if (Modules.get("zoom") instanceof VisualModules.Zoom z) {
         class_310 var10 = class_310.method_1551();
         boolean active = z.active();
         if (!active) {
            z.scrollMul = 1.0;
         }

         double target = active ? z.factor.value * z.scrollMul : 1.0;
         z.current = z.current + (target - z.current) * 0.25;
         if (Math.abs(z.current - target) < 0.01) {
            z.current = target;
         }

         if (z.smooth.value) {
            if (active && !this.mrbean$smoothSet) {
               this.mrbean$prevSmooth = var10.field_1690.field_1914;
               var10.field_1690.field_1914 = true;
               this.mrbean$smoothSet = true;
            } else if (!active && this.mrbean$smoothSet) {
               var10.field_1690.field_1914 = this.mrbean$prevSmooth;
               this.mrbean$smoothSet = false;
            }
         }

         if (z.current != 1.0) {
            cir.setReturnValue((float)(cir.getReturnValueF() / z.current));
         }
      }
   }

   @Inject(
      method = {"method_3199"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$staticFov(CallbackInfo ci) {
      if (Modules.on(Modules.get("static_fov"))) {
         this.field_4019 = 1.0F;
         this.field_3999 = 1.0F;
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_3198"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$noHurtCam(class_4587 matrices, float tickDelta, CallbackInfo ci) {
      if (Modules.on(Modules.get("no_hurt_cam"))) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_3186"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$noBob(class_4587 matrices, float tickDelta, CallbackInfo ci) {
      if (Modules.on(Modules.get("no_bob"))) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_3172"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void mrbean$zoomHand(CallbackInfo ci) {
      if (Modules.get("zoom") instanceof VisualModules.Zoom z && z.hideHand.value && z.current > 1.05) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"method_3192"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V",
         shift = Shift.AFTER
      )}
   )
   private void mrbean$postFx(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
      PostFx.render(this.field_53066);
   }
}
