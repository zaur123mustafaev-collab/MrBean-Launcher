package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.WorldModules;
import net.minecraft.class_1937;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1937.class})
public class WorldMixin {
   @Inject(
      method = {"method_8430"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$rain(float delta, CallbackInfoReturnable<Float> cir) {
      if (((Object)this) instanceof class_638 && Modules.get("weather") instanceof WorldModules.Weather w && w.isEnabled()) {
         cir.setReturnValue(w.rain());
      }
   }

   @Inject(
      method = {"method_8478"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$thunder(float delta, CallbackInfoReturnable<Float> cir) {
      if (((Object)this) instanceof class_638 && Modules.get("weather") instanceof WorldModules.Weather w && w.isEnabled()) {
         cir.setReturnValue(w.thunder());
      }
   }
}
