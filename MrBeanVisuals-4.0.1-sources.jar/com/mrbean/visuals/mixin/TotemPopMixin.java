package com.mrbean.visuals.mixin;

import com.mrbean.visuals.util.Info;
import net.minecraft.class_1297;
import net.minecraft.class_2663;
import net.minecraft.class_634;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_634.class})
public class TotemPopMixin {
   @Inject(
      method = {"method_11148"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/network/PacketApplyBatcher;)V",
         shift = Shift.AFTER
      )},
      require = 0
   )
   private void mrbean$pop(class_2663 packet, CallbackInfo ci) {
      if (packet.method_11470() == 35) {
         class_638 world = ((class_634)(Object)this).method_2890();
         class_1297 e = world == null ? null : packet.method_11469(world);
         if (e != null) {
            Info.onTotemPop(e);
         }
      }
   }
}
