package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import com.mrbean.visuals.util.Info;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_312.class})
public class MouseMixin {
   @Inject(
      method = {"method_1601"},
      at = {@At("HEAD")}
   )
   private void mrbean$cps(long window, class_11910 input, int action, CallbackInfo ci) {
      if (action == 1 && class_310.method_1551().field_1755 == null) {
         Info.onClick(input.comp_4801());
      }
   }

   @Inject(
      method = {"method_1598"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mrbean$zoomScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
      if (Modules.get("zoom") instanceof VisualModules.Zoom z && z.active() && z.scroll.value && vertical != 0.0) {
         z.scrollMul = Math.max(0.3, Math.min(4.0, z.scrollMul * (vertical > 0.0 ? 1.15 : 0.8695652173913044)));
         ci.cancel();
      }
   }
}
