package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_303;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_338.class})
public class ChatHudMixin {
   @Inject(
      method = {"method_75804"},
      at = {@At("HEAD")}
   )
   private void mrbean$head(class_332 ctx, class_327 tr, int a, int b, int c, boolean d, boolean e, CallbackInfo ci) {
      ctx.method_51448().pushMatrix();
      if (Modules.get("smooth_chat") instanceof VisualModules.SmoothChat s && s.isEnabled()) {
         s.frame();
         ctx.method_51448().translate(0.0F, s.offset);
      }
   }

   @Inject(
      method = {"method_75804"},
      at = {@At("TAIL")}
   )
   private void mrbean$tail(class_332 ctx, class_327 tr, int a, int b, int c, boolean d, boolean e, CallbackInfo ci) {
      ctx.method_51448().popMatrix();
   }

   @Inject(
      method = {"method_58744"},
      at = {@At("TAIL")}
   )
   private void mrbean$added(class_303 line, CallbackInfo ci) {
      if (Modules.get("smooth_chat") instanceof VisualModules.SmoothChat s && s.isEnabled()) {
         s.onMessage();
      }
   }
}
