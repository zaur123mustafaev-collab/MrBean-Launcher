package com.mrbean.visuals.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.impl.VisualModules;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({class_765.class})
public class LightmapMixin {
   @ModifyExpressionValue(
      method = {"method_3313"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;",
         ordinal = 2
      )}
   )
   private Object mrbean$gamma(Object original) {
      if (!(Modules.get("fullbright") instanceof VisualModules.Fullbright f)) {
         return original;
      } else {
         double base = original instanceof Double d ? d : 1.0;
         double want = f.isEnabled() ? f.gamma.value / 100.0 : base;
         if (!f.smooth.value || f.smoothed < 0.0) {
            f.smoothed = want;
         } else {
            f.smoothed += (want - f.smoothed) * 0.22;
            if (Math.abs(want - f.smoothed) < 0.005) {
               f.smoothed = want;
            }
         }

         return f.smoothed;
      }
   }
}
