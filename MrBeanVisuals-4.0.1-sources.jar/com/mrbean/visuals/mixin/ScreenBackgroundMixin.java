package com.mrbean.visuals.mixin;

import com.mrbean.visuals.gui.menu.MainMenuScreen;
import com.mrbean.visuals.gui.menu.MenuBackground;
import com.mrbean.visuals.module.impl.MainMenuModule;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_437.class})
public abstract class ScreenBackgroundMixin {
   @Shadow
   public int field_22789;
   @Shadow
   public int field_22790;

   private boolean mrbean$styled() {
      MainMenuModule m = MenuBackground.module();
      return m != null && m.isEnabled() ? ((Object)this) instanceof MainMenuScreen || m.otherScreens.value : false;
   }

   @Inject(
      method = {"method_57728"},
      at = {@At("TAIL")},
      require = 0
   )
   private void mrbean$overlay(class_332 ctx, float delta, CallbackInfo ci) {
      if (this.mrbean$styled()) {
         class_310 mc = class_310.method_1551();
         double mx = mc.field_1729.method_68879(mc.method_22683());
         double my = mc.field_1729.method_68883(mc.method_22683());
         MenuBackground.draw(ctx, this.field_22789, this.field_22790, mx, my, ((Object)this) instanceof MainMenuScreen ? 1.0F : 0.75F);
      }
   }

   @Inject(
      method = {"method_57734"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void mrbean$noBlur(class_332 ctx, CallbackInfo ci) {
      if (class_310.method_1551().field_1687 == null && this.mrbean$styled()) {
         ci.cancel();
      }
   }
}
