#version 330

uniform sampler2D InSampler;
uniform sampler2D ParamsSampler;
uniform sampler2D BloomSampler;

in vec2 texCoord;
out vec4 fragColor;

vec4 P(int i) { return texelFetch(ParamsSampler, ivec2(i, 0), 0); }

// Складываем исходный кадр и размытое свечение (screen blend)
void main() {
    vec3 base = texture(InSampler, texCoord).rgb;
    vec3 glow = texture(BloomSampler, texCoord).rgb * (P(2).g * 2.0);
    vec3 col = 1.0 - (1.0 - base) * (1.0 - clamp(glow, 0.0, 1.0));
    fragColor = vec4(col, 1.0);
}
