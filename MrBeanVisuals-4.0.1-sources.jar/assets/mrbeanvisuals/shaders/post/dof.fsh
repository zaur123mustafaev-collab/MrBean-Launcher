#version 330

uniform sampler2D InSampler;
uniform sampler2D ParamsSampler;
uniform sampler2D BlurSampler;
uniform sampler2D DepthSampler;

in vec2 texCoord;
out vec4 fragColor;

vec4 P(int i) { return texelFetch(ParamsSampler, ivec2(i, 0), 0); }

// Глубина резкости: чем дальше от дистанции фокуса, тем сильнее размытие
float linearDepth(float d) {
    float n = 0.05;
    float f = 1024.0;
    float z = d * 2.0 - 1.0;
    return (2.0 * n * f) / (f + n - z * (f - n));
}

void main() {
    vec3 sharp = texture(InSampler, texCoord).rgb;
    vec3 blur = texture(BlurSampler, texCoord).rgb;
    float depth = texture(DepthSampler, texCoord).r;
    float dist = linearDepth(depth);
    float focus = P(3).r * 64.0;
    float strength = P(2).a;
    float k = smoothstep(focus * 0.5, focus * 2.5 + 4.0, abs(dist - focus)) * strength;
    fragColor = vec4(mix(sharp, blur, clamp(k, 0.0, 1.0)), 1.0);
}
