#version 330

uniform sampler2D InSampler;
uniform sampler2D ParamsSampler;
uniform sampler2D PrevSampler;

in vec2 texCoord;
out vec4 fragColor;

vec4 P(int i) { return texelFetch(ParamsSampler, ivec2(i, 0), 0); }

// Смешиваем текущий кадр с предыдущим
void main() {
    vec3 cur = texture(InSampler, texCoord).rgb;
    vec3 prev = texture(PrevSampler, texCoord).rgb;
    float s = clamp(P(2).b, 0.0, 0.92);
    fragColor = vec4(mix(cur, prev, s), 1.0);
}
