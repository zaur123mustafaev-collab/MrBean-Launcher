#version 330

uniform sampler2D InSampler;
uniform sampler2D ParamsSampler;

in vec2 texCoord;
out vec4 fragColor;

vec4 P(int i) { return texelFetch(ParamsSampler, ivec2(i, 0), 0); }

// Цветокоррекция MrBean Visuals: яркость, контраст, насыщенность, оттенок, виньетка
void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    vec4 p0 = P(0);
    vec4 p1 = P(1);
    vec4 p3 = P(3);
    if (p3.g > 0.5) {
        col *= p0.b * 2.0;
        col = (col - 0.5) * (p0.g * 2.0) + 0.5;
        float l = dot(col, vec3(0.299, 0.587, 0.114));
        col = mix(vec3(l), col, p0.r * 2.0);
        col = mix(col, col * p1.rgb * 1.6, p1.a);
    }
    float v = p0.a;
    if (v > 0.001) {
        vec2 d = texCoord - 0.5;
        float r = dot(d, d) * 2.4;
        col *= 1.0 - v * smoothstep(0.15, 1.0, r);
    }
    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
