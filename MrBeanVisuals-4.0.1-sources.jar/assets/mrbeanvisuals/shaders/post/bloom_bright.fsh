#version 330

uniform sampler2D InSampler;
uniform sampler2D ParamsSampler;

in vec2 texCoord;
out vec4 fragColor;

vec4 P(int i) { return texelFetch(ParamsSampler, ivec2(i, 0), 0); }

// Выделяем только яркие области для свечения
void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    float threshold = P(2).r;
    float l = max(col.r, max(col.g, col.b));
    float k = smoothstep(threshold, min(1.0, threshold + 0.2), l);
    fragColor = vec4(col * k, 1.0);
}
