package com.mrbean.visuals.gui;

import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.hud.HudModule;
import com.mrbean.visuals.render.R2D;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HudEditorScreen extends class_437 {
   private final class_437 parent;
   private final Ui ui = new Ui();
   private HudModule selected;
   private HudModule dragging;
   private double grabX;
   private double grabY;
   private boolean snap = true;
   private boolean listOpen;
   private final List<int[]> guides = new ArrayList<>();
   private double panelScroll;
   private String presetName = "";
   private double listScroll;

   public HudEditorScreen(class_437 parent) {
      super(class_2561.method_43470("HUD"));
      this.parent = parent;
   }

   public boolean method_25421() {
      return false;
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
   }

   private List<HudModule> enabled() {
      List<HudModule> l = new ArrayList<>();

      for (Module m : Modules.all()) {
         if (m instanceof HudModule h && h.isEnabled()) {
            l.add(h);
         }
      }

      return l;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      HudModule.editing = true;
      this.ui.begin(context, mouseX, mouseY);
      if (this.snap) {
         for (int x = 0; x < this.field_22789; x += 16) {
            R2D.rect(context, x, 0, 1, this.field_22790, 218103807);
         }

         for (int y = 0; y < this.field_22790; y += 16) {
            R2D.rect(context, 0, y, this.field_22789, 1, 218103807);
         }
      }

      R2D.rect(context, this.field_22789 / 2, 0, 1, this.field_22790, 587202559);
      R2D.rect(context, 0, this.field_22790 / 2, this.field_22789, 1, 587202559);

      for (HudModule h : this.enabled()) {
         try {
            h.renderHud(context, deltaTicks, this.field_22789, this.field_22790);
         } catch (Exception var9) {
         }

         boolean hov = R2D.inside(mouseX, mouseY, h.sx, h.sy, h.sw, h.sh);
         int c = h == this.selected ? R2D.accent(0.0F) : (hov ? -1593835521 : 1090519039);
         R2D.outline(context, h.sx - 1, h.sy - 1, h.sw + 2, h.sh + 2, 2, c);
         if (hov || h == this.selected) {
            R2D.text(context, h.name(), h.sx, Math.max(0, h.sy - 10), -1, true);
         }
      }

      this.guides.clear();
      if (this.dragging != null) {
         if (!this.ui.mouseDown) {
            this.dragging = null;
            Config.markDirty();
         } else {
            this.moveDragged(mouseX, mouseY);
         }
      }

      for (int[] g : this.guides) {
         R2D.rect(context, g[0], g[1], Math.max(1, g[2] - g[0]), Math.max(1, g[3] - g[1]), R2D.accent(0.0F));
      }

      boolean overPanel = this.selected != null && R2D.inside(mouseX, mouseY, this.panelX(), 6, 170, this.field_22790 - 40)
         || R2D.inside(mouseX, mouseY, 0, this.field_22790 - 26, this.field_22789, 26)
         || this.listOpen && R2D.inside(mouseX, mouseY, this.field_22789 / 2 - 110, 30, 220, this.field_22790 - 70);
      if (!overPanel) {
         List<HudModule> list = this.enabled();

         for (int i = list.size() - 1; i >= 0; i--) {
            HudModule h = list.get(i);
            if (this.ui.rightClicked(h.sx, h.sy, h.sw, h.sh)) {
               h.toggle();
               if (this.selected == h) {
                  this.selected = null;
               }

               Config.markDirty();
               break;
            }

            if (this.ui.pressedIn(h.sx, h.sy, h.sw, h.sh)) {
               this.selected = h;
               this.dragging = h;
               this.grabX = mouseX - h.sx;
               this.grabY = mouseY - h.sy;
               this.panelScroll = 0.0;
               break;
            }
         }

         if (this.ui.scroll != 0.0) {
            for (HudModule hx : this.enabled()) {
               if (R2D.inside(mouseX, mouseY, hx.sx, hx.sy, hx.sw, hx.sh)) {
                  hx.scale.set(hx.scale.value + Math.signum(this.ui.scroll) * 0.05);
                  this.ui.scroll = 0.0;
                  Config.markDirty();
                  break;
               }
            }
         }
      }

      if (this.selected != null && !this.selected.isEnabled()) {
         this.selected = null;
      }

      if (this.selected != null) {
         this.drawStylePanel(context);
      }

      if (this.listOpen) {
         this.drawElementList(context);
      }

      this.drawToolbar(context);
      this.ui.end();
   }

   private int panelX() {
      return this.selected != null && this.selected.sx + this.selected.sw / 2 > this.field_22789 / 2 ? 6 : this.field_22789 - 176;
   }

   private void moveDragged(int mouseX, int mouseY) {
      HudModule h = this.dragging;
      int x = (int)(mouseX - this.grabX);
      int y = (int)(mouseY - this.grabY);
      int w = h.sw;
      int hh = h.sh;
      if (this.snap) {
         int th = 4;
         int[] xs = new int[]{0, this.field_22789 / 2 - w / 2, this.field_22789 - w};
         int[] ys = new int[]{0, this.field_22790 / 2 - hh / 2, this.field_22790 - hh};

         for (int sx : xs) {
            if (Math.abs(x - sx) < th) {
               x = sx;
               this.guides
                  .add(
                     new int[]{
                        sx + (sx == 0 ? 0 : (sx == this.field_22789 - w ? w - 1 : w / 2)),
                        0,
                        sx + (sx == 0 ? 1 : (sx == this.field_22789 - w ? w : w / 2 + 1)),
                        this.field_22790
                     }
                  );
            }
         }

         for (int sy : ys) {
            if (Math.abs(y - sy) < th) {
               y = sy;
               this.guides
                  .add(
                     new int[]{
                        0,
                        sy + (sy == 0 ? 0 : (sy == this.field_22790 - hh ? hh - 1 : hh / 2)),
                        this.field_22789,
                        sy + (sy == 0 ? 1 : (sy == this.field_22790 - hh ? hh : hh / 2 + 1))
                     }
                  );
            }
         }

         for (HudModule o : this.enabled()) {
            if (o != h && o.sw != 0) {
               int[][] candX = new int[][]{{o.sx, o.sx}, {o.sx + o.sw, o.sx + o.sw}, {o.sx - w, o.sx}, {o.sx + o.sw - w, o.sx + o.sw}};

               for (int[] c : candX) {
                  if (Math.abs(x - c[0]) < th) {
                     x = c[0];
                     this.guides.add(new int[]{c[1], Math.min(y, o.sy), c[1] + 1, Math.max(y + hh, o.sy + o.sh)});
                  }
               }

               int[][] candY = new int[][]{{o.sy, o.sy}, {o.sy + o.sh + 2, o.sy + o.sh}, {o.sy - hh - 2, o.sy}, {o.sy + o.sh - hh, o.sy + o.sh}};

               for (int[] cx : candY) {
                  if (Math.abs(y - cx[0]) < th) {
                     y = cx[0];
                     this.guides.add(new int[]{Math.min(x, o.sx), cx[1], Math.max(x + w, o.sx + o.sw), cx[1] + 1});
                  }
               }
            }
         }
      }

      x = Math.max(0, Math.min(this.field_22789 - w, x));
      y = Math.max(0, Math.min(this.field_22790 - hh, y));
      h.fx = this.field_22789 - w <= 0 ? 0.0 : (double)x / (this.field_22789 - w);
      h.fy = this.field_22790 - hh <= 0 ? 0.0 : (double)y / (this.field_22790 - hh);
   }

   private void drawStylePanel(class_332 ctx) {
      int px = this.panelX();
      int py = 6;
      int pw = 170;
      int ph = this.field_22790 - 40;
      R2D.panel(ctx, px, py, pw, ph, 8, -267382248, true, 587202559);
      R2D.text(ctx, this.selected.name(), px + 8, py + 7, -1, false);
      if (this.ui.button("hide_sel", px + pw - 48, py + 5, 40, 12, Lang.t("Скрыть", "Hide"), 3)) {
         this.selected.toggle();
         this.selected = null;
         Config.markDirty();
      } else {
         ctx.method_44379(px, py + 22, px + pw, py + ph - 4);
         if (this.ui.scroll != 0.0 && R2D.inside(this.ui.mx, this.ui.my, px, py, pw, ph)) {
            this.panelScroll = Math.max(0.0, this.panelScroll - this.ui.scroll * 18.0);
            this.ui.scroll = 0.0;
         }

         this.ui.offsetY(this.panelScroll);
         ctx.method_51448().pushMatrix();
         ctx.method_51448().translate(0.0F, (float)(-this.panelScroll));
         int y = py + 26;

         for (Setting s : this.selected.settings) {
            if (s.visible.getAsBoolean()) {
               y += this.ui.settingRow("hud:" + this.selected.id + ":", s, px + 8, y, pw - 16) + 4;
            }
         }

         if (this.ui.button("reset_pos", px + 8, y + 2, pw - 16, 13, Lang.t("Вернуть на место", "Reset position"), 0)) {
            this.selected.resetPosition();
            Config.markDirty();
         }

         y += 18;
         ctx.method_51448().popMatrix();
         this.ui.offsetY(-this.panelScroll);
         ctx.method_44380();
         this.panelScroll = Math.min(this.panelScroll, (double)Math.max(0, y - py - ph + 10));
      }
   }

   private void drawElementList(class_332 ctx) {
      int lw = 220;
      int lx = this.field_22789 / 2 - lw / 2;
      int ly = 30;
      int lh = this.field_22790 - 70;
      R2D.panel(ctx, lx, ly, lw, lh, 8, -267382248, true, R2D.withAlpha(R2D.accent(0.0F), 100));
      R2D.text(ctx, Lang.t("Элементы HUD", "HUD elements"), lx + 8, ly + 7, -1, false);
      List<HudModule> all = new ArrayList<>();

      for (Module m : Modules.all()) {
         if (m instanceof HudModule h) {
            all.add(h);
         }
      }

      if (this.ui.scroll != 0.0 && R2D.inside(this.ui.mx, this.ui.my, lx, ly, lw, lh)) {
         this.listScroll = Math.max(0.0, this.listScroll - this.ui.scroll * 15.0);
         this.ui.scroll = 0.0;
      }

      this.listScroll = Math.min(this.listScroll, (double)Math.max(0, all.size() * 15 - (lh - 30)));
      ctx.method_44379(lx, ly + 20, lx + lw, ly + lh - 4);
      this.ui.offsetY(this.listScroll);
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(0.0F, (float)(-this.listScroll));
      int y = ly + 22;

      for (HudModule h : all) {
         R2D.text(ctx, h.name(), lx + 10, y + 2, h.isEnabled() ? -1 : -6643532, false);
         boolean nv = this.ui.toggle("el:" + h.id, lx + lw - 32, y, h.isEnabled());
         if (nv != h.isEnabled()) {
            h.setEnabled(nv);
            Config.markDirty();
         }

         y += 15;
      }

      ctx.method_51448().popMatrix();
      this.ui.offsetY(-this.listScroll);
      ctx.method_44380();
   }

   private void drawToolbar(class_332 ctx) {
      int bh = 22;
      int y = this.field_22790 - bh;
      R2D.rect(ctx, 0, y, this.field_22789, bh, -535817704);
      R2D.rect(ctx, 0, y, this.field_22789, 1, R2D.withAlpha(R2D.accent(0.0F), 120));
      int x = 6;
      if (this.ui.button("list", x, y + 4, 80, 14, (this.listOpen ? "▾ " : "▸ ") + Lang.t("Элементы", "Elements"), this.listOpen ? 1 : 0)) {
         this.listOpen = !this.listOpen;
      }

      x += 86;
      if (this.ui.button("snap", x, y + 4, 80, 14, (this.snap ? "✔ " : "  ") + Lang.t("Привязка", "Snapping"), this.snap ? 1 : 0)) {
         this.snap = !this.snap;
      }

      x += 86;
      List<String> presets = Config.list(Config.hudDir());
      int idx = Math.max(0, presets.indexOf(Config.hudPreset));
      if (this.ui.button("preset", x, y + 4, 110, 14, Lang.t("Пресет: ", "Preset: ") + Config.hudPreset, 0)) {
         Config.switchHudPreset(presets.get((idx + 1) % presets.size()));
      }

      x += 116;
      if (this.field_22789 > 520) {
         this.presetName = this.ui.textField("pname", x, y + 4, 90, this.presetName, Lang.t("новый пресет", "new preset"), 20);
         x += 94;
         if (this.ui.button("psave", x, y + 4, 50, 14, Lang.t("Создать", "Create"), 0) && !this.presetName.isBlank()) {
            Config.switchHudPreset(this.presetName);
            this.presetName = "";
         }

         x += 56;
      }

      if (this.ui.button("resetall", this.field_22789 - 168, y + 4, 90, 14, Lang.t("Сбросить всё", "Reset all"), 3)) {
         for (Module m : Modules.all()) {
            if (m instanceof HudModule h) {
               h.resetPosition();
            }
         }

         Config.markDirty();
      }

      if (this.ui.button("done", this.field_22789 - 72, y + 4, 66, 14, Lang.ui("ui.finish"), 1)) {
         this.method_25419();
      }

      if (this.selected == null && !this.listOpen) {
         R2D.textScaled(
            ctx,
            Lang.t("Тяни мышкой • колёсико — размер • ПКМ — скрыть • стрелки — точный сдвиг", "Drag • scroll to resize • right-click to hide • arrows to nudge"),
            x + 4,
            y + 8,
            0.7F,
            -6643532,
            false
         );
      }
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      int k = input.comp_4795();
      if (this.ui.focus != null) {
         if (k == 256) {
            this.ui.focus = null;
         } else {
            this.ui.onKey(k);
         }

         return true;
      } else if (this.ui.overlayOpen() && k == 256) {
         this.ui.closeOverlay();
         return true;
      } else {
         if (this.selected != null) {
            int dx = k == 263 ? -1 : (k == 262 ? 1 : 0);
            int dy = k == 265 ? -1 : (k == 264 ? 1 : 0);
            if (dx != 0 || dy != 0) {
               int nx = Math.max(0, Math.min(this.field_22789 - this.selected.sw, this.selected.sx + dx));
               int ny = Math.max(0, Math.min(this.field_22790 - this.selected.sh, this.selected.sy + dy));
               this.selected.fx = this.field_22789 - this.selected.sw <= 0 ? 0.0 : (double)nx / (this.field_22789 - this.selected.sw);
               this.selected.fy = this.field_22790 - this.selected.sh <= 0 ? 0.0 : (double)ny / (this.field_22790 - this.selected.sh);
               Config.markDirty();
               return true;
            }

            if (k == 261) {
               this.selected.toggle();
               this.selected = null;
               return true;
            }
         }

         return super.method_25404(input);
      }
   }

   public boolean method_25400(class_11905 input) {
      String s = input.method_74226();
      if (s != null) {
         for (char c : s.toCharArray()) {
            this.ui.onChar(c);
         }
      }

      return true;
   }

   public void method_25419() {
      HudModule.editing = false;
      Config.save();
      this.field_22787.method_1507(this.parent);
   }

   public void method_25432() {
      HudModule.editing = false;
   }
}
