package com.mrbean.visuals.gui;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.impl.Emotes;
import com.mrbean.visuals.render.R2D;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.joml.Matrix3x2fStack;

/**
 * Круговое колесо эмоций в стиле Fortnite: открывается клавишей B, выбор — наведением и кликом
 * (или цифрами 1..0). Панель не ставит игру на паузу и не размывает кадр.
 */
public class EmoteWheelScreen extends class_437 {
   private final class_437 parent;
   private final List<Emotes.Def> defs = Emotes.all();
   private final float[] hl = new float[Math.max(1, this.defs.size())];
   private float open;
   private float cx;
   private float cy;
   private float ring = 120.0F;
   private float k = 1.0F;
   private int hover = -1;
   private static final int CARD_W = 68;
   private static final int CARD_H = 24;
   private static final int HUB_R = 40;

   public EmoteWheelScreen(class_437 parent) {
      super(class_2561.method_43470(Lang.t("Колесо эмоций", "Emote wheel")));
      this.parent = parent;
   }

   public boolean method_25421() {
      return false;
   }

   protected void method_25426() {
      this.layout();
      Sounds.play(Sounds.OPEN);
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      if (this.field_22787.field_1687 == null) {
         this.method_57728(context, deltaTicks);
      } else {
         context.method_25296(
            0, 0, this.field_22789, this.field_22790, R2D.argb((int)(70.0F * this.open), 3, 4, 6), R2D.argb((int)(120.0F * this.open), 2, 3, 5)
         );
      }
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.open = R2D.approach(this.open, 1.0F, 0.22F);
      this.layout();
      double mx = (mouseX - (double)this.cx) / (double)this.k + (double)this.cx;
      double my = (mouseY - (double)this.cy) / (double)this.k + (double)this.cy;
      this.hover = this.slotAt(mx, my);
      Matrix3x2fStack mt = context.method_51448();
      mt.pushMatrix();
      mt.translate(this.cx, this.cy);
      mt.scale(this.k, this.k);
      mt.translate(-this.cx, -this.cy);
      float oldA = R2D.alpha;
      R2D.alpha = this.open;
      Emotes.EmoteModule em = Emotes.module();
      R2D.ringCircle(context, (int)this.cx, (int)this.cy, (int)this.ring, R2D.withAlpha(R2D.accent(0.0F), 36));
      int i = 0;

      for (Emotes.Def d : this.defs) {
         this.slot(context, i, d, em);
         i++;
      }

      this.hub(context, em);
      R2D.alpha = oldA;
      mt.popMatrix();
      String hint = Lang.t("ЛКМ — сыграть · цифры 1…0 · B или ESC — закрыть", "Left click — play · keys 1…0 · B or ESC — close");
      R2D.text(
         context, hint, this.field_22789 / 2 - R2D.width(hint) / 2, (int)Math.min(this.field_22790 - 12, this.cy + this.ring * this.k + 30), R2D.withAlpha(-6643532, 220), false
      );
   }

   private void slot(class_332 ctx, int i, Emotes.Def d, Emotes.EmoteModule em) {
      float n = (float)Math.max(1, this.defs.size());
      float a = (float)(-Math.PI / 2.0 + i * 2.0 * Math.PI / (double)n);
      float ap = Math.max(0.0F, Math.min(1.0F, (this.open - i * 0.045F) / 0.55F));
      float r = this.ring * (0.58F + 0.42F * ap);
      float px = this.cx + (float)Math.cos(a) * r;
      float py = this.cy + (float)Math.sin(a) * r;
      int x = (int)(px - CARD_W / 2.0F);
      int y = (int)(py - CARD_H / 2.0F);
      this.hl[i] = R2D.approach(this.hl[i], this.hover == i ? 1.0F : 0.0F, 0.4F);
      int fill = R2D.withAlpha(R2D.lerp(0x14161D, 0x1E2230, this.hl[i]), (int)(246.0F * ap));
      R2D.round(ctx, x, y, CARD_W, CARD_H, 6, fill);
      R2D.outline(
         ctx, x, y, CARD_W, CARD_H, 6, this.hover == i ? R2D.withAlpha(R2D.accent(0.0F), (int)(230.0F * ap)) : R2D.withAlpha(587202559, (int)(200.0F * ap))
      );
      if (this.hover == i) {
         R2D.rect(ctx, x + 2, y + CARD_H / 2 - 3, 2, 6, R2D.withAlpha(R2D.accent(0.0F), (int)(255.0F * ap)));
      }

      String label = fit(Lang.t(d.ru(), d.en()), CARD_W - 10);
      int c = R2D.withAlpha(this.hover == i ? -1 : -1183755, (int)(255.0F * ap));
      R2D.textScaled(ctx, label, px - R2D.width(label) * 0.78F / 2.0F, y + 3, 0.78F, c, false);
      String sub = keyOf(em, d);
      if (sub != null) {
         R2D.textScaled(
            ctx, sub, px - R2D.width(sub) * 0.62F / 2.0F, y + 14, 0.62F, R2D.withAlpha(R2D.accent(0.35F), (int)(230.0F * ap)), false
         );
      } else {
         R2D.textScaled(ctx, String.valueOf(slotKey(i)), x + CARD_W - 10, y + 15, 0.62F, R2D.withAlpha(-9735802, (int)(210.0F * ap)), false);
      }
   }

   private void hub(class_332 ctx, Emotes.EmoteModule em) {
      int hx = (int)this.cx;
      int hy = (int)this.cy;
      R2D.circle(ctx, hx, hy, HUB_R, R2D.withAlpha(0x0C0E14, 240));
      R2D.ringCircle(ctx, hx, hy, HUB_R, R2D.withAlpha(R2D.accent(0.0F), 150));
      if (this.hover >= 0 && this.hover < this.defs.size()) {
         Emotes.Def d = this.defs.get(this.hover);
         String name = fit(Lang.t(d.ru(), d.en()), 74);
         R2D.textScaled(ctx, name, this.cx - R2D.width(name) * 1.1F / 2.0F, this.cy - 11, 1.1F, -1, false);
         String sub = keyOf(em, d);
         String hint = sub == null ? Lang.t("клик — сыграть", "click to play") : Lang.t("клавиша ", "key ") + sub;
         R2D.textScaled(ctx, hint, this.cx - R2D.width(hint) * 0.72F / 2.0F, this.cy + 5, 0.72F, -6643532, false);
         String time = String.format(java.util.Locale.ROOT, "%.1fс", d.seconds());
         R2D.textScaled(ctx, time, this.cx - R2D.width(time) * 0.66F / 2.0F, this.cy + 17, 0.66F, -9735802, false);
      } else {
         R2D.bean(ctx, hx - 9, hy - 12, 18);
         String t = Lang.t("Выберите эмоцию", "Pick an emote");
         R2D.textScaled(ctx, t, this.cx - R2D.width(t) * 0.72F / 2.0F, this.cy + 10, 0.72F, -9735802, false);
      }
   }

   private void layout() {
      this.cx = this.field_22789 / 2.0F;
      this.cy = this.field_22790 / 2.0F - 6.0F;
      float n = (float)Math.max(1, this.defs.size());
      float minRing = CARD_W / 2.0F / (float)Math.sin(Math.PI / n) + 6.0F;
      this.ring = Math.max(minRing, Math.min(168.0F, Math.min(this.field_22789, this.field_22790) * 0.3F));
      float needW = 2.0F * (this.ring + CARD_W / 2.0F + 8.0F);
      float needH = 2.0F * (this.ring + CARD_H / 2.0F + 22.0F);
      this.k = Math.max(0.5F, Math.min(1.0F, Math.min((this.field_22789 - 10.0F) / needW, (this.field_22790 - 10.0F) / needH)));
   }

   private int slotAt(double mx, double my) {
      float n = (float)Math.max(1, this.defs.size());

      for (int i = 0; i < this.defs.size(); i++) {
         float a = (float)(-Math.PI / 2.0 + i * 2.0 * Math.PI / (double)n);
         float px = this.cx + (float)Math.cos(a) * this.ring;
         float py = this.cy + (float)Math.sin(a) * this.ring;
         if (R2D.inside(mx, my, (int)(px - CARD_W / 2.0F), (int)(py - CARD_H / 2.0F), CARD_W, CARD_H)) {
            return i;
         }
      }

      return -1;
   }

   private static String keyOf(Emotes.EmoteModule em, Emotes.Def d) {
      Setting.Key k = em == null ? null : em.binds.get(d.id());
      return k != null && k.value >= 0 ? k.display() : null;
   }

   /** Цифра, которой можно выбрать этот слот (1…9, затем 0). */
   private static int slotKey(int i) {
      return i < 9 ? i + 1 : 0;
   }

   private void pick(int i) {
      if (i >= 0 && i < this.defs.size()) {
         Emotes.EmoteModule em = Emotes.module();
         if (em != null) {
            em.start(this.defs.get(i).id());
         }
      }

      this.method_25419();
   }

   public void method_25419() {
      Emotes.EmoteModule em = Emotes.module();
      if (em != null) {
         em.wheelClosed();
      }

      this.field_22787.method_1507(this.parent);
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      if (click.method_74245() == 1) {
         this.method_25419();
         return true;
      } else if (click.method_74245() == 0) {
         double mx = (click.comp_4798() - (double)this.cx) / (double)this.k + (double)this.cx;
         double my = (click.comp_4799() - (double)this.cy) / (double)this.k + (double)this.cy;
         int i = this.slotAt(mx, my);
         if (i >= 0) {
            Sounds.play(Sounds.CLICK);
            this.pick(i);
         } else {
            this.method_25419();
         }

         return true;
      } else {
         return true;
      }
   }

   public boolean method_25404(class_11908 input) {
      int k = input.comp_4795();
      if (k >= 49 && k <= 57 && k - 49 < this.defs.size()) {
         this.pick(k - 49);
         return true;
      } else if (k == 48 && this.defs.size() > 9) {
         this.pick(9);
         return true;
      } else if (k == 66) {
         this.method_25419();
         return true;
      } else {
         return super.method_25404(input);
      }
   }

   private static String fit(String s, int max) {
      if (R2D.width(s) <= max) {
         return s;
      } else {
         String out = s;

         while (out.length() > 1 && R2D.width(out + "…") > max) {
            out = out.substring(0, out.length() - 1);
         }

         return out + "…";
      }
   }
}
