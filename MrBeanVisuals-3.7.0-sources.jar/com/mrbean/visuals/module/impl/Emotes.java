package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.EmoteWheelScreen;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.net.EmoteNetwork;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_304;
import net.minecraft.class_310;

/**
 * Эмоции персонажа. Позы считаются процедурно по t (0..1), mixin добавляет их к ванильным углам модели.
 * Своя поза ставится сразу локально, а на сервер уходит EmoteProtocol.Play — сервер показывает её
 * остальным, если стоит MrBeanServerBridge или MrBeanBadgePlugin. Без моста эмоция видна только себе.
 */
public final class Emotes {
   private static final float R = (float)Math.PI / 180.0F;
   private static final Map<String, Def> DEFS = new LinkedHashMap<>();
   private static final Map<Integer, Run> RUNS = new ConcurrentHashMap<>();
   private static final Pose SHARED = new Pose();

   private Emotes() {
   }

   public static final class Pose {
      public float headPitch;
      public float headYaw;
      public float headRoll;
      public float bodyPitch;
      public float bodyYaw;
      public float rArmPitch;
      public float rArmYaw;
      public float rArmRoll;
      public float lArmPitch;
      public float lArmYaw;
      public float lArmRoll;
      public float rLegPitch;
      public float lLegPitch;
      public boolean legs;
      public float strength;

      public void clear() {
         this.headPitch = 0.0F;
         this.headYaw = 0.0F;
         this.headRoll = 0.0F;
         this.bodyPitch = 0.0F;
         this.bodyYaw = 0.0F;
         this.rArmPitch = 0.0F;
         this.rArmYaw = 0.0F;
         this.rArmRoll = 0.0F;
         this.lArmPitch = 0.0F;
         this.lArmYaw = 0.0F;
         this.lArmRoll = 0.0F;
         this.rLegPitch = 0.0F;
         this.lLegPitch = 0.0F;
         this.legs = false;
      }

      public void leg(float right, float left) {
         this.rLegPitch = right;
         this.lLegPitch = left;
         this.legs = true;
      }
   }

   public interface Clip {
      void apply(Pose var1, float var2);
   }

   public record Def(String id, String ru, String en, float seconds, Clip clip) {
   }

   private record Run(Def def, long start, float seconds) {
   }

   private static void reg(String id, String ru, String en, float seconds, Clip clip) {
      DEFS.put(id, new Def(id, ru, en, seconds, clip));
   }

   public static Def def(String id) {
      return id == null ? null : DEFS.get(id.toLowerCase());
   }

   public static List<Def> all() {
      return new ArrayList<>(DEFS.values());
   }

   public static String ids() {
      return String.join(", ", DEFS.keySet());
   }

   public static boolean play(int entityId, String id, float speed) {
      Def d = def(id);
      if (d != null && !busy(entityId)) {
         RUNS.put(entityId, new Run(d, System.currentTimeMillis(), Math.max(0.2F, d.seconds() / Math.max(0.2F, speed))));
         return true;
      } else {
         return false;
      }
   }

   public static void stop(int entityId) {
      RUNS.remove(entityId);
   }

   public static boolean busy(int entityId) {
      Run r = RUNS.get(entityId);
      if (r == null) {
         return false;
      } else if (progress(r) >= 1.0F) {
         RUNS.remove(entityId);
         return false;
      } else {
         return true;
      }
   }

   private static float progress(Run r) {
      return (float)(System.currentTimeMillis() - r.start) / 1000.0F / r.seconds();
   }

   /** Заполняет общую позу и возвращает силу подмешивания в Pose.strength; null, если эмоции нет. */
   public static Pose pose(int entityId) {
      Run r = RUNS.get(entityId);
      if (r == null) {
         return null;
      } else {
         float t = progress(r);
         if (t >= 1.0F) {
            RUNS.remove(entityId);
            return null;
         } else {
            SHARED.clear();
            r.def().clip().apply(SHARED, Math.max(0.0F, t));
            float b = t < 0.12F ? t / 0.12F : (t > 0.78F ? (1.0F - t) / 0.22F : 1.0F);
            SHARED.strength = Math.max(0.0F, Math.min(1.0F, b));
            return SHARED;
         }
      }
   }

   private static float sin(float cycles, float t) {
      return (float)Math.sin(t * cycles * Math.PI * 2.0);
   }

   private static float hold(float t, float from, float to) {
      float in = Math.min(1.0F, t / from);
      float out2 = Math.min(1.0F, Math.max(0.0F, (1.0F - t) / to));
      return Math.min(in, out2);
   }

   static {
      reg(
         "wave", "Пока", "Wave", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.25F);
            p.rArmPitch = -150.0F * R * k;
            p.rArmRoll = -22.0F * R * k;
            p.rArmYaw = sin(6.0F, t) * 26.0F * R * k;
            p.headYaw = sin(6.0F, t) * 7.0F * R * k;
            p.bodyYaw = 6.0F * R * k;
         }
      );
      reg(
         "clap", "Хлопки", "Clap", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.2F);
            float s = sin(7.0F, t);
            p.rArmPitch = (-75.0F + s * 8.0F) * R * k;
            p.lArmPitch = (-75.0F + s * 8.0F) * R * k;
            p.rArmYaw = (-42.0F - s * 22.0F) * R * k;
            p.lArmYaw = (42.0F + s * 22.0F) * R * k;
            p.headPitch = 12.0F * R * k;
         }
      );
      reg(
         "cheer", "Ура", "Cheer", 3.0F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.22F);
            float s = sin(4.0F, t);
            p.rArmPitch = (-165.0F + s * 12.0F) * R * k;
            p.lArmPitch = (-165.0F - s * 12.0F) * R * k;
            p.rArmRoll = -28.0F * R * k;
            p.lArmRoll = 28.0F * R * k;
            p.bodyPitch = s * 5.0F * R * k;
            p.headPitch = (-10.0F + s * 6.0F) * R * k;
            p.leg(s * 12.0F * R * k, -s * 12.0F * R * k);
         }
      );
      reg(
         "point", "Указать", "Point", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.12F, 0.25F);
            p.rArmPitch = (-96.0F + sin(2.0F, t) * 4.0F) * R * k;
            p.rArmYaw = -12.0F * R * k;
            p.bodyYaw = -18.0F * R * k;
            p.headYaw = -10.0F * R * k;
            p.lArmPitch = 8.0F * R * k;
         }
      );
      reg(
         "facepalm", "Рука к лицу", "Facepalm", 2.6F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.3F);
            p.rArmPitch = -152.0F * R * k;
            p.rArmYaw = -28.0F * R * k;
            p.rArmRoll = 10.0F * R * k;
            p.headPitch = 26.0F * R * k;
            p.bodyPitch = 6.0F * R * k;
         }
      );
      reg(
         "shrug", "Пожатье плечами", "Shrug", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.18F, 0.28F);
            float s = sin(2.0F, t);
            p.rArmPitch = (-38.0F + s * 4.0F) * R * k;
            p.lArmPitch = (-38.0F - s * 4.0F) * R * k;
            p.rArmRoll = -58.0F * R * k;
            p.lArmRoll = 58.0F * R * k;
            p.headRoll = (10.0F + s * 4.0F) * R * k;
            p.bodyPitch = -4.0F * R * k;
         }
      );
      reg(
         "dance", "Танец", "Dance", 6.0F,
         (p, t) -> {
            float k = hold(t, 0.12F, 0.15F);
            float s = sin(4.0F, t);
            float c = sin(4.0F, t + 0.25F);
            p.bodyYaw = s * 24.0F * R * k;
            p.bodyPitch = c * 6.0F * R * k;
            p.rArmPitch = (-135.0F + s * 45.0F) * R * k;
            p.lArmPitch = (-135.0F - s * 45.0F) * R * k;
            p.rArmRoll = (-20.0F + c * 15.0F) * R * k;
            p.lArmRoll = (20.0F - c * 15.0F) * R * k;
            p.headYaw = c * 12.0F * R * k;
            p.leg((18.0F + c * 22.0F) * R * k, (18.0F - c * 22.0F) * R * k);
         }
      );
      reg(
         "yes", "Кивать", "Yes", 2.2F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            p.headPitch = sin(6.0F, t) * 22.0F * R * k;
            p.bodyPitch = sin(6.0F, t) * 4.0F * R * k;
         }
      );
      reg(
         "no", "Мотать головой", "No", 2.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.25F);
            p.headYaw = sin(5.0F, t) * 34.0F * R * k;
            p.headRoll = sin(5.0F, t) * 6.0F * R * k;
            p.bodyYaw = sin(5.0F, t) * 8.0F * R * k;
         }
      );
      reg(
         "rock", "Рок", "Rock", 3.4F,
         (p, t) -> {
            float k = hold(t, 0.15F, 0.22F);
            float s = sin(6.0F, t);
            p.rArmPitch = (-158.0F + s * 14.0F) * R * k;
            p.rArmRoll = -18.0F * R * k;
            p.lArmPitch = (-30.0F + s * 10.0F) * R * k;
            p.headPitch = (-24.0F + s * 6.0F) * R * k;
            p.bodyPitch = s * 9.0F * R * k;
         }
      );
   }

   public static class EmoteModule extends Module {
      public final Setting.Mode pick = this.add(
         new Setting.Mode(
            "emote",
            "Эмоция",
            "Emote",
            0,
            "wave", "Пока", "Wave",
            "clap", "Хлопки", "Clap",
            "cheer", "Ура", "Cheer",
            "point", "Указать", "Point",
            "facepalm", "Рука к лицу", "Facepalm",
            "shrug", "Пожатие плечами", "Shrug",
            "dance", "Танец", "Dance",
            "yes", "Кивать", "Yes",
            "no", "Мотать головой", "No",
            "rock", "Рок", "Rock"
         )
      );
      public final Setting.Num speed = this.add(new Setting.Num("speed", "Скорость", "Speed", 1.0, 0.5, 2.0, 0.05).suffix("x"));
      public final Setting.Bool calmLegs = this.add(new Setting.Bool("calm_legs", "Не махать ногами", "Calm legs", true));
      public final Setting.Bool firstPerson = this.add(new Setting.Bool("first_person", "Видеть от первого лица", "First person", false));
      public final Setting.Bool watchOthers = this.add(
         new Setting.Bool("watch_others", "Видеть эмоции других", "See others' emotes", true)
      );
      public final Setting.Bool wheel = this.add(new Setting.Bool("wheel", "Колесо эмоций по B", "Emote wheel on B", true));
      public final Setting.Action playBtn = this.add(new Setting.Action("play", "Сыграть", "Play", this::trigger));
      public final Setting.Action wheelBtn = this.add(new Setting.Action("open_wheel", "Открыть колесо", "Open wheel", this::openWheel));
      public final Map<String, Setting.Key> binds = new LinkedHashMap<>();
      public class_304 key;
      public long wheelClosedAt;

      public EmoteModule() {
         super(
            "emotes",
            Category.ANIMATIONS,
            false,
            "Эмоции",
            "Emotes",
            "Анимации персонажа: пока, хлопки, танец, указательный жест",
            "Character animations: wave, clap, dance, pointing"
         );

         for (Def d : DEFS.values()) {
            this.binds.put(
               d.id(),
               this.add(new Setting.Key("key_" + d.id(), "Бинд: " + d.ru(), "Bind: " + d.en(), -1))
            );
         }
      }

      @Override
      public void onTick() {
         EmoteNetwork.applyInbound();
         if (this.key != null) {
            while (this.key.method_1436()) {
               if (this.wheel.get()) {
                  if (this.mc.field_1755 == null && System.currentTimeMillis() - this.wheelClosedAt > 400L) {
                     this.openWheel();
                  }
               } else {
                  this.trigger();
               }
            }
         }

         for (Map.Entry<String, Setting.Key> e : this.binds.entrySet()) {
            if (e.getValue().pressed()) {
               this.start(e.getKey());
            }
         }
      }

      /** Открывает колесо выбора. Никак, если уже открыт другой экран. */
      public void openWheel() {
         if (this.mc.field_1755 == null) {
            this.mc.method_1507(new EmoteWheelScreen(null));
         }
      }

      /** Колесо закрылось: край клавиши B в этот момент игнорируем, иначе оно открылось бы снова. */
      public void wheelClosed() {
         this.wheelClosedAt = System.currentTimeMillis();
      }

      public String selected() {
         return this.pick.ids[this.pick.index];
      }

      public void trigger() {
         this.start(this.selected());
      }

      /** Ставит эмоцию себе и просит сервер показать её другим. */
      public void start(String id) {
         if (this.mc.field_1724 != null) {
            if (play(this.mc.field_1724.method_5628(), id, this.speed.f())) {
               EmoteNetwork.send(id, this.speed.f());
            } else {
               Notifications.push(Lang.t("Эмоция уже идёт", "An emote is already playing"), false);
            }
         }
      }

      @Override
      public void onDisable() {
         if (this.mc.field_1724 != null) {
            stop(this.mc.field_1724.method_5628());
         }
      }
   }

   public static EmoteModule module() {
      return Modules.get("emotes") instanceof EmoteModule em ? em : null;
   }

   /** Поза для модели игрока: null, если эмоции нет или модуль выключен. */
   public static Pose activePose(int entityId, EmoteModule em) {
      if (em == null || !em.isEnabled()) {
         return null;
      } else if (!em.firstPerson.get() && isFirstPersonSelf(entityId)) {
         return null;
      } else {
         return pose(entityId);
      }
   }

   private static boolean isFirstPersonSelf(int entityId) {
      class_310 mc = class_310.method_1551();
      return mc.field_1724 != null && mc.field_1724.method_5628() == entityId && mc.field_1690.method_31044().method_31034();
   }

   /** Запускает эмоцию у своего игрока. null — получилось. */
   public static String playSelf(String id, float speed) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1724 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || !em.isEnabled()) {
         return Lang.t("Включи модуль «Эмоции» в меню", "Enable the Emotes module first");
      } else if (def(id) == null) {
         return Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + ids();
      } else if (play(mc.field_1724.method_5628(), id, speed)) {
         EmoteNetwork.send(id, speed);
         return null;
      } else {
         return Lang.t("Эмоция уже идёт", "An emote is already playing");
      }
   }

   /** Клавиша одной эмоции — для .emotebind. null, если модуля или такой эмоции нет. */
   public static Setting.Key bindOf(String id) {
      EmoteModule em = module();
      Def d = def(id);
      if (em == null || d == null) {
         return null;
      } else {
         return em.binds.get(d.id());
      }
   }

   /** Список «эмоция — клавиша» для чата. */
   public static String bindList() {
      EmoteModule em = module();
      if (em == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();

         for (Map.Entry<String, Setting.Key> e : em.binds.entrySet()) {
            if (e.getValue().value >= 0) {
               if (sb.length() > 0) {
                  sb.append(", ");
               }

               sb.append(e.getKey()).append("=").append(e.getValue().display());
            }
         }

         return sb.toString();
      }
   }

   /** Ищет игрока по нику рядом и запускает у него эмоцию. */
   public static String playOn(String nick, String id, float speed) {
      class_310 mc = class_310.method_1551();
      EmoteModule em = module();
      if (mc.field_1687 == null) {
         return Lang.t("Сначала зайди в мир", "Join a world first");
      } else if (em == null || !em.isEnabled()) {
         return Lang.t("Включи модуль «Эмоции» в меню", "Enable the Emotes module first");
      } else if (def(id) == null) {
         return Lang.t("Нет такой эмоции. Есть: ", "No such emote. Available: ") + ids();
      } else {
         for (class_1657 p : mc.field_1687.method_18456()) {
            if (p.method_7334().name().equalsIgnoreCase(nick)) {
               return play(p.method_5628(), id, speed)
                  ? null
                  : Lang.t("У этого игрока уже идёт эмоция", "That player is already emoting");
            }
         }

         return Lang.t("Игрок не найден рядом: ", "Player not found nearby: ") + nick;
      }
   }
}
