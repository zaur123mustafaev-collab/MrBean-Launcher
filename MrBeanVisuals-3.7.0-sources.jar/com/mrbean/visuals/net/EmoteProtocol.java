package com.mrbean.visuals.net;

import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Пакеты эмоций. Клиент шлёт Play, сервер разворачивает его в Show всем, кто поддержал канал.
 * Тот же формат, что в MrBeanServerBridge и MrBeanBadgePlugin — менять вместе.
 */
public final class EmoteProtocol {
   public static final class_2960 PLAY_ID = class_2960.method_60655("mrbeanvisuals", "emote");
   public static final class_2960 SHOW_ID = class_2960.method_60655("mrbeanvisuals", "emote_show");

   private EmoteProtocol() {
   }

   public record Play(String emote, float speed) implements class_8710 {
      public static final class_9154<Play> ID = new class_9154<>(EmoteProtocol.PLAY_ID);
      public static final class_9139<class_9129, Play> CODEC = class_9139.method_56437(
         Play::write, buf -> new Play(buf.method_10800(64), buf.readFloat())
      );

      private static void write(class_2540 buf, Play p) {
         buf.method_10814(p.emote());
         buf.method_52941(p.speed());
      }

      @Override
      public class_9154<? extends class_8710> method_56479() {
         return ID;
      }
   }

   public record Show(UUID player, String emote, float speed) implements class_8710 {
      public static final class_9154<Show> ID = new class_9154<>(EmoteProtocol.SHOW_ID);
      public static final class_9139<class_9129, Show> CODEC = class_9139.method_56437(
         Show::write, buf -> new Show(buf.method_10790(), buf.method_10800(64), buf.readFloat())
      );

      private static void write(class_2540 buf, Show p) {
         buf.method_10797(p.player());
         buf.method_10814(p.emote());
         buf.method_52941(p.speed());
      }

      @Override
      public class_9154<? extends class_8710> method_56479() {
         return ID;
      }
   }
}
