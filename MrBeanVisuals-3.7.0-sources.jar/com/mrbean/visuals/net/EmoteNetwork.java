package com.mrbean.visuals.net;

import com.mrbean.visuals.module.impl.Emotes;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedDeque;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/**
 * Отправка и приём эмоций через сервер. Сервер должен знать каналы — это MrBeanServerBridge
 * (Fabric) или MrBeanBadgePlugin (Paper). Без них эмоция остаётся локальной, как и раньше.
 */
public final class EmoteNetwork {
   private static final ConcurrentLinkedDeque<EmoteProtocol.Show> INBOUND = new ConcurrentLinkedDeque<>();
   private static boolean registered;
   private static long lastSend;

   private EmoteNetwork() {
   }

   public static void registerPayloads() {
      if (!registered) {
         registered = true;
         PayloadTypeRegistry.playC2S().register(EmoteProtocol.Play.ID, EmoteProtocol.Play.CODEC);
         PayloadTypeRegistry.playS2C().register(EmoteProtocol.Show.ID, EmoteProtocol.Show.CODEC);
      }
   }

   public static void init() {
      registerPayloads();
      ClientPlayNetworking.registerGlobalReceiver(EmoteProtocol.Show.ID, (payload, context) -> {
         if (payload.player() != null && Emotes.def(payload.emote()) != null) {
            INBOUND.addLast(payload);
         }
      });
      ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> clear());
      ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> clear());
   }

   /** Сервер принимает наш канал эмоций? */
   public static boolean supported() {
      return ClientPlayNetworking.canSend(EmoteProtocol.Play.ID);
   }

   public static void send(String emote, float speed) {
      if (emote != null && supported() && System.currentTimeMillis() - lastSend > 400L) {
         lastSend = System.currentTimeMillis();
         ClientPlayNetworking.send(new EmoteProtocol.Play(emote, Math.max(0.2F, Math.min(3.0F, speed))));
      }
   }

   /** Разбирает очередь на клиентском тике: из сетевого потока мир трогать нельзя. */
   public static void applyInbound() {
      EmoteProtocol.Show s;
      class_310 mc = class_310.method_1551();

      while ((s = INBOUND.pollFirst()) != null) {
         if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
         }

         Emotes.EmoteModule em = Emotes.module();
         if (em == null || !em.isEnabled() || !em.watchOthers.get()) {
            clear();
            return;
         }

         UUID who = s.player();
         if (!who.equals(mc.field_1724.method_5667())) {
            class_1657 p = mc.field_1687.method_18470(who);
            if (p != null && !p.method_7325()) {
               Emotes.play(p.method_5628(), s.emote(), Math.max(0.2F, Math.min(3.0F, s.speed())));
            }
         }
      }
   }

   public static void clear() {
      INBOUND.clear();
   }
}
