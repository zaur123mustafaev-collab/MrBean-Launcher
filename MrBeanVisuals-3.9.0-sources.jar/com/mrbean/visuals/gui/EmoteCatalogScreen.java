package com.mrbean.visuals.gui;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.impl.Emotes;
import com.mrbean.visuals.render.R2D;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

/**
 * Каталог эмоций: поиск по названию, разделы (танцы, жесты, мемы), избранное, прослушивание звука
 * до запуска и предпросмотр позы на своём персонаже при наведении. Игру не ставит на паузу, чтобы
 * предпросмотр было видно. Все эмоции и их звуки уже есть в Emotes — экран только их показывает.
 */
public class EmoteCatalogScreen extends class_437 {
   private final Ui ui = new Ui();
   private final class_437 parent;
   private String search = "";
   private int tab;
   private double scroll;
   private double scrollTarget;
   private int contentHeight;
   private float open;
   private boolean closing;
   @Nullable
   private String hoverId;
   private static final int ROW_H = 26;
   private static final int FAV_TAB = 1;

   public EmoteCatalogScreen(class_437 parent) {
      super(class_2561.method_43470(Lang.t("Каталог эмоций", "Emote catalog")));
      this.parent = parent;
   }

   public boolean method_25421() {
      return false;
   }

   protected void method_25426() {
      Sounds.play(Sounds.OPEN);
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      if (this.field_22787.field_1687 == null) {
         this.method_57728(context, deltaTicks);
      } else {
         context.method_25296(0, 0, this.field_22789, this.field_22790, R2D.argb(110, 3, 4, 6), R2D.argb(160, 2, 3, 5));
      }
   }

   public void method_25394(class_332 ctx, int mouseX, int mouseY, float deltaTicks) {
      this.open = R2D.approach(this.open, 1.0F, 0.22F);
      int w = Math.min(this.field_22789 - 20, 330);
      int h = Math.min(this.field_22790 - 20, 280);
      int x = (this.field_22789 - w) / 2;
      int y = (this.field_22790 - h) / 2;
      Emotes.EmoteModule em = Emotes.module();
      List<Emotes.Def> list = this.list(em);
      this.ui.screenW = this.field_22789;
      this.ui.begin(ctx, mouseX, mouseY);
      float oldA = R2D.alpha;
      R2D.alpha = this.open;
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(0.0F, (1.0F - this.open) * 8.0F);
      this.ui.offsetY((double)((1.0F - this.open) * -8.0F));
      R2D.panel(ctx, x, y, w, h, 8, -166455776, true, R2D.withAlpha(R2D.accent(0.0F), 120));
      R2D.textScaled(ctx, Lang.t("Каталог эмоций", "Emote catalog"), x + 12, y + 9, 1.1F, -1, false);
      String count = list.size() + " " + Lang.t("из ", "of ") + Emotes.all().size();
      R2D.textScaled(ctx, count, x + w - R2D.width(count) * 0.75F - 30.0F, y + 11, 0.75F, Ui.DIM, false);
      if (this.ui.button("close", x + w - 22, y + 6, 16, 14, "✕", 2)) {
         this.method_25419();
      }

      this.search = this.ui.textField("q", x + 10, y + 26, w - 20, this.search, "⌕ " + Lang.t("Поиск эмоции…", "Search emotes…"), 24);
      this.tab = this.ui.segmented("tabs", x + 10, y + 44, w - 20, this.tabNames(), this.tab);
      int ly = y + 64;
      int lh = h - 64 - 16;
      this.contentHeight = list.size() * ROW_H + 4;
      if (this.ui.scroll != 0.0 && R2D.inside(mouseX, mouseY, x, ly, w, lh)) {
         this.scrollTarget = this.scrollTarget - this.ui.scroll * 22.0;
         this.ui.scroll = 0.0;
      }

      this.scrollTarget = Math.max(0.0, Math.min((double)Math.max(0, this.contentHeight - lh + 4), this.scrollTarget));
      this.scroll = R2D.approach((float)this.scroll, (float)this.scrollTarget, 0.35F);
      ctx.method_44379(x + 8, ly, x + w - 8, ly + lh);
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(0.0F, (float)-this.scroll);
      this.ui.offsetY(this.scroll);
      this.hoverId = null;

      for (int i = 0; i < list.size(); i++) {
         this.row(ctx, em, list.get(i), x + 10, ly + 2 + i * ROW_H, w - 20);
      }

      if (list.isEmpty()) {
         String none = Lang.t("Ничего не найдено", "Nothing found");
         R2D.text(ctx, none, x + w / 2 - R2D.width(none) / 2, ly + 20, Ui.DIM, false);
      }

      ctx.method_51448().popMatrix();
      ctx.method_44380();
      if (this.contentHeight > lh) {
         int bh = Math.max(16, (int)((float)(lh * lh) / this.contentHeight));
         int by = ly + (int)((float)(lh - bh) * ((float)this.scroll / (float)Math.max(1, this.contentHeight - lh + 4)));
         R2D.round(ctx, x + w - 5, by, 2, bh, 1, R2D.accent(0.0F));
      }

      if (this.hoverId != null && em != null && em.isEnabled() && this.field_22787.field_1724 != null) {
         em.preview(this.hoverId);
      }

      String hint = Lang.t(
            "ЛКМ ▶ — играть · ♪ — прослушать звук · ★ — в избранное · ESC — закрыть",
            "LMB ▶ — play · ♪ — listen · ★ — favourite · ESC — close"
         );
      R2D.textScaled(ctx, hint, x + w / 2.0F - R2D.width(hint) * 0.68F / 2.0F, y + h - 12, 0.68F, Ui.DIM, false);
      ctx.method_51448().popMatrix();
      R2D.alpha = oldA;
      this.ui.end();
   }

   private void row(class_332 ctx, Emotes.EmoteModule em, Emotes.Def d, int x, int y, int w) {
      boolean hov = this.ui.hover(x, y, w, ROW_H - 2);
      boolean fav = em != null && em.isFav(d.id());
      boolean on = em != null && d.id().equals(em.active());
      float t = this.ui.anim("row:" + d.id(), hov || on ? 1.0F : 0.0F, 0.3F);
      R2D.round(ctx, x, y, w, ROW_H - 2, 6, R2D.lerp(-15395041, on ? -14869470 : -14277082, t));
      R2D.outline(ctx, x, y, w, ROW_H - 2, 6, on ? R2D.withAlpha(R2D.accent(0.0F), 200) : R2D.withAlpha(587202559, (int)(60.0F + 140.0F * t)));
      String icon = Emotes.groupIcon(d.group());
      float hue = (float)Math.max(0, Emotes.groups().indexOf(d.group())) * 0.15F;
      R2D.round(ctx, x + 3, y + 3, 18, 18, 5, R2D.withAlpha(R2D.accent(hue), 70));
      R2D.textScaled(ctx, icon, x + 12 - R2D.width(icon) * 0.9F / 2.0F, y + 6, 0.9F, -1, false);
      R2D.text(ctx, Lang.t(d.ru(), d.en()), x + 26, y + 3, hov ? -1 : Ui.TEXT, false);
      String sub = d.en() + " · " + String.format(java.util.Locale.ROOT, "%.1f", d.seconds()) + Lang.t("с", "s")
         + (d.sound() == null ? "" : " · " + Lang.t("со звуком", "with sound"));
      R2D.textScaled(ctx, sub, x + 26, y + 13, 0.68F, Ui.DIM, false);
      if (hov) {
         this.hoverId = d.id();
      }

      int bx = x + w - 3 - 44;
      if (this.ui.button("play:" + d.id(), bx, y + 5, 44, 14, on ? "∞ " + Lang.t("Идёт", "Playing") : Lang.t("▶ Играть", "▶ Play"), 0)) {
         this.play(em, d);
      }

      Setting.Key bind = Emotes.bindOf(d.id());
      if (d.sound() != null) {
         bx -= 18;
         if (this.ui.button("snd:" + d.id(), bx, y + 5, 16, 14, "♪", 2)) {
            this.listen(d);
         }
      }

      bx -= 18;
      if (this.ui.button("fav:" + d.id(), bx, y + 5, 16, 14, fav ? "★" : "☆", 2) && em != null) {
         Sounds.play(em.toggleFav(d.id()) ? Sounds.ON : Sounds.OFF);
      }

      if (bind != null && bind.value >= 0) {
         String key = bind.display();
         R2D.textScaled(ctx, key, bx - 8.0F - R2D.width(key) * 0.62F, y + 8, 0.62F, R2D.withAlpha(R2D.accent(0.35F), 220), false);
      }
   }

   private void play(@Nullable Emotes.EmoteModule em, Emotes.Def d) {
      if (em == null) {
         Notifications.push(Lang.t("Включи модуль «Эмоции»", "Enable the Emotes module"), false);
      } else if (this.field_22787.field_1724 == null) {
         Notifications.push(Lang.t("Сначала зайди в мир", "Join a world first"), false);
      } else if (!em.isEnabled()) {
         Notifications.push(Lang.t("Включи модуль «Эмоции»", "Enable the Emotes module"), false);
      } else {
         em.restoreAfterPreview();
         Sounds.play(Sounds.CLICK);
         em.start(d.id());
         this.method_25419();
         return;
      }

      Sounds.play(Sounds.OFF);
   }

   private void listen(Emotes.Def d) {
      if (Emotes.listen(d)) {
         Sounds.play(Sounds.CLICK);
      } else {
         Emotes.EmoteModule em = Emotes.module();
         Notifications.push(
            em != null && em.soundVolume.value <= 0.0
               ? Lang.t("Громкость эмоций равна нулю", "Emote volume is zero")
               : Lang.t("У этой эмоции нет звука", "This emote has no sound"),
            false
         );
      }
   }

   private String[] tabNames() {
      List<String> l = new ArrayList<>();
      l.add(Lang.t("Все", "All"));
      l.add("★");

      for (String g : Emotes.groups()) {
         l.add(Lang.t(Emotes.groupRu(g), Emotes.groupEn(g)));
      }

      return l.toArray(new String[0]);
   }

   @Nullable
   private String tabGroup() {
      int i = this.tab - 2;
      List<String> gs = Emotes.groups();
      return i >= 0 && i < gs.size() ? gs.get(i) : null;
   }

   private List<Emotes.Def> list(@Nullable Emotes.EmoteModule em) {
      List<Emotes.Def> out;
      if (this.tab == FAV_TAB) {
         out = em == null ? new ArrayList<>() : em.favDefs();
      } else {
         out = Emotes.of(this.tabGroup());
      }

      String q = this.search.trim().toLowerCase(java.util.Locale.ROOT);
      if (!q.isEmpty()) {
         List<Emotes.Def> f = new ArrayList<>();

         for (Emotes.Def d : out) {
            if (d.id().contains(q) || d.ru().toLowerCase(java.util.Locale.ROOT).contains(q) || d.en().toLowerCase(java.util.Locale.ROOT).contains(q)) {
               f.add(d);
            }
         }

         out = f;
      }

      return out;
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      this.ui.onClick(click.comp_4798(), click.comp_4799(), click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      int k = input.comp_4795();
      if (this.ui.focus != null) {
         if (k == 256) {
            this.ui.focus = null;
            return true;
         }

         this.ui.onKey(k);
         return true;
      } else if (k != 256 && k != 66) {
         return super.method_25404(input);
      } else {
         this.method_25419();
         return true;
      }
   }

   public boolean method_25400(class_11905 input) {
      String s = input.method_74226();
      if (this.ui.focus == null && s != null && !s.isBlank()) {
         this.ui.focus = "q";
      }

      if (s != null) {
         for (char ch : s.toCharArray()) {
            this.ui.onChar(ch);
         }
      }

      return true;
   }

   public void method_25419() {
      if (!this.closing) {
         this.closing = true;
         Sounds.play(Sounds.CLOSE);
         Emotes.stopListen();
         Emotes.EmoteModule em = Emotes.module();
         if (em != null) {
            em.restoreAfterPreview();
         }

         this.field_22787.method_1507(this.parent);
      }
   }
}
