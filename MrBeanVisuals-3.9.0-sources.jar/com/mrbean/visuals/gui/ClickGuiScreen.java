package com.mrbean.visuals.gui;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.CfgManager;
import com.mrbean.visuals.core.Config;
import com.mrbean.visuals.core.Friends;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.menu.SkinHeads;
import com.mrbean.visuals.gui.ui.Ui;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Previewable;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.impl.AutoDuel;
import com.mrbean.visuals.module.impl.ThemeModule;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.Info;
import com.mrbean.visuals.util.Mobile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675.class_307;
import net.minecraft.class_437;
import org.joml.Matrix3x2fStack;

public class ClickGuiScreen extends class_437 {
   private final Ui ui = new Ui();
   private static ClickGuiScreen.Page page = ClickGuiScreen.Page.VISUALS;
   private static final Set<String> expanded = new HashSet<>();
   private String search = "";
   private String friendName = "";
   private String cfgName = "";
   private Module binding;
   private float open;
   private float pageAnim = 1.0F;
   private boolean closing;
   private double scroll;
   private double scrollTarget;
   private int contentH;
   private int winX;
   private int winY;
   private int winW;
   private int winH;
   private float gs = 1.0F;
   private static boolean soundOpen = true;
   private String delConfirm;
   private static final int SIDE = 104;
   private int cfgTab;
   private boolean cfgByCode;
   private String cfgCode = "";
   private static final int HEAD = 34;
   private static final int BG = -200207852;
   private static final int CARD = -15263717;
   private static final int CARD_H = -14934494;
   private static final int LINE = 352321535;
   private static final int MUTED = -7565159;
   private static final int DIM = -10657429;
   private static final String[] HELPERS = new String[]{
      "totem_counter",
      "durability_warning",
      "combat_timer",
      "hit_particles",
      "cooldowns",
      "scanner",
      "target_hud",
      "armor",
      "potions",
      "inventory_hud",
      "item_counter",
      "keystrokes",
      "cps",
      "fps",
      "ping",
      "coords",
      "crosshair",
      "fullbright",
      "player_outline"
   };
   private static final String[] USEFUL = new String[]{
      "clip_pearl",
      "auto_duel",
      "pvp_helper",
      "totem_alert",
      "fullbright",
      "zoom",
      "player_outline",
      "crystal_overlay",
      "target_hud",
      "auto_sprint",
      "low_fire",
      "crosshair",
      "hit_particles",
      "radius_preview",
      "scanner",
      "chat_filter"
   };
   private static final int TEXT_C = -1644306;

   public ClickGuiScreen() {
      super(class_2561.method_43470("MrBean Visuals"));
   }

   public boolean method_25421() {
      return false;
   }

   private void layout() {
      float want = (float)(Modules.theme().guiScale.value / 100.0) * Mobile.menu();
      this.gs = Math.max(0.5F, Math.min(want, Math.min(this.field_22789 / 330.0F, this.field_22790 / 210.0F)));
      int W = (int)(this.field_22789 / this.gs);
      int H = (int)(this.field_22790 / this.gs);
      this.winW = Math.min(540, W - 16);
      this.winH = Math.min(320, H - 16);
      this.winX = (W - this.winW) / 2;
      this.winY = (H - this.winH) / 2;
   }

   protected void method_25426() {
      this.layout();
      if (soundOpen) {
         Sounds.play(Sounds.OPEN);
         soundOpen = false;
      }
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      if (Modules.theme().blur.value && this.field_22787 != null && this.field_22787.field_1687 != null) {
         context.method_71278();
      }

      context.method_25296(0, 0, this.field_22789, this.field_22790, R2D.argb((int)(110.0F * this.open), 4, 5, 7), R2D.argb((int)(170.0F * this.open), 4, 5, 7));
   }

   private int acc() {
      return R2D.accent(0.0F);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.open = R2D.approach(this.open, this.closing ? 0.0F : 1.0F, 0.22F);
      if (this.closing && this.open < 0.03F) {
         soundOpen = true;
         super.method_25419();
      } else {
         this.layout();
         float s = 0.92F + 0.08F * this.open;
         float cx = this.winX + this.winW / 2.0F;
         float cy = this.winY + this.winH / 2.0F;
         double mx = (mouseX / this.gs - cx) / s + cx;
         double my = (mouseY / this.gs - cy) / s + cy;
         Matrix3x2fStack mt = context.method_51448();
         mt.pushMatrix();
         mt.scale(this.gs, this.gs);
         mt.translate(cx, cy + (1.0F - this.open) * 10.0F);
         mt.scale(s, s);
         mt.translate(-cx, -cy);
         float oldA = R2D.alpha;
         R2D.alpha = Math.min(1.0F, this.open * 1.15F);
         this.ui.screenW = (int)((this.field_22789 / this.gs - cx) / s + cx);
         this.ui.begin(context, mx, my);

         for (int i = 4; i >= 1; i--) {
            R2D.round(context, this.winX + 30 - i * 6, this.winY + this.winH - 30 + i * 3, this.winW - 60 + i * 12, 40, 20, R2D.withAlpha(this.acc(), 7));
         }

         if (Modules.theme().shadows.value) {
            R2D.shadow(context, this.winX, this.winY, this.winW, this.winH, 14, -1879048192);
         }

         R2D.round(context, this.winX, this.winY, this.winW, this.winH, 10, R2D.withAlpha(0x111214, 255));
         R2D.outline(context, this.winX, this.winY, this.winW, this.winH, 10, 318767103);
         this.sidebar(context);
         this.header(context);
         this.content(context);
         this.ui.end();
         R2D.alpha = oldA;
         mt.popMatrix();
         Notifications.render(context);
      }
   }

   private void sidebar(class_332 ctx) {
      int x = this.winX;
      int y = this.winY;
      R2D.rect(ctx, x + 104, y, 1, this.winH, 352321535);
      R2D.bean(ctx, x + 12, y + 12, 14);
      R2D.text(ctx, "MrBean", x + 30, y + 11, -1, false);
      R2D.textScaled(ctx, "Visuals", x + 30, y + 21, 0.75F, this.acc(), false);
      ClickGuiScreen.Page[] pages = ClickGuiScreen.Page.values();
      int top = y + 40;
      int bottom = y + this.winH - 34;
      int ih = Math.max(14, Math.min(20, (bottom - top) / pages.length));
      float sel = this.ui.anim("rv_sel", page.ordinal(), 0.28F);
      int selY = (int)(top + sel * ih);
      R2D.round(ctx, x + 8, selY - 1, 88, ih, 6, R2D.withAlpha(this.acc(), 40));
      R2D.round(ctx, x + 10, selY, 84, ih - 2, 5, this.acc());

      for (ClickGuiScreen.Page p : pages) {
         int iy = top + p.ordinal() * ih;
         boolean act = p == page;
         boolean hov = this.ui.hover(x + 10, iy, 84, ih - 2);
         float t = this.ui.anim("rv_side:" + p, hov && !act ? 1.0F : 0.0F, 0.3F);
         if (t > 0.01F) {
            R2D.round(ctx, x + 10, iy, 84, ih - 2, 5, R2D.withAlpha(-1, (int)(12.0F * t)));
         }

         int tc = act ? -16053235 : R2D.lerp(-3552045, -1, t);
         if (act) {
            R2D.textScaled(ctx, "⠿", x + 14, iy + (ih - 2) / 2.0F - 3.5F, 0.75F, -1878324211, false);
         }

         R2D.text(ctx, p.icon, x + 22, iy + (ih - 2) / 2 - 4, act ? -16053235 : -10657429, false);
         R2D.text(ctx, p.label(), x + 34 + (int)(2.0F * t), iy + (ih - 2) / 2 - 4, tc, false);
         if (p == ClickGuiScreen.Page.UTILITIES || p == ClickGuiScreen.Page.PERFORMANCE || p == ClickGuiScreen.Page.CONFIGS) {
            R2D.rect(ctx, x + 34, iy + ih - 1, 58, 1, 218103807);
         }

         if (this.ui.clicked(x + 10, iy, 84, ih - 2) && p != page) {
            this.switchPage(p);
         }
      }

      int py = y + this.winH - 28;
      SkinHeads.drawSelf(ctx, x + 12, py + 2, 18);
      R2D.outline(ctx, x + 11, py + 1, 20, 20, 10, 822083583);
      String name = this.field_22787.method_1548().method_1676();
      if (R2D.width(name) > 46) {
         name = name.substring(0, Math.min(name.length(), 8)) + "…";
      }

      R2D.text(ctx, name, x + 36, py + 3, -1, false);
      R2D.textScaled(ctx, Info.microsoftAccount() ? "Microsoft" : Lang.t("Офлайн", "Offline"), x + 36, py + 13, 0.7F, -7565159, false);
      boolean hb = this.ui.hover(x + 104 - 20, py + 4, 12, 12);
      R2D.text(ctx, "≡", x + 104 - 18, py + 6, hb ? this.acc() : -7565159, false);
      if (this.ui.clicked(x + 104 - 20, py + 4, 12, 12)) {
         this.switchPage(ClickGuiScreen.Page.SETTINGS);
      }
   }

   private void switchPage(ClickGuiScreen.Page p) {
      page = p;
      this.pageAnim = 0.0F;
      this.scroll = this.scrollTarget = 0.0;
      this.search = "";
      this.binding = null;
      this.ui.closeOverlay();
   }

   private void header(class_332 ctx) {
      int x = this.winX + 104 + 1;
      int y = this.winY;
      int w = this.winW - 104 - 1;
      String title = !this.search.isEmpty() ? Lang.t("Поиск", "Search") : page.label();
      R2D.textScaled(ctx, title, x + 14, y + 12, 1.15F, -1, false);
      R2D.rect(ctx, x, y + 34, w, 1, 352321535);
      int gx = x + w - 22;
      if (this.iconButton(ctx, "rv_gear", gx, y + 9, "⚙")) {
         this.switchPage(ClickGuiScreen.Page.SETTINGS);
      }

      int sw = Math.min(170, w - 160);
      int sx = gx - 8 - sw;
      R2D.round(ctx, sx, y + 8, sw, 17, 6, -15197924);
      R2D.outline(ctx, sx, y + 8, sw, 17, 6, "rv_search".equals(this.ui.focus) ? R2D.withAlpha(this.acc(), 160) : 352321535);
      String before = this.search;
      this.search = this.textInline("rv_search", sx + 6, y + 13, sw - 22, this.search, Lang.t("Поиск", "Search"));
      if (!this.search.equals(before)) {
         this.scroll = this.scrollTarget = 0.0;
      }

      R2D.text(ctx, "⌕", sx + sw - 13, y + 12, -7565159, false);
      if (this.iconButton(ctx, "rv_hud", sx - 22, y + 9, "⬡")) {
         this.field_22787.method_1507(Screens.hudEditor(this));
      }

      if (this.ui.hover(sx - 22, y + 9, 15, 15)) {
         this.ui.tooltip(Lang.t("Редактор HUD", "HUD editor"));
      }
   }

   private boolean iconButton(class_332 ctx, String id, int x, int y, String icon) {
      boolean hov = this.ui.hover(x, y, 15, 15);
      float t = this.ui.anim(id, hov ? 1.0F : 0.0F, 0.3F);
      if (t > 0.01F) {
         R2D.round(ctx, x, y, 15, 15, 5, R2D.withAlpha(-1, (int)(16.0F * t)));
      }

      R2D.text(ctx, icon, x + 8 - R2D.width(icon) / 2, y + 4, R2D.lerp(-7565159, -1, t), false);
      return this.ui.clicked(x, y, 15, 15);
   }

   private String textInline(String id, int x, int y, int w, String value, String placeholder) {
      boolean focused = id.equals(this.ui.focus);
      if (this.ui.clicked(x - 6, y - 5, w + 22, 17)) {
         this.ui.focus = id;
      }

      String v = value;
      if (focused) {
         for (char c : this.ui.chars()) {
            if (v.length() < 32 && c >= ' ') {
               v = v + c;
            }
         }

         for (int k : this.ui.keys()) {
            if (k == 259 && !v.isEmpty()) {
               v = v.substring(0, v.length() - 1);
            }
         }
      }

      String shown = v;

      while (R2D.width(shown) > w && shown.length() > 1) {
         shown = shown.substring(1);
      }

      if (v.isEmpty() && !focused) {
         R2D.text(this.ui.ctx, placeholder, x, y, -10657429, false);
      } else {
         R2D.text(this.ui.ctx, shown, x, y, -1, false);
      }

      if (focused && System.currentTimeMillis() / 500L % 2L == 0L) {
         R2D.rect(this.ui.ctx, x + R2D.width(shown) + 1, y - 1, 1, 9, this.acc());
      }

      return v;
   }

   private void content(class_332 ctx) {
      int x = this.winX + 104 + 13;
      int y = this.winY + 34 + 10;
      int w = this.winW - 104 - 30;
      int h = this.winH - 34 - 16;
      this.pageAnim = R2D.approach(this.pageAnim, 1.0F, 0.18F);
      if (this.ui.scroll != 0.0 && this.ui.hover(x - 4, y - 4, w + 12, h + 8) && !this.ui.overlayOpen()) {
         this.scrollTarget = this.scrollTarget - this.ui.scroll * 26.0;
         this.ui.scroll = 0.0;
      }

      this.scrollTarget = Math.max(0.0, Math.min((double)Math.max(0, this.contentH - h + 6), this.scrollTarget));
      this.scroll = R2D.approach((float)this.scroll, (float)this.scrollTarget, 0.3F);
      ctx.method_44379(x - 6, y - 4, x + w + 6, y + h);
      Matrix3x2fStack mt = ctx.method_51448();
      mt.pushMatrix();
      float slide = (1.0F - this.pageAnim) * 10.0F;
      mt.translate(0.0F, (float)(-this.scroll + slide));
      double off = this.scroll - slide;
      this.ui.offsetY(off);
      float a = R2D.alpha;
      R2D.alpha = R2D.alpha * this.pageAnim;
      if (!this.search.isEmpty()) {
         this.contentH = this.moduleCards(ctx, x, y, w, this.found());
      } else {
         this.contentH = switch (page) {
            case UTILITIES -> this.moduleCards(ctx, x, y, w, this.utilities());
            case PVE -> this.moduleCards(ctx, x, y, w, com.mrbean.visuals.module.impl.PveModules.page());
            default -> this.moduleCards(ctx, x, y, w, Modules.of(page.cat));
            case BINDS -> this.binds(ctx, x, y, w);
            case FRIENDS -> this.friends(ctx, x, y, w);
            case CONFIGS -> this.configs(ctx, x, y, w);
            case SETTINGS -> this.settings(ctx, x, y, w);
         };
      }

      R2D.alpha = a;
      this.ui.offsetY(-off);
      mt.popMatrix();
      ctx.method_44380();
      if (this.contentH > h) {
         int bh = Math.max(20, (int)((float)(h * h) / this.contentH));
         int by = y + (int)((h - bh) * (this.scroll / Math.max(1, this.contentH - h + 6)));
         R2D.round(ctx, this.winX + this.winW - 7, by, 3, bh, 1, this.acc());
      }
   }

   private List<Module> utilities() {
      List<Module> l = new ArrayList<>(Modules.of(Category.UTILITIES));

      for (String id : HELPERS) {
         Module m = Modules.get(id);
         if (m != null && !l.contains(m)) {
            l.add(m);
         }
      }

      return l;
   }

   private List<Module> found() {
      String q = this.search.toLowerCase();
      List<Module> out = new ArrayList<>();

      for (Module m : Modules.all()) {
         if (m.searchText().contains(q)) {
            out.add(m);
         }
      }

      return out;
   }

   private int moduleCards(class_332 ctx, int x, int y, int w, List<Module> mods) {
      int cols = w >= 300 ? 2 : 1;
      int gap = 8;
      int cw = (w - gap * (cols - 1)) / cols;
      int[] colY = new int[cols];

      for (int c = 0; c < cols; c++) {
         colY[c] = y;
      }

      int i = 0;

      for (Module m : mods) {
         int c = cols == 1 ? 0 : (colY[0] <= colY[1] ? 0 : 1);
         float in = this.ui.anim("rv_in:" + page + ":" + m.id, 1.0F, 0.1F + Math.min(0.12F, i++ * 0.006F));
         float oa = R2D.alpha;
         R2D.alpha = R2D.alpha * Math.min(1.0F, in);
         int ch = this.card(ctx, m, x + c * (cw + gap), colY[c] + (int)((1.0F - in) * 6.0F), cw);
         R2D.alpha = oa;
         colY[c] += ch + gap;
      }

      if (mods.isEmpty()) {
         R2D.text(ctx, Lang.ui("ui.nothing_found"), x, y + 4, -7565159, false);
      }

      int max = y;

      for (int v : colY) {
         max = Math.max(max, v);
      }

      return max - y;
   }

   private int card(class_332 ctx, Module m, int x, int y, int w) {
      boolean exp = expanded.contains(m.id);
      boolean hasSet = !m.settings.isEmpty();
      List<String> desc = Ui.wrap(m.description(), (int)((w - 92) / 0.8F));
      boolean cut = desc.size() > 2;
      if (cut) {
         desc = new ArrayList<>(desc.subList(0, 2));
         desc.set(1, desc.get(1) + "…");
      }

      int headH = 26 + desc.size() * 8 + 4;
      float ex = this.ui.anim("rv_exp:" + m.id, exp ? 1.0F : 0.0F, 0.25F);
      int setH = 0;
      if (hasSet && ex > 0.01F) {
         for (Setting s : m.settings) {
            if (s.visible.getAsBoolean()) {
               setH += rowH(s) + 4;
            }
         }
      }

      if (hasSet && ex > 0.01F && m instanceof Previewable pv) {
         setH += pv.previewHeight() + 6;
      }

      int fullH = headH + (int)((setH + (setH > 0 ? 10 : 0)) * ex);
      boolean hov = this.ui.hover(x, y, w, headH);
      float t = this.ui.anim("rv_card:" + m.id, hov ? 1.0F : 0.0F, 0.3F);
      R2D.round(ctx, x, y, w, fullH, 8, R2D.lerp(-15263717, -14934494, t));
      R2D.outline(ctx, x, y, w, fullH, 8, R2D.lerp(251658239, R2D.withAlpha(this.acc(), 70), t * 0.8F));
      int ctrlW = (m.toggleable() ? 28 + (int)(R2D.width(this.binding == m ? "..." : keyName(m.bind)) * 0.75F) + 8 + 6 : 0) + (hasSet ? 14 : 0) + 12;
      String title = m.name();
      int maxT = w - 20 - ctrlW;
      if (R2D.width(title) > maxT) {
         while (title.length() > 3 && R2D.width(title + "…") > maxT) {
            title = title.substring(0, title.length() - 1);
         }

         title = title + "…";
      }

      R2D.text(ctx, title, x + 10, y + 10, -1, false);
      int dy = y + 23;

      for (String line : desc) {
         R2D.textScaled(ctx, line, x + 10, dy, 0.8F, -7565159, false);
         dy += 8;
      }

      if ((cut || !title.equals(m.name())) && this.ui.hover(x, y, w - ctrlW - 10, headH)) {
         this.ui.tooltip(m.name() + " — " + m.description());
      }

      int rx = x + w - 10;
      if (hasSet) {
         rx -= 8;
         R2D.textScaled(ctx, ex > 0.5F ? "⌃" : "⌄", rx, y + 9 + (ex > 0.5F ? 2 : 0), 1.0F, hov ? -1 : -7565159, false);
         rx -= 6;
      }

      if (m.toggleable()) {
         rx -= 22;
         boolean nv = this.toggleRv("rv_tg:" + m.id, rx, y + 9, m.isEnabled());
         if (nv != m.isEnabled()) {
            m.toggle();
            Config.markDirty();
         }

         rx -= 6;
         String kb = this.binding == m ? "..." : keyName(m.bind);
         int kw = (int)(R2D.width(kb) * 0.75F) + 8;
         rx -= kw;
         boolean kh = this.ui.hover(rx, y + 9, kw, 12);
         R2D.round(ctx, rx, y + 9, kw, 12, 4, this.binding == m ? R2D.withAlpha(this.acc(), 70) : (kh ? 654311423 : 352321535));
         R2D.textScaled(ctx, kb, rx + 4, y + 12.5F, 0.75F, this.binding == m ? -1 : -7565159, false);
         if (kh) {
            this.ui.tooltip(Lang.t("Клик — назначить клавишу, ПКМ — убрать", "Click to bind a key, right-click to clear"));
         }

         if (this.ui.clicked(rx, y + 9, kw, 12)) {
            this.binding = this.binding == m ? null : m;
         }

         if (this.ui.rightClicked(rx, y + 9, kw, 12)) {
            m.bind = -1;
            this.binding = null;
            Config.markDirty();
         }
      }

      if (this.ui.clicked(x, y, w, headH)) {
         if (hasSet) {
            if (!expanded.remove(m.id)) {
               expanded.add(m.id);
            }
         } else if (m.toggleable()) {
            m.toggle();
            Config.markDirty();
         }
      }

      if (this.ui.rightClicked(x, y, w, headH) && m.toggleable()) {
         m.toggle();
         Config.markDirty();
      }

      if (hasSet && ex > 0.01F) {
         int sy = y + headH;
         this.ui.ctx.method_44379(x, sy, x + w, y + fullH);
         R2D.rect(ctx, x + 10, sy, w - 20, 1, 352321535);
         int yy = sy + 7;
         if (m instanceof Previewable pv) {
            pv.drawPreview(ctx, x + 10, yy, w - 20, pv.previewHeight());
            yy += pv.previewHeight() + 6;
         }

         for (Setting sx : m.settings) {
            if (sx.visible.getAsBoolean()) {
               yy += this.ui.settingRow("rv_set:" + m.id + ":", sx, x + 10, yy, w - 20) + 4;
            }
         }

         this.ui.ctx.method_44380();
      }

      return fullH;
   }

   private static int rowH(Setting s) {
      if (s instanceof Setting.Num) {
         return 22;
      } else if (s instanceof Setting.Mode || s instanceof Setting.Text || s instanceof Setting.Key) {
         return 18;
      } else {
         return s instanceof Setting.Action ? 19 : 16;
      }
   }

   private boolean toggleRv(String id, int x, int y, boolean value) {
      float t = this.ui.anim(id, value ? 1.0F : 0.0F, 0.3F);
      boolean hov = this.ui.hover(x - 2, y - 2, 26, 16);
      if (t > 0.02F) {
         R2D.round(this.ctx(), x, y, 22, 12, 6, R2D.withAlpha(this.acc(), (int)(255.0F * t)));
      }

      int kx = (int)(x + 6 + 10.0F * t);
      R2D.circle(this.ctx(), kx, y + 6, 4, R2D.lerp(hov ? -7696487 : -9538949, -1, t));
      return this.ui.clicked(x - 2, y - 2, 26, 16) ? !value : value;
   }

   private class_332 ctx() {
      return this.ui.ctx;
   }

   private static String keyName(int key) {
      if (key < 0) {
         return "None";
      } else {
         try {
            String s = class_307.field_1668.method_1447(key).method_27445().getString();
            return s.length() > 6 ? s.substring(0, 6) : s;
         } catch (Exception var2) {
            return "#" + key;
         }
      }
   }

   private int binds(class_332 ctx, int x, int y, int w) {
      int yy = y;

      for (String line : Ui.wrap(
         Lang.t(
            "Клик по клавише справа — назначить, ПКМ — убрать. Клавиша модуля включает/выключает его. У Clip Pearl и Auto Duel ещё есть клавиши действий.",
            "Click the key on the right to bind, right-click to clear. A module key toggles it. Clip Pearl and Auto Duel also have action keys."
         ),
         w
      )) {
         R2D.text(ctx, line, x, yy, -7565159, false);
         yy += 10;
      }

      yy += 6;
      List<Module> list = new ArrayList<>();

      for (String id : USEFUL) {
         Module m = Modules.get(id);
         if (m != null) {
            list.add(m);
         }
      }

      for (Module m : Modules.all()) {
         if (m.toggleable() && m.bind >= 0 && !list.contains(m)) {
            list.add(m);
         }
      }

      R2D.text(ctx, Lang.t("Полезные для PvP", "Useful for PvP"), x, yy, -1, false);
      yy += 14;

      for (Module mx : list) {
         yy = this.bindRow(ctx, mx, x, yy, w);
      }

      yy += 6;
      R2D.text(ctx, Lang.t("Клавиши действий", "Action keys"), x, yy, -1, false);
      yy += 14;

      for (Module mx : Modules.all()) {
         for (Setting st : mx.settings) {
            if (st instanceof Setting.Key k) {
               R2D.round(ctx, x, yy, w, 20, 6, -15263717);
               R2D.text(ctx, mx.name() + " — " + k.name(), x + 8, yy + 6, -1644306, false);
               this.ui.keyField("rv_bk:" + mx.id + ":" + k.id, x + 8, yy + 3, w - 16, k);
               yy += 23;
            }
         }
      }

      if (Modules.get("auto_duel") instanceof AutoDuel ad && ad.key != null) {
         R2D.round(ctx, x, yy, w, 20, 6, -15263717);
         R2D.text(ctx, "Auto Duel — " + Lang.t("вызов (в «Управлении» игры)", "challenge (in game Controls)"), x + 8, yy + 6, -1644306, false);
         String kn = ad.key.method_16007().getString();
         R2D.text(ctx, kn, x + w - 8 - R2D.width(kn), yy + 6, this.acc(), false);
         yy += 24;
      }

      yy += 6;
      R2D.text(ctx, Lang.t("Остальные модули", "Other modules"), x, yy, -1, false);
      yy += 14;

      for (Module mx : Modules.all()) {
         if (mx.toggleable() && !list.contains(mx)) {
            yy = this.bindRow(ctx, mx, x, yy, w);
         }
      }

      return yy - y;
   }

   private int bindRow(class_332 ctx, Module m, int x, int y, int w) {
      boolean hov = this.ui.hover(x, y, w, 20);
      R2D.round(ctx, x, y, w, 20, 6, hov ? -14934494 : -15263717);
      R2D.circle(ctx, x + 10, y + 10, 3, m.isEnabled() ? this.acc() : -11184033);
      R2D.text(ctx, m.name(), x + 18, y + 6, -1644306, false);
      String kb = this.binding == m ? Lang.t("Нажмите клавишу…", "Press a key…") : keyName(m.bind);
      int kw = R2D.width(kb) + 14;
      int kx = x + w - 8 - kw;
      boolean kh = this.ui.hover(kx, y + 3, kw, 14);
      R2D.round(ctx, kx, y + 3, kw, 14, 4, this.binding == m ? R2D.withAlpha(this.acc(), 90) : (kh ? 1090519039 : 587202559));
      R2D.text(ctx, kb, kx + 7, y + 6, m.bind < 0 && this.binding != m ? -7565159 : -1, false);
      if (this.ui.clicked(kx, y + 3, kw, 14)) {
         this.binding = m;
      }

      if (this.ui.rightClicked(kx, y + 3, kw, 14)) {
         m.bind = -1;
         this.binding = null;
         Config.markDirty();
      }

      return y + 23;
   }

   private int friends(class_332 ctx, int x, int y, int w) {
      int yy = y;

      for (String line : Ui.wrap(
         Lang.t(
            "Друзья подсвечиваются зелёным, не попадают в сканер и Auto Duel. Добавить можно здесь, командой .friend add <ник> или средней кнопкой мыши по игроку.",
            "Friends are highlighted green and skipped by Scanner and Auto Duel. Add them here, with .friend add <nick> or by middle-clicking a player."
         ),
         w
      )) {
         R2D.text(ctx, line, x, yy, -7565159, false);
         yy += 10;
      }

      yy += 6;
      R2D.round(ctx, x, yy, w - 96, 18, 6, -15197924);
      R2D.outline(ctx, x, yy, w - 96, 18, 6, "rv_friend".equals(this.ui.focus) ? R2D.withAlpha(this.acc(), 160) : 352321535);
      this.friendName = this.textInline("rv_friend", x + 6, yy + 5, w - 110, this.friendName, Lang.t("Ник друга", "Friend's nick"));
      if (this.pill(ctx, "rv_fadd", x + w - 90, yy, 90, 18, "+ " + Lang.t("Добавить", "Add"), true)) {
         if (Friends.add(this.friendName.trim())) {
            Notifications.push(Lang.t("Друг добавлен: ", "Friend added: ") + this.friendName.trim(), true);
            this.friendName = "";
            Config.save();
         } else {
            Notifications.push(Lang.t("Ник: 3–16 символов, латиница, цифры и _", "Nick: 3–16 chars"), false);
         }
      }

      yy += 26;
      List<String> all = Friends.all();
      if (all.isEmpty()) {
         R2D.text(ctx, Lang.t("Список пуст", "No friends yet"), x, yy + 4, -10657429, false);
         return yy - y + 20;
      } else {
         int cw = (w - 8) / 2;
         int i = 0;

         for (String f : all) {
            int cx = x + i % 2 * (cw + 8);
            int cy = yy + i / 2 * 28;
            R2D.round(ctx, cx, cy, cw, 24, 7, -15263717);
            SkinHeads.drawOffline(ctx, f, cx + 6, cy + 4, 16);
            R2D.text(ctx, f, cx + 28, cy + 8, -8588644, false);
            if (this.pill(ctx, "rv_fdel:" + f, cx + cw - 52, cy + 5, 46, 14, Lang.t("Убрать", "Remove"), false)) {
               Friends.remove(f);
               Config.save();
            }

            i++;
         }

         return yy - y + (all.size() + 1) / 2 * 28;
      }
   }

   private int configs(class_332 ctx, int x, int y, int w) {
      List<CfgManager.Info> all = new ArrayList<>();

      for (String n : CfgManager.list()) {
         CfgManager.Info i = CfgManager.info(n);
         if (i != null) {
            all.add(i);
         }
      }

      List<CfgManager.Info> favs = new ArrayList<>();

      for (CfgManager.Info i : all) {
         if (i.fav()) {
            favs.add(i);
         }
      }

      int yy = y;
      String l0 = Lang.t("Все", "All");
      String l1 = Lang.t("Избранные", "Favourites");
      int w0 = 26 + R2D.width(l0);
      int w1 = 26 + R2D.width(l1);
      if (this.chip(ctx, "rv_cfgtab0", x, yy, w0, l0, all.size(), this.cfgTab == 0)) {
         this.cfgTab = 0;
      }

      if (this.chip(ctx, "rv_cfgtab1", x + w0 + 6, yy, w1, l1, favs.size(), this.cfgTab == 1)) {
         this.cfgTab = 1;
      }

      yy += 23;
      int cols = w >= 300 ? 2 : 1;
      int gap = 8;
      int cw = cols == 2 ? (w - gap) / 2 : w;
      int[] colY = new int[cols];

      for (int c = 0; c < cols; c++) {
         colY[c] = yy;
      }

      List<CfgManager.Info> list = this.cfgTab == 1 ? favs : all;
      colY[cols == 1 ? 0 : (colY[0] <= colY[1] ? 0 : 1)] += this.newCfgCard(ctx, x, colY[0], cw) + gap;

      for (CfgManager.Info i : list) {
         int c = cols == 1 ? 0 : (colY[0] <= colY[1] ? 0 : 1);
         colY[c] += this.cfgCard(ctx, x + c * (cw + gap), colY[c], cw, i) + gap;
      }

      if (list.isEmpty() && this.cfgTab == 1) {
         R2D.text(ctx, Lang.t("В избранном пока пусто — нажми ☆ на карточке", "Nothing favourited yet — press ☆ on a card"), x, colY[0] + 4, -10657429, false);
         colY[0] += 16;
      }

      int max = yy;

      for (int v : colY) {
         max = Math.max(max, v);
      }

      return max - y + 4;
   }

   private boolean chip(class_332 ctx, String id, int x, int y, int w, String label, int count, boolean sel) {
      boolean hov = this.ui.hover(x, y, w, 17);
      float t = this.ui.anim(id, sel ? 1.0F : (hov ? 0.4F : 0.0F), 0.3F);
      R2D.round(ctx, x, y, w, 17, 9, R2D.lerp(352321535, R2D.withAlpha(this.acc(), 190), t));
      if (sel) {
         R2D.outline(ctx, x, y, w, 17, 9, R2D.withAlpha(this.acc(), 220));
      }

      R2D.text(ctx, label, x + 8, y + 5, R2D.lerp(-7565159, -1, t), false);
      if (count >= 0) {
         String c = Integer.toString(count);
         R2D.text(ctx, c, x + w - 6 - R2D.width(c), y + 5, R2D.lerp(-10657429, -1, t), false);
      }

      return this.ui.clicked(x, y, w, 17);
   }

   private int newCfgCard(class_332 ctx, int x, int y, int w) {
      int h = this.cfgByCode ? 104 : 84;
      R2D.panel(ctx, x, y, w, h, 8, -15263717, true, 251658239);
      R2D.circle(ctx, x + 17, y + 17, 9, R2D.withAlpha(this.acc(), 70));
      R2D.text(ctx, "+", x + 17 - R2D.width("+") / 2, y + 13, -1, false);
      R2D.text(ctx, Lang.t("Новый конфиг", "New config"), x + 32, y + 10, -1, false);
      R2D.text(ctx, Lang.t("Сохранить текущие настройки", "Store the current settings"), x + 32, y + 21, -10657429, false);
      if (this.chip(ctx, "rv_cfgm0", x + 10, y + 34, 46, Lang.t("Новый", "New"), -1, !this.cfgByCode)) {
         this.cfgByCode = false;
      }

      if (this.chip(ctx, "rv_cfgm1", x + 60, y + 34, 58, Lang.t("По коду", "By code"), -1, this.cfgByCode)) {
         this.cfgByCode = true;
      }

      this.cfgName = this.textInline("rv_cfgn", x + 10, y + 60, w - 76, this.cfgName, Lang.t("Название конфига", "Config name"));
      if (!this.cfgByCode) {
         if (this.pill(ctx, "rv_cfgnew", x + w - 62, y + 56, 52, 17, Lang.t("Создать", "Create"), true) && !this.cfgName.isBlank()) {
            CfgManager.Result r = CfgManager.save(this.cfgName.trim());
            Notifications.push(r.message(), r.ok());
            if (r.ok()) {
               this.cfgName = "";
            }
         }
      } else {
         String shown = this.cfgCode.isEmpty() ? Lang.t("код не вставлен", "no code pasted") : this.cfgCode.length() + " " + Lang.t("символов", "chars");

         while (R2D.width(shown) > w - 74 && shown.length() > 3) {
            shown = shown.substring(0, shown.length() - 1);
         }

         R2D.round(ctx, x + 10, y + 78, w - 20, 16, 4, -15197924);
         R2D.outline(ctx, x + 10, y + 78, w - 20, 16, 4, 352321535);
         R2D.text(ctx, shown, x + 15, y + 82, this.cfgCode.isEmpty() ? -10657429 : -3552045, false);
         if (this.iconButton(ctx, "rv_cfgpaste", x + w - 44, y + 79, "⌕")) {
            this.cfgCode = this.field_22787.field_1774.method_1460();
            Notifications.push(Lang.t("Код взят из буфера обмена", "Code taken from the clipboard"), !this.cfgCode.isEmpty());
         }

         if (this.ui.hover(x + w - 44, y + 79, 15, 15)) {
            this.ui.tooltip(Lang.t("Взять код из буфера обмена", "Read the code from the clipboard"));
         }

         if (this.iconButton(ctx, "rv_cfgclr", x + w - 28, y + 79, "✕")) {
            this.cfgCode = "";
         }

         if (this.pill(ctx, "rv_cfgimp", x + w - 82, y + 56, 72, 17, Lang.t("Импортировать", "Import"), true)) {
            String code = this.cfgCode.isBlank() ? this.field_22787.field_1774.method_1460() : this.cfgCode;
            CfgManager.Result r = CfgManager.importCode(this.cfgName.trim(), code);
            Notifications.push(r.message(), r.ok());
            if (r.ok()) {
               this.cfgName = "";
               this.cfgCode = "";
            }
         }
      }

      return h;
   }

   private int cfgCard(class_332 ctx, int x, int y, int w, CfgManager.Info i) {
      int h = 76;
      boolean act = i.name().equals(CfgManager.active);
      int seed = Math.abs(i.name().hashCode());
      int c1 = R2D.hsv((float)(seed % 360) / 360.0F, 0.5F, 0.72F);
      int c2 = R2D.hsv((float)((seed / 7 + 130) % 360) / 360.0F, 0.6F, 0.5F);
      R2D.panel(ctx, x, y, w, h, 8, act ? R2D.lerp(-15263717, c1, 0.16F) : -15263717, true, act ? R2D.withAlpha(this.acc(), 160) : 251658239);
      R2D.round(ctx, x, y, w, 28, 8, c1);
      R2D.rect(ctx, x, y + 14, w, 14, c1);
      R2D.hGradient(ctx, x + 1, y + 6, w - 2, 22, R2D.withAlpha(c1, 0), R2D.withAlpha(c2, 170));
      R2D.text(ctx, "▤", x + 9, y + 10, -1, true);
      String nm = i.name();

      while (R2D.width(nm) > w - 66 && nm.length() > 2) {
         nm = nm.substring(0, nm.length() - 1);
      }

      R2D.text(ctx, nm, x + 24, y + 10, -1, true);
      if (act) {
         R2D.circle(ctx, x + w - 15, y + 13, 6, -1);
         R2D.text(ctx, "✓", x + w - 18, y + 10, c1, false);
      }

      if (this.iconButton(ctx, "rv_cfgf:" + i.name(), x + w - 34, y + 6, i.fav() ? "★" : "☆")) {
         CfgManager.Result r = CfgManager.setFav(i.name(), !i.fav());
         Notifications.push(r.message(), r.ok());
      }

      if (this.ui.hover(x + w - 34, y + 6, 15, 15)) {
         this.ui.tooltip(i.fav() ? Lang.t("Убрать из избранного", "Remove from favourites") : Lang.t("В избранное", "Add to favourites"));
      }

      R2D.text(ctx, Lang.t("Включено функций: ", "Enabled features: ") + i.funcs(), x + 10, y + 35, -1644306, false);
      R2D.text(ctx, "HUD: " + i.hud() + ", " + Lang.t("бинды: ", "binds: ") + i.binds(), x + 10, y + 46, -10657429, false);
      R2D.text(ctx, Lang.t("Изменён ", "Modified ") + this.date(i.modified()), x + 10, y + h - 12, -10657429, false);
      int ax = x + w - 10;
      String dl = i.name().equals(this.delConfirm) ? Lang.t("Точно?", "Sure?") : null;

      if (dl != null) {
         if (this.pill(ctx, "rv_cfgsure", ax - 40, y + h - 19, 40, 15, Lang.t("Да", "Yes"), false)) {
            CfgManager.Result r = CfgManager.delete(i.name());
            Notifications.push(r.message(), r.ok());
            this.delConfirm = null;
         }

         ax -= 46;
         if (this.iconButton(ctx, "rv_cfgno:" + i.name(), ax - 15, y + h - 18, "✕")) {
            this.delConfirm = null;
         }

         ax -= 21;
      } else {
         if (this.iconButton(ctx, "rv_cfgdel:" + i.name(), ax - 15, y + h - 18, "✕")) {
            this.delConfirm = i.name();
         }

         if (this.ui.hover(ax - 15, y + h - 18, 15, 15)) {
            this.ui.tooltip(Lang.t("Удалить конфиг", "Delete config"));
         }

         ax -= 19;
         String code = CfgManager.code(i.name());
         if (this.iconButton(ctx, "rv_cfgcode:" + i.name(), ax - 15, y + h - 18, "⇄")) {
            if (code != null) {
               this.field_22787.field_1774.method_1455(code);
               Notifications.push(Lang.t("Код конфига «" + i.name() + "» скопирован", "Config code “" + i.name() + "” copied"), true);
            } else {
               Notifications.push(Lang.t("Не удалось собрать код", "Could not build the code"), false);
            }
         }

         if (this.ui.hover(ax - 15, y + h - 18, 15, 15)) {
            this.ui.tooltip(Lang.t("Скопировать код для друга", "Copy a code to share"));
         }

         ax -= 19;
         if (this.iconButton(ctx, "rv_cfgload:" + i.name(), ax - 15, y + h - 18, act ? "•" : "↓")) {
            CfgManager.Result r = CfgManager.load(i.name());
            Notifications.push(r.message(), r.ok());
         }

         if (this.ui.hover(ax - 15, y + h - 18, 15, 15)) {
            this.ui.tooltip(act ? Lang.t("Активный конфиг", "This config is active") : Lang.t("Загрузить", "Load config"));
         }
      }

      return h;
   }

   private String date(long ms) {
      if (ms <= 0L) {
         return "—";
      } else {
         try {
            return java.time.Instant.ofEpochMilli(ms)
               .atZone(java.time.ZoneId.systemDefault())
               .format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"));
         } catch (Exception var4) {
            return "—";
         }
      }
   }

   private int settings(class_332 ctx, int x, int y, int w) {
      ThemeModule t = Modules.theme();
      R2D.text(ctx, Lang.t("Язык интерфейса", "Interface language"), x, y + 4, -1, false);
      int li = this.ui.segmented("rv_lang", x + w - 140, y, 140, new String[]{"Русский", "English"}, Lang.english ? 1 : 0);
      if (li == 1 != Lang.english) {
         Lang.english = li == 1;
         Config.save();
      }

      int yy = y + 22;
      R2D.text(ctx, Lang.t("Уведомления о вкл/выкл", "Toggle notifications"), x, yy + 2, -1, false);
      boolean nb = this.toggleRv("rv_notif", x + w - 22, yy, Notifications.enabled);
      if (nb != Notifications.enabled) {
         Notifications.enabled = nb;
      }

      yy += 20;
      R2D.rect(ctx, x, yy, w, 1, 352321535);
      yy += 8;
      R2D.text(ctx, Lang.t("Тема и интерфейс", "Theme & interface"), x, yy, this.acc(), false);
      yy += 14;

      for (Setting s : t.settings) {
         if (s.visible.getAsBoolean()) {
            yy += this.ui.settingRow("rv_theme:", s, x, yy, w) + 4;
         }
      }

      R2D.rect(ctx, x, yy, w, 1, 352321535);
      yy += 8;
      if (this.pill(ctx, "rv_classic", x, yy, 150, 16, Lang.t("Классическое меню", "Classic menu"), false)) {
         this.field_22787.method_1507(new MenuScreen());
      }

      if (this.pill(ctx, "rv_hud2", x + 156, yy, 120, 16, Lang.t("Редактор HUD", "HUD editor"), false)) {
         this.field_22787.method_1507(Screens.hudEditor(this));
      }

      return yy - y + 24;
   }

   private boolean pill(class_332 ctx, String id, int x, int y, int w, int h, String label, boolean primary) {
      boolean hov = this.ui.hover(x, y, w, h);
      float t = this.ui.anim(id, hov ? 1.0F : 0.0F, 0.3F);
      if (primary) {
         R2D.round(ctx, x, y, w, h, 6, this.acc());
         if (t > 0.0F) {
            R2D.round(ctx, x, y, w, h, 6, R2D.withAlpha(-1, (int)(35.0F * t)));
         }

         R2D.text(ctx, label, x + w / 2 - R2D.width(label) / 2, y + h / 2 - 4, -16053235, false);
      } else {
         R2D.round(ctx, x, y, w, h, 6, R2D.lerp(352321535, 620756991, t));
         R2D.text(ctx, label, x + w / 2 - R2D.width(label) / 2, y + h / 2 - 4, R2D.lerp(-3552045, -1, t), false);
      }

      return this.ui.clicked(x, y, w, h);
   }

   private double[] toWin(double mx, double my) {
      float s = 0.92F + 0.08F * this.open;
      float cx = this.winX + this.winW / 2.0F;
      float cy = this.winY + this.winH / 2.0F;
      return new double[]{(mx / this.gs - cx) / s + cx, (my / this.gs - cy) / s + cy};
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      double[] p = this.toWin(click.comp_4798(), click.comp_4799());
      this.ui.onClick(p[0], p[1], click.method_74245());
      return true;
   }

   public boolean method_25406(class_11909 click) {
      this.ui.onRelease();
      return true;
   }

   public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
      if (this.ui.drag == null && click.method_74245() == 0 && click.comp_4798() / this.gs > this.winX + 104) {
         this.scrollTarget = this.scrollTarget - offsetY / this.gs;
         this.scroll = this.scrollTarget;
      }

      return true;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.ui.onScroll(verticalAmount);
      return true;
   }

   public boolean method_25404(class_11908 input) {
      int k = input.comp_4795();
      if (this.binding == null) {
         if (this.ui.focus != null) {
            if (k != 256 && k != 257) {
               this.ui.onKey(k);
               return true;
            } else {
               this.ui.focus = null;
               return true;
            }
         } else if (k == 256) {
            if (this.ui.overlayOpen()) {
               this.ui.closeOverlay();
               return true;
            } else if (!this.search.isEmpty()) {
               this.search = "";
               return true;
            } else {
               this.method_25419();
               return true;
            }
         } else if (MrBeanClient.menuKey.method_1417(input)) {
            this.method_25419();
            return true;
         } else {
            return super.method_25404(input);
         }
      } else {
         if (k == 256 || k == 259 || k == 261) {
            this.binding.bind = -1;
         } else if (!MrBeanClient.menuKey.method_1417(input)) {
            this.binding.bind = k;
         }

         Notifications.push(this.binding.name() + ": " + keyName(this.binding.bind), this.binding.bind >= 0);
         this.binding = null;
         Config.markDirty();
         return true;
      }
   }

   public boolean method_25400(class_11905 input) {
      String s = input.method_74226();
      if (this.binding != null) {
         return true;
      } else {
         if (this.ui.focus == null && s != null && !s.isBlank()) {
            this.ui.focus = "rv_search";
         }

         if (s != null) {
            for (char ch : s.toCharArray()) {
               this.ui.onChar(ch);
            }
         }

         return true;
      }
   }

   public void method_25419() {
      if (!this.closing) {
         this.closing = true;
         Sounds.play(Sounds.CLOSE);
         Config.save();
      }
   }

   public void method_25432() {
      Config.save();
   }

   public static void testPage(String key) {
      for (ClickGuiScreen.Page p : ClickGuiScreen.Page.values()) {
         if (p.name().equalsIgnoreCase(key) || p.title.equalsIgnoreCase(key)) {
            page = p;
         }
      }
   }

   public static void testExpand(String id) {
      expanded.add(id);
   }

   private static enum Page {
      VISUALS("Visuals", "◉", Category.VISUALS),
      HUD("HUD", "▣", Category.HUD),
      UTILITIES("Utilities", "✧", Category.UTILITIES),
      PVE("PVE", "⛏", Category.PVE),
      MARKERS("Markers", "◎", Category.MARKERS),
      CRYSTAL("Crystal PvP", "◆", Category.CRYSTAL),
      COSMETICS("Cosmetics", "♛", Category.COSMETICS),
      WORLD("World", "☁", Category.WORLD),
      PARTICLES("Particles", "✦", Category.PARTICLES),
      ANIMATIONS("Animations", "↻", Category.ANIMATIONS),
      PERFORMANCE("Performance", "⚡", Category.PERFORMANCE),
      BINDS("Binds", "⌨", null),
      FRIENDS("Friends", "☺", null),
      CONFIGS("Configs", "☁", null),
      SETTINGS("Settings", "⚙", null);

      final String title;
      final String icon;
      final Category cat;

      private Page(String t, String i, Category c) {
         this.title = t;
         this.icon = i;
         this.cat = c;
      }

      String label() {
         return switch (this) {
            case BINDS -> Lang.t("Бинды", "Binds");
            case FRIENDS -> Lang.t("Друзья", "Friends");
            case CONFIGS -> Lang.t("Конфиги", "Configs");
            case SETTINGS -> Lang.t("Настройки", "Settings");
            default -> this.cat.title();
         };
      }
   }
}
