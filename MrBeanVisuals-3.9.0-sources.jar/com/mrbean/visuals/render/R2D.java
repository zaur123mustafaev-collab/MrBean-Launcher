package com.mrbean.visuals.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mrbean.visuals.module.Modules;
import java.util.HashMap;
import java.util.Map;
import java.util.function.IntBinaryOperator;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_11719.class_11721;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class R2D {
   private static final class_310 mc = class_310.method_1551();
   public static float alpha = 1.0F;
   public static final class_2960 FONT_DEFAULT = class_2960.method_60656("default");
   public static final class_2960 FONT_UNIFORM = class_2960.method_60656("uniform");
   public static class_2960 font = null;
   private static class_2960 circleTex;
   private static class_2960 shadowTex;
   private static final Map<Integer, class_2960> rings = new HashMap<>();
   private static final int T = 128;

   private R2D() {
   }

   public static int argb(int a, int r, int g, int b) {
      return clamp(a) << 24 | clamp(r) << 16 | clamp(g) << 8 | clamp(b);
   }

   private static int clamp(int v) {
      return v < 0 ? 0 : Math.min(255, v);
   }

   public static int withAlpha(int c, int a) {
      return c & 16777215 | clamp(a) << 24;
   }

   public static int mulAlpha(int c, float m) {
      return withAlpha(c, (int)((c >>> 24 & 0xFF) * m));
   }

   public static int a(int c) {
      return alpha >= 0.999F ? c : mulAlpha(c, alpha);
   }

   public static int hsv(float h, float s, float v) {
      return 0xFF000000 | hsbToRgb(h, s, v);
   }

   public static int hsbToRgb(float h, float s, float v) {
      if (s <= 0.0F) {
         int g = (int)(v * 255.0F + 0.5F);
         return g << 16 | g << 8 | g;
      } else {
         float hh = (h - (float)Math.floor(h)) * 6.0F;
         int i = (int)Math.floor(hh);
         float f = hh - i;
         float p = v * (1.0F - s);
         float q = v * (1.0F - s * f);
         float t = v * (1.0F - s * (1.0F - f));
         float r;
         float g;
         float b;
         switch (i) {
            case 0:
               r = v;
               g = t;
               b = p;
               break;
            case 1:
               r = q;
               g = v;
               b = p;
               break;
            case 2:
               r = p;
               g = v;
               b = t;
               break;
            case 3:
               r = p;
               g = q;
               b = v;
               break;
            case 4:
               r = t;
               g = p;
               b = v;
               break;
            default:
               r = v;
               g = p;
               b = q;
         }

         return (int)(r * 255.0F + 0.5F) << 16 | (int)(g * 255.0F + 0.5F) << 8 | (int)(b * 255.0F + 0.5F);
      }
   }

   public static float[] rgbToHsb(int r, int g, int b, float[] out) {
      if (out == null) {
         out = new float[3];
      }

      int max = Math.max(r, Math.max(g, b));
      int min = Math.min(r, Math.min(g, b));
      float v = max / 255.0F;
      float s = max == 0 ? 0.0F : (float)(max - min) / max;
      float h;
      if (s == 0.0F) {
         h = 0.0F;
      } else {
         float rc = (float)(max - r) / (max - min);
         float gc = (float)(max - g) / (max - min);
         float bc = (float)(max - b) / (max - min);
         if (r == max) {
            h = bc - gc;
         } else if (g == max) {
            h = 2.0F + rc - bc;
         } else {
            h = 4.0F + gc - rc;
         }

         h /= 6.0F;
         if (h < 0.0F) {
            h++;
         }
      }

      out[0] = h;
      out[1] = s;
      out[2] = v;
      return out;
   }

   public static int lerp(int c1, int c2, float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      int a1 = c1 >>> 24;
      int r1 = c1 >> 16 & 0xFF;
      int g1 = c1 >> 8 & 0xFF;
      int b1 = c1 & 0xFF;
      int a2 = c2 >>> 24;
      int r2 = c2 >> 16 & 0xFF;
      int g2 = c2 >> 8 & 0xFF;
      int b2 = c2 & 0xFF;
      return argb((int)(a1 + (a2 - a1) * t), (int)(r1 + (r2 - r1) * t), (int)(g1 + (g2 - g1) * t), (int)(b1 + (b2 - b1) * t));
   }

   public static int brighten(int c, float f) {
      return argb(c >>> 24, (int)((c >> 16 & 0xFF) * f), (int)((c >> 8 & 0xFF) * f), (int)((c & 0xFF) * f));
   }

   public static int accent(float off) {
      return Modules.theme().accent(off);
   }

   public static int bg() {
      return Modules.theme().background();
   }

   public static int panel() {
      return Modules.theme().panel();
   }

   private static class_2960 make(String name, IntBinaryOperator alphaFn) {
      class_1011 img = new class_1011(128, 128, false);

      for (int y = 0; y < 128; y++) {
         for (int x = 0; x < 128; x++) {
            img.method_61941(x, y, alphaFn.applyAsInt(x, y) << 24 | 16777215);
         }
      }

      class_2960 id = class_2960.method_60655("mrbeanvisuals", "dyn/" + name);
      mc.method_1531().method_4616(id, new R2D.LinearTexture(name, img));
      return id;
   }

   private static class_2960 circle() {
      if (circleTex == null) {
         circleTex = make("circle", (x, y) -> {
            double dx = x + 0.5 - 64.0;
            double dy = y + 0.5 - 64.0;
            double d = Math.sqrt(dx * dx + dy * dy);
            double a = Math.max(0.0, Math.min(1.0, 64.0 - d + 0.5));
            return (int)(a * 255.0);
         });
      }

      return circleTex;
   }

   private static class_2960 shadow() {
      if (shadowTex == null) {
         shadowTex = make("shadow", (x, y) -> {
            double dx = (x + 0.5 - 64.0) / 64.0;
            double dy = (y + 0.5 - 64.0) / 64.0;
            double d = Math.sqrt(dx * dx + dy * dy);
            double a = Math.max(0.0, 1.0 - d);
            a = a * a * (3.0 - 2.0 * a);
            return (int)(a * 255.0);
         });
      }

      return shadowTex;
   }

   private static class_2960 ring(int r) {
      return rings.computeIfAbsent(r, rr -> make("ring" + rr, (x, y) -> {
         double dx = x + 0.5 - 64.0;
         double dy = y + 0.5 - 64.0;
         double d = Math.sqrt(dx * dx + dy * dy);
         double outer = 64.0;
         double inner = outer - 64.0 / rr.intValue();
         double a = Math.max(0.0, Math.min(1.0, outer - d + 0.5)) * Math.max(0.0, Math.min(1.0, d - inner + 0.5));
         return (int)(a * 255.0);
      }));
   }

   private static void quad(class_332 ctx, class_2960 tex, int x, int y, int w, int h, int u, int v, int rw, int rh, int color) {
      if (w > 0 && h > 0) {
         ctx.method_25293(class_10799.field_56883, tex, x, y, u, v, w, h, rw, rh, 128, 128, color);
      }
   }

   /** Картинка из произвольной живой текстуры (скриншоты, обложки). */
   public static void picture(class_332 ctx, class_2960 tex, int x, int y, int w, int h, int texW, int texH, int color) {
      if (w > 0 && h > 0 && tex != null && texW > 0 && texH > 0) {
         ctx.method_25291(class_10799.field_56883, tex, x, y, 0.0F, 0.0F, w, h, texW, texH, color);
      }
   }

   public static void rect(class_332 ctx, int x, int y, int w, int h, int color) {
      if (w > 0 && h > 0) {
         ctx.method_25294(x, y, x + w, y + h, a(color));
      }
   }

   public static void round(class_332 ctx, int x, int y, int w, int h, int r, int color) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
         int c = a(color);
         if (c >>> 24 != 0) {
            if (r == 0) {
               ctx.method_25294(x, y, x + w, y + h, c);
            } else {
               class_2960 t = circle();
               int H = 64;
               quad(ctx, t, x, y, r, r, 0, 0, H, H, c);
               quad(ctx, t, x + w - r, y, r, r, H, 0, H, H, c);
               quad(ctx, t, x, y + h - r, r, r, 0, H, H, H, c);
               quad(ctx, t, x + w - r, y + h - r, r, r, H, H, H, H, c);
               ctx.method_25294(x + r, y, x + w - r, y + r, c);
               ctx.method_25294(x, y + r, x + w, y + h - r, c);
               ctx.method_25294(x + r, y + h - r, x + w - r, y + h, c);
            }
         }
      }
   }

   public static void outline(class_332 ctx, int x, int y, int w, int h, int r, int color) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
         int c = a(color);
         if (r <= 1) {
            ctx.method_73198(x, y, w, h, c);
         } else {
            class_2960 t = ring(r);
            int H = 64;
            quad(ctx, t, x, y, r, r, 0, 0, H, H, c);
            quad(ctx, t, x + w - r, y, r, r, H, 0, H, H, c);
            quad(ctx, t, x, y + h - r, r, r, 0, H, H, H, c);
            quad(ctx, t, x + w - r, y + h - r, r, r, H, H, H, H, c);
            ctx.method_25294(x + r, y, x + w - r, y + 1, c);
            ctx.method_25294(x + r, y + h - 1, x + w - r, y + h, c);
            ctx.method_25294(x, y + r, x + 1, y + h - r, c);
            ctx.method_25294(x + w - 1, y + r, x + w, y + h - r, c);
         }
      }
   }

   public static void shadow(class_332 ctx, int x, int y, int w, int h, int size, int color) {
      if (size > 0) {
         int c = a(color);
         class_2960 t = shadow();
         int H = 64;
         int x0 = x - size;
         int y0 = y - size;
         int s2 = size * 2;
         quad(ctx, t, x0, y0, s2, s2, 0, 0, H, H, c);
         quad(ctx, t, x + w - size, y0, s2, s2, H, 0, H, H, c);
         quad(ctx, t, x0, y + h - size, s2, s2, 0, H, H, H, c);
         quad(ctx, t, x + w - size, y + h - size, s2, s2, H, H, H, H, c);
         int midW = w - s2;
         int midH = h - s2;
         if (midW > 0) {
            quad(ctx, t, x + size, y0, midW, s2, H - 1, 0, 2, H, c);
            quad(ctx, t, x + size, y + h - size, midW, s2, H - 1, H, 2, H, c);
         }

         if (midH > 0) {
            quad(ctx, t, x0, y + size, s2, midH, 0, H - 1, H, 2, c);
            quad(ctx, t, x + w - size, y + size, s2, midH, H, H - 1, H, 2, c);
         }

         if (midW > 0 && midH > 0) {
            ctx.method_25294(x + size, y + size, x + w - size, y + h - size, c);
         }
      }
   }

   public static void circle(class_332 ctx, int cx, int cy, int r, int color) {
      quad(ctx, circle(), cx - r, cy - r, r * 2, r * 2, 0, 0, 128, 128, a(color));
   }

   public static void ringCircle(class_332 ctx, int cx, int cy, int r, int color) {
      quad(ctx, ring(Math.max(2, r)), cx - r, cy - r, r * 2, r * 2, 0, 0, 128, 128, a(color));
   }

   public static void hGradient(class_332 ctx, int x, int y, int w, int h, int c1, int c2) {
      int step = Math.max(1, w / 48);

      for (int i = 0; i < w; i += step) {
         ctx.method_25294(x + i, y, x + Math.min(w, i + step), y + h, a(lerp(c1, c2, (float)i / Math.max(1, w))));
      }
   }

   public static void accentBar(class_332 ctx, int x, int y, int w, int h) {
      int step = Math.max(1, w / 40);

      for (int i = 0; i < w; i += step) {
         ctx.method_25294(x + i, y, x + Math.min(w, i + step), y + h, a(accent((float)i / Math.max(1, w) * 0.6F)));
      }
   }

   public static void panel(class_332 ctx, int x, int y, int w, int h, int r, int bgColor, boolean shadow, int border) {
      if (shadow && Modules.theme().shadows.value) {
         shadow(ctx, x, y + 2, w, h, 8, 1342177280);
      }

      round(ctx, x, y, w, h, r, bgColor);
      if (border >>> 24 != 0) {
         outline(ctx, x, y, w, h, r, border);
      }
   }

   public static class_327 tr() {
      return mc.field_1772;
   }

   private static class_2561 styled(String s) {
      class_2561 t = class_2561.method_43470(s);
      if (font != null) {
         t = class_2561.method_43470(s).method_10862(class_2583.field_24360.method_27704(new class_11721(font)));
      }

      return t;
   }

   public static int width(String s) {
      return font == null ? tr().method_1727(s) : tr().method_27525(styled(s));
   }

   public static void text(class_332 ctx, String s, int x, int y, int color) {
      text(ctx, s, x, y, color, true);
   }

   public static void text(class_332 ctx, String s, int x, int y, int color, boolean shadow) {
      int c = a(color);
      if (c >>> 24 >= 5) {
         if (font == null) {
            ctx.method_51433(tr(), s, x, y, c, shadow);
         } else {
            ctx.method_51439(tr(), styled(s), x, y, c, shadow);
         }
      }
   }

   public static void centered(class_332 ctx, String s, int cx, int y, int color) {
      text(ctx, s, cx - width(s) / 2, y, color, true);
   }

   public static int gradientText(class_332 ctx, String s, int x, int y, float spread, boolean shadow) {
      int cx = x;

      for (int i = 0; i < s.length(); i++) {
         String ch = String.valueOf(s.charAt(i));
         text(ctx, ch, cx, y, accent(i * spread), shadow);
         cx += width(ch);
      }

      return cx - x;
   }

   public static void textScaled(class_332 ctx, String s, float x, float y, float scale, int color, boolean shadow) {
      ctx.method_51448().pushMatrix();
      ctx.method_51448().translate(x, y);
      ctx.method_51448().scale(scale, scale);
      text(ctx, s, 0, 0, color, shadow);
      ctx.method_51448().popMatrix();
   }

   public static void bean(class_332 ctx, int x, int y, int size) {
      int r = size / 2;
      circle(ctx, x + r, y + r + 1, r, accent(0.0F));
      circle(ctx, x + r + r / 3, y + r - r / 3, Math.max(1, r * 2 / 3), accent(0.3F));
      circle(ctx, x + r - r / 4, y + r + r / 4, Math.max(1, r / 3), -15724268);
      circle(ctx, x + r + r / 2, y + r / 2 + 1, Math.max(1, r / 5), -570425345);
   }

   public static int healthColor(float frac) {
      return hsv(Math.max(0.0F, Math.min(1.0F, frac)) / 3.0F, 0.7F, 1.0F);
   }

   public static float approach(float cur, float target, float speed) {
      if (!Modules.theme().animations.value) {
         return target;
      } else {
         float d = target - cur;
         return Math.abs(d) < 0.002F ? target : cur + d * Math.min(1.0F, speed * mc.method_61966().method_60636());
      }
   }

   public static boolean inside(double mx, double my, int x, int y, int w, int h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   private static final class LinearTexture extends class_1043 {
      LinearTexture(String name, class_1011 img) {
         super(() -> name, img);
         this.field_63613 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
      }
   }
}
