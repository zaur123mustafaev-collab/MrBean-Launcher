package com.mrbean.visuals.module.hud;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.render.R2D;
import com.mrbean.visuals.util.ChromeMedia;
import com.mrbean.visuals.util.Info;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.io.File;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1702;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_5321;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

public final class HudElements {
   private HudElements() {
   }

   public static void registerAll() {
      Modules.reg(new HudElements.Watermark());
      Modules.reg(new HudElements.ArrayListHud());
      Modules.reg(new HudElements.Coords());
      Modules.reg(new HudElements.Compass());
      Modules.reg(new HudElements.Keystrokes());
      Modules.reg(new HudElements.Armor());
      Modules.reg(new HudElements.Potions());
      Modules.reg(new HudElements.TargetHud());
      Modules.reg(new HudElements.ItemCounter());
      Modules.reg(new HudElements.ItemDurability());
      Modules.reg(new HudElements.InventoryHud());
      Modules.reg(new HudElements.Equipment());
      Modules.reg(new HudElements.Fps());
      Modules.reg(new HudElements.Ping());
      Modules.reg(new HudElements.Cps());
      Modules.reg(new HudElements.Speed());
      Modules.reg(new HudElements.Clock());
      Modules.reg(new HudElements.SessionTimer());
      Modules.reg(new HudElements.Memory());
      Modules.reg(new HudElements.Cpu());
      Modules.reg(new HudElements.Gpu());
      Modules.reg(new HudElements.Biome());
      Modules.reg(new HudElements.ServerInfoHud());
      Modules.reg(new HudElements.Music());
      Modules.reg(new HudElements.Browser());
      Modules.reg(new HudElements.Combo());
      Modules.reg(new HudElements.ReachDisplay());
      Modules.reg(new HudElements.LightLevel());
      Modules.reg(new HudElements.DayCounter());
      Modules.reg(new HudElements.DeathPoint());
      Modules.reg(new HudElements.Hunger());
      Modules.reg(new HudElements.ActionBar());
      MrBeanClient.LOG.debug("HUD elements registered");
   }

   public static class ActionBar extends HudModule {
      public static class_2561 message;
      public static int remaining;

      public ActionBar() {
         super(
            "action_bar",
            false,
            0.5,
            0.78,
            "Панель действий",
            "Action Bar",
            "Сообщения над хотбаром в своём стиле и месте",
            "Action bar messages, restyled and movable"
         );
      }

      @Override
      protected void layout() {
         class_2561 m = this.msg();
         this.w = Math.max(40, mc.field_1772.method_27525(m) + 4);
         this.h = 9;
      }

      private class_2561 msg() {
         return (class_2561)(message != null ? message : class_2561.method_43470(editing ? Lang.t("Сообщение панели действий", "Action bar message") : ""));
      }

      @Override
      protected boolean hasContent() {
         return message != null && remaining > 0;
      }

      @Override
      public void onTick() {
         if (remaining > 0) {
            remaining--;
         }
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         float fade = remaining > 20 ? 1.0F : remaining / 20.0F;
         float a = R2D.alpha;
         if (!editing) {
            R2D.alpha *= fade;
         }

         ctx.method_51439(mc.field_1772, this.msg(), 2, 0, R2D.a(-1), this.ts());
         R2D.alpha = a;
      }
   }

   public static class Armor extends HudModule {
      final Setting.Mode layout = this.add(new Setting.Mode("layout", "Вид", "Layout", 0, "h", "Горизонтально", "Horizontal", "v", "Вертикально", "Vertical"));
      final Setting.Mode dura = this.add(
         new Setting.Mode("durability", "Прочность", "Durability", 0, "pct", "Проценты", "Percent", "num", "Числом", "Number", "none", "Нет", "None")
      );
      final Setting.Bool hands = this.add(new Setting.Bool("hands", "Предметы в руках", "Held items", true));
      final Setting.Bool warn = this.add(new Setting.Bool("warn", "Предупреждение о низкой прочности", "Low durability warning", true));
      final Setting.Num warnLevel = (Setting.Num)this.add(new Setting.Num("warn_level", "Предупреждать ниже", "Warn below", 20.0, 5.0, 60.0, 5.0).suffix("%"))
         .showIf(() -> this.warn.value);
      final Setting.Bool blink = (Setting.Bool)this.add(new Setting.Bool("warn_blink", "Мигание", "Blink", true)).showIf(() -> this.warn.value);
      private final List<class_1799> stacks = new ArrayList<>();

      public Armor() {
         super("armor", true, 0.66, 1.0, "Статус брони", "Armor Status", "Броня и её прочность", "Armor with durability");
         this.background.value = false;
      }

      @Override
      protected void layout() {
         this.stacks.clear();
         if (mc.field_1724 != null) {
            for (class_1304 s : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
               class_1799 st = mc.field_1724.method_6118(s);
               if (!st.method_7960()) {
                  this.stacks.add(st);
               }
            }

            if (this.hands.value) {
               if (!mc.field_1724.method_6047().method_7960()) {
                  this.stacks.add(mc.field_1724.method_6047());
               }

               if (!mc.field_1724.method_6079().method_7960()) {
                  this.stacks.add(mc.field_1724.method_6079());
               }
            }
         }

         if (this.stacks.isEmpty() && editing) {
            this.stacks.add(new class_1799(class_1802.field_8805));
            this.stacks.add(new class_1799(class_1802.field_8058));
         }

         boolean hz = this.layout.is("h");
         this.w = hz ? Math.max(18, this.stacks.size() * 20) : 52;
         this.h = hz ? 24 : Math.max(18, this.stacks.size() * 18);
      }

      @Override
      protected boolean hasContent() {
         return !this.stacks.isEmpty() || mc.field_1724 != null && !mc.field_1724.method_6118(class_1304.field_6174).method_7960();
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         boolean hz = this.layout.is("h");

         for (int i = 0; i < this.stacks.size(); i++) {
            class_1799 st = this.stacks.get(i);
            int x = hz ? i * 20 + 1 : 0;
            int y = hz ? 0 : i * 18;
            float frac = st.method_7963() ? 1.0F - (float)st.method_7919() / (float)st.method_7936() : 1.0F;
            boolean low = this.warn.value && st.method_7963() && frac * 100.0F <= this.warnLevel.value;
            int pulse = low
               ? this.blink.value
                  ? (int)(100.0F + 100.0F * ((float)Math.sin(System.currentTimeMillis() / 140.0) + 1.0F) / 2.0F)
                  : 170
               : 255;
            if (low) {
               R2D.round(ctx, x - 1, y - 1, 18, 18, 3, R2D.withAlpha(0xFF4444, pulse / 3));
               R2D.outline(ctx, x - 1, y - 1, 18, 18, 3, R2D.withAlpha(0xFF4444, pulse));
            }

            ctx.method_51427(st, x, y);
            ctx.method_51431(mc.field_1772, st, x, y);
            if (st.method_7963() && !this.dura.is("none")) {
               String t = this.dura.is("pct") ? Math.round(frac * 100.0F) + "%" : String.valueOf(st.method_7936() - st.method_7919());
               int c = low ? R2D.withAlpha(R2D.healthColor(frac), pulse) : R2D.healthColor(frac);
               if (hz) {
                  R2D.textScaled(ctx, t, x + 8 - this.tw(t) * 0.3F, y + 17, 0.6F, c, this.ts());
               } else {
                  this.text(ctx, t, x + 20, y + 5, c);
               }
            }
         }
      }
   }

   public static class ArrayListHud extends HudModule {
      final Setting.Bool lines = this.add(new Setting.Bool("lines", "Боковая линия", "Side line", true));
      final Setting.Bool compact = this.add(new Setting.Bool("compact", "Скрывать служебные модули", "Hide utility modules", true));
      private static final Set<String> UTILITY = Set.of(
         "inventory_anim",
         "smooth_perspective",
         "no_hurt_cam",
         "warnings",
         "custom_tooltip",
         "smooth_chat",
         "low_fire",
         "hitmarker",
         "macros",
         "auto_sprint",
         "zoom",
         "item_switch",
         "eat_animation"
      );
      private final List<Module> on = new ArrayList<>();

      public ArrayListHud() {
         super("array_list", true, 1.0, 0.01, "Список модулей", "Module List", "Показывает включённые модули", "Shows enabled modules");
         this.background.value = false;
      }

      @Override
      protected void layout() {
         this.on.clear();

         for (Module m : Modules.all()) {
            m.anim = R2D.approach(m.anim, m.isEnabled() ? 1.0F : 0.0F, 0.25F);
            if (m.anim > 0.02F && m.showInArray() && !(m instanceof HudModule) && (!this.compact.value || !UTILITY.contains(m.id))) {
               this.on.add(m);
            }
         }

         this.on.sort(Comparator.comparingInt(mx -> -this.tw(mx.name())));
         this.w = 40;

         for (Module mx : this.on) {
            this.w = Math.max(this.w, this.tw(mx.name()) + 8);
         }

         this.h = Math.max(11, (int)this.on.stream().mapToDouble(mx -> 11.0F * mx.anim).sum());
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         boolean right = this.fx > 0.5;
         float y = 0.0F;
         int i = 0;

         for (Module m : this.on) {
            int mw = this.tw(m.name()) + 8;
            int x = right ? (int)(this.w - mw * m.anim) : (int)(-mw * (1.0F - m.anim));
            int yy = (int)y;
            float oldA = R2D.alpha;
            R2D.alpha = R2D.alpha * m.anim;
            R2D.rect(ctx, x, yy, mw, 11, R2D.bg());
            int c = this.accent(i * 0.07F);
            if (this.lines.value) {
               R2D.rect(ctx, right ? x + mw - 1 : x, yy, 1, 11, c);
            }

            this.text(ctx, m.name(), x + 4, yy + 2, c);
            R2D.alpha = oldA;
            y += 11.0F * m.anim;
            i++;
         }
      }
   }

   public static class Biome extends HudElements.Info1 {
      public Biome() {
         super("biome", false, 0.005, 0.54, "Биом", "Biome", "Текущий биом", "Current biome");
      }

      @Override
      protected String label() {
         return Lang.t("Биом", "Biome");
      }

      @Override
      protected String value() {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            Optional<class_5321<net.minecraft.class_1959>> key = mc.field_1687.method_23753(mc.field_1724.method_24515()).method_40230();
            if (key.isEmpty()) {
               return "?";
            } else {
               class_2960 id = key.get().method_29177();
               return class_2561.method_43471("biome." + id.method_12836() + "." + id.method_12832()).getString();
            }
         } else {
            return "—";
         }
      }
   }

   public static class Clock extends HudElements.Info1 {
      final Setting.Bool seconds = this.add(new Setting.Bool("seconds", "Секунды", "Seconds", false));
      final Setting.Bool h12 = this.add(new Setting.Bool("h12", "12-часовой формат", "12-hour format", false));

      public Clock() {
         super("clock", false, 0.005, 0.34, "Часы", "Clock", "Реальное время", "Real-world time");
      }

      @Override
      protected String label() {
         return "⌚";
      }

      @Override
      protected String value() {
         String p = (this.h12.value ? "hh" : "HH") + ":mm" + (this.seconds.value ? ":ss" : "") + (this.h12.value ? " a" : "");
         return LocalTime.now().format(DateTimeFormatter.ofPattern(p));
      }
   }

   public static class Combo extends HudElements.Info1 {
      public Combo() {
         super("combo", true, 0.005, 0.62, "Комбо", "Combo Counter", "Удары подряд без получения урона", "Hits in a row without taking damage");
      }

      @Override
      protected String label() {
         return Lang.t("Комбо", "Combo");
      }

      @Override
      protected String value() {
         return Info.combo == 0 ? "—" : Info.combo + "x";
      }
   }

   public static class Compass extends HudModule {
      final Setting.Num width = this.add(new Setting.Num("width", "Ширина", "Width", 160.0, 80.0, 300.0, 10.0));

      public Compass() {
         super("compass", false, 0.5, 0.0, "Компас", "Direction Compass", "Лента сторон света вверху экрана", "Heading strip at the top of the screen");
      }

      @Override
      protected void layout() {
         this.w = this.width.i();
         this.h = 14;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         float yaw = mc.field_1724 == null ? 0.0F : (mc.field_1724.method_5705(d) % 360.0F + 360.0F) % 360.0F;
         String[] names = Lang.english ? new String[]{"S", "SW", "W", "NW", "N", "NE", "E", "SE"} : new String[]{"Ю", "ЮЗ", "З", "СЗ", "С", "СВ", "В", "ЮВ"};
         float pxPerDeg = 1.4F;
         ctx.method_44379(0, 0, this.w, this.h);

         for (int deg = -180; deg <= 540; deg += 15) {
            float x = this.w / 2.0F + (deg - yaw) * pxPerDeg;
            if (!(x < -10.0F) && !(x > this.w + 10)) {
               int dd = (deg % 360 + 360) % 360;
               if (dd % 45 == 0) {
                  String n = names[dd / 45];
                  boolean main = dd % 90 == 0;
                  this.text(ctx, n, (int)x - this.tw(n) / 2, 3, main ? (dd == 180 ? -42396 : -1) : -5196608);
               } else {
                  R2D.rect(ctx, (int)x, 6, 1, 3, -2130706433);
               }
            }
         }

         ctx.method_44380();
         R2D.rect(ctx, this.w / 2, 0, 1, 2, this.accent(0.0F));
         R2D.rect(ctx, this.w / 2, this.h - 2, 1, 2, this.accent(0.0F));
      }
   }

   public static class Coords extends HudModule {
      final Setting.Bool nether = this.add(new Setting.Bool("nether", "Координаты Ада/мира", "Nether/overworld coords", true));
      final Setting.Bool direction = this.add(new Setting.Bool("direction", "Направление", "Direction", true));
      private final List<String> lines = new ArrayList<>();

      public Coords() {
         super("coords", true, 0.005, 0.06, "Координаты", "Coordinates", "XYZ, направление и пересчёт для Ада", "XYZ, facing and Nether conversion");
      }

      @Override
      protected void layout() {
         this.lines.clear();
         class_746 p = mc.field_1724;
         if (p == null) {
            this.lines.add("XYZ 0 0 0");
         } else {
            this.lines.add(String.format("XYZ §f%d %d %d", p.method_31477(), p.method_31478(), p.method_31479()));
            if (this.direction.value) {
               String d = switch (p.method_5735()) {
                  case field_11043 -> Lang.t("Север -Z", "North -Z");
                  case field_11035 -> Lang.t("Юг +Z", "South +Z");
                  case field_11039 -> Lang.t("Запад -X", "West -X");
                  case field_11034 -> Lang.t("Восток +X", "East +X");
                  default -> "";
               };
               this.lines.add(Lang.t("Смотрю §f", "Facing §f") + d);
            }

            if (this.nether.value && mc.field_1687 != null) {
               boolean inNether = mc.field_1687.method_27983() == class_1937.field_25180;
               double k = inNether ? 8.0 : 0.125;
               this.lines
                  .add(
                     (inNether ? Lang.t("Мир §f", "Overworld §f") : Lang.t("Ад §f", "Nether §f"))
                        + (int)Math.floor(p.method_23317() * k)
                        + " "
                        + (int)Math.floor(p.method_23321() * k)
                  );
            }
         }

         this.w = 0;

         for (String l : this.lines) {
            this.w = Math.max(this.w, this.tw(l));
         }

         this.w += 2;
         this.h = this.lines.size() * 10 - 1;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         for (int i = 0; i < this.lines.size(); i++) {
            this.text(ctx, "§7" + this.lines.get(i), 1, i * 10, this.accent(i * 0.1F));
         }
      }
   }

   public static class Cps extends HudElements.Info1 {
      public Cps() {
         super("cps", false, 0.005, 0.26, "CPS", "CPS", "Клики в секунду", "Clicks per second");
      }

      @Override
      protected String label() {
         return "CPS";
      }

      @Override
      protected String value() {
         return Info.cpsLeft() + " | " + Info.cpsRight();
      }
   }

   public static class Cpu extends HudElements.Info1 {
      public Cpu() {
         super("cpu", false, 0.005, 0.46, "Процессор", "CPU Usage", "Загрузка процессора игрой", "CPU load of the game");
      }

      @Override
      protected String label() {
         return "CPU";
      }

      @Override
      protected String value() {
         double c = Info.cpu();
         return c < 0.0 ? "—" : Math.round(c * 100.0) + "%";
      }
   }

   public static class DayCounter extends HudElements.Info1 {
      public DayCounter() {
         super("day_counter", false, 0.005, 0.74, "День мира", "World Day", "Номер дня и время в игре", "Day number and in-game time");
      }

      @Override
      protected String label() {
         return Lang.t("День", "Day");
      }

      @Override
      protected String value() {
         if (mc.field_1687 == null) {
            return "—";
         } else {
            long t = mc.field_1687.method_8532();
            long tod = t % 24000L;
            int hh = (int)((tod / 1000L + 6L) % 24L);
            int mm = (int)(tod % 1000L * 60L / 1000L);
            return t / 24000L + String.format(" §7%02d:%02d", hh, mm);
         }
      }
   }

   public static class DeathPoint extends HudElements.Info1 {
      public DeathPoint() {
         super("death_coords", true, 0.005, 0.78, "Точка смерти", "Death Point", "Запоминает, где ты умер", "Remembers where you died");
      }

      @Override
      protected String label() {
         return "☠";
      }

      @Override
      protected String value() {
         return Info.deathPos == null ? "—" : Info.deathPos;
      }

      @Override
      protected boolean hasContent() {
         return Info.deathPos != null;
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null && !mc.field_1724.method_29504() && Info.deathPos != null && !Info.deathAnnounced) {
            mc.field_1724.method_7353(class_2561.method_43470(Lang.t("§a[MrBean] §fТы умер на: §e", "§a[MrBean] §fYou died at: §e") + Info.deathPos), false);
            Info.deathAnnounced = true;
         }
      }
   }

   public static class Equipment extends HudModule {
      public Equipment() {
         super("equipment", false, 0.36, 1.0, "Снаряжение", "Equipment HUD", "Предметы в обеих руках крупно", "Both held items, larger");
         this.background.value = true;
      }

      @Override
      protected void layout() {
         this.w = 40;
         this.h = 18;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         if (mc.field_1724 != null) {
            class_1799 a = mc.field_1724.method_6047();
            class_1799 b = mc.field_1724.method_6079();
            ctx.method_51427(a, 1, 1);
            ctx.method_51431(mc.field_1772, a, 1, 1);
            ctx.method_51427(b, 22, 1);
            ctx.method_51431(mc.field_1772, b, 22, 1);
            R2D.rect(ctx, 19, 3, 1, 12, 1358954495);
         }
      }
   }

   public static class Fps extends HudElements.Info1 {
      public Fps() {
         super("fps", true, 0.005, 0.18, "FPS", "FPS", "Кадры в секунду", "Frames per second");
      }

      @Override
      protected String label() {
         return "FPS";
      }

      @Override
      protected String value() {
         return String.valueOf(mc.method_47599());
      }
   }

   public static class Gpu extends HudElements.Info1 {
      public Gpu() {
         super("gpu", false, 0.005, 0.5, "Видеокарта", "GPU Info", "Модель видеокарты", "Graphics card model");
      }

      @Override
      protected String label() {
         return "GPU";
      }

      @Override
      protected String value() {
         String g = Info.gpu();
         return g.length() > 40 ? g.substring(0, 40) + "…" : g;
      }
   }

   public static class Hunger extends HudElements.Info1 {
      public Hunger() {
         super("hunger", false, 0.005, 0.82, "Сытость", "Hunger", "Еда и скрытая насыщенность", "Food and hidden saturation");
      }

      @Override
      protected String label() {
         return "♨";
      }

      @Override
      protected String value() {
         if (mc.field_1724 == null) {
            return "—";
         } else {
            class_1702 hm = mc.field_1724.method_7344();
            return hm.method_7586() + Lang.t(" §7насыщ. ", " §7sat. ") + String.format("%.1f", hm.method_7589());
         }
      }
   }

   public abstract static class Info1 extends HudModule {
      protected final Setting.Bool showLabel = this.add(new Setting.Bool("show_label", "Показывать подпись", "Show label", true));
      private String l;
      private String v;

      Info1(String id, boolean on, double fx, double fy, String ru, String en, String dRu, String dEn) {
         super(id, on, fx, fy, ru, en, dRu, dEn);
      }

      protected abstract String label();

      protected abstract String value();

      @Override
      protected void layout() {
         this.l = this.showLabel.value ? this.label() + " " : "";
         this.v = this.value();
         this.w = this.tw(this.l) + this.tw(this.v) + (this.background.value ? 4 : 0);
         this.h = 9;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         int x = this.background.value ? 2 : 0;
         if (!this.l.isEmpty()) {
            this.text(ctx, this.l, x, 1, this.accent(0.0F));
         }

         this.text(ctx, this.v, x + this.tw(this.l), 1, -1);
      }
   }

   public static class InventoryHud extends HudModule {
      public InventoryHud() {
         super("inventory_hud", false, 1.0, 0.75, "Инвентарь", "Inventory HUD", "Показывает содержимое инвентаря", "Shows your inventory contents");
      }

      @Override
      protected void layout() {
         this.w = 162;
         this.h = 54;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         if (mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();

            for (int i = 0; i < 27; i++) {
               int x = i % 9 * 18;
               int y = i / 9 * 18;
               R2D.round(ctx, x + 1, y + 1, 16, 16, 2, 822083583);
               class_1799 st = inv.method_5438(9 + i);
               if (!st.method_7960()) {
                  ctx.method_51427(st, x + 1, y + 1);
                  ctx.method_51431(mc.field_1772, st, x + 1, y + 1);
               }
            }
         }
      }
   }

   public static class ItemCounter extends HudModule {
      final Setting.Bool hideZero = this.add(new Setting.Bool("hide_zero", "Скрывать нули", "Hide zeros", false));
      private static final class_1792[] ITEMS = new class_1792[]{
         class_1802.field_8288,
         class_1802.field_8634,
         class_1802.field_8463,
         class_1802.field_8367,
         class_1802.field_8287,
         class_1802.field_8107,
         class_1802.field_8301,
         class_1802.field_8281,
         class_1802.field_8786,
         class_1802.field_49098
      };
      private final List<class_1792> shown = new ArrayList<>();
      private final int[] counts = new int[ITEMS.length];

      public ItemCounter() {
         super(
            "item_counter",
            true,
            0.36,
            0.86,
            "Счётчик предметов",
            "Item Counter",
            "Тотемы, перлы, яблоки, пузырьки опыта…",
            "Totems, pearls, apples, XP bottles…"
         );
         this.background.value = false;
      }

      @Override
      protected void layout() {
         this.shown.clear();
         if (mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();

            for (int k = 0; k < ITEMS.length; k++) {
               int c = 0;

               for (int i = 0; i < inv.method_5439(); i++) {
                  class_1799 s = inv.method_5438(i);
                  if (s.method_31574(ITEMS[k])) {
                     c += s.method_7947();
                  }
               }

               this.counts[k] = c;
               boolean optional = k >= 6;
               if (c != 0 || !this.hideZero.value && !optional) {
                  this.shown.add(ITEMS[k]);
               }
            }
         }

         this.w = Math.max(18, this.shown.size() * 18);
         this.h = 18;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         int x = 0;

         for (class_1792 it : this.shown) {
            int c = this.counts[Arrays.asList(ITEMS).indexOf(it)];
            ctx.method_51427(new class_1799(it), x, 0);
            String t = String.valueOf(c);
            int col = c == 0 ? -42396 : (it == class_1802.field_8288 && c < 2 ? -22016 : -1);
            R2D.text(ctx, t, x + 17 - this.tw(t), 9, col, true);
            x += 18;
         }
      }
   }

   public static class ItemDurability extends HudModule {
      public ItemDurability() {
         super(
            "item_durability",
            false,
            0.62,
            0.9,
            "Прочность предмета",
            "Item Durability",
            "Прочность предмета в руке с полоской",
            "Held item durability with bar"
         );
      }

      @Override
      protected void layout() {
         this.w = 90;
         this.h = 18;
      }

      @Override
      protected boolean hasContent() {
         return mc.field_1724 != null && mc.field_1724.method_6047().method_7963();
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         class_1799 st = mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
         if (st.method_7960() && editing) {
            st = new class_1799(class_1802.field_8377);
         }

         ctx.method_51427(st, 0, 1);
         if (st.method_7963()) {
            int left = st.method_7936() - st.method_7919();
            float frac = (float)left / st.method_7936();
            this.text(ctx, left + "/" + st.method_7936(), 20, 1, -1);
            R2D.round(ctx, 20, 12, 68, 3, 1, 1610612736);
            R2D.round(ctx, 20, 12, Math.max(2, (int)(68.0F * frac)), 3, 1, R2D.healthColor(frac));
         }
      }
   }

   public static class Keystrokes extends HudModule {
      final Setting.Bool mouse = this.add(new Setting.Bool("mouse", "Кнопки мыши", "Mouse buttons", true));
      final Setting.Bool space = this.add(new Setting.Bool("space", "Пробел", "Space bar", true));
      final Setting.Bool cps = this.add(new Setting.Bool("cps", "CPS на кнопках", "CPS on buttons", true));
      private final float[] anim = new float[7];

      public Keystrokes() {
         super("keystrokes", true, 1.0, 0.62, "Клавиши", "Keystrokes", "WASD, мышь и пробел с подсветкой", "WASD, mouse and space with highlights");
         this.background.value = false;
      }

      @Override
      protected void layout() {
         this.w = 64;
         this.h = 42 + (this.mouse.value ? 20 : 0) + (this.space.value ? 12 : 0);
      }

      private void key(class_332 ctx, int i, int x, int y, int kw, int kh, String label, boolean down) {
         this.anim[i] = R2D.approach(this.anim[i], down ? 1.0F : 0.0F, 0.45F);
         int col = R2D.lerp(R2D.bg(), R2D.withAlpha(this.accent(i * 0.1F), 230), this.anim[i]);
         R2D.round(ctx, x, y, kw, kh, Math.min(4, this.radius.i() + 1), col);
         int tc = R2D.lerp(-1, -15724528, this.anim[i]);
         R2D.text(ctx, label, x + kw / 2 - this.tw(label) / 2, y + kh / 2 - 4, tc, this.ts() && this.anim[i] < 0.5F);
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         class_315 o = mc.field_1690;
         int s = 20;
         int g = 2;
         boolean ed = editing;
         this.key(ctx, 0, s + g, 0, s, s, "W", !ed && o.field_1894.method_1434());
         this.key(ctx, 1, 0, s + g, s, s, "A", !ed && o.field_1913.method_1434());
         this.key(ctx, 2, s + g, s + g, s, s, "S", !ed && o.field_1881.method_1434());
         this.key(ctx, 3, 2 * (s + g), s + g, s, s, "D", !ed && o.field_1849.method_1434());
         int y = 2 * (s + g);
         if (this.mouse.value) {
            int half = (this.w - g) / 2;
            long win = mc.method_22683().method_4490();
            boolean l = !ed && mc.field_1755 == null && GLFW.glfwGetMouseButton(win, 0) == 1;
            boolean r = !ed && mc.field_1755 == null && GLFW.glfwGetMouseButton(win, 1) == 1;
            this.key(ctx, 4, 0, y, half, 18, Lang.t("ЛКМ", "LMB") + (this.cps.value ? " " + Info.cpsLeft() : ""), l);
            this.key(ctx, 5, half + g, y, half, 18, Lang.t("ПКМ", "RMB") + (this.cps.value ? " " + Info.cpsRight() : ""), r);
            y += 20;
         }

         if (this.space.value) {
            this.key(ctx, 6, 0, y, this.w, 10, "▬▬▬", !ed && o.field_1903.method_1434());
         }
      }
   }

   public static class LightLevel extends HudElements.Info1 {
      public LightLevel() {
         super("light_level", false, 0.005, 0.7, "Уровень света", "Light Level", "Свет под ногами — спавнятся ли мобы", "Light at your feet — can mobs spawn");
      }

      @Override
      protected String label() {
         return "☀";
      }

      @Override
      protected String value() {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            class_2338 p = mc.field_1724.method_24515();
            int b = mc.field_1687.method_8314(class_1944.field_9282, p);
            return b + " " + (b == 0 ? Lang.t("§cмобы спавнятся", "§cmobs spawn") : Lang.t("§aбезопасно", "§asafe"));
         } else {
            return "—";
         }
      }
   }

   public static class Memory extends HudElements.Info1 {
      public Memory() {
         super("memory", false, 0.005, 0.42, "Память", "Memory Usage", "Использование оперативной памяти", "RAM usage");
      }

      @Override
      protected String label() {
         return Lang.t("ОЗУ", "RAM");
      }

      @Override
      protected String value() {
         long u = Info.usedMemMb();
         long m = Info.maxMemMb();
         return u + "/" + m + " MB (" + (m == 0L ? 0L : u * 100L / m) + "%)";
      }
   }

   /**
    * Карточка текущей музыки: что играет в игре и что играет в браузере (ChromeMedia).
    * Название прокручивается, если не влезает, есть полоса прогресса и живой эквалайзер.
    */
   public static class Music extends HudModule {
      private final Setting.Mode source = this.add(
         new Setting.Mode(
            "music_source",
            "Источник",
            "Source",
            2,
            "game", "Игра", "Game",
            "chrome", "Браузер", "Browser",
            "both", "Оба", "Both"
         )
      );
      private final Setting.Num wide = this.add(new Setting.Num("music_width", "Ширина", "Width", 168.0, 96.0, 300.0, 4.0).suffix("px"));
      private final Setting.Bool bars = this.add(new Setting.Bool("music_bars", "Эквалайзер", "Equalizer", true));
      private final Setting.Bool progress = this.add(new Setting.Bool("music_progress", "Прогресс и время", "Progress and time", true));
      private final Setting.Bool scroll = this.add(new Setting.Bool("music_scroll", "Прокручивать название", "Scroll title", true));
      private final Setting.Bool showSub = this.add(new Setting.Bool("music_sub", "Вторая строка", "Second line", true));
      private String title = "";
      private String sub = "";
      private float frac = -1.0F;
      private boolean playing;
      private boolean watching;

      public Music() {
         super("music", false, 0.5, 0.0, "Текущая музыка", "Current Music", "Что играет в игре и в браузере", "What is playing in game and in the browser");
      }

      @Override
      public void onEnable() {
         this.syncWatch();
      }

      @Override
      public void onDisable() {
         if (this.watching) {
            ChromeMedia.release();
            this.watching = false;
         }
      }

      @Override
      public void onTick() {
         this.syncWatch();
      }

      /** Опрос браузера нужен только когда источник не «игра»; подписываемся ровно один раз. */
      private void syncWatch() {
         if (this.source.is("game")) {
            if (this.watching) {
               ChromeMedia.release();
               this.watching = false;
            }
         } else if (!this.watching) {
            ChromeMedia.acquire();
            this.watching = true;
         }
      }

      private void resolve() {
         ChromeMedia.Media cm = ChromeMedia.media();
         String key = mc.method_1538().method_71934();
         String game = key == null ? null : class_2561.method_43471(key).getString();
         boolean fromChrome = !this.source.is("game") && (cm.playing() || !cm.text().isEmpty());
         if (fromChrome) {
            this.title = cm.title().isEmpty() ? cm.docTitle() : cm.title();
            this.sub = cm.artist().isEmpty() ? hostOf(cm.url()) : cm.artist();
            this.playing = cm.playing();
            this.frac = cm.playing() && cm.dur() > 0.0F ? Math.max(0.0F, Math.min(1.0F, cm.pos() / cm.dur())) : -1.0F;
         } else if (game != null) {
            this.title = game;
            this.sub = Lang.t("игровая музыка", "game music");
            this.playing = true;
            this.frac = -1.0F;
         } else if (!this.source.is("game")) {
            this.title = Lang.t("тишина", "silence");
            this.sub = ChromeMedia.state();
            this.playing = false;
            this.frac = -1.0F;
         } else {
            this.title = Lang.t("тишина", "silence");
            this.sub = "";
            this.playing = false;
            this.frac = -1.0F;
         }

         if (this.title.isEmpty()) {
            this.title = Lang.t("без названия", "untitled");
         }

         if (this.sub.isEmpty()) {
            this.sub = Lang.t("нет трека", "no track");
         }
      }

      private static String hostOf(String url) {
         int i = url.indexOf(47, url.indexOf("//") + 2);
         return i > 2 && i < url.length() ? url.substring(url.indexOf("//") + 2, i) : url;
      }

      @Override
      protected void layout() {
         this.resolve();
         this.w = this.wide.i();
         this.h = 9 + (this.showSub.value ? 10 : 0) + (this.progress.value && this.frac >= 0.0F ? 13 : 0);
      }

      @Override
      protected boolean hasContent() {
         this.resolve();
         return this.playing || !this.source.is("game");
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         int eq = this.bars.value ? 20 : 0;
         R2D.circle(ctx, 5, 5, 5, R2D.withAlpha(this.accent(this.playing ? 0.0F : 0.45F), this.playing ? 210 : 110));
         this.text(ctx, "♫", 2, 1, this.playing ? -1 : -9735802);
         int x = 13;
         int avail = Math.max(20, this.w - x - eq);
         int tw = this.tw(this.title);
         int ox = 0;

         if (this.scroll.value && tw > avail) {
            int over = tw - avail;
            int ph = (int)((System.currentTimeMillis() / 45L) % (long)(over + 70));
            ox = Math.min(over, Math.max(0, ph - 10));
         }

         if (tw > avail) {
            ctx.method_44379(x, 0, x + avail, 9);
         }

         this.text(ctx, this.title, x + (tw <= avail ? 0 : -ox), 1, -1);

         if (tw > avail) {
            ctx.method_44380();
         }

         if (this.bars.value) {
            int bx = this.w - eq + 2;

            for (int i = 0; i < 5; i++) {
               float t = System.currentTimeMillis() / 130.0F + i * 0.8F;
               int hh = this.playing ? 2 + (int)(Math.abs((float)Math.sin(t * (i % 2 == 0 ? 0.7F : 1.1F))) * 8.0F) : 2;
               R2D.rect(ctx, bx + i * 4, 9 - hh, 2, hh, R2D.withAlpha(this.accent(i % 2 == 0 ? 0.0F : 0.4F), 220));
            }
         }

         int y = 11;
         if (this.showSub.value) {
            this.text(ctx, this.sub, x, y, -6643532);
            y += 10;
         }

         if (this.progress.value && this.frac >= 0.0F) {
            ChromeMedia.Media cm = ChromeMedia.media();
            int bw = this.w - x;
            R2D.rect(ctx, x, y + 1, bw, 3, R2D.withAlpha(-1, 50));
            R2D.rect(ctx, x, y + 1, Math.max(2, (int)(bw * this.frac)), 3, this.accent(0.0F));
            this.text(ctx, time(cm.pos()) + " / " + (cm.live() ? Lang.t("эфир", "live") : time(cm.dur())), x, y + 5, -9735802);
         }
      }

      private static String time(float s) {
         int sec = Math.max(0, (int)s);
         return String.format(java.util.Locale.ROOT, "%d:%02d", sec / 60, sec % 60);
      }
   }

   /**
    * Мини-экран браузера: кадр играющего видео или стрима из вкладки. Кнопка «Подключить Chrome»
    * поднимает окно браузера с отладочным портом; без связи виджет показывает своё состояние.
    */
   public static class Browser extends HudModule {
      private final Setting.Num wide = this.add(new Setting.Num("br_width", "Ширина", "Width", 220.0, 120.0, 420.0, 10.0).suffix("px"));
      private final Setting.Num port = this.add(new Setting.Num("br_port", "Порт DevTools", "DevTools port", 9222.0, 1024.0, 65535.0, 1.0));
      private final Setting.Bool cap = this.add(new Setting.Bool("br_caption", "Подпись", "Caption", true));
      private final Setting.Action connect = this.add(
            new Setting.Action("br_connect", "Подключить Chrome", "Connect Chrome", this::openBrowser)
         );
      private volatile boolean busy;
      private static class_2960 TEX;
      private static Photo photo;
      private static int texW = 0;
      private static int texH = 0;
      private int picH = 124;

      /** Живая текстура из байтов кадра; линейная фильтрация, чтобы картинка не была «пиксельной». */
      private static final class Photo extends class_1043 {
         Photo(class_1011 img) {
            super(() -> "mrbeanvisuals:chrome_screen", img);
            this.field_63613 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
         }
      }

      public Browser() {
         super(
               "browser_screen",
               false,
               1.0,
               0.0,
               "Экран браузера",
               "Browser Screen",
               "Мини-экран видео или стрима из вкладки Chrome",
               "Mini view of the video or stream playing in a Chrome tab"
            );
      }

      @Override
      public void onEnable() {
         ChromeMedia.setDebugPort(this.port.i());
         ChromeMedia.acquire();
         ChromeMedia.wantFrame(true);
      }

      @Override
      public void onDisable() {
         ChromeMedia.wantFrame(false);
         ChromeMedia.release();
      }

      @Override
      public void onTick() {
         ChromeMedia.setDebugPort(this.port.i());
      }

      /**
       * Chrome начиная с 136 версии не включает отладочный порт в профиле по умолчанию, поэтому кнопка
       * поднимает отдельное окно с своим профилем рядом с папкой игры; чужие вкладки не трогаются.
       */
      private void openBrowser() {
         if (this.busy) {
            return;
         }

         this.busy = true;
         Notifications.push(Lang.t("Открываю окно браузера...", "Opening browser window..."), true);
         final int p = this.port.i();
         final String dir = new File(mc.field_1697, "chrome-hud").getAbsolutePath();
         Thread t = new Thread(
               () -> {
                  String r = ChromeMedia.connect(p, dir);
                  this.busy = false;
                  Notifications.push(r, r.startsWith("окно") || r.startsWith("уже"));
               },
               "mrbean-chrome-connect"
            );
         t.setDaemon(true);
         t.start();
      }

      private void take() {
         byte[] f = ChromeMedia.takeFrame();
         if (f == null) {
            return;
         }

         try {
            class_1011 img = class_1011.method_49277(f);

            if (TEX == null) {
               TEX = class_2960.method_60655("mrbeanvisuals", "dyn/chrome_screen");
               photo = new Photo(img);
               mc.method_1531().method_4616(TEX, photo);
            } else {
               photo.method_4526(img);
               photo.method_4524();
            }

            texW = img.method_4307();
            texH = img.method_4323();
         } catch (Exception var2) {
         }
      }

      @Override
      protected void layout() {
         this.take();
         this.w = this.wide.i();
         this.picH = texW > 0 && texH > 0 ? Math.max(24, Math.round((float)this.w * (float)texH / (float)texW)) : Math.round((float)this.w * 0.56F);
         this.h = this.picH + (this.cap.value ? 11 : 0);
      }

      @Override
      protected int pad() {
         return 0;
      }

      @Override
      protected boolean hasContent() {
         return true;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         if (texW > 0 && texH > 0) {
            R2D.picture(ctx, TEX, 0, 0, this.w, this.picH, texW, texH, R2D.a(-1));
         } else {
            R2D.rect(ctx, 0, 0, this.w, this.picH, R2D.argb(200, 10, 12, 17));
            this.text(ctx, "♫", 5, 5, -9735802);
            this.text(ctx, Lang.t("Нет картинки", "No picture"), 16, 5, -6643532);
            this.text(ctx, ChromeMedia.state(), 16, 15, -9735802);
            this.text(
               ctx,
               Lang.t("«Подключить Chrome» → видео в новом окне", "Press Connect Chrome, play video in the new window"),
               5,
               this.picH - 10,
               -9735802
            );
         }

         if (this.cap.value) {
            ChromeMedia.Media cm = ChromeMedia.media();
            String line = cm.playing() ? cm.text() : Lang.t("пауза", "paused");
            int y = this.picH + 1;
            R2D.rect(ctx, 0, y - 1, this.w, 11, R2D.argb(180, 6, 8, 12));
            R2D.rect(ctx, 2, y + 3, 4, 4, cm.playing() ? R2D.argb(230, 90, 220, 120) : R2D.argb(180, 150, 150, 150));
            ctx.method_44379(9, y, this.w - 2, y + 10);
            this.text(ctx, line, 9, y + 1, -1183755);
            ctx.method_44380();
         }
      }
   }

   public static class Ping extends HudElements.Info1 {
      public Ping() {
         super("ping", false, 0.005, 0.22, "Пинг", "Ping", "Задержка до сервера", "Latency to the server");
      }

      @Override
      protected String label() {
         return Lang.t("Пинг", "Ping");
      }

      @Override
      protected String value() {
         return Info.ping() + " ms";
      }
   }

   public static class Potions extends HudModule {
      private final List<class_1293> list = new ArrayList<>();

      public Potions() {
         super("potions", true, 1.0, 0.98, "Эффекты зелий", "Potion Effects", "Активные эффекты с таймером", "Active effects with timers");
         this.background.value = false;
      }

      @Override
      protected void layout() {
         this.list.clear();
         if (mc.field_1724 != null) {
            this.list.addAll(mc.field_1724.method_6026());
         }

         this.w = 96;

         for (class_1293 e : this.list) {
            this.w = Math.max(this.w, this.tw(this.name(e)) + this.tw("00:00") + 18);
         }

         this.h = Math.max(14, this.list.size() * 16 - 2);
      }

      private String name(class_1293 e) {
         String n = ((class_1291)e.method_5579().comp_349()).method_5560().getString();
         return e.method_5578() > 0 ? n + " " + (e.method_5578() + 1) : n;
      }

      @Override
      protected boolean hasContent() {
         return mc.field_1724 != null && !mc.field_1724.method_6026().isEmpty();
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         if (this.list.isEmpty()) {
            this.text(ctx, Lang.t("Нет эффектов", "No effects"), 4, 3, -6643532);
         } else {
            int y = 0;

            for (class_1293 e : this.list) {
               R2D.round(ctx, 0, y, this.w, 14, this.radius.i(), R2D.bg());
               int col = 0xFF000000 | ((class_1291)e.method_5579().comp_349()).method_5556();
               R2D.rect(ctx, 0, y + 2, 2, 10, col);
               this.text(ctx, this.name(e), 6, y + 3, col);
               String time;
               if (e.method_48559()) {
                  time = "∞";
               } else {
                  int s = e.method_5584() / 20;
                  time = String.format("%d:%02d", s / 60, s % 60);
               }

               boolean blink = !e.method_48559() && e.method_5584() < 200 && System.currentTimeMillis() / 300L % 2L == 0L;
               this.text(ctx, time, this.w - this.tw(time) - 4, y + 3, blink ? -42396 : -1);
               y += 16;
            }
         }
      }
   }

   public static class ReachDisplay extends HudElements.Info1 {
      public ReachDisplay() {
         super(
            "reach_display",
            false,
            0.005,
            0.66,
            "Дистанция удара",
            "Hit Distance",
            "Расстояние последнего удара (только показ)",
            "Distance of your last hit (display only)"
         );
      }

      @Override
      protected String label() {
         return Lang.t("Удар", "Hit");
      }

      @Override
      protected String value() {
         return System.currentTimeMillis() - Info.lastHitTime < 5000L ? String.format("%.2f m", Info.lastReach) : "—";
      }
   }

   public static class ServerInfoHud extends HudElements.Info1 {
      final Setting.Bool players = this.add(new Setting.Bool("players", "Игроков онлайн", "Online players", true));

      public ServerInfoHud() {
         super("server_info", false, 0.005, 0.58, "Сервер", "Server Info", "Адрес сервера и игроки", "Server address and players");
      }

      @Override
      protected String label() {
         return Lang.t("Сервер", "Server");
      }

      @Override
      protected String value() {
         String s = Info.server();
         if (this.players.value && mc.method_1562() != null) {
            s = s + " (" + mc.method_1562().method_2880().size() + ")";
         }

         return s;
      }
   }

   public static class SessionTimer extends HudElements.Info1 {
      public SessionTimer() {
         super("session_timer", false, 0.005, 0.38, "Время сессии", "Session Timer", "Сколько ты уже играешь", "How long you have been playing");
      }

      @Override
      protected String label() {
         return Lang.t("Сессия", "Session");
      }

      @Override
      protected String value() {
         long s = (System.currentTimeMillis() - Info.sessionStart) / 1000L;
         return String.format("%d:%02d:%02d", s / 3600L, s / 60L % 60L, s % 60L);
      }
   }

   public static class Speed extends HudElements.Info1 {
      public Speed() {
         super("speed", false, 0.005, 0.3, "Скорость", "Speed", "Скорость в блоках в секунду", "Speed in blocks per second");
      }

      @Override
      protected String label() {
         return "BPS";
      }

      @Override
      protected String value() {
         return String.format("%.2f", Info.bps);
      }
   }

   public static class TargetHud extends HudModule {
      final Setting.Bool armor = this.add(new Setting.Bool("armor", "Броня цели", "Target armor", true));
      final Setting.Bool winInfo = this.add(new Setting.Bool("win", "Кто побеждает", "Who is winning", true));
      private float animHp = -1.0F;
      private class_1309 shown;

      public TargetHud() {
         super("target_hud", true, 0.56, 0.56, "Цель", "Target HUD", "Здоровье, броня и дистанция противника", "Opponent health, armor and distance");
      }

      @Override
      protected void layout() {
         this.w = 126;
         this.h = this.armor.value ? 46 : 32;
      }

      @Override
      protected boolean hasContent() {
         class_1309 t = Info.currentTarget();
         if (t != null) {
            this.shown = t;
         }

         return t != null;
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         class_1309 e = this.shown;
         if (e == null) {
            if (!editing || mc.field_1724 == null) {
               return;
            }

            e = mc.field_1724;
         }

         float max = Math.max(1.0F, e.method_6063());
         float hp = e.method_6032();
         if (this.animHp < 0.0F || Math.abs(this.animHp - hp) > max) {
            this.animHp = hp;
         }

         this.animHp = R2D.approach(this.animHp, hp, 0.15F);
         R2D.circle(ctx, 12, 12, 11, R2D.withAlpha(this.accent(0.0F), 220));
         String name = e.method_5477().getString();
         this.text(ctx, name.substring(0, 1).toUpperCase(), 12 - this.tw(name.substring(0, 1).toUpperCase()) / 2, 8, -15724528);
         if (e.field_6235 > 0) {
            R2D.circle(ctx, 12, 12, 11, R2D.argb(e.field_6235 * 12, 255, 40, 40));
         }

         this.text(ctx, name.length() > 14 ? name.substring(0, 14) + "…" : name, 28, 0, -1);
         double dist = mc.field_1724 == null ? 0.0 : mc.field_1724.method_5739(e);
         this.text(ctx, String.format("%.1f HP  §7%.1f m", hp + e.method_6067(), dist), 28, 10, R2D.healthColor(hp / max));
         int bx = 28;
         int by = 22;
         int bw = this.w - 28;
         R2D.round(ctx, bx, by, bw, 5, 2, 1610612736);
         R2D.round(ctx, bx, by, (int)(bw * Math.min(1.0F, this.animHp / max)), 5, 2, -1426063361);
         int real = (int)(bw * Math.min(1.0F, hp / max));

         for (int i = 0; i < real; i += 2) {
            R2D.rect(ctx, bx + i, by, Math.min(2, real - i), 5, this.accent((float)i / bw));
         }

         if (this.armor.value) {
            int ix = 28;

            for (class_1304 s : new class_1304[]{
               class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6173, class_1304.field_6171
            }) {
               class_1799 st = e.method_6118(s);
               if (!st.method_7960()) {
                  ctx.method_51448().pushMatrix();
                  ctx.method_51448().translate(ix, 30.0F);
                  ctx.method_51448().scale(0.8F, 0.8F);
                  ctx.method_51427(st, 0, 0);
                  ctx.method_51448().popMatrix();
                  ix += 14;
               }
            }
         }

         if (this.winInfo.value && e instanceof class_1657 && e != mc.field_1724 && mc.field_1724 != null) {
            float mine = mc.field_1724.method_6032() + mc.field_1724.method_6067();
            float theirs = hp + e.method_6067();
            String sx = mine > theirs + 2.0F
               ? Lang.t("§aВыигрываешь", "§aWinning")
               : (mine + 2.0F < theirs ? Lang.t("§cПроигрываешь", "§cLosing") : Lang.t("§eРавно", "§eEven"));
            R2D.textScaled(ctx, sx, 0.0F, this.armor.value ? 38.0F : 26.0F, 0.6F, -1, this.ts());
         }
      }
   }

   public static class Watermark extends HudModule {
      final Setting.Mode style = this.add(
         new Setting.Mode("style", "Стиль", "Style", 0, "card", "Плашка", "Card", "minimal", "Минимал", "Minimal", "neon", "Неон", "Neon")
      );
      final Setting.Text title = this.add(new Setting.Text("title", "Текст", "Text", "MrBean Visuals"));
      final Setting.Bool nick = this.add(new Setting.Bool("nick", "Ник", "Nickname", true));
      final Setting.Bool fps = this.add(new Setting.Bool("fps", "FPS", "FPS", true));
      final Setting.Bool ping = this.add(new Setting.Bool("ping", "Пинг", "Ping", true));
      final Setting.Bool time = this.add(new Setting.Bool("time", "Время", "Time", true));
      private final List<String> parts = new ArrayList<>();

      public Watermark() {
         super("watermark", true, 0.005, 0.005, "Ватермарка", "Watermark", "Логотип MrBean Visuals с информацией", "MrBean Visuals logo with info");
         this.background.value = false;
         this.shadow.value = false;
      }

      @Override
      protected void layout() {
         this.parts.clear();
         if (this.nick.value && mc.field_1724 != null) {
            this.parts.add(mc.field_1724.method_5477().getString());
         }

         if (this.fps.value) {
            this.parts.add(mc.method_47599() + " fps");
         }

         if (this.ping.value) {
            this.parts.add(Info.ping() + " ms");
         }

         if (this.time.value) {
            this.parts.add(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
         }

         String t = this.title.value.isBlank() ? "MrBean Visuals" : this.title.value;
         int info = 0;

         for (String p : this.parts) {
            info += this.tw(p) + 9;
         }

         String var5 = this.style.get();
         switch (var5) {
            case "minimal":
               this.w = this.tw(t) + info;
               this.h = 9;
               break;
            case "neon":
               this.w = Math.max((int)(this.tw(t) * 1.6F), this.tw(String.join("  ·  ", this.parts))) + 2;
               this.h = 26;
               break;
            default:
               this.w = 19 + this.tw(t) + info + 5;
               this.h = 18;
         }
      }

      @Override
      protected void draw(class_332 ctx, float d) {
         String t = this.title.value.isBlank() ? "MrBean Visuals" : this.title.value;
         String var4 = this.style.get();
         switch (var4) {
            case "minimal":
               int x = R2D.gradientText(ctx, t, 0, 0, 0.06F, this.ts());

               for (String p : this.parts) {
                  this.text(ctx, " §7|§r " + p, x, 0, -2039584);
                  x += this.tw(" | " + p);
               }
               break;
            case "neon":
               ctx.method_51448().pushMatrix();
               ctx.method_51448().scale(1.6F, 1.6F);

               for (int i = 1; i <= 2; i++) {
                  R2D.text(ctx, t, i, 0, R2D.withAlpha(this.accent(0.0F), 60), false);
                  R2D.text(ctx, t, -i, 0, R2D.withAlpha(this.accent(0.0F), 60), false);
               }

               R2D.gradientText(ctx, t, 0, 0, 0.05F, false);
               ctx.method_51448().popMatrix();
               this.text(ctx, String.join("  ·  ", this.parts), 1, 17, -4209712);
               break;
            default:
               R2D.panel(ctx, 0, 0, this.w, this.h, 5, R2D.bg(), true, 0);
               R2D.accentBar(ctx, 3, 0, this.w - 6, 1);
               R2D.bean(ctx, 5, 4, 10);
               int xx = R2D.gradientText(ctx, t, 19, 5, 0.06F, this.ts()) + 19;

               for (String p : this.parts) {
                  R2D.rect(ctx, xx + 4, 5, 1, 8, 1358954495);
                  this.text(ctx, p, xx + 9, 5, -1644305);
                  xx += this.tw(p) + 9;
               }
         }
      }
   }
}
