package com.mrbean.visuals.module.impl;

import com.mrbean.visuals.core.Lang;
import com.mrbean.visuals.gui.Notifications;
import com.mrbean.visuals.module.Category;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.util.LastServer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239.class_240;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4174;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

/**
 * PVE-набор: всё, что помогает жить на выживании и на ReallyWorld, а не в PvP.
 * Модули работают только через клиентские данные (инвентарь, прицел, прочность), ничего
 * не угадывают и не подменяют серверную логику.
 */
public final class PveModules {
   private PveModules() {
   }

   public static void registerAll() {
      Modules.reg(new PveModules.AutoClicker());
      Modules.reg(new PveModules.FastInventoryMove());
      Modules.reg(new PveModules.AutoFixAll());
      Modules.reg(new PveModules.InventoryOrganizer());
      Modules.reg(new PveModules.AutoEat());
   }

   /** Порядок страницы PVE: свои модули плюс уже готовые предупреждения из других категорий. */
   public static List<Module> page() {
      String[] order = new String[]{"auto_clicker", "fast_inv_move", "auto_fix_all", "durability_warning", "inv_organizer", "auto_eat", "totem_alert"};
      List<Module> out = new ArrayList<>();

      for (String id : order) {
         Module m = Modules.get(id);
         if (m != null) {
            out.add(m);
         }
      }

      for (Module m : Modules.of(Category.PVE)) {
         if (!out.contains(m)) {
            out.add(m);
         }
      }

      return out;
   }

   /** Прочность (0..1) самой убитой вещи из брони и рук; 1, если ломаться нечему. */
   static float worstGear() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null || mc.field_1724.method_68878()) {
         return 1.0F;
      } else {
         float worst = 1.0F;

         for (class_1304 s : new class_1304[]{
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6173, class_1304.field_6171
         }) {
            class_1799 st = mc.field_1724.method_6118(s);
            if (!st.method_7960() && st.method_7963() && st.method_7936() > 0) {
               worst = Math.min(worst, 1.0F - (float)st.method_7919() / st.method_7936());
            }
         }

         return worst;
      }
   }

   public static class AutoClicker extends Module {
      final Setting.Num cps = this.add(new Setting.Num("cps", "Кликов в секунду", "Clicks per second", 12.0, 1.0, 20.0, 1.0));
      final Setting.Num jitter = this.add(new Setting.Num("jitter", "Разброс интервала", "Interval jitter", 20.0, 0.0, 60.0, 5.0).suffix("%"));
      final Setting.Bool held = this.add(new Setting.Bool("held", "Только пока зажата атака", "Only while attack is held", true));
      final Setting.Bool entities = this.add(new Setting.Bool("entities", "Бить сущности", "Attack entities", true));
      final Setting.Bool blocks = this.add(new Setting.Bool("blocks", "Ломать блоки", "Break blocks", true));
      final Setting.Bool cooldown = this.add(
         new Setting.Bool("cooldown", "Ждать перезарядку оружия", "Wait for the weapon cooldown", true)
      );
      private long next;

      public AutoClicker() {
         super(
            "auto_clicker",
            Category.PVE,
            false,
            "Auto Clicker",
            "Auto Clicker",
            "Кликает сам с нужной частотой: бьёт сущность или ломает блок под прицелом. По умолчанию работает, пока зажата атака",
            "Clicks for you at a set rate: hits the entity or breaks the block under the crosshair. By default it runs while attack is held"
         );
      }

      @Override
      public void onEnable() {
         this.next = 0L;
      }

      @Override
      public void onDisable() {
         this.next = 0L;
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null && mc.field_1761 != null && mc.field_1687 != null && mc.field_1755 == null) {
            if (!this.held.value || mc.field_1690.field_1886.method_1434()) {
               long now = System.currentTimeMillis();
               if (now >= this.next) {
                  boolean busy = this.click();
                  if (busy) {
                     this.next = now + this.interval();
                  }
               }
            }
         }
      }

      /** Один клик. false — под прицелом нечего бить, интервал не сдвигаем. */
      private boolean click() {
         if (this.entities.value && mc.field_1692 != null) {
            if (this.cooldown.value && mc.field_1724.method_7261(0.5F) < 1.0F) {
               return true;
            }

            mc.field_1761.method_2918(mc.field_1724, mc.field_1692);
            mc.field_1724.method_6104(class_1268.field_5808);
            return true;
         } else if (this.blocks.value && mc.field_1765 instanceof class_3965 bh && bh.method_17783() != class_240.field_1333) {
            mc.field_1761.method_2902(bh.method_17777(), bh.method_17780());
            return true;
         } else {
            return false;
         }
      }

      private long interval() {
         long ms = (long)(1000.0 / Math.max(1.0, this.cps.value));
         double j = this.jitter.value / 100.0;
         if (j > 0.0) {
            ms += (long)((Math.random() * 2.0 - 1.0) * j * ms);
         }

         return Math.max(25L, ms);
      }
   }

   public static class FastInventoryMove extends Module {
      final Setting.Key key = this.add(new Setting.Key("key", "Клавиша переноса", "Move key", 86));
      final Setting.Mode dir = this.add(
         new Setting.Mode(
            "dir",
            "Куда переносить",
            "Direction",
            0,
            "take",
            "Забирать из контейнера",
            "Take from the container",
            "put",
            "Выкладывать в контейнер",
            "Put into the container"
         )
      );
      final Setting.Num rate = this.add(new Setting.Num("rate", "Предметов в секунду", "Items per second", 20.0, 4.0, 40.0, 2.0));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Сообщение, когда всё перенесено", "Message when done", true));
      private long next;
      private boolean wasDown;
      private boolean done;

      public FastInventoryMove() {
         super(
            "fast_inv_move",
            Category.PVE,
            false,
            "Fast Inventory Move",
            "Fast Inventory Move",
            "Зажми клавишу в открытом сундуке или печи — предметы переедут без ожидания анимаций. Клавиша по умолчанию V",
            "Hold the key with a chest or furnace open and items move over without waiting for animations. Default key V"
         );
      }

      @Override
      public void onDisable() {
         this.wasDown = false;
         this.done = false;
      }

      @Override
      public void onTick() {
         boolean down = this.key.isDown();
         if (down && !this.wasDown) {
            this.done = false;
            this.next = 0L;
         }

         this.wasDown = down;
         if (down && mc.field_1724 != null && mc.field_1761 != null && mc.field_1755 instanceof class_465) {
            long now = System.currentTimeMillis();
            if (now >= this.next) {
               this.next = now + (long)(1000.0 / Math.max(4.0, this.rate.value));
               class_1735 s = this.nextSlot();
               if (s == null) {
                  if (!this.done) {
                     this.done = true;
                     if (this.notify.value) {
                        Notifications.push(
                           this.dir.is("take")
                              ? Lang.t("Всё забрано", "Everything taken")
                              : Lang.t("Всё выложено", "Everything stored"),
                           true
                        );
                     }
                  }
               } else {
                  mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, s.field_7874, 0, class_1713.field_7794, mc.field_1724);
               }
            }
         }
      }

      /** Первый подходящий слот: из контейнера для «забрать», из инвентаря для «выложить». */
      private class_1735 nextSlot() {
         class_1703 h = mc.field_1724.field_7512;
         class_1661 inv = mc.field_1724.method_31548();

         for (class_1735 s : h.field_7761) {
            if ((s.field_7871 == inv) != this.dir.is("put") && s.method_7681() && s.method_7674(mc.field_1724) && s.method_7682()) {
               return s;
            }
         }

         return null;
      }
   }

   public static class AutoFixAll extends Module {
      final Setting.Num threshold = this.add(
         new Setting.Num("threshold", "Чинить при прочности ниже", "Repair below", 25.0, 5.0, 80.0, 5.0).suffix("%")
      );
      final Setting.Text command = this.add(new Setting.Text("command", "Команда починки", "Repair command", "/fix all"));
      final Setting.Num cooldown = this.add(
         new Setting.Num("cooldown", "Не чаще, чем раз в", "At most once per", 60.0, 10.0, 600.0, 10.0).suffix(" с")
      );
      final Setting.Bool onlyRw = this.add(new Setting.Bool("only_rw", "Только на ReallyWorld", "Only on ReallyWorld", true));
      final Setting.Bool onJoin = this.add(new Setting.Bool("on_join", "Чинить сразу при входе", "Repair right after joining", true));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомления", "Notifications", true));
      private long next;
      private boolean inWorld;

      public AutoFixAll() {
         super(
            "auto_fix_all",
            Category.PVE,
            false,
            "Auto Fix All",
            "Auto Fix All",
            "Сам отправляет команду починки, когда броня или инструмент почти сломались. Команда сервера меняется в настройках",
            "Sends the repair command itself when armor or a tool is about to break. The server command is editable"
         );
      }

      @Override
      public void onEnable() {
         this.next = System.currentTimeMillis() + 4000L;
         this.inWorld = mc.field_1687 != null;
      }

      @Override
      public void onTick() {
         if (mc.field_1724 != null && mc.method_1562() != null) {
            boolean now = mc.field_1687 != null;
            if (now && !this.inWorld && this.onJoin.value) {
               this.next = System.currentTimeMillis() + 5000L;
            }

            this.inWorld = now;
            long t = System.currentTimeMillis();
            if (t >= this.next
               && (!this.onlyRw.value || LastServer.currentAddress(mc).contains("reallyworld"))
               && PveModules.worstGear() * 100.0F <= this.threshold.value) {
               String c = this.command.value == null ? "" : this.command.value.trim();
               if (!c.isEmpty()) {
                  if (c.startsWith("/")) {
                     mc.method_1562().method_45730(c.substring(1));
                  } else {
                     mc.method_1562().method_45729(c);
                  }

                  if (this.notify.value) {
                     Notifications.push(Lang.t("Починка: ", "Repair: ") + c, true);
                  }
               }

               this.next = t + (long)(Math.max(10.0, this.cooldown.value) * 1000.0);
            }
         } else {
            this.inWorld = false;
         }
      }
   }

   public static class InventoryOrganizer extends Module {
      final Setting.Key key = this.add(new Setting.Key("key", "Клавиша сортировки", "Sort key", 89));
      final Setting.Action sortBtn = this.add(new Setting.Action("sort", "Отсортировать сейчас", "Sort now", this::start));
      final Setting.Mode order = this.add(
         new Setting.Mode(
            "order",
            "Порядок",
            "Order",
            0,
            "type",
            "По типу и количеству",
            "By type and count",
            "name",
            "По названию",
            "By name",
            "size",
            "По количеству",
            "By count"
         )
      );
      final Setting.Bool keepHotbar = this.add(new Setting.Bool("keep_hotbar", "Не трогать хотбар", "Leave the hotbar alone", true));
      final Setting.Bool autoOpen = this.add(new Setting.Bool("auto_open", "Открывать инвентарь сам", "Open the inventory itself", true));
      final Setting.Num swaps = this.add(new Setting.Num("swaps", "Обменов за тик", "Swaps per tick", 2.0, 1.0, 6.0, 1.0));
      final Setting.Bool notify = this.add(new Setting.Bool("notify", "Уведомление в конце", "Notify when done", true));
      private boolean running;
      private boolean opened;
      private boolean wasDown;
      private int closeIn;

      public InventoryOrganizer() {
         super(
            "inv_organizer",
            Category.PVE,
            false,
            "Inventory Organizer",
            "Inventory Organizer",
            "Раскладывает инвентарь по порядку: одинаковые предметы собираются рядом. Клавиша по умолчанию Y",
            "Sorts the inventory so identical items end up next to each other. Default key Y"
         );
      }

      @Override
      public void onDisable() {
         this.running = false;
         this.opened = false;
         this.wasDown = false;
         this.closeIn = 0;
      }

      void start() {
         if (mc.field_1724 != null) {
            if (mc.field_1755 == null) {
               if (!this.autoOpen.value) {
                  Notifications.push(Lang.t("Открой инвентарь и нажми ещё раз", "Open the inventory and press again"), false);
                  return;
               }

               this.opened = true;
               mc.method_1507(new class_490(mc.field_1724));
            } else if (!(mc.field_1755 instanceof class_465)) {
               return;
            }

            this.running = true;
            this.closeIn = 0;
         }
      }

      @Override
      public void onTick() {
         boolean down = this.key.isDown();
         if (down && !this.wasDown) {
            this.start();
         }

         this.wasDown = down;
         if (this.running) {
            if (mc.field_1724 == null || mc.field_1761 == null || !(mc.field_1755 instanceof class_465)) {
               this.running = false;
               this.opened = false;
            } else {
               int n = 0;

               for (int i = this.swaps.i(); i > 0 && this.step(); i--) {
                  n++;
               }

               if (n == 0) {
                  this.running = false;
                  if (this.notify.value) {
                     Notifications.push(Lang.t("Инвентарь отсортирован", "Inventory sorted"), true);
                  }

                  if (this.opened) {
                     this.closeIn = 6;
                  }
               }
            }
         }

         if (this.closeIn > 0 && --this.closeIn == 0) {
            this.opened = false;
            if (mc.field_1724 != null && mc.field_1755 instanceof class_465) {
               mc.field_1724.method_7346();
            }
         }
      }

      /** Один обмен местами. false — всё уже на своих местах. */
      private boolean step() {
         class_1703 h = mc.field_1724.field_7512;
         List<class_1735> slots = this.slots(h);
         if (slots.size() < 2) {
            return false;
         } else {
            List<class_1799> have = new ArrayList<>();

            for (class_1735 s : slots) {
               have.add(s.method_7677());
            }

            List<class_1799> want = new ArrayList<>(have);
            want.sort(this.comparator());

            for (int i = 0; i < have.size(); i++) {
               if (!class_1799.method_7973(have.get(i), want.get(i))) {
                  for (int j = i + 1; j < have.size(); j++) {
                     if (class_1799.method_7973(have.get(j), want.get(i))) {
                        this.swap(h, slots.get(i).field_7874, slots.get(j).field_7874);
                        return true;
                     }
                  }
               }
            }

            return false;
         }
      }

      /** Меняет два слота тремя кликами, курсор в конце пустой. */
      private void swap(class_1703 h, int a, int b) {
         mc.field_1761.method_2906(h.field_7763, a, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(h.field_7763, b, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(h.field_7763, a, 0, class_1713.field_7790, mc.field_1724);
      }

      private List<class_1735> slots(class_1703 h) {
         class_1661 inv = mc.field_1724.method_31548();
         List<class_1735> out = new ArrayList<>();

         for (class_1735 s : h.field_7761) {
            if (s.field_7871 == inv && s.method_7682() && (!this.keepHotbar.value || s.method_34266() >= 9)) {
               out.add(s);
            }
         }

         return out;
      }

      private Comparator<class_1799> comparator() {
         Comparator<class_1799> c = Comparator.comparing((class_1799 s) -> s.method_7960() ? 1 : 0);
         if (this.order.is("name")) {
            return c.thenComparing(InventoryOrganizer::label, String.CASE_INSENSITIVE_ORDER)
               .thenComparing((class_1799 s) -> -s.method_7947());
         } else if (this.order.is("size")) {
            return c.thenComparing((class_1799 s) -> -s.method_7947()).thenComparing(InventoryOrganizer::id);
         } else {
            return c.thenComparing(InventoryOrganizer::id).thenComparing((class_1799 s) -> -s.method_7947()).thenComparing(class_1799::method_7919);
         }
      }

      private static String id(class_1799 s) {
         return class_7923.field_41178.method_10221(s.method_7909()).toString();
      }

      private static String label(class_1799 s) {
         return s.method_7964().getString();
      }
   }

   public static class AutoEat extends Module {
      final Setting.Num hunger = this.add(
         new Setting.Num("hunger", "Есть при голоде ниже", "Eat below hunger", 14.0, 1.0, 20.0, 1.0).suffix(" 🍗")
      );
      final Setting.Mode prefer = this.add(
         new Setting.Mode(
            "prefer",
            "Какую еду брать",
            "Which food",
            0,
            "best",
            "Самую сытную",
            "The most filling",
            "first",
            "Первую найденную",
            "The first found"
         )
      );
      final Setting.Bool offhand = this.add(new Setting.Bool("offhand", "Еда во второй руке", "Food in the offhand", true));
      final Setting.Bool gapple = this.add(
         new Setting.Bool("gapple", "Золотые яблоки только при малом HP", "Golden apples only at low HP", true)
      );
      final Setting.Num hp = (Setting.Num)this.add(new Setting.Num("hp", "Мало HP — это ниже", "Low HP below", 10.0, 1.0, 20.0, 1.0).suffix(" ❤"))
         .showIf(() -> this.gapple.value);
      final Setting.Bool restore = this.add(new Setting.Bool("restore", "Вернуть прежний слот", "Restore the previous slot", true));
      private boolean eating;
      private int prevSlot = -1;

      public AutoEat() {
         super(
            "auto_eat",
            Category.PVE,
            false,
            "Auto Eat",
            "Auto Eat",
            "Сама достаёт еду из хотбара и ест, когда голод падает ниже порога. Возвращает прежний слот",
            "Takes food from the hotbar and eats it when hunger drops below the threshold. Restores the previous slot"
         );
      }

      @Override
      public void onDisable() {
         this.release();
      }

      @Override
      public void onTick() {
         if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1724.method_68878() || mc.field_1724.method_7325()) {
            this.release();
         } else if (mc.field_1755 != null) {
            this.release();
         } else {
            boolean need = this.needed();
            if (!this.eating) {
               if (need) {
                  this.begin();
               }
            } else if (!need || !mc.field_1724.method_6115()) {
               this.release();
            }
         }
      }

      private boolean needed() {
         return (double)mc.field_1724.method_7344().method_7586() < this.hunger.value
            || this.gapple.value && mc.field_1724.method_6032() < this.hp.value && mc.field_1724.method_7344().method_7586() < 20;
      }

      private void begin() {
         class_1268 hand = null;
         int slot = -1;
         if (this.offhand.value && this.eatable(mc.field_1724.method_6079())) {
            hand = class_1268.field_5810;
         } else {
            class_1661 inv = mc.field_1724.method_31548();
            int best = -1;
            float bestScore = -1.0F;

            for (int i = 0; i < 9; i++) {
               class_1799 st = inv.method_5438(i);
               if (this.eatable(st)) {
                  if (this.prefer.is("first")) {
                     slot = i;
                     break;
                  }

                  float sc = this.score(st);
                  if (sc > bestScore) {
                     bestScore = sc;
                     best = i;
                  }
               }
            }

            if (slot < 0 && best >= 0) {
               slot = best;
            }
         }

         if (hand == null && slot >= 0) {
            hand = class_1268.field_5808;
            this.prevSlot = this.restore.value ? mc.field_1724.method_31548().method_67532() : -1;
            mc.field_1724.method_31548().method_61496(slot);
         }

         if (hand != null) {
            mc.field_1690.field_1904.method_23481(true);
            this.eating = true;
         } else {
            this.eating = false;
         }
      }

      private void release() {
         if (this.eating) {
            this.eating = false;
            mc.field_1690.field_1904.method_23481(false);
            if (this.prevSlot >= 0 && mc.field_1724 != null && class_1661.method_7380(this.prevSlot)) {
               mc.field_1724.method_31548().method_61496(this.prevSlot);
            }

            this.prevSlot = -1;
         }
      }

      private boolean eatable(class_1799 st) {
         if (st.method_7960()) {
            return false;
         } else {
            class_4174 f = st.method_58694(class_9334.field_50075);
            if (f == null) {
               return false;
            } else if (!this.gapple.value || !st.method_31574(class_1802.field_8463) && !st.method_31574(class_1802.field_8367)) {
               return true;
            } else {
               return mc.field_1724 != null && mc.field_1724.method_6032() < this.hp.value;
            }
         }
      }

      private float score(class_1799 st) {
         class_4174 f = st.method_58694(class_9334.field_50075);
         return f == null ? 0.0F : f.comp_2491() + f.comp_2492() * 2.0F;
      }
   }
}
