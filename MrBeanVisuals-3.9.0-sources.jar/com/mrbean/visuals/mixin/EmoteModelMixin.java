package com.mrbean.visuals.mixin;

import com.mrbean.visuals.module.impl.Emotes;
import net.minecraft.class_10055;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_591.class})
public abstract class EmoteModelMixin extends class_572<class_10055> {
   public EmoteModelMixin(class_630 root) {
      super(root);
      throw new UnsupportedOperationException();
   }

   @Inject(
      method = {"setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V"},
      at = {@At("TAIL")}
   )
   private void mrbean$emote(class_10055 state, CallbackInfo ci) {
      Emotes.EmoteModule em = Emotes.module();
      Emotes.Pose p = Emotes.activePose(state.field_53528, em);
      if (p != null) {
         float b = p.strength;
         this.field_3398.field_3654 += p.headPitch * b;
         this.field_3398.field_3675 += p.headYaw * b;
         this.field_3398.field_3674 += p.headRoll * b;
         this.field_3391.field_3654 += p.bodyPitch * b;
         this.field_3391.field_3675 += p.bodyYaw * b;
         this.field_3401.field_3654 += p.rArmPitch * b;
         this.field_3401.field_3675 += p.rArmYaw * b;
         this.field_3401.field_3674 += p.rArmRoll * b;
         this.field_27433.field_3654 += p.lArmPitch * b;
         this.field_27433.field_3675 += p.lArmYaw * b;
         this.field_27433.field_3674 += p.lArmRoll * b;
         if (p.legs) {
            this.field_3392.field_3654 += p.rLegPitch * b;
            this.field_3397.field_3654 += p.lLegPitch * b;
         } else if (em.calmLegs.get()) {
            this.field_3392.field_3654 *= 1.0F - b;
            this.field_3397.field_3654 *= 1.0F - b;
         }
      }
   }
}
