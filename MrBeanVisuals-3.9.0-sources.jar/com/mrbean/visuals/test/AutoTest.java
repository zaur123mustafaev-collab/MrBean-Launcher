package com.mrbean.visuals.test;

import com.mrbean.visuals.MrBeanClient;
import com.mrbean.visuals.core.Friends;
import com.mrbean.visuals.gui.ClickGuiScreen;
import com.mrbean.visuals.gui.MenuScreen;
import com.mrbean.visuals.gui.menu.AccountScreen;
import com.mrbean.visuals.gui.menu.MainMenuScreen;
import com.mrbean.visuals.module.Module;
import com.mrbean.visuals.module.Modules;
import com.mrbean.visuals.module.Setting;
import com.mrbean.visuals.module.impl.AutoDuel;
import com.mrbean.visuals.module.impl.CrystalModules;
import com.mrbean.visuals.module.impl.FxModules;
import com.mrbean.visuals.module.impl.UtilityModules;
import com.mrbean.visuals.optimize.OptMods;
import com.mrbean.visuals.optimize.OptimizationScreen;
import com.mrbean.visuals.util.Info;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_1267;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1511;
import net.minecraft.class_1659;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_1940;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_315;
import net.minecraft.class_318;
import net.minecraft.class_3965;
import net.minecraft.class_429;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.minecraft.class_5285;
import net.minecraft.class_5317;
import net.minecraft.class_5498;
import net.minecraft.class_7701;
import net.minecraft.class_7712;

public final class AutoTest {
   private static final class_310 mc = class_310.method_1551();
   private static ArrayDeque<String> script;
   private static int wait;
   private static boolean worldRequested;
   public static Supplier<class_437> guiFactory;
   public static Supplier<class_437> hudEditorFactory;
   public static Supplier<class_437> wizardFactory;

   private AutoTest() {
   }

   public static boolean active() {
      return script != null;
   }

   public static void init() {
      String p = System.getProperty("mrbean.autotest");
      if (p != null) {
         try {
            List<String> lines = Files.readAllLines(Path.of(p));
            script = new ArrayDeque<>();

            for (String l : lines) {
               if (!l.isBlank() && !l.startsWith("#")) {
                  script.add(l.trim());
               }
            }

            MrBeanClient.LOG.info("[AutoTest] сценарий: {} команд", script.size());
         } catch (Exception var4) {
            MrBeanClient.LOG.error("[AutoTest] не удалось прочитать сценарий", var4);
         }
      }
   }

   public static void tick() {
      if (script != null) {
         if (!worldRequested && !script.isEmpty() && script.peek().startsWith("@")) {
            if (mc.field_1755 != null && mc.method_18506() == null) {
               if (wait > 0) {
                  wait--;
               } else {
                  String line = script.poll().substring(1);
                  MrBeanClient.LOG.info("[AutoTest] @> {}", line);

                  try {
                     exec(line.split(" ", 4));
                  } catch (Exception var2) {
                     MrBeanClient.LOG.error("[AutoTest] ошибка в '{}'", line, var2);
                  }
               }
            }
         } else if (worldRequested || !(mc.field_1755 instanceof class_442) && !(mc.field_1755 instanceof MainMenuScreen)) {
            if (mc.field_1724 != null && mc.field_1687 != null) {
               if (wait > 0) {
                  wait--;
               } else {
                  while (!script.isEmpty() && wait == 0) {
                     String line = script.poll();
                     MrBeanClient.LOG.info("[AutoTest] > {}", line);

                     try {
                        exec(line.split(" ", 4));
                     } catch (Exception var3) {
                        MrBeanClient.LOG.error("[AutoTest] ошибка в '{}'", line, var3);
                     }
                  }

                  if (script.isEmpty() && wait == 0) {
                     script = null;
                  }
               }
            }
         } else {
            worldRequested = true;
            String name = "mrbean_test";
            if (mc.method_1586().method_230(name)) {
               mc.method_41735().method_57784(name, () -> {});
            } else {
               class_1940 info = new class_1940(
                  name, class_1934.field_9220, false, class_1267.field_5801, true, new class_1928(class_7701.field_40183), class_7712.field_40260
               );
               mc.method_41735()
                  .method_41895(name, info, class_5285.method_64223(), class_5317::method_64225, new class_442());
            }
         }
      }
   }

   /**
    * Координаты задаются в экранных (уже масштабированных) пикселях, как их видят экраны:
    * Mouse хранит сырые позиции окна, поэтому умножаем на GUI-шкалу.
    */
   private static void warpMouse(double x, double y) {
      int f = Math.max(1, mc.method_22683().method_4495());

      try {
         Field fx = class_312.class.getDeclaredField("x");
         fx.setAccessible(true);
         fx.setDouble(mc.field_1729, x * (double)f);
         Field fy = class_312.class.getDeclaredField("y");
         fy.setAccessible(true);
         fy.setDouble(mc.field_1729, y * (double)f);
      } catch (Exception var6) {
         MrBeanClient.LOG.warn("[AutoTest] warpMouse: {}", var6.toString());
      }
   }

   private static void exec(String[] a) {
      String var1 = a[0];
      switch (var1) {
         case "wait":
            wait = Integer.parseInt(a[1]);
            break;
         case "persp":
            class_315 var53 = mc.field_1690;
            String var25 = a[1];

            var53.method_31043(switch (var25) {
               case "back" -> class_5498.field_26665;
               case "front" -> class_5498.field_26666;
               default -> class_5498.field_26664;
            });
            break;
         case "enable":
         case "disable":
            Module mxxx = Modules.get(a[1]);
            if (mxxx != null) {
               mxxx.setEnabled(a[0].equals("enable"));
            }
            break;
         case "set":
            Module mxx = Modules.get(a[1]);
            Setting s = mxx == null ? null : mxx.setting(a[2]);
            if (s != null) {
               s.load(a[3]);
            }
            break;
         case "cmd":
            mc.method_1562().method_45730(String.join(" ", Arrays.copyOfRange(a, 1, a.length)).substring(1));
            break;
         case "yaw":
            mc.field_1724.method_36456(Float.parseFloat(a[1]));
            mc.field_1724.method_5847(Float.parseFloat(a[1]));
            mc.field_1724.method_5636(Float.parseFloat(a[1]));
            break;
         case "pitch":
            mc.field_1724.method_36457(Float.parseFloat(a[1]));
            break;
         case "sneak":
            mc.field_1690.field_1832.method_23481(a[1].equals("on"));
            break;
         case "forward":
            mc.field_1690.field_1894.method_23481(a[1].equals("on"));
            break;
         case "log":
            MrBeanClient.LOG
               .info(
                  "[AutoTest] sprinting={} onGround={} pos={} win={}x{} scale={}",
                  new Object[]{
                     mc.field_1724.method_5624(), mc.field_1724.method_24828(), mc.field_1724.method_24515(),
                     mc.method_22683().method_4486(), mc.method_22683().method_4502(), mc.method_22683().method_4495()
                  }
               );
            break;
         case "screen":
            class_310 var52 = mc;
            String var22 = a[1];

            var52.method_1507((class_437)(switch (var22) {
               case "gui" -> guiFactory == null ? null : (class_437)guiFactory.get();
               case "hud" -> hudEditorFactory == null ? null : (class_437)hudEditorFactory.get();
               case "wizard" -> wizardFactory == null ? null : (class_437)wizardFactory.get();
               case "opt" -> new OptimizationScreen(null);
               case "title" -> new class_442();
               case "pause" -> new class_433(true);
               case "accounts" -> new AccountScreen(mc.field_1755);
               case "wheel" -> new com.mrbean.visuals.gui.EmoteWheelScreen(mc.field_1755);
               case "multiplayer" -> new class_500(mc.field_1755);
               case "worlds" -> new class_526(mc.field_1755);
               case "options" -> new class_429(mc.field_1755, mc.field_1690);
               default -> null;
            }));
            break;
         case "key":
            if (mc.field_1755 != null) {
               double x = Double.parseDouble(a[1]);
               double y = Double.parseDouble(a[2]);
               mc.field_1755.method_25402(new class_11909(x, y, new class_11910(0, 0)), false);
               if (mc.field_1755 != null) {
                  mc.field_1755.method_25406(new class_11909(x, y, new class_11910(0, 0)));
               }
            }
            break;
         case "mouse":
            warpMouse(Double.parseDouble(a[1]), Double.parseDouble(a[2]));
            break;
         case "hold":
            if (mc.field_1755 != null) {
               double hx = Double.parseDouble(a[1]);
               double hy = Double.parseDouble(a[2]);
               warpMouse(hx, hy);
               mc.field_1755.method_25402(new class_11909(hx, hy, new class_11910(0, 0)), false);
            }
            break;
         case "drop":
            if (mc.field_1755 != null) {
               double dx = Double.parseDouble(a[1]);
               double dy = Double.parseDouble(a[2]);
               warpMouse(dx, dy);
               mc.field_1755.method_25406(new class_11909(dx, dy, new class_11910(0, 0)));
            }
            break;
         case "type":
            if (mc.field_1755 != null) {
               for (char ch : a[1].toCharArray()) {
                  mc.field_1755.method_25400(new class_11905(ch, 0));
               }
            }
            break;
         case "shot":
            class_318.method_22690(
               mc.field_1697, a[1] + ".png", mc.method_1522(), 1, t -> MrBeanClient.LOG.info("[AutoTest] {}", t.getString())
            );
            break;
         case "quit":
            mc.method_1592();
            break;
         case "attack":
            class_1297 best = null;
            double bd = 1.0E9;

            for (class_1297 e : mc.field_1687.method_18112()) {
               if (e instanceof class_1511 && e.method_5858(mc.field_1724) < bd) {
                  bd = e.method_5858(mc.field_1724);
                  best = e;
               }
            }

            if (best != null) {
               mc.field_1761.method_2918(mc.field_1724, best);
            }

            MrBeanClient.LOG.info("[AutoTest] attack crystal: {}", best != null);
            break;
         case "hit":
            class_1297 bestMob = null;
            double bestDist = 64.0;

            for (class_1297 ex : mc.field_1687.method_18112()) {
               if (ex instanceof class_1308 && ex.method_5858(mc.field_1724) < bestDist) {
                  bestDist = ex.method_5858(mc.field_1724);
                  bestMob = ex;
               }
            }

            if (bestMob != null) {
               mc.field_1761.method_2918(mc.field_1724, bestMob);
               mc.field_1724.method_6104(class_1268.field_5808);
            }

            MrBeanClient.LOG.info("[AutoTest] hit mob: {} target={}", bestMob != null, Info.lastTarget);
            break;
         case "logaim":
            class_239 hr = mc.field_1765;
            String d = hr == null
               ? "null"
               : String.valueOf(hr.method_17783())
                  + (hr instanceof class_3965 b ? " " + b.method_17777() + " " + mc.field_1687.method_8320(b.method_17777()).method_26204() : "");
            long n = 0L;

            for (class_1297 exx : mc.field_1687.method_18112()) {
               if (exx instanceof class_1511) {
                  n++;
               }
            }

            MrBeanClient.LOG
               .info(
                  "[AutoTest] aim={} crystals={} hand={} shockwaves={} hiddenVanilla={} breakBursts={}",
                  new Object[]{
                     d,
                     n,
                     mc.field_1724.method_6047(),
                     CrystalModules.Explosions.bursts,
                     CrystalModules.Explosions.hidden,
                     CrystalModules.BreakParticles.breaks
                  }
               );
            break;
         case "logpops":
            MrBeanClient.LOG.info("[AutoTest] pops self={}", Info.pops(mc.field_1724));
            break;
         case "chat":
            mc.method_1562().method_45729(String.join(" ", Arrays.copyOfRange(a, 1, a.length)));
            break;
         case "logset":
            Module mxxxxx = Modules.get(a[1]);
            Setting sx = mxxxxx == null ? null : mxxxxx.setting(a[2]);
            MrBeanClient.LOG
               .info("[AutoTest] {}.{} = {} (enabled={})", new Object[]{a[1], a[2], sx == null ? "?" : sx.save(), mxxxxx != null && mxxxxx.isEnabled()});
            break;
         case "page":
            ClickGuiScreen.testPage(a[1]);
            break;
         case "expand":
            ClickGuiScreen.testExpand(a[1]);
            break;
         case "bind":
            Module mx = Modules.get(a[1]);
            if (mx != null) {
               mx.bind = Integer.parseInt(a[2]);
            }
            break;
         case "press":
            Module m = Modules.get(a[1]);
            if (m instanceof UtilityModules.ClipPearl cp) {
               cp.throwPearl();
            } else if (m != null) {
               m.onBindPress();
            }
            break;
         case "slot":
            mc.field_1724.method_31548().method_61496(Integer.parseInt(a[1]));
            break;
         case "loginv":
            class_1661 inv = mc.field_1724.method_31548();
            int pearls = 0;

            for (int i = 0; i < inv.method_5439(); i++) {
               if (inv.method_5438(i).method_31574(class_1802.field_8634)) {
                  pearls += inv.method_5438(i).method_7947();
               }
            }

            MrBeanClient.LOG
               .info(
                  "[AutoTest] inv selected={} pearls={} pearlCooldown={} offhand={} main={}",
                  new Object[]{
                     inv.method_67532(),
                     pearls,
                     mc.field_1724.method_7357().method_7904(new class_1799(class_1802.field_8634)),
                     mc.field_1724.method_6079(),
                     inv.method_7391()
                  }
               );
            break;
         case "logmods_on":
            StringBuilder b = new StringBuilder();

            for (Module mxxxx : Modules.all()) {
               if (mxxxx.isEnabled()) {
                  b.append(mxxxx.id).append(' ');
               }
            }

            MrBeanClient.LOG.info("[AutoTest] enabled: {}", b);
            break;
         case "useblock":
            mc.field_1761
               .method_2896(
                  mc.field_1724,
                  class_1268.field_5808,
                  new class_3965(
                     class_243.method_24953(new class_2338(Integer.parseInt(a[1]), Integer.parseInt(a[2]), Integer.parseInt(a[3]))),
                     class_2350.field_11036,
                     new class_2338(Integer.parseInt(a[1]), Integer.parseInt(a[2]), Integer.parseInt(a[3])),
                     false
                  )
               );
            break;
         case "duel":
            if (Modules.get("auto_duel") instanceof AutoDuel ad) {
               ad.challenge(a[1]);
            }
            break;
         case "logcursor":
            MrBeanClient.LOG
               .info(
                  "[AutoTest] screen={} cursor={}",
                  mc.field_1755 == null ? "none" : mc.field_1755.getClass().getSimpleName(),
                  mc.field_1724.field_7512.method_34255()
               );
            break;
         case "jumpup":
            mc.field_1724.method_18800(0.0, 0.6, 0.0);
            break;
         case "logcrit":
            MrBeanClient.LOG
               .info(
                  "[AutoTest] critNow={} fall={} ground={} vy={} cd={}",
                  new Object[]{
                     UtilityModules.PvpHelper.critNow(),
                     mc.field_1724.field_6017,
                     mc.field_1724.method_24828(),
                     mc.field_1724.method_18798().field_1351,
                     mc.field_1724.method_7261(0.5F)
                  }
               );
            break;
         case "wheel":
            if (mc.field_1755 != null) {
               mc.field_1755.method_25401(640.0, 360.0, 0.0, Double.parseDouble(a[1]));
            }
            break;
         case "keyin":
            if (mc.field_1755 != null) {
               mc.field_1755.method_25404(new class_11908(Integer.parseInt(a[1]), 0, 0));
            }
            break;
         case "swing":
            mc.field_1724.method_6104(class_1268.field_5808);
            break;
         case "logswing":
            MrBeanClient.LOG.info("[AutoTest] swing applied={} swinging={}", FxModules.SwordAnimation.applied, mc.field_1724.field_6252);
            break;
         case "clearchat":
            mc.field_1705.method_1743().method_1808(false);
            mc.method_1566().method_2000();
            mc.field_1690.method_42539().method_41748(class_1659.field_7536);
            break;
         case "logscreen":
            MrBeanClient.LOG.info("[AutoTest] screen={}", mc.field_1755 == null ? "none" : mc.field_1755.getClass().getSimpleName());
            break;
         case "friend":
            Friends.add(a[1]);
            break;
         case "category":
            MenuScreen.testCategory(a[1]);
            break;
         case "logopt":
            for (OptMods.Entry exx : OptMods.entries) {
               MrBeanClient.LOG.info("[AutoTest] opt {} {} {} {}", new Object[]{exx.name, exx.state, exx.versionNumber, exx.note});
            }

            MrBeanClient.LOG.info("[AutoTest] opt status: {}", OptMods.status);
            break;
         case "logmods":
            FabricLoader.getInstance().getAllMods().forEach(mod -> {
               String id = mod.getMetadata().getId();
               if (!id.startsWith("fabric-") && !id.equals("java")) {
                  MrBeanClient.LOG.info("[AutoTest] mod {} {}", id, mod.getMetadata().getVersion().getFriendlyString());
               }
            });
            break;
         default:
            MrBeanClient.LOG.warn("[AutoTest] неизвестная команда {}", a[0]);
      }
   }
}
