using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MrBeanLauncher.Ui;

public class XSlider : XControl
{
	public int Min = 1;

	public int Max = 10;

	public int Value = 4;

	public Func<int, string> Format = (int v) => v.ToString();

	private bool drag;

	public event EventHandler Changed;

	public XSlider()
	{
		Height = Theme.S(40f);
	}

	private void SetFromMouse(int mx)
	{
		float num = Theme.Sf(10f);
		float val = ((float)mx - num) / Math.Max(1f, (float)Width - num * 2f);
		int num2 = (int)Math.Round((float)Min + (float)(Max - Min) * Math.Max(0f, Math.Min(1f, val)));
		if (num2 != Value)
		{
			Value = num2;
			Changed?.Invoke(this, EventArgs.Empty);
			Invalidate();
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		drag = true;
		SetFromMouse(e.X);
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		if (drag)
		{
			SetFromMouse(e.X);
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		drag = false;
	}

	protected override void Draw(Graphics g)
	{
		float num = Theme.Sf(10f);
		float num2 = (float)Height - Theme.Sf(12f);
		float num3 = (float)Width - num * 2f;
		float num4 = ((Max == Min) ? 0f : ((float)(Value - Min) / (float)(Max - Min)));
		RectangleF rectangleF = new RectangleF(num, num2 - Theme.Sf(3f), num3, Theme.Sf(6f));
		Theme.FillRound(g, Color.FromArgb(40, 44, 58), rectangleF, Theme.Sf(3f));
		RectangleF r = rectangleF;
		r.Width = Math.Max(Theme.Sf(6f), num3 * num4);
		using (LinearGradientBrush b = new LinearGradientBrush(rectangleF, Theme.Green, Theme.Yellow, 0f))
		{
			Theme.FillRound(g, b, r, Theme.Sf(3f));
		}
		int num5 = Max - Min;
		if (num5 <= 32)
		{
			using SolidBrush brush = new SolidBrush(Color.FromArgb(60, 255, 255, 255));
			for (int i = 0; i <= num5; i++)
			{
				g.FillEllipse(brush, num + num3 * (float)i / (float)num5 - Theme.Sf(1f), num2 + Theme.Sf(6f), Theme.Sf(2f), Theme.Sf(2f));
			}
		}
		float num6 = num + num3 * num4;
		float num7 = Theme.Sf(8f + 2f * HoverT);
		using (SolidBrush brush2 = new SolidBrush(Theme.A(Theme.Green, (int)(60f * HoverT))))
		{
			g.FillEllipse(brush2, num6 - num7 - Theme.Sf(4f), num2 - num7 - Theme.Sf(4f), (num7 + Theme.Sf(4f)) * 2f, (num7 + Theme.Sf(4f)) * 2f);
		}
		using (SolidBrush brush3 = new SolidBrush(Color.White))
		{
			g.FillEllipse(brush3, num6 - num7, num2 - num7, num7 * 2f, num7 * 2f);
		}
		using Font font = Theme.Bold(12f);
		string s = Format(Value);
		SizeF sizeF = g.MeasureString(s, font);
		RectangleF r2 = new RectangleF(Math.Max(0f, Math.Min((float)Width - sizeF.Width - Theme.Sf(12f), num6 - sizeF.Width / 2f - Theme.Sf(6f))), 0f, sizeF.Width + Theme.Sf(12f), Theme.Sf(20f));
		Theme.FillRound(g, Theme.CardHover, r2, Theme.Sf(6f));
		Theme.Text(g, s, font, Theme.Fg, r2, StringAlignment.Center);
	}
}
