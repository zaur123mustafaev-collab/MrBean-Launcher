using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("MrBean")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCopyright("MrBean 2026")]
[assembly: AssemblyDescription("MrBean Launcher — Minecraft 1.21.11 + MrBean Visuals")]
[assembly: AssemblyFileVersion("2.1.0.0")]
[assembly: AssemblyInformationalVersion("2.1.0")]
[assembly: AssemblyProduct("MrBean Launcher")]
[assembly: AssemblyTitle("MrBeanLauncher")]
[assembly: AssemblyVersion("2.1.0.0")]
