using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace MrBeanLauncher.Ui;

public class XToggle : XControl
{
	private bool on;

	private float t;

	public bool Checked
	{
		get
		{
			return on;
		}
		set
		{
			if (on != value)
			{
				on = value;
				Invalidate();
			}
		}
	}

	public event EventHandler Changed;

	public XToggle()
	{
		Size = new Size(Theme.S(44f), Theme.S(24f));
	}

	protected override void OnClick(EventArgs e)
	{
		on = !on;
		Changed?.Invoke(this, e);
		base.OnClick(e);
	}

	public override void Step()
	{
		base.Step();
		float num = (on ? 1 : 0);
		float num2 = t + (num - t) * 0.25f;
		if (Math.Abs(num2 - num) < 0.01f)
		{
			num2 = num;
		}
		if (num2 != t)
		{
			t = num2;
			Invalidate();
		}
	}

	protected override void Draw(Graphics g)
	{
		RectangleF rectangleF = new RectangleF(0.5f, 0.5f, (float)Width - 1.5f, (float)Height - 1.5f);
		float rad = rectangleF.Height / 2f;
		Theme.FillRound(g, Theme.Lerp(Color.FromArgb(46, 50, 66), Theme.Green, t), rectangleF, rad);
		if (t > 0.01f)
		{
			using LinearGradientBrush b = new LinearGradientBrush(rectangleF, Theme.A(Theme.Green, (int)(255f * t)), Theme.A(Theme.Yellow, (int)(255f * t)), 0f);
			Theme.FillRound(g, b, rectangleF, rad);
		}
		float num = rectangleF.Height - Theme.Sf(6f);
		float num2 = rectangleF.X + Theme.Sf(3f) + (rectangleF.Width - num - Theme.Sf(6f)) * t;
		using (SolidBrush brush = new SolidBrush(Color.FromArgb(40, 0, 0, 0)))
		{
			g.FillEllipse(brush, num2, rectangleF.Y + Theme.Sf(4f), num, num);
		}
		using SolidBrush brush2 = new SolidBrush(Color.White);
		g.FillEllipse(brush2, num2, rectangleF.Y + Theme.Sf(3f), num, num);
	}
}
