using System;

namespace MrBeanLauncher.Core;

public class AuthException : Exception
{
	public readonly bool NeedsRelogin;

	public AuthException(string message, bool needsRelogin = false)
		: base(message)
	{
		NeedsRelogin = needsRelogin;
	}
}
