using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MrBeanLauncher.Core;

public class MicrosoftAuth
{
	public class DeviceCode
	{
		public string UserCode;

		public string VerificationUri;

		public string Message;

		public int ExpiresIn;

		public int Interval;
	}

	public string ClientId;

	public string AuthorizeUrl = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize";

	public string TokenUrl = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";

	public string XblUrl = "https://user.auth.xboxlive.com/user/authenticate";

	public string XstsUrl = "https://xsts.auth.xboxlive.com/xsts/authorize";

	public string McLoginUrl = "https://api.minecraftservices.com/authentication/login_with_xbox";

	public string EntitlementsUrl = "https://api.minecraftservices.com/entitlements/mcstore";

	public string ProfileUrl = "https://api.minecraftservices.com/minecraft/profile";

	public const string Scope = "XboxLive.signin offline_access";

	public Action<string> Status = delegate
	{
	};

	public Action<string> OpenBrowser = (string url) =>
	{
		Process.Start(new ProcessStartInfo(url)
		{
			UseShellExecute = true
		});
	};

	private readonly HttpClient http;

	public string DeviceCodeUrl = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";

	public MicrosoftAuth(string clientId)
	{
		ClientId = clientId;
		try
		{
			ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
		}
		catch
		{
		}
		http = new HttpClient
		{
			Timeout = TimeSpan.FromSeconds(30.0)
		};
		http.DefaultRequestHeaders.UserAgent.ParseAdd("MrBeanLauncher/2.0");
	}

	public static string Base64Url(byte[] b)
	{
		return Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-')
			.Replace('/', '_');
	}

	public static string NewVerifier()
	{
		byte[] array = new byte[48];
		using (RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create())
		{
			randomNumberGenerator.GetBytes(array);
		}
		return Base64Url(array);
	}

	public static string Challenge(string verifier)
	{
		using SHA256 sHA = SHA256.Create();
		return Base64Url(sHA.ComputeHash(Encoding.ASCII.GetBytes(verifier)));
	}

	public async Task<MinecraftSession> LoginInteractive(CancellationToken ct)
	{
		if (string.IsNullOrWhiteSpace(ClientId))
		{
			throw new AuthException("Не указан Client ID приложения Azure (Настройки → Аккаунт).");
		}
		string verifier = NewVerifier();
		string text = Challenge(verifier);
		string state = NewVerifier().Substring(0, 24);
		TcpListener listener = new TcpListener(IPAddress.Loopback, 0);
		listener.Start();
		string redirect = "http://localhost:" + ((IPEndPoint)listener.LocalEndpoint).Port;
		try
		{
			string obj = AuthorizeUrl + "?client_id=" + Uri.EscapeDataString(ClientId) + "&response_type=code&redirect_uri=" + Uri.EscapeDataString(redirect) + "&scope=" + Uri.EscapeDataString("XboxLive.signin offline_access") + "&code_challenge=" + text + "&code_challenge_method=S256&state=" + state + "&prompt=select_account";
			Status("Подключение к Microsoft...");
			OpenBrowser(obj);
			Dictionary<string, string> dictionary = await WaitForRedirect(listener, ct);
			dictionary.TryGetValue("error", out var value);
			if (value != null)
			{
				dictionary.TryGetValue("error_description", out var value2);
				if (value == "access_denied")
				{
					throw new AuthException("Вход отменён.");
				}
				throw new AuthException("Microsoft вернул ошибку: " + value + ((value2 == null) ? "" : (" — " + value2)));
			}
			dictionary.TryGetValue("state", out var value3);
			if (value3 != state)
			{
				throw new AuthException("Ответ не прошёл проверку безопасности (state). Попробуйте снова.");
			}
			dictionary.TryGetValue("code", out var value4);
			if (string.IsNullOrEmpty(value4))
			{
				throw new AuthException("Microsoft не вернул код входа.");
			}
			return await FinishWithMsToken(await PostForm(TokenUrl, new Dictionary<string, string>
			{
				{ "client_id", ClientId },
				{ "scope", "XboxLive.signin offline_access" },
				{ "code", value4 },
				{ "redirect_uri", redirect },
				{ "grant_type", "authorization_code" },
				{ "code_verifier", verifier }
			}, ct), ct);
		}
		finally
		{
			listener.Stop();
		}
	}

	public async Task<MinecraftSession> LoginDeviceCode(Action<DeviceCode> show, CancellationToken ct)
	{
		if (string.IsNullOrWhiteSpace(ClientId))
		{
			throw new AuthException("Не указан Client ID приложения Azure.");
		}
		Status("Подключение к Microsoft...");
		object o = await PostForm(DeviceCodeUrl, new Dictionary<string, string>
		{
			{ "client_id", ClientId },
			{ "scope", "XboxLive.signin offline_access" }
		}, ct);
		string deviceCode = o.Str("device_code");
		DeviceCode deviceCode2 = new DeviceCode
		{
			UserCode = o.Str("user_code"),
			VerificationUri = (o.Str("verification_uri") ?? "https://www.microsoft.com/link"),
			Message = o.Str("message"),
			ExpiresIn = (int)((o.Get("expires_in") != null) ? o.Long("expires_in") : 900),
			Interval = (int)((o.Get("interval") != null) ? o.Long("interval") : 5)
		};
		if (string.IsNullOrEmpty(deviceCode) || string.IsNullOrEmpty(deviceCode2.UserCode))
		{
			throw new AuthException("Microsoft не выдал код входа.");
		}
		show(deviceCode2);
		Status("Ожидание входа на сайте Microsoft...");
		int interval = Math.Max(1, deviceCode2.Interval);
		DateTime deadline = DateTime.UtcNow.AddSeconds(deviceCode2.ExpiresIn);
		while (DateTime.UtcNow < deadline)
		{
			await Task.Delay(TimeSpan.FromSeconds(interval), ct);
			HttpResponseMessage r;
			try
			{
				r = await http.PostAsync(TokenUrl, new FormUrlEncodedContent(new Dictionary<string, string>
				{
					{ "client_id", ClientId },
					{ "grant_type", "urn:ietf:params:oauth:grant-type:device_code" },
					{ "device_code", deviceCode }
				}), ct);
			}
			catch (Exception ex) when (!(ex is OperationCanceledException))
			{
				continue;
			}
			string s = await r.Content.ReadAsStringAsync();
			object obj = null;
			try
			{
				obj = Json.Parse(s);
			}
			catch
			{
			}
			if (r.IsSuccessStatusCode && obj != null)
			{
				return await FinishWithMsToken(obj, ct);
			}
			string text = obj?.Str("error");
			switch (text)
			{
			case "slow_down":
				interval += 5;
				break;
			case "authorization_declined":
				throw new AuthException("Вход отменён на сайте Microsoft.");
			case "expired_token":
			case "code_expired":
				throw new AuthException("Код устарел. Нажмите «Войти» ещё раз.");
			case "invalid_client":
			case "unauthorized_client":
				throw new AuthException("Client ID не подходит: в Azure включите «Разрешить потоки общедоступных клиентов».");
			case "bad_verification_code":
				throw new AuthException("Неверный код. Нажмите «Войти» ещё раз.");
			default:
				throw new AuthException("Microsoft отклонил вход: " + (text ?? ((int)r.StatusCode).ToString()));
			case "authorization_pending":
				break;
			}
		}
		throw new AuthException("Код устарел (15 минут). Нажмите «Войти» ещё раз.");
	}

	private async Task<Dictionary<string, string>> WaitForRedirect(TcpListener listener, CancellationToken ct)
	{
		Task timeout = Task.Delay(TimeSpan.FromMinutes(5.0), ct);
		while (true)
		{
			Task<TcpClient> accept = listener.AcceptTcpClientAsync();
			if (await Task.WhenAny(accept, timeout) == timeout)
			{
				break;
			}
			using TcpClient client = accept.Result;
			using (NetworkStream stream = client.GetStream())
			{
				stream.ReadTimeout = 5000;
				byte[] buf = new byte[8192];
				int count = await stream.ReadAsync(buf, 0, buf.Length, ct);
				string[] array = Encoding.ASCII.GetString(buf, 0, count).Split('\n')[0].Split(' ');
				if (array.Length < 2 || !array[0].StartsWith("GET"))
				{
					goto end_IL_0115;
				}
				string text = array[1];
				if (text.StartsWith("/favicon"))
				{
					await Respond(stream, 404, "");
					goto end_IL_0115;
				}
				Dictionary<string, string> q = ParseQuery(text);
				bool ok = q.ContainsKey("code");
				await Respond(stream, 200, Page(ok));
				if (q.ContainsKey("code") || q.ContainsKey("error"))
				{
					return q;
				}
				goto end_IL_00ef;
				end_IL_0115:;
			}
			end_IL_00ef:;
		}
		ct.ThrowIfCancellationRequested();
		throw new AuthException("Время ожидания входа истекло (5 минут).");
	}

	private static string Page(bool ok)
	{
		string text = (ok ? "Вход выполнен" : "Вход не выполнен");
		string text2 = (ok ? "Можно закрыть эту вкладку и вернуться в MrBean Launcher." : "Вернитесь в MrBean Launcher и попробуйте снова.");
		string text3 = (ok ? "#2EE59D" : "#FF5A64");
		return "<!doctype html><html><head><meta charset='utf-8'><title>MrBean Launcher</title><style>body{background:#0f1117;color:#eef;font-family:Segoe UI,sans-serif;display:flex;height:100vh;align-items:center;justify-content:center;margin:0}div{background:#181b25;padding:40px 56px;border-radius:18px;text-align:center;border:1px solid #2a2e3c}h1{color:" + text3 + ";margin:0 0 10px}</style></head><body><div><h1>" + text + "</h1><p>" + text2 + "</p></div></body></html>";
	}

	private static async Task Respond(Stream s, int code, string html)
	{
		byte[] body = Encoding.UTF8.GetBytes(html);
		byte[] bytes = Encoding.ASCII.GetBytes("HTTP/1.1 " + code + ((code == 200) ? " OK" : " Not Found") + "\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + body.Length + "\r\nConnection: close\r\n\r\n");
		await s.WriteAsync(bytes, 0, bytes.Length);
		await s.WriteAsync(body, 0, body.Length);
		await s.FlushAsync();
	}

	public static Dictionary<string, string> ParseQuery(string path)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		int num = path.IndexOf('?');
		if (num < 0)
		{
			return dictionary;
		}
		string[] array = path.Substring(num + 1).Split('&');
		for (int i = 0; i < array.Length; i++)
		{
			string[] array2 = array[i].Split(new char[1] { '=' }, 2);
			if (array2.Length == 2)
			{
				dictionary[Uri.UnescapeDataString(array2[0])] = Uri.UnescapeDataString(array2[1].Replace('+', ' '));
			}
		}
		return dictionary;
	}

	public async Task<MinecraftSession> Refresh(string refreshToken, CancellationToken ct)
	{
		if (string.IsNullOrWhiteSpace(ClientId))
		{
			throw new AuthException("Не указан Client ID приложения Azure.", needsRelogin: true);
		}
		Status("Обновление входа...");
		object tok;
		try
		{
			tok = await PostForm(TokenUrl, new Dictionary<string, string>
			{
				{ "client_id", ClientId },
				{ "scope", "XboxLive.signin offline_access" },
				{ "refresh_token", refreshToken },
				{ "grant_type", "refresh_token" }
			}, ct);
		}
		catch (AuthException ex)
		{
			throw new AuthException("Сессия Microsoft истекла. Войдите снова. (" + ex.Message + ")", needsRelogin: true);
		}
		return await FinishWithMsToken(tok, ct);
	}

	private async Task<MinecraftSession> FinishWithMsToken(object tok, CancellationToken ct)
	{
		string text = tok.Str("access_token");
		string refresh = tok.Str("refresh_token");
		if (string.IsNullOrEmpty(text))
		{
			throw new AuthException("Microsoft не выдал токен доступа.", needsRelogin: true);
		}
		Status("Вход в Xbox Live...");
		object o = await PostJson(XblUrl, new Dictionary<string, object>
		{
			{
				"Properties",
				new Dictionary<string, object>
				{
					{ "AuthMethod", "RPS" },
					{ "SiteName", "user.auth.xboxlive.com" },
					{
						"RpsTicket",
						"d=" + text
					}
				}
			},
			{ "RelyingParty", "http://auth.xboxlive.com" },
			{ "TokenType", "JWT" }
		}, null, ct, XboxError);
		string item = o.Str("Token");
		string uhs = (from x in o.Obj("DisplayClaims").Arr("xui")
			select x.Str("uhs")).FirstOrDefault();
		object o2 = await PostJson(XstsUrl, new Dictionary<string, object>
		{
			{
				"Properties",
				new Dictionary<string, object>
				{
					{ "SandboxId", "RETAIL" },
					{
						"UserTokens",
						new List<object> { item }
					}
				}
			},
			{ "RelyingParty", "rp://api.minecraftservices.com/" },
			{ "TokenType", "JWT" }
		}, null, ct, XboxError);
		string text2 = o2.Str("Token");
		string text3 = (from x in o2.Obj("DisplayClaims").Arr("xui")
			select x.Str("uhs")).FirstOrDefault() ?? uhs;
		Status("Проверка лицензии Minecraft...");
		object o3 = await PostJson(McLoginUrl, new Dictionary<string, object> { 
		{
			"identityToken",
			"XBL3.0 x=" + text3 + ";" + text2
		} }, null, ct, McError);
		string mcToken = o3.Str("access_token");
		long expires = o3.Long("expires_in");
		if (string.IsNullOrEmpty(mcToken))
		{
			throw new AuthException("Сервер Minecraft не выдал токен.");
		}
		bool owns = (await GetJson(EntitlementsUrl, mcToken, ct, McError)).Arr("items").Any((object i) =>
		{
			string text5 = i.Str("name");
			return text5 == "product_minecraft" || text5 == "game_minecraft";
		});
		Status("Загрузка профиля...");
		object o4;
		try
		{
			o4 = await GetJson(ProfileUrl, mcToken, ct, McError);
		}
		catch (AuthException) when (!owns)
		{
			throw new AuthException("На этом аккаунте нет лицензии Minecraft: Java Edition.");
		}
		string text4 = o4.Str("id");
		string name = o4.Str("name");
		if (string.IsNullOrEmpty(text4))
		{
			throw new AuthException(owns ? "У аккаунта ещё нет профиля Minecraft. Создайте его на minecraft.net." : "На этом аккаунте нет лицензии Minecraft: Java Edition.");
		}
		string skinUrl = (from s in o4.Arr("skins")
			where s.Str("state") == "ACTIVE"
			select s.Str("url")).FirstOrDefault();
		Status("Авторизация успешна!");
		return new MinecraftSession
		{
			Uuid = text4,
			Name = name,
			AccessToken = mcToken,
			Xuid = "0",
			SkinUrl = skinUrl,
			ExpiresUtc = DateTime.UtcNow.AddSeconds(Math.Max(60L, expires - 60)),
			RefreshToken = refresh
		};
	}

	private static string XboxError(int status, string body)
	{
		try
		{
			switch (Json.Parse(body).Long("XErr"))
			{
			case 2148916233L:
				return "У этого аккаунта Microsoft нет профиля Xbox. Зайдите на xbox.com и создайте его.";
			case 2148916235L:
				return "Xbox Live недоступен в вашей стране.";
			case 2148916236L:
			case 2148916237L:
				return "Аккаунт требует подтверждения взрослого (Южная Корея).";
			case 2148916238L:
				return "Это детский аккаунт — его нужно добавить в семью Microsoft взрослым.";
			}
		}
		catch
		{
		}
		return "Xbox Live отклонил вход (код " + status + ").";
	}

	private static string McError(int status, string body)
	{
		if (status == 403 && body.IndexOf("Invalid app registration", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return "Mojang ещё не одобрил это приложение (Client ID). Нужно отправить заявку: aka.ms/mce-reviewappid";
		}
		return status switch
		{
			404 => "Профиль Minecraft не найден — на аккаунте нет лицензии Java Edition.", 
			429 => "Слишком много попыток входа. Подождите пару минут.", 
			401 => "Сервер Minecraft не принял вход. Попробуйте снова.", 
			_ => "Сервер Minecraft вернул ошибку " + status + ".", 
		};
	}

	private async Task<object> PostForm(string url, Dictionary<string, string> form, CancellationToken ct)
	{
		HttpResponseMessage r;
		try
		{
			r = await http.PostAsync(url, new FormUrlEncodedContent(form), ct);
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			throw new AuthException("Нет связи с Microsoft: " + ex.Message);
		}
		string s = await r.Content.ReadAsStringAsync();
		object obj = null;
		try
		{
			obj = Json.Parse(s);
		}
		catch
		{
		}
		if (!r.IsSuccessStatusCode)
		{
			string text = obj?.Str("error");
			switch (text)
			{
			case "invalid_grant":
				throw new AuthException("Сессия Microsoft истекла или отозвана. Войдите снова.", needsRelogin: true);
			case "invalid_client":
			case "unauthorized_client":
				throw new AuthException("Client ID не подходит для входа (проверьте регистрацию приложения в Azure).");
			default:
				throw new AuthException("Microsoft отклонил вход: " + (text ?? ((int)r.StatusCode).ToString()));
			}
		}
		return obj;
	}

	private async Task<object> PostJson(string url, object payload, string bearer, CancellationToken ct, Func<int, string, string> errorText)
	{
		HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, url)
		{
			Content = new StringContent(Json.Write(payload), Encoding.UTF8, "application/json")
		};
		httpRequestMessage.Headers.Accept.ParseAdd("application/json");
		if (bearer != null)
		{
			httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
		}
		return await Send(httpRequestMessage, ct, errorText);
	}

	private async Task<object> GetJson(string url, string bearer, CancellationToken ct, Func<int, string, string> errorText)
	{
		HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, url);
		httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
		return await Send(httpRequestMessage, ct, errorText);
	}

	private async Task<object> Send(HttpRequestMessage req, CancellationToken ct, Func<int, string, string> errorText)
	{
		HttpResponseMessage r;
		try
		{
			r = await http.SendAsync(req, ct);
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			throw new AuthException("Нет связи с сервером: " + ex.Message);
		}
		string text = await r.Content.ReadAsStringAsync();
		if (!r.IsSuccessStatusCode)
		{
			throw new AuthException(errorText((int)r.StatusCode, text));
		}
		try
		{
			return Json.Parse(text);
		}
		catch
		{
			throw new AuthException("Сервер вернул непонятный ответ.");
		}
	}

	public async Task<byte[]> Download(string url, CancellationToken ct)
	{
		return await http.GetByteArrayAsync(url);
	}
}
